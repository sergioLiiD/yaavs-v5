-- Verificar el ticket
SELECT * FROM "tickets" WHERE id = 3;

-- Verificar la reparación
SELECT * FROM "Reparacion" WHERE "ticketId" = 3; 