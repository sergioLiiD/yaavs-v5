export default function CostosLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return children;
} 