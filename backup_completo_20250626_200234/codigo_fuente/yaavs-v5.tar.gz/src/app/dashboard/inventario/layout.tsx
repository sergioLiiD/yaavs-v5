export default function InventarioLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return children;
} 