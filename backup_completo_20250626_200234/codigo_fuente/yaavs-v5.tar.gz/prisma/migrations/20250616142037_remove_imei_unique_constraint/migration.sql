-- DropIndex
DROP INDEX "tickets_imei_key";
