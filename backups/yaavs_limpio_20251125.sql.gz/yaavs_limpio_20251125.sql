SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;
CREATE TYPE public."MetodoPago" AS ENUM (
    'EFECTIVO',
    'TRANSFERENCIA',
    'TARJETA'
);
ALTER TYPE public."MetodoPago" OWNER TO postgres;
CREATE TYPE public."NivelUsuarioPunto" AS ENUM (
    'ADMIN',
    'OPERADOR'
);
ALTER TYPE public."NivelUsuarioPunto" OWNER TO postgres;
CREATE TYPE public."TipoCupon" AS ENUM (
    'GENERAL',
    'PERSONALIZADO'
);
ALTER TYPE public."TipoCupon" OWNER TO postgres;
CREATE TYPE public."TipoDescuento" AS ENUM (
    'PORCENTAJE',
    'MONTO_FIJO'
);
ALTER TYPE public."TipoDescuento" OWNER TO postgres;
CREATE TYPE public."TipoEntrega" AS ENUM (
    'DOMICILIO',
    'PUNTO_RECOLECCION'
);
ALTER TYPE public."TipoEntrega" OWNER TO postgres;
CREATE TYPE public."TipoProducto" AS ENUM (
    'PRODUCTO',
    'SERVICIO'
);
ALTER TYPE public."TipoProducto" OWNER TO postgres;
CREATE TYPE public."TipoProveedor" AS ENUM (
    'FISICA',
    'MORAL',
    'DISTRIBUIDOR',
    'FABRICANTE'
);
ALTER TYPE public."TipoProveedor" OWNER TO postgres;
CREATE TYPE public."TipoSalida" AS ENUM (
    'VENTA',
    'REPARACION',
    'PERDIDA',
    'AJUSTE'
);
ALTER TYPE public."TipoSalida" OWNER TO postgres;
SET default_tablespace = '';
SET default_table_access_method = heap;
CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);
ALTER TABLE public._prisma_migrations OWNER TO postgres;
CREATE TABLE public.categorias (
    id integer NOT NULL,
    nombre text NOT NULL,
    descripcion text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);
ALTER TABLE public.categorias OWNER TO postgres;
CREATE SEQUENCE public.categorias_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;
ALTER TABLE public.categorias_id_seq OWNER TO postgres;
ALTER SEQUENCE public.categorias_id_seq OWNED BY public.categorias.id;
CREATE TABLE public.checklist_diagnostico (
    id integer NOT NULL,
    reparacion_id integer NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);
ALTER TABLE public.checklist_diagnostico OWNER TO postgres;
CREATE SEQUENCE public.checklist_diagnostico_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;
ALTER TABLE public.checklist_diagnostico_id_seq OWNER TO postgres;
ALTER SEQUENCE public.checklist_diagnostico_id_seq OWNED BY public.checklist_diagnostico.id;
CREATE TABLE public.checklist_items (
    id integer NOT NULL,
    descripcion text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    nombre text NOT NULL,
    para_diagnostico boolean DEFAULT false NOT NULL,
    para_reparacion boolean DEFAULT false NOT NULL
);
ALTER TABLE public.checklist_items OWNER TO postgres;
CREATE SEQUENCE public.checklist_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;
ALTER TABLE public.checklist_items_id_seq OWNER TO postgres;
ALTER SEQUENCE public.checklist_items_id_seq OWNED BY public.checklist_items.id;
CREATE TABLE public.checklist_reparacion (
    id integer NOT NULL,
    reparacion_id integer NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);
ALTER TABLE public.checklist_reparacion OWNER TO postgres;
CREATE SEQUENCE public.checklist_reparacion_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;
ALTER TABLE public.checklist_reparacion_id_seq OWNER TO postgres;
ALTER SEQUENCE public.checklist_reparacion_id_seq OWNED BY public.checklist_reparacion.id;
CREATE TABLE public.checklist_respuesta_diagnostico (
    id integer NOT NULL,
    checklist_diagnostico_id integer NOT NULL,
    checklist_item_id integer NOT NULL,
    respuesta boolean NOT NULL,
    observaciones text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);
ALTER TABLE public.checklist_respuesta_diagnostico OWNER TO postgres;
CREATE SEQUENCE public.checklist_respuesta_diagnostico_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;
ALTER TABLE public.checklist_respuesta_diagnostico_id_seq OWNER TO postgres;
ALTER SEQUENCE public.checklist_respuesta_diagnostico_id_seq OWNED BY public.checklist_respuesta_diagnostico.id;
CREATE TABLE public.checklist_respuesta_reparacion (
    id integer NOT NULL,
    checklist_reparacion_id integer NOT NULL,
    checklist_item_id integer NOT NULL,
    respuesta boolean NOT NULL,
    observaciones text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);
ALTER TABLE public.checklist_respuesta_reparacion OWNER TO postgres;
CREATE SEQUENCE public.checklist_respuesta_reparacion_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;
ALTER TABLE public.checklist_respuesta_reparacion_id_seq OWNER TO postgres;
ALTER SEQUENCE public.checklist_respuesta_reparacion_id_seq OWNED BY public.checklist_respuesta_reparacion.id;
CREATE TABLE public.clientes (
    id integer NOT NULL,
    nombre text NOT NULL,
    apellido_paterno text NOT NULL,
    apellido_materno text,
    telefono_celular text NOT NULL,
    telefono_contacto text,
    email text NOT NULL,
    calle text,
    numero_exterior text,
    numero_interior text,
    colonia text,
    ciudad text,
    estado text,
    codigo_postal text,
    latitud double precision,
    longitud double precision,
    fuente_referencia text,
    rfc text,
    password_hash text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    creado_por_id integer,
    tipo_registro text,
    punto_recoleccion_id integer
);
ALTER TABLE public.clientes OWNER TO postgres;
CREATE SEQUENCE public.clientes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;
ALTER TABLE public.clientes_id_seq OWNER TO postgres;
ALTER SEQUENCE public.clientes_id_seq OWNED BY public.clientes.id;
CREATE TABLE public.conceptos_presupuesto (
    id integer NOT NULL,
    presupuesto_id integer NOT NULL,
    descripcion text NOT NULL,
    cantidad integer NOT NULL,
    precio_unitario double precision NOT NULL,
    total double precision NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);
ALTER TABLE public.conceptos_presupuesto OWNER TO postgres;
CREATE SEQUENCE public.conceptos_presupuesto_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;
ALTER TABLE public.conceptos_presupuesto_id_seq OWNER TO postgres;
ALTER SEQUENCE public.conceptos_presupuesto_id_seq OWNED BY public.conceptos_presupuesto.id;
CREATE TABLE public.cupones (
    id integer NOT NULL,
    codigo text NOT NULL,
    nombre text NOT NULL,
    descripcion text,
    tipo public."TipoCupon" NOT NULL,
    tipo_descuento public."TipoDescuento" NOT NULL,
    valor_descuento double precision NOT NULL,
    monto_minimo double precision DEFAULT 0,
    fecha_inicio timestamp(3) without time zone NOT NULL,
    fecha_expiracion timestamp(3) without time zone NOT NULL,
    limite_usos integer,
    usos_actuales integer DEFAULT 0 NOT NULL,
    activo boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);
ALTER TABLE public.cupones OWNER TO postgres;
CREATE SEQUENCE public.cupones_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;
ALTER TABLE public.cupones_id_seq OWNER TO postgres;
ALTER SEQUENCE public.cupones_id_seq OWNED BY public.cupones.id;
CREATE TABLE public.detalle_ventas (
    id integer NOT NULL,
    venta_id integer NOT NULL,
    producto_id integer NOT NULL,
    cantidad integer NOT NULL,
    precio_unitario double precision NOT NULL,
    subtotal double precision NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);
ALTER TABLE public.detalle_ventas OWNER TO postgres;
CREATE SEQUENCE public.detalle_ventas_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;
ALTER TABLE public.detalle_ventas_id_seq OWNER TO postgres;
ALTER SEQUENCE public.detalle_ventas_id_seq OWNED BY public.detalle_ventas.id;
CREATE TABLE public.direcciones (
    id integer NOT NULL,
    cliente_id integer NOT NULL,
    calle text NOT NULL,
    numero_exterior text NOT NULL,
    numero_interior text,
    colonia text NOT NULL,
    ciudad text NOT NULL,
    estado text NOT NULL,
    codigo_postal text NOT NULL,
    latitud double precision,
    longitud double precision,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);
ALTER TABLE public.direcciones OWNER TO postgres;
CREATE SEQUENCE public.direcciones_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;
ALTER TABLE public.direcciones_id_seq OWNER TO postgres;
ALTER SEQUENCE public.direcciones_id_seq OWNED BY public.direcciones.id;
CREATE TABLE public.dispositivos (
    id integer NOT NULL,
    ticket_id integer NOT NULL,
    tipo text NOT NULL,
    marca text NOT NULL,
    modelo text NOT NULL,
    serie text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);
ALTER TABLE public.dispositivos OWNER TO postgres;
CREATE SEQUENCE public.dispositivos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;
ALTER TABLE public.dispositivos_id_seq OWNER TO postgres;
ALTER SEQUENCE public.dispositivos_id_seq OWNED BY public.dispositivos.id;
CREATE TABLE public.entradas_almacen (
    id integer NOT NULL,
    producto_id integer NOT NULL,
    cantidad integer NOT NULL,
    precio_compra double precision NOT NULL,
    notas text,
    fecha timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    usuario_id integer NOT NULL,
    proveedor_id integer,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);
ALTER TABLE public.entradas_almacen OWNER TO postgres;
CREATE SEQUENCE public.entradas_almacen_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;
ALTER TABLE public.entradas_almacen_id_seq OWNER TO postgres;
ALTER SEQUENCE public.entradas_almacen_id_seq OWNED BY public.entradas_almacen.id;
CREATE TABLE public.entregas (
    id integer NOT NULL,
    ticket_id integer NOT NULL,
    tipo public."TipoEntrega" NOT NULL,
    direccion text,
    notas text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);
ALTER TABLE public.entregas OWNER TO postgres;
CREATE SEQUENCE public.entregas_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;
ALTER TABLE public.entregas_id_seq OWNER TO postgres;
ALTER SEQUENCE public.entregas_id_seq OWNED BY public.entregas.id;
CREATE TABLE public.estatus_reparacion (
    id integer NOT NULL,
    nombre text NOT NULL,
    descripcion text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    activo boolean,
    color text,
    orden integer NOT NULL
);
ALTER TABLE public.estatus_reparacion OWNER TO postgres;
CREATE SEQUENCE public.estatus_reparacion_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;
ALTER TABLE public.estatus_reparacion_id_seq OWNER TO postgres;
ALTER SEQUENCE public.estatus_reparacion_id_seq OWNED BY public.estatus_reparacion.id;
CREATE TABLE public.fotos_producto (
    id integer NOT NULL,
    producto_id integer NOT NULL,
    url text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);
ALTER TABLE public.fotos_producto OWNER TO postgres;
CREATE SEQUENCE public.fotos_producto_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;
ALTER TABLE public.fotos_producto_id_seq OWNER TO postgres;
ALTER SEQUENCE public.fotos_producto_id_seq OWNED BY public.fotos_producto.id;
CREATE TABLE public.marcas (
    id integer NOT NULL,
    nombre text NOT NULL,
    descripcion text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);
ALTER TABLE public.marcas OWNER TO postgres;
CREATE SEQUENCE public.marcas_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;
ALTER TABLE public.marcas_id_seq OWNER TO postgres;
ALTER SEQUENCE public.marcas_id_seq OWNED BY public.marcas.id;
CREATE TABLE public.modelos (
    id integer NOT NULL,
    nombre text NOT NULL,
    marca_id integer NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    descripcion text
);
ALTER TABLE public.modelos OWNER TO postgres;
CREATE SEQUENCE public.modelos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;
ALTER TABLE public.modelos_id_seq OWNER TO postgres;
ALTER SEQUENCE public.modelos_id_seq OWNED BY public.modelos.id;
CREATE TABLE public.pagos (
    id integer NOT NULL,
    ticket_id integer NOT NULL,
    monto double precision NOT NULL,
    metodo public."MetodoPago" NOT NULL,
    referencia text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);
ALTER TABLE public.pagos OWNER TO postgres;
CREATE SEQUENCE public.pagos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;
ALTER TABLE public.pagos_id_seq OWNER TO postgres;
ALTER SEQUENCE public.pagos_id_seq OWNED BY public.pagos.id;
CREATE TABLE public.pasos_reparacion_frecuente (
    id integer NOT NULL,
    reparacion_frecuente_id integer NOT NULL,
    descripcion text NOT NULL,
    orden integer NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);
ALTER TABLE public.pasos_reparacion_frecuente OWNER TO postgres;
CREATE SEQUENCE public.pasos_reparacion_frecuente_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;
ALTER TABLE public.pasos_reparacion_frecuente_id_seq OWNER TO postgres;
ALTER SEQUENCE public.pasos_reparacion_frecuente_id_seq OWNED BY public.pasos_reparacion_frecuente.id;
CREATE TABLE public.permisos (
    id integer NOT NULL,
    codigo text NOT NULL,
    nombre text NOT NULL,
    descripcion text,
    categoria text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);
ALTER TABLE public.permisos OWNER TO postgres;
CREATE SEQUENCE public.permisos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;
ALTER TABLE public.permisos_id_seq OWNER TO postgres;
ALTER SEQUENCE public.permisos_id_seq OWNED BY public.permisos.id;
CREATE TABLE public.piezas (
    id integer NOT NULL,
    nombre text NOT NULL,
    marca_id integer NOT NULL,
    modelo_id integer NOT NULL,
    stock integer DEFAULT 0 NOT NULL,
    precio double precision NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);
ALTER TABLE public.piezas OWNER TO postgres;
CREATE SEQUENCE public.piezas_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;
ALTER TABLE public.piezas_id_seq OWNER TO postgres;
ALTER SEQUENCE public.piezas_id_seq OWNED BY public.piezas.id;
CREATE TABLE public.piezas_reparacion (
    id integer NOT NULL,
    reparacion_id integer NOT NULL,
    pieza_id integer NOT NULL,
    cantidad integer NOT NULL,
    precio double precision NOT NULL,
    total double precision NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);
ALTER TABLE public.piezas_reparacion OWNER TO postgres;
CREATE SEQUENCE public.piezas_reparacion_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;
ALTER TABLE public.piezas_reparacion_id_seq OWNER TO postgres;
ALTER SEQUENCE public.piezas_reparacion_id_seq OWNED BY public.piezas_reparacion.id;
CREATE TABLE public.piezas_reparacion_productos (
    id integer NOT NULL,
    reparacion_id integer NOT NULL,
    producto_id integer NOT NULL,
    cantidad integer NOT NULL,
    precio double precision NOT NULL,
    total double precision NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);
ALTER TABLE public.piezas_reparacion_productos OWNER TO postgres;
CREATE SEQUENCE public.piezas_reparacion_productos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;
ALTER TABLE public.piezas_reparacion_productos_id_seq OWNER TO postgres;
ALTER SEQUENCE public.piezas_reparacion_productos_id_seq OWNED BY public.piezas_reparacion_productos.id;
CREATE TABLE public.precios_venta (
    id integer NOT NULL,
    tipo public."TipoProducto" NOT NULL,
    nombre text NOT NULL,
    marca text,
    modelo text,
    precio_compra_promedio double precision NOT NULL,
    precio_venta double precision NOT NULL,
    producto_id integer,
    servicio_id integer,
    created_by text NOT NULL,
    updated_by text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);
ALTER TABLE public.precios_venta OWNER TO postgres;
CREATE SEQUENCE public.precios_venta_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;
ALTER TABLE public.precios_venta_id_seq OWNER TO postgres;
ALTER SEQUENCE public.precios_venta_id_seq OWNED BY public.precios_venta.id;
CREATE TABLE public.presupuestos (
    id integer NOT NULL,
    ticket_id integer NOT NULL,
    total double precision NOT NULL,
    descuento double precision DEFAULT 0 NOT NULL,
    total_final double precision NOT NULL,
    aprobado boolean DEFAULT false NOT NULL,
    fecha_aprobacion timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    iva_incluido boolean DEFAULT true NOT NULL,
    saldo double precision DEFAULT 0 NOT NULL,
    pagado boolean DEFAULT false NOT NULL
);
ALTER TABLE public.presupuestos OWNER TO postgres;
CREATE SEQUENCE public.presupuestos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;
ALTER TABLE public.presupuestos_id_seq OWNER TO postgres;
ALTER SEQUENCE public.presupuestos_id_seq OWNED BY public.presupuestos.id;
CREATE TABLE public.presupuestos_independientes (
    id integer NOT NULL,
    nombre text NOT NULL,
    descripcion text,
    cliente_nombre text,
    usuario_id integer NOT NULL,
    total double precision DEFAULT 0 NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);
ALTER TABLE public.presupuestos_independientes OWNER TO postgres;
CREATE SEQUENCE public.presupuestos_independientes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;
ALTER TABLE public.presupuestos_independientes_id_seq OWNER TO postgres;
ALTER SEQUENCE public.presupuestos_independientes_id_seq OWNED BY public.presupuestos_independientes.id;
CREATE TABLE public.problemas_frecuentes (
    id integer NOT NULL,
    nombre text NOT NULL,
    descripcion text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);
ALTER TABLE public.problemas_frecuentes OWNER TO postgres;
CREATE SEQUENCE public.problemas_frecuentes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;
ALTER TABLE public.problemas_frecuentes_id_seq OWNER TO postgres;
ALTER SEQUENCE public.problemas_frecuentes_id_seq OWNED BY public.problemas_frecuentes.id;
CREATE TABLE public.productos (
    id integer NOT NULL,
    sku text NOT NULL,
    nombre text NOT NULL,
    descripcion text,
    notas_internas text,
    garantia_valor integer,
    garantia_unidad text,
    categoria_id integer,
    marca_id integer,
    modelo_id integer,
    proveedor_id integer,
    precio_promedio double precision DEFAULT 0 NOT NULL,
    stock integer DEFAULT 0 NOT NULL,
    tipo_servicio_id integer,
    stock_maximo integer,
    stock_minimo integer,
    tipo public."TipoProducto" NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);
ALTER TABLE public.productos OWNER TO postgres;
CREATE SEQUENCE public.productos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;
ALTER TABLE public.productos_id_seq OWNER TO postgres;
ALTER SEQUENCE public.productos_id_seq OWNED BY public.productos.id;
CREATE TABLE public.productos_presupuesto_independiente (
    id integer NOT NULL,
    presupuesto_independiente_id integer NOT NULL,
    producto_id integer,
    cantidad integer NOT NULL,
    precio_venta double precision NOT NULL,
    concepto_extra text,
    precio_concepto_extra double precision,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);
ALTER TABLE public.productos_presupuesto_independiente OWNER TO postgres;
CREATE SEQUENCE public.productos_presupuesto_independiente_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;
ALTER TABLE public.productos_presupuesto_independiente_id_seq OWNER TO postgres;
ALTER SEQUENCE public.productos_presupuesto_independiente_id_seq OWNED BY public.productos_presupuesto_independiente.id;
CREATE TABLE public.productos_reparacion_frecuente (
    id integer NOT NULL,
    reparacion_frecuente_id integer NOT NULL,
    producto_id integer NOT NULL,
    cantidad integer NOT NULL,
    precio_venta double precision NOT NULL,
    concepto_extra text,
    precio_concepto_extra double precision,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);
ALTER TABLE public.productos_reparacion_frecuente OWNER TO postgres;
CREATE SEQUENCE public.productos_reparacion_frecuente_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;
ALTER TABLE public.productos_reparacion_frecuente_id_seq OWNER TO postgres;
ALTER SEQUENCE public.productos_reparacion_frecuente_id_seq OWNED BY public.productos_reparacion_frecuente.id;
CREATE TABLE public.proveedores (
    id integer NOT NULL,
    nombre text NOT NULL,
    contacto text NOT NULL,
    telefono text NOT NULL,
    email text,
    direccion text,
    notas text,
    banco text NOT NULL,
    clabe_interbancaria text NOT NULL,
    cuenta_bancaria text NOT NULL,
    rfc text NOT NULL,
    tipo public."TipoProveedor" DEFAULT 'FISICA'::public."TipoProveedor" NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);
ALTER TABLE public.proveedores OWNER TO postgres;
CREATE SEQUENCE public.proveedores_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;
ALTER TABLE public.proveedores_id_seq OWNER TO postgres;
ALTER SEQUENCE public.proveedores_id_seq OWNED BY public.proveedores.id;
CREATE TABLE public.puntos_recoleccion (
    id integer NOT NULL,
    nombre text NOT NULL,
    activo boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT now() NOT NULL,
    email text,
    is_headquarters boolean DEFAULT false NOT NULL,
    location jsonb,
    parent_id integer,
    phone text,
    schedule jsonb,
    url text,
    is_repair_point boolean DEFAULT false NOT NULL
);
ALTER TABLE public.puntos_recoleccion OWNER TO postgres;
CREATE SEQUENCE public.puntos_recoleccion_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;
ALTER TABLE public.puntos_recoleccion_id_seq OWNER TO postgres;
ALTER SEQUENCE public.puntos_recoleccion_id_seq OWNED BY public.puntos_recoleccion.id;
CREATE TABLE public.reparaciones (
    id integer NOT NULL,
    ticket_id integer NOT NULL,
    diagnostico text,
    solucion text,
    observaciones text,
    fecha_inicio timestamp(3) without time zone,
    fecha_fin timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    capacidad text,
    codigo_desbloqueo text,
    red_celular text,
    salud_bateria integer,
    version_so text,
    fecha_pausa timestamp(3) without time zone,
    fecha_reanudacion timestamp(3) without time zone
);
ALTER TABLE public.reparaciones OWNER TO postgres;
CREATE TABLE public.reparaciones_frecuentes (
    id integer NOT NULL,
    nombre text NOT NULL,
    descripcion text,
    activo boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);
ALTER TABLE public.reparaciones_frecuentes OWNER TO postgres;
CREATE SEQUENCE public.reparaciones_frecuentes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;
ALTER TABLE public.reparaciones_frecuentes_id_seq OWNER TO postgres;
ALTER SEQUENCE public.reparaciones_frecuentes_id_seq OWNED BY public.reparaciones_frecuentes.id;
CREATE SEQUENCE public.reparaciones_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;
ALTER TABLE public.reparaciones_id_seq OWNER TO postgres;
ALTER SEQUENCE public.reparaciones_id_seq OWNED BY public.reparaciones.id;
CREATE TABLE public.roles (
    id integer NOT NULL,
    nombre text NOT NULL,
    descripcion text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);
ALTER TABLE public.roles OWNER TO postgres;
CREATE SEQUENCE public.roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;
ALTER TABLE public.roles_id_seq OWNER TO postgres;
ALTER SEQUENCE public.roles_id_seq OWNED BY public.roles.id;
CREATE TABLE public.roles_permisos (
    id integer NOT NULL,
    rol_id integer NOT NULL,
    permiso_id integer NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);
ALTER TABLE public.roles_permisos OWNER TO postgres;
CREATE SEQUENCE public.roles_permisos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;
ALTER TABLE public.roles_permisos_id_seq OWNER TO postgres;
ALTER SEQUENCE public.roles_permisos_id_seq OWNED BY public.roles_permisos.id;
CREATE TABLE public.salidas_almacen (
    id integer NOT NULL,
    producto_id integer NOT NULL,
    cantidad integer NOT NULL,
    razon text NOT NULL,
    tipo public."TipoSalida" NOT NULL,
    referencia text,
    fecha timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    usuario_id integer NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);
ALTER TABLE public.salidas_almacen OWNER TO postgres;
CREATE SEQUENCE public.salidas_almacen_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;
ALTER TABLE public.salidas_almacen_id_seq OWNER TO postgres;
ALTER SEQUENCE public.salidas_almacen_id_seq OWNED BY public.salidas_almacen.id;
CREATE TABLE public.ticket_problemas (
    id integer NOT NULL,
    ticket_id integer NOT NULL,
    problema_id integer NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);
ALTER TABLE public.ticket_problemas OWNER TO postgres;
CREATE SEQUENCE public.ticket_problemas_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;
ALTER TABLE public.ticket_problemas_id_seq OWNER TO postgres;
ALTER SEQUENCE public.ticket_problemas_id_seq OWNED BY public.ticket_problemas.id;
CREATE TABLE public.tickets (
    id integer NOT NULL,
    numero_ticket text NOT NULL,
    fecha_recepcion timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    cliente_id integer NOT NULL,
    tipo_servicio_id integer NOT NULL,
    modelo_id integer NOT NULL,
    descripcion_problema text,
    estatus_reparacion_id integer NOT NULL,
    creador_id integer NOT NULL,
    tecnico_asignado_id integer,
    punto_recoleccion_id integer,
    recogida boolean DEFAULT false NOT NULL,
    fecha_entrega timestamp(3) without time zone,
    entregado boolean DEFAULT false NOT NULL,
    cancelado boolean DEFAULT false NOT NULL,
    motivo_cancelacion text,
    fecha_inicio_diagnostico timestamp(3) without time zone,
    fecha_fin_diagnostico timestamp(3) without time zone,
    fecha_inicio_reparacion timestamp(3) without time zone,
    fecha_fin_reparacion timestamp(3) without time zone,
    fecha_cancelacion timestamp(3) without time zone,
    direccion_id integer,
    imei text,
    capacidad text,
    color text,
    fecha_compra timestamp(3) without time zone,
    codigo_desbloqueo text,
    red_celular text,
    patron_desbloqueo integer[] DEFAULT ARRAY[]::integer[],
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    tipo_desbloqueo text
);
ALTER TABLE public.tickets OWNER TO postgres;
CREATE SEQUENCE public.tickets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;
ALTER TABLE public.tickets_id_seq OWNER TO postgres;
ALTER SEQUENCE public.tickets_id_seq OWNED BY public.tickets.id;
CREATE TABLE public.tipos_servicio (
    id integer NOT NULL,
    nombre text NOT NULL,
    descripcion text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);
ALTER TABLE public.tipos_servicio OWNER TO postgres;
CREATE SEQUENCE public.tipos_servicio_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;
ALTER TABLE public.tipos_servicio_id_seq OWNER TO postgres;
ALTER SEQUENCE public.tipos_servicio_id_seq OWNED BY public.tipos_servicio.id;
CREATE TABLE public.usos_cupon (
    id integer NOT NULL,
    cupon_id integer NOT NULL,
    ticket_id integer,
    venta_id integer,
    usuario_id integer NOT NULL,
    monto_descuento double precision NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);
ALTER TABLE public.usos_cupon OWNER TO postgres;
CREATE SEQUENCE public.usos_cupon_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;
ALTER TABLE public.usos_cupon_id_seq OWNER TO postgres;
ALTER SEQUENCE public.usos_cupon_id_seq OWNED BY public.usos_cupon.id;
CREATE TABLE public.usuarios (
    id integer NOT NULL,
    nombre text NOT NULL,
    apellido_paterno text NOT NULL,
    apellido_materno text,
    email text NOT NULL,
    password_hash text NOT NULL,
    telefono text,
    activo boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);
ALTER TABLE public.usuarios OWNER TO postgres;
CREATE SEQUENCE public.usuarios_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;
ALTER TABLE public.usuarios_id_seq OWNER TO postgres;
ALTER SEQUENCE public.usuarios_id_seq OWNED BY public.usuarios.id;
CREATE TABLE public.usuarios_puntos_recoleccion (
    id integer NOT NULL,
    usuario_id integer NOT NULL,
    punto_recoleccion_id integer NOT NULL,
    nivel public."NivelUsuarioPunto" NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);
ALTER TABLE public.usuarios_puntos_recoleccion OWNER TO postgres;
CREATE SEQUENCE public.usuarios_puntos_recoleccion_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;
ALTER TABLE public.usuarios_puntos_recoleccion_id_seq OWNER TO postgres;
ALTER SEQUENCE public.usuarios_puntos_recoleccion_id_seq OWNED BY public.usuarios_puntos_recoleccion.id;
CREATE TABLE public.usuarios_roles (
    id integer NOT NULL,
    usuario_id integer NOT NULL,
    rol_id integer NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);
ALTER TABLE public.usuarios_roles OWNER TO postgres;
CREATE SEQUENCE public.usuarios_roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;
ALTER TABLE public.usuarios_roles_id_seq OWNER TO postgres;
ALTER SEQUENCE public.usuarios_roles_id_seq OWNED BY public.usuarios_roles.id;
CREATE TABLE public.ventas (
    id integer NOT NULL,
    cliente_id integer NOT NULL,
    usuario_id integer NOT NULL,
    total double precision NOT NULL,
    estado text DEFAULT 'COMPLETADA'::text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);
ALTER TABLE public.ventas OWNER TO postgres;
CREATE SEQUENCE public.ventas_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;
ALTER TABLE public.ventas_id_seq OWNER TO postgres;
ALTER SEQUENCE public.ventas_id_seq OWNED BY public.ventas.id;
ALTER TABLE ONLY public.categorias ALTER COLUMN id SET DEFAULT nextval('public.categorias_id_seq'::regclass);
ALTER TABLE ONLY public.checklist_diagnostico ALTER COLUMN id SET DEFAULT nextval('public.checklist_diagnostico_id_seq'::regclass);
ALTER TABLE ONLY public.checklist_items ALTER COLUMN id SET DEFAULT nextval('public.checklist_items_id_seq'::regclass);
ALTER TABLE ONLY public.checklist_reparacion ALTER COLUMN id SET DEFAULT nextval('public.checklist_reparacion_id_seq'::regclass);
ALTER TABLE ONLY public.checklist_respuesta_diagnostico ALTER COLUMN id SET DEFAULT nextval('public.checklist_respuesta_diagnostico_id_seq'::regclass);
ALTER TABLE ONLY public.checklist_respuesta_reparacion ALTER COLUMN id SET DEFAULT nextval('public.checklist_respuesta_reparacion_id_seq'::regclass);
ALTER TABLE ONLY public.clientes ALTER COLUMN id SET DEFAULT nextval('public.clientes_id_seq'::regclass);
ALTER TABLE ONLY public.conceptos_presupuesto ALTER COLUMN id SET DEFAULT nextval('public.conceptos_presupuesto_id_seq'::regclass);
ALTER TABLE ONLY public.cupones ALTER COLUMN id SET DEFAULT nextval('public.cupones_id_seq'::regclass);
ALTER TABLE ONLY public.detalle_ventas ALTER COLUMN id SET DEFAULT nextval('public.detalle_ventas_id_seq'::regclass);
ALTER TABLE ONLY public.direcciones ALTER COLUMN id SET DEFAULT nextval('public.direcciones_id_seq'::regclass);
ALTER TABLE ONLY public.dispositivos ALTER COLUMN id SET DEFAULT nextval('public.dispositivos_id_seq'::regclass);
ALTER TABLE ONLY public.entradas_almacen ALTER COLUMN id SET DEFAULT nextval('public.entradas_almacen_id_seq'::regclass);
ALTER TABLE ONLY public.entregas ALTER COLUMN id SET DEFAULT nextval('public.entregas_id_seq'::regclass);
ALTER TABLE ONLY public.estatus_reparacion ALTER COLUMN id SET DEFAULT nextval('public.estatus_reparacion_id_seq'::regclass);
ALTER TABLE ONLY public.fotos_producto ALTER COLUMN id SET DEFAULT nextval('public.fotos_producto_id_seq'::regclass);
ALTER TABLE ONLY public.marcas ALTER COLUMN id SET DEFAULT nextval('public.marcas_id_seq'::regclass);
ALTER TABLE ONLY public.modelos ALTER COLUMN id SET DEFAULT nextval('public.modelos_id_seq'::regclass);
ALTER TABLE ONLY public.pagos ALTER COLUMN id SET DEFAULT nextval('public.pagos_id_seq'::regclass);
ALTER TABLE ONLY public.pasos_reparacion_frecuente ALTER COLUMN id SET DEFAULT nextval('public.pasos_reparacion_frecuente_id_seq'::regclass);
ALTER TABLE ONLY public.permisos ALTER COLUMN id SET DEFAULT nextval('public.permisos_id_seq'::regclass);
ALTER TABLE ONLY public.piezas ALTER COLUMN id SET DEFAULT nextval('public.piezas_id_seq'::regclass);
ALTER TABLE ONLY public.piezas_reparacion ALTER COLUMN id SET DEFAULT nextval('public.piezas_reparacion_id_seq'::regclass);
ALTER TABLE ONLY public.piezas_reparacion_productos ALTER COLUMN id SET DEFAULT nextval('public.piezas_reparacion_productos_id_seq'::regclass);
ALTER TABLE ONLY public.precios_venta ALTER COLUMN id SET DEFAULT nextval('public.precios_venta_id_seq'::regclass);
ALTER TABLE ONLY public.presupuestos ALTER COLUMN id SET DEFAULT nextval('public.presupuestos_id_seq'::regclass);
ALTER TABLE ONLY public.presupuestos_independientes ALTER COLUMN id SET DEFAULT nextval('public.presupuestos_independientes_id_seq'::regclass);
ALTER TABLE ONLY public.problemas_frecuentes ALTER COLUMN id SET DEFAULT nextval('public.problemas_frecuentes_id_seq'::regclass);
ALTER TABLE ONLY public.productos ALTER COLUMN id SET DEFAULT nextval('public.productos_id_seq'::regclass);
ALTER TABLE ONLY public.productos_presupuesto_independiente ALTER COLUMN id SET DEFAULT nextval('public.productos_presupuesto_independiente_id_seq'::regclass);
ALTER TABLE ONLY public.productos_reparacion_frecuente ALTER COLUMN id SET DEFAULT nextval('public.productos_reparacion_frecuente_id_seq'::regclass);
ALTER TABLE ONLY public.proveedores ALTER COLUMN id SET DEFAULT nextval('public.proveedores_id_seq'::regclass);
ALTER TABLE ONLY public.puntos_recoleccion ALTER COLUMN id SET DEFAULT nextval('public.puntos_recoleccion_id_seq'::regclass);
ALTER TABLE ONLY public.reparaciones ALTER COLUMN id SET DEFAULT nextval('public.reparaciones_id_seq'::regclass);
ALTER TABLE ONLY public.reparaciones_frecuentes ALTER COLUMN id SET DEFAULT nextval('public.reparaciones_frecuentes_id_seq'::regclass);
ALTER TABLE ONLY public.roles ALTER COLUMN id SET DEFAULT nextval('public.roles_id_seq'::regclass);
ALTER TABLE ONLY public.roles_permisos ALTER COLUMN id SET DEFAULT nextval('public.roles_permisos_id_seq'::regclass);
ALTER TABLE ONLY public.salidas_almacen ALTER COLUMN id SET DEFAULT nextval('public.salidas_almacen_id_seq'::regclass);
ALTER TABLE ONLY public.ticket_problemas ALTER COLUMN id SET DEFAULT nextval('public.ticket_problemas_id_seq'::regclass);
ALTER TABLE ONLY public.tickets ALTER COLUMN id SET DEFAULT nextval('public.tickets_id_seq'::regclass);
ALTER TABLE ONLY public.tipos_servicio ALTER COLUMN id SET DEFAULT nextval('public.tipos_servicio_id_seq'::regclass);
ALTER TABLE ONLY public.usos_cupon ALTER COLUMN id SET DEFAULT nextval('public.usos_cupon_id_seq'::regclass);
ALTER TABLE ONLY public.usuarios ALTER COLUMN id SET DEFAULT nextval('public.usuarios_id_seq'::regclass);
ALTER TABLE ONLY public.usuarios_puntos_recoleccion ALTER COLUMN id SET DEFAULT nextval('public.usuarios_puntos_recoleccion_id_seq'::regclass);
ALTER TABLE ONLY public.usuarios_roles ALTER COLUMN id SET DEFAULT nextval('public.usuarios_roles_id_seq'::regclass);
ALTER TABLE ONLY public.ventas ALTER COLUMN id SET DEFAULT nextval('public.ventas_id_seq'::regclass);
COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
4909d8ed-8b1a-458f-a6b6-74eaa59d668f	7b146969a11ad9b4c7954b4a7c20bc134190f26837de07ea008e5c539d9cc38d	2025-06-17 17:39:16.789577+00	20250616100334_init	\N	\N	2025-06-17 17:39:16.705847+00	1
6edf6a27-405b-4a8f-94bb-13ee64e77e53	c7671a898084b553163753e99f3a5d1f9e2d3564a27c062d3a13244a5359e016	2025-06-17 17:39:16.791609+00	20250616121148_add_pause_resume_dates	\N	\N	2025-06-17 17:39:16.790212+00	1
e51cd5b2-1a5e-4a8c-afb7-35d2009a187b	b2aff5b47c352351e7f6a563ea6d1b96de70a5f48a896e5ee47a22ed30051f90	2025-06-17 17:39:16.794123+00	20250616142037_remove_imei_unique_constraint	\N	\N	2025-06-17 17:39:16.792173+00	1
9a1483e6-84e8-4b25-b2c2-c86ba243252c	a28d36af030f5c67b1f381323114d4ebac6327ecfceb0a1b3083a7e1e5e83762	2025-06-17 17:39:16.800179+00	20250616143848_add_checklist_respuestas	\N	\N	2025-06-17 17:39:16.794685+00	1
1b13b877-57e9-4d4d-8f1f-1b169aae2ae5	190510a0b56a86b36bdf5f8ddf3de5514a83b76622a154be03ca1c85b0ae879c	2025-06-17 17:39:16.804309+00	20250616164101_update_checklist_respuesta_to_boolean	\N	\N	2025-06-17 17:39:16.800727+00	1
e1281349-b809-4182-8232-8fa3732c0df2	e5a9b0d40eeb9b9f63a36fdb943528e09c19e0f5d08343f5b7316b786f9d786b	2025-06-17 17:39:16.805533+00	20250616211622_add_tipo_desbloqueo	\N	\N	2025-06-17 17:39:16.804792+00	1
fa13e558-13a8-4303-bc6c-b9c65e7d82b0	fdf48022bc2e2f6de8ce55cd5619b917ce07c42f70f4d30397b03526ec49b5fe	2025-06-17 17:39:16.807891+00	20250617002938_add_punto_recoleccion_to_cliente	\N	\N	2025-06-17 17:39:16.805908+00	1
8ce3f50e-e119-4091-b591-916874bde219	142571ca3b85cd5f8ba05d860842cb5a67709150ab9a9bcf01515ee1cbc100b1	2025-06-17 17:39:16.810232+00	20250617130817_add_is_repair_point_to_puntos_recoleccion	\N	\N	2025-06-17 17:39:16.809+00	1
c493d62d-7870-4b9f-95c1-01417f56e2ba	b3766ad492b4f4cf23abab7c88cf20f5ef89004bed1d28bd5578bcfcabd0303b	2025-06-17 17:39:16.811904+00	20250617130921_agregar_reparacion_a_puntos_recoleccion	\N	\N	2025-06-17 17:39:16.811118+00	1
ddf8fb01-5ffd-404d-accf-dc9c837a6ad2	afa760c5a5bcc5ed4d2cb8e8928b229b8a5461aef1aeb4cc502cb4d905467f2f	2025-06-17 17:39:17.650599+00	20250617173917_add_checklist_reparacion	\N	\N	2025-06-17 17:39:17.640561+00	1
6b66cd46-56b6-4ceb-a64d-645e4885b43f	ef31da6fc07ef79d8bac64f345a941f22f432e82a3fb47b6c507ddc62d2b22fe	2025-08-07 13:20:54.994933+00	20250127_fix_updated_at_default	\N	\N	2025-08-07 13:20:54.982864+00	1
c6b4951f-ad5f-4d6e-a6d5-aa67c292ba14	8d9f50a8c97ea4b5327a9d1cbf72af15537de27faeff24f9924fe433bbec2be0	2025-08-07 13:40:17.3143+00	20250127_add_ventas_tables	\N	\N	2025-08-07 13:40:17.257881+00	1
70e012ed-26d1-42eb-aac9-72bd6223cf8c	0d0fd9c1aaa071a90ff807c198fe9bd4bba55a6cc46973317831849a274ad22c	2025-08-12 10:49:40.307937+00	20250127_add_presupuestos_independientes	\N	\N	2025-08-12 10:49:40.17342+00	1
\.
COPY public.categorias (id, nombre, descripcion, created_at, updated_at) FROM stdin;
1	Reparación de Celulares	Categoría por defecto para productos de reparación de celulares	2025-06-17 17:42:32.574	2025-06-17 17:42:32.574
\.
COPY public.checklist_diagnostico (id, reparacion_id, created_at, updated_at) FROM stdin;
7	51	2025-09-01 17:27:26.501	2025-09-01 17:27:26.5
8	55	2025-09-01 20:09:02.05	2025-09-01 20:09:02.049
9	57	2025-09-06 23:18:14.165	2025-09-06 23:18:14.164
10	89	2025-09-26 15:56:55.801	2025-09-26 15:56:55.8
11	100	2025-09-28 19:44:00.757	2025-09-28 19:44:00.756
12	112	2025-10-05 19:03:59.733	2025-10-05 19:03:59.732
13	113	2025-10-05 22:58:57.652	2025-10-05 22:58:57.651
14	116	2025-10-07 17:34:47.762	2025-10-07 17:34:47.761
17	171	2025-10-27 22:35:50.539	2025-10-27 22:35:50.538
\.
COPY public.checklist_items (id, descripcion, created_at, updated_at, nombre, para_diagnostico, para_reparacion) FROM stdin;
1		2025-06-17 18:00:47.011	2025-06-17 18:00:47.011	¿Golpes Visibles?	t	t
2		2025-06-17 18:00:57.133	2025-06-17 18:00:57.133	¿Botones funcionando?	t	t
3		2025-06-17 18:01:09.948	2025-06-17 18:01:09.948	¿Prende y apaga correctamente?	t	t
4		2025-06-17 18:01:20.418	2025-06-17 18:01:20.418	¿Cámara delantera funcionando?	t	t
5		2025-06-17 18:01:28.986	2025-06-17 18:01:28.986	¿Altavoces funcionando?	t	t
6		2025-06-18 16:12:09.873	2025-06-18 16:12:09.873	¿Cámara trasera funcionando?	t	t
7		2025-08-18 20:15:34.118	2025-08-18 20:16:04.221	¿Trae porta sim?	t	t
8		2025-08-18 20:18:40.59	2025-08-18 20:18:40.589	¿trae mica en pantalla?	t	t
9		2025-08-18 20:19:19.623	2025-08-18 20:19:19.622	¿vidrios de cámara rotos?	t	t
10		2025-08-18 20:19:42.629	2025-08-18 20:19:42.627	¿trae todos los tornillos?	f	t
11		2025-08-18 20:20:34.604	2025-08-18 20:20:34.603	¿trae tapa rota o rallada?	t	t
12		2025-08-18 20:21:35.423	2025-08-18 20:21:35.421	¿marco de display completo?	t	t
13		2025-08-18 20:22:21.6	2025-08-18 20:22:21.599	¿trae cubre polvo de pantalla?	t	t
14		2025-08-18 20:23:02.905	2025-08-18 20:23:02.904	¿micrófono funcionando?	t	t
15		2025-08-18 20:25:26.662	2025-08-18 20:25:26.661	¿display roto?	t	t
\.
COPY public.checklist_reparacion (id, reparacion_id, created_at, updated_at) FROM stdin;
141	182	2025-10-30 18:52:04.957	2025-10-30 18:52:04.958
138	179	2025-10-28 23:45:55.212	2025-10-31 19:52:02.477
142	183	2025-10-31 18:08:40.223	2025-10-31 20:55:03.307
143	184	2025-10-31 18:08:51.896	2025-10-31 21:41:36.715
147	188	2025-11-01 18:13:32.142	2025-11-01 18:13:32.142
148	189	2025-11-01 18:16:14.461	2025-11-01 18:16:14.461
149	190	2025-11-01 20:55:18.169	2025-11-01 20:55:34.486
151	192	2025-11-01 23:18:32.672	2025-11-01 23:18:32.672
152	193	2025-11-01 23:19:11.494	2025-11-01 23:19:11.494
127	167	2025-10-24 21:31:03.985	2025-11-02 21:20:55.599
154	195	2025-11-02 22:00:38.705	2025-11-02 22:00:38.705
155	196	2025-11-03 22:41:08.638	2025-11-03 22:41:08.638
156	197	2025-11-04 23:20:37.033	2025-11-04 23:20:37.033
20	51	2025-09-01 17:36:29.596	2025-09-01 17:36:29.596
21	53	2025-09-01 19:00:22.447	2025-09-01 19:00:42.409
23	55	2025-09-01 21:17:46.389	2025-09-01 21:17:46.389
24	57	2025-09-05 20:45:21.587	2025-09-06 22:37:30.108
157	198	2025-11-05 16:28:10.187	2025-11-05 16:28:10.187
27	60	2025-09-08 19:53:32.467	2025-09-08 19:54:27.244
30	63	2025-09-10 00:00:51.27	2025-09-10 00:00:51.27
31	64	2025-09-10 16:36:30.882	2025-09-10 16:36:30.882
26	59	2025-09-08 19:47:42.972	2025-09-10 18:43:21.4
33	66	2025-09-11 18:24:42.524	2025-09-11 18:24:42.524
34	67	2025-09-13 20:19:13.459	2025-09-13 20:20:44.679
38	71	2025-09-13 23:49:28.149	2025-09-13 23:49:46.777
36	69	2025-09-13 20:21:21.245	2025-09-13 23:50:25.193
41	74	2025-09-17 20:02:26.541	2025-09-17 20:02:44.805
43	76	2025-09-21 00:04:36.612	2025-09-21 00:04:47.516
45	78	2025-09-21 00:07:12.076	2025-09-21 00:07:12.076
46	79	2025-09-21 20:58:13.922	2025-09-21 20:58:13.922
47	80	2025-09-22 23:41:30.058	2025-09-22 23:41:30.058
48	81	2025-09-23 16:35:11.39	2025-09-23 16:35:11.39
49	82	2025-09-23 16:41:07.151	2025-09-23 16:41:08.973
51	84	2025-09-23 22:05:35.794	2025-09-23 22:05:35.794
52	85	2025-09-23 22:12:55.047	2025-09-23 22:12:55.94
54	87	2025-09-23 22:16:50.504	2025-09-23 22:16:51.924
56	90	2025-09-26 22:45:40.601	2025-09-26 22:45:40.601
57	91	2025-09-26 23:07:43.821	2025-09-26 23:07:45.265
59	89	2025-09-26 23:51:09.29	2025-09-26 23:51:09.29
60	94	2025-09-27 20:11:05.254	2025-09-27 20:11:05.254
61	95	2025-09-27 20:12:55.836	2025-09-27 20:13:12.955
63	97	2025-09-27 20:16:57.494	2025-09-27 20:16:57.494
64	98	2025-09-27 23:40:17.216	2025-09-27 23:40:17.216
65	99	2025-09-28 19:35:28.157	2025-09-28 19:35:28.157
66	101	2025-09-28 21:06:57.556	2025-09-28 21:06:57.556
67	102	2025-09-29 21:48:59.785	2025-09-29 21:48:59.785
68	103	2025-09-30 22:17:17.097	2025-09-30 22:49:17.444
70	105	2025-09-30 23:03:39.114	2025-09-30 23:03:39.114
71	106	2025-10-01 21:25:29.229	2025-10-01 21:25:29.229
72	107	2025-10-01 21:26:23.549	2025-10-01 23:20:49.655
74	109	2025-10-01 23:57:46.1	2025-10-01 23:57:46.1
75	110	2025-10-02 22:05:52.006	2025-10-04 16:49:31.339
77	114	2025-10-06 21:42:02.325	2025-10-06 21:42:02.325
78	115	2025-10-07 16:05:13.822	2025-10-07 16:05:13.822
79	116	2025-10-07 23:21:43.253	2025-10-07 23:21:43.253
81	113	2025-10-08 20:09:07.266	2025-10-08 20:09:07.266
82	120	2025-10-08 20:22:07.284	2025-10-08 20:22:07.284
80	118	2025-10-08 20:07:35.803	2025-10-08 22:25:00.629
158	199	2025-11-05 23:28:19.485	2025-11-05 23:28:21.512
161	202	2025-11-06 22:22:35.504	2025-11-06 22:22:35.504
164	205	2025-11-07 16:01:04.948	2025-11-07 16:01:04.948
162	203	2025-11-06 22:43:51.504	2025-11-07 22:29:58.446
166	207	2025-11-08 20:56:56.912	2025-11-08 20:56:56.912
160	201	2025-11-06 21:50:36.784	2025-11-08 21:05:07.696
94	134	2025-10-09 23:05:22.024	2025-10-09 23:05:22.625
97	137	2025-10-10 22:20:55.539	2025-10-10 22:20:55.539
98	138	2025-10-10 22:30:11.396	2025-10-10 22:30:11.396
99	139	2025-10-10 22:31:30.912	2025-10-10 22:31:30.912
96	136	2025-10-09 23:08:01.652	2025-10-11 19:21:07.05
103	143	2025-10-11 22:39:41.794	2025-10-11 22:40:53.772
105	145	2025-10-11 23:24:27.937	2025-10-11 23:24:27.937
100	140	2025-10-10 22:41:55.541	2025-10-13 20:32:54.109
107	147	2025-10-13 23:30:11.133	2025-10-13 23:30:11.133
109	149	2025-10-14 19:07:00.97	2025-10-14 19:07:01.817
111	151	2025-10-14 21:32:38.924	2025-10-14 21:32:42.524
113	153	2025-10-16 21:11:23.19	2025-10-16 21:12:42.156
115	155	2025-10-16 21:22:56.63	2025-10-16 21:22:56.63
101	100	2025-10-11 15:08:00.954	2025-10-16 23:19:54.33
108	148	2025-10-14 15:00:46.612	2025-10-17 20:59:59.75
118	158	2025-10-17 21:52:59.303	2025-10-17 21:53:01.285
120	160	2025-10-18 19:50:53.647	2025-10-18 19:50:53.647
121	161	2025-10-18 19:52:43.327	2025-10-18 20:37:04.689
123	163	2025-10-19 19:49:34.558	2025-10-19 19:49:34.558
124	164	2025-10-22 19:26:09.906	2025-10-22 19:26:09.906
125	165	2025-10-23 15:35:42.505	2025-10-23 15:35:42.505
126	166	2025-10-23 16:22:28.88	2025-10-23 16:22:28.88
129	169	2025-10-25 18:04:57.375	2025-10-25 18:04:57.375
130	170	2025-10-27 19:59:06.28	2025-10-27 19:59:06.28
131	171	2025-10-27 22:36:32.504	2025-10-27 22:36:32.504
132	173	2025-10-27 22:47:27.179	2025-10-27 22:47:27.179
168	209	2025-11-08 21:07:31.752	2025-11-08 21:53:18.635
133	174	2025-10-28 00:30:32.945	2025-10-28 00:31:24.748
136	177	2025-10-28 00:33:11.945	2025-10-28 00:33:11.945
137	178	2025-10-28 20:12:22.544	2025-10-28 20:12:22.544
139	180	2025-10-29 23:11:05.44	2025-10-29 23:11:18.631
163	204	2025-11-06 22:44:15.75	2025-11-09 19:16:34.14
171	212	2025-11-09 21:52:35.561	2025-11-09 22:19:10.426
172	213	2025-11-09 22:13:38.471	2025-11-10 20:42:12.89
175	216	2025-11-10 21:14:39.423	2025-11-10 21:14:39.423
205	246	2025-11-14 20:00:50.678	2025-11-14 20:00:50.678
176	217	2025-11-10 21:55:05.134	2025-11-10 21:55:54.206
180	221	2025-11-12 18:37:26.912	2025-11-12 18:37:26.912
182	223	2025-11-12 23:24:26.283	2025-11-12 23:28:50.968
204	245	2025-11-14 19:07:18.501	2025-11-14 22:05:12.08
208	249	2025-11-15 18:48:59.888	2025-11-15 18:49:00.439
185	226	2025-11-12 23:57:53.252	2025-11-12 23:58:22.608
191	232	2025-11-13 15:35:29.124	2025-11-13 15:35:29.124
192	233	2025-11-13 15:54:23.463	2025-11-13 15:54:23.463
193	234	2025-11-13 17:15:16.428	2025-11-13 17:15:17.208
210	251	2025-11-15 23:44:30.824	2025-11-15 23:44:30.824
211	252	2025-11-18 21:31:33.412	2025-11-18 21:31:33.412
207	248	2025-11-14 22:51:28.63	2025-11-18 21:36:35.997
213	254	2025-11-19 15:02:34.522	2025-11-19 15:03:10.735
179	220	2025-11-11 22:16:50.142	2025-11-13 18:11:26.499
183	224	2025-11-12 23:24:49.884	2025-11-13 18:12:11.244
181	222	2025-11-12 22:47:19.636	2025-11-13 18:12:33.486
203	244	2025-11-14 18:56:49.651	2025-11-14 18:56:49.651
215	256	2025-11-19 18:11:25.313	2025-11-19 18:11:25.313
216	257	2025-11-19 21:02:12.4	2025-11-20 19:21:54.946
219	260	2025-11-21 18:26:38.381	2025-11-21 18:29:10.127
220	261	2025-11-21 18:26:47.39	2025-11-21 18:29:38.188
223	264	2025-11-21 18:30:43.322	2025-11-21 18:30:43.322
217	258	2025-11-19 21:02:24.812	2025-11-21 20:34:12.816
225	266	2025-11-21 21:19:07.031	2025-11-21 21:19:07.031
226	267	2025-11-22 19:52:40.604	2025-11-22 19:52:40.604
227	268	2025-11-22 22:07:53.206	2025-11-22 22:07:53.206
228	269	2025-11-22 22:08:00.883	2025-11-22 22:08:00.883
229	270	2025-11-23 19:21:18.313	2025-11-23 19:21:18.313
230	271	2025-11-24 18:25:29.805	2025-11-24 18:25:29.805
231	272	2025-11-24 23:00:57.936	2025-11-24 23:00:57.936
232	273	2025-11-24 23:56:43.795	2025-11-24 23:56:43.795
\.
COPY public.checklist_respuesta_diagnostico (id, checklist_diagnostico_id, checklist_item_id, respuesta, observaciones, created_at, updated_at) FROM stdin;
193	9	1	f	\N	2025-09-06 23:18:14.178	2025-09-06 23:18:14.174
194	9	2	t	\N	2025-09-06 23:18:14.178	2025-09-06 23:18:14.175
195	9	14	t	\N	2025-09-06 23:18:14.179	2025-09-06 23:18:14.175
196	9	11	t	si, tapa estrellada	2025-09-06 23:18:14.178	2025-09-06 23:18:14.175
197	9	3	t	\N	2025-09-06 23:18:14.179	2025-09-06 23:18:14.175
198	9	15	t	\N	2025-09-06 23:18:14.179	2025-09-06 23:18:14.175
200	9	4	t	\N	2025-09-06 23:18:14.179	2025-09-06 23:18:14.175
199	9	9	f	\N	2025-09-06 23:18:14.178	2025-09-06 23:18:14.175
201	9	5	t	\N	2025-09-06 23:18:14.179	2025-09-06 23:18:14.175
202	9	6	t	\N	2025-09-06 23:18:14.179	2025-09-06 23:18:14.175
203	9	7	t	\N	2025-09-06 23:18:14.179	2025-09-06 23:18:14.175
204	9	8	t	\N	2025-09-06 23:18:14.179	2025-09-06 23:18:14.175
205	9	13	f	\N	2025-09-06 23:18:14.179	2025-09-06 23:18:14.175
206	9	12	t	\N	2025-09-06 23:18:14.179	2025-09-06 23:18:14.175
207	10	1	t	\N	2025-09-26 15:56:55.809	2025-09-26 15:56:55.806
208	10	9	f	\N	2025-09-26 15:56:55.809	2025-09-26 15:56:55.806
209	10	14	f	\N	2025-09-26 15:56:55.809	2025-09-26 15:56:55.806
210	10	2	f	\N	2025-09-26 15:56:55.809	2025-09-26 15:56:55.806
211	10	15	t	\N	2025-09-26 15:56:55.81	2025-09-26 15:56:55.806
212	10	3	f	\N	2025-09-26 15:56:55.81	2025-09-26 15:56:55.806
213	10	11	f	\N	2025-09-26 15:56:55.81	2025-09-26 15:56:55.806
214	10	12	f	\N	2025-09-26 15:56:55.81	2025-09-26 15:56:55.806
215	10	4	f	\N	2025-09-26 15:56:55.81	2025-09-26 15:56:55.806
216	10	5	f	\N	2025-09-26 15:56:55.81	2025-09-26 15:56:55.806
217	10	13	f	\N	2025-09-26 15:56:55.81	2025-09-26 15:56:55.806
218	10	6	f	\N	2025-09-26 15:56:55.81	2025-09-26 15:56:55.806
219	10	7	f	\N	2025-09-26 15:56:55.81	2025-09-26 15:56:55.806
220	10	8	f	\N	2025-09-26 15:56:55.81	2025-09-26 15:56:55.806
221	11	1	f	\N	2025-09-28 19:44:00.767	2025-09-28 19:44:00.765
222	11	2	f	\N	2025-09-28 19:44:00.767	2025-09-28 19:44:00.765
223	11	11	f	\N	2025-09-28 19:44:00.768	2025-09-28 19:44:00.765
224	11	14	f	\N	2025-09-28 19:44:00.768	2025-09-28 19:44:00.765
225	11	12	f	\N	2025-09-28 19:44:00.768	2025-09-28 19:44:00.765
226	11	15	f	\N	2025-09-28 19:44:00.768	2025-09-28 19:44:00.765
227	11	3	f	\N	2025-09-28 19:44:00.768	2025-09-28 19:44:00.765
228	11	13	f	\N	2025-09-28 19:44:00.768	2025-09-28 19:44:00.765
229	11	6	f	\N	2025-09-28 19:44:00.768	2025-09-28 19:44:00.765
230	11	4	f	\N	2025-09-28 19:44:00.768	2025-09-28 19:44:00.765
231	11	5	f	\N	2025-09-28 19:44:00.768	2025-09-28 19:44:00.765
232	11	8	f	\N	2025-09-28 19:44:00.768	2025-09-28 19:44:00.765
233	11	7	f	\N	2025-09-28 19:44:00.768	2025-09-28 19:44:00.765
234	11	9	f	\N	2025-09-28 19:44:00.769	2025-09-28 19:44:00.765
235	12	2	t	\N	2025-10-05 19:03:59.746	2025-10-05 19:03:59.743
236	12	1	t	tapa estrellada 	2025-10-05 19:03:59.746	2025-10-05 19:03:59.743
238	12	7	f	el cliente la tiene resguardada 	2025-10-05 19:03:59.747	2025-10-05 19:03:59.743
237	12	12	f	\N	2025-10-05 19:03:59.747	2025-10-05 19:03:59.744
239	12	13	f	\N	2025-10-05 19:03:59.747	2025-10-05 19:03:59.744
240	12	8	f	\N	2025-10-05 19:03:59.747	2025-10-05 19:03:59.743
242	12	14	f	\N	2025-10-05 19:03:59.747	2025-10-05 19:03:59.744
241	12	6	f	\N	2025-10-05 19:03:59.747	2025-10-05 19:03:59.743
243	12	9	f	\N	2025-10-05 19:03:59.747	2025-10-05 19:03:59.743
244	12	11	t	\N	2025-10-05 19:03:59.747	2025-10-05 19:03:59.743
245	12	15	f	\N	2025-10-05 19:03:59.747	2025-10-05 19:03:59.744
246	12	5	f	\N	2025-10-05 19:03:59.747	2025-10-05 19:03:59.743
247	12	3	f	\N	2025-10-05 19:03:59.747	2025-10-05 19:03:59.743
248	12	4	f	\N	2025-10-05 19:03:59.747	2025-10-05 19:03:59.743
249	13	3	t	\N	2025-10-05 22:58:57.662	2025-10-05 22:58:57.66
250	13	7	f	\N	2025-10-05 22:58:57.663	2025-10-05 22:58:57.66
251	13	1	f	\N	2025-10-05 22:58:57.663	2025-10-05 22:58:57.66
252	13	8	f	\N	2025-10-05 22:58:57.663	2025-10-05 22:58:57.66
253	13	2	t	\N	2025-10-05 22:58:57.663	2025-10-05 22:58:57.66
254	13	9	f	\N	2025-10-05 22:58:57.663	2025-10-05 22:58:57.66
255	13	14	f	\N	2025-10-05 22:58:57.663	2025-10-05 22:58:57.661
256	13	11	f	\N	2025-10-05 22:58:57.663	2025-10-05 22:58:57.66
257	13	15	f	\N	2025-10-05 22:58:57.663	2025-10-05 22:58:57.661
258	13	12	f	\N	2025-10-05 22:58:57.663	2025-10-05 22:58:57.66
259	13	13	f	\N	2025-10-05 22:58:57.663	2025-10-05 22:58:57.661
260	13	5	t	\N	2025-10-05 22:58:57.664	2025-10-05 22:58:57.66
261	13	6	t	\N	2025-10-05 22:58:57.664	2025-10-05 22:58:57.66
165	7	2	t	\N	2025-09-01 17:28:08.935	2025-09-01 17:28:08.932
166	7	1	f	\N	2025-09-01 17:28:08.935	2025-09-01 17:28:08.932
167	7	9	f	\N	2025-09-01 17:28:08.936	2025-09-01 17:28:08.932
168	7	14	f	\N	2025-09-01 17:28:08.936	2025-09-01 17:28:08.932
169	7	3	t	\N	2025-09-01 17:28:08.936	2025-09-01 17:28:08.932
170	7	15	f	\N	2025-09-01 17:28:08.936	2025-09-01 17:28:08.932
171	7	11	f	\N	2025-09-01 17:28:08.936	2025-09-01 17:28:08.932
172	7	12	t	\N	2025-09-01 17:28:08.936	2025-09-01 17:28:08.932
173	7	13	f	\N	2025-09-01 17:28:08.936	2025-09-01 17:28:08.932
174	7	5	t	\N	2025-09-01 17:28:08.936	2025-09-01 17:28:08.932
175	7	7	t	\N	2025-09-01 17:28:08.936	2025-09-01 17:28:08.932
176	7	6	t	\N	2025-09-01 17:28:08.936	2025-09-01 17:28:08.932
177	7	8	t	\N	2025-09-01 17:28:08.936	2025-09-01 17:28:08.932
178	7	4	f	\N	2025-09-01 17:28:08.936	2025-09-01 17:28:08.932
179	8	1	t	en la parte trasera presenta 2 rayones	2025-09-01 20:09:02.063	2025-09-01 20:09:02.059
180	8	2	t	\N	2025-09-01 20:09:02.063	2025-09-01 20:09:02.059
181	8	11	f	\N	2025-09-01 20:09:02.063	2025-09-01 20:09:02.06
182	8	9	f	\N	2025-09-01 20:09:02.063	2025-09-01 20:09:02.059
183	8	15	t	\N	2025-09-01 20:09:02.063	2025-09-01 20:09:02.061
184	8	14	f	\N	2025-09-01 20:09:02.063	2025-09-01 20:09:02.061
185	8	3	t	\N	2025-09-01 20:09:02.063	2025-09-01 20:09:02.059
186	8	12	t	\N	2025-09-01 20:09:02.063	2025-09-01 20:09:02.061
187	8	4	t	\N	2025-09-01 20:09:02.063	2025-09-01 20:09:02.059
188	8	13	t	\N	2025-09-01 20:09:02.063	2025-09-01 20:09:02.061
189	8	7	t	\N	2025-09-01 20:09:02.063	2025-09-01 20:09:02.059
190	8	5	t	\N	2025-09-01 20:09:02.063	2025-09-01 20:09:02.059
191	8	6	t	\N	2025-09-01 20:09:02.063	2025-09-01 20:09:02.059
192	8	8	t	Un poco desprendida de la parte superior derecha	2025-09-01 20:09:02.063	2025-09-01 20:09:02.059
262	13	4	t	\N	2025-10-05 22:58:57.664	2025-10-05 22:58:57.66
263	14	1	t	\N	2025-10-07 17:34:47.773	2025-10-07 17:34:47.771
265	14	3	t	\N	2025-10-07 17:34:47.773	2025-10-07 17:34:47.771
264	14	9	f	\N	2025-10-07 17:34:47.774	2025-10-07 17:34:47.771
266	14	4	t	\N	2025-10-07 17:34:47.774	2025-10-07 17:34:47.771
267	14	11	t	\N	2025-10-07 17:34:47.774	2025-10-07 17:34:47.771
268	14	12	f	\N	2025-10-07 17:34:47.774	2025-10-07 17:34:47.771
269	14	2	t	\N	2025-10-07 17:34:47.774	2025-10-07 17:34:47.771
270	14	13	t	\N	2025-10-07 17:34:47.774	2025-10-07 17:34:47.771
271	14	15	t	\N	2025-10-07 17:34:47.775	2025-10-07 17:34:47.771
272	14	14	t	\N	2025-10-07 17:34:47.775	2025-10-07 17:34:47.771
273	14	5	t	\N	2025-10-07 17:34:47.775	2025-10-07 17:34:47.771
274	14	6	t	\N	2025-10-07 17:34:47.775	2025-10-07 17:34:47.771
275	14	7	t	\N	2025-10-07 17:34:47.775	2025-10-07 17:34:47.771
276	14	8	f	\N	2025-10-07 17:34:47.776	2025-10-07 17:34:47.771
291	17	1	t	tapa trasera	2025-10-27 22:35:50.567	2025-10-27 22:35:50.557
292	17	2	t	\N	2025-10-27 22:35:50.567	2025-10-27 22:35:50.557
293	17	11	t	\N	2025-10-27 22:35:50.567	2025-10-27 22:35:50.557
294	17	14	t	\N	2025-10-27 22:35:50.567	2025-10-27 22:35:50.56
295	17	12	t	\N	2025-10-27 22:35:50.567	2025-10-27 22:35:50.557
296	17	9	f	\N	2025-10-27 22:35:50.567	2025-10-27 22:35:50.557
297	17	15	t	\N	2025-10-27 22:35:50.567	2025-10-27 22:35:50.56
298	17	3	t	\N	2025-10-27 22:35:50.567	2025-10-27 22:35:50.557
299	17	13	t	\N	2025-10-27 22:35:50.567	2025-10-27 22:35:50.557
300	17	4	t	\N	2025-10-27 22:35:50.568	2025-10-27 22:35:50.557
301	17	5	t	\N	2025-10-27 22:35:50.568	2025-10-27 22:35:50.557
302	17	7	f	se entrega al cliente 	2025-10-27 22:35:50.568	2025-10-27 22:35:50.557
303	17	8	f	\N	2025-10-27 22:35:50.568	2025-10-27 22:35:50.557
304	17	6	f	no se puede 	2025-10-27 22:35:50.568	2025-10-27 22:35:50.557
\.
COPY public.checklist_respuesta_reparacion (id, checklist_reparacion_id, checklist_item_id, respuesta, observaciones, created_at, updated_at) FROM stdin;
374	27	1	f	\N	2025-09-08 19:54:27.25	2025-09-08 19:54:27.25
375	27	2	t	\N	2025-09-08 19:54:27.254	2025-09-08 19:54:27.254
376	27	3	t	\N	2025-09-08 19:54:27.258	2025-09-08 19:54:27.258
377	27	4	t	\N	2025-09-08 19:54:27.26	2025-09-08 19:54:27.26
378	27	5	t	\N	2025-09-08 19:54:27.264	2025-09-08 19:54:27.264
379	27	6	t	\N	2025-09-08 19:54:27.266	2025-09-08 19:54:27.266
380	27	7	t	\N	2025-09-08 19:54:27.271	2025-09-08 19:54:27.271
381	27	8	t	\N	2025-09-08 19:54:27.276	2025-09-08 19:54:27.276
382	27	9	f	\N	2025-09-08 19:54:27.283	2025-09-08 19:54:27.283
383	27	10	t	\N	2025-09-08 19:54:27.286	2025-09-08 19:54:27.286
384	27	11	f	\N	2025-09-08 19:54:27.29	2025-09-08 19:54:27.29
385	27	12	t	\N	2025-09-08 19:54:27.296	2025-09-08 19:54:27.296
386	27	13	t	\N	2025-09-08 19:54:27.299	2025-09-08 19:54:27.299
387	27	14	t	\N	2025-09-08 19:54:27.307	2025-09-08 19:54:27.307
388	27	15	f	\N	2025-09-08 19:54:27.312	2025-09-08 19:54:27.312
404	31	1	f	\N	2025-09-10 16:36:30.886	2025-09-10 16:36:30.886
405	31	2	f	\N	2025-09-10 16:36:30.889	2025-09-10 16:36:30.889
406	31	3	f	\N	2025-09-10 16:36:30.891	2025-09-10 16:36:30.891
407	31	4	f	\N	2025-09-10 16:36:30.892	2025-09-10 16:36:30.892
408	31	5	f	\N	2025-09-10 16:36:30.894	2025-09-10 16:36:30.894
409	31	6	f	\N	2025-09-10 16:36:30.895	2025-09-10 16:36:30.895
410	31	7	f	\N	2025-09-10 16:36:30.897	2025-09-10 16:36:30.897
411	31	8	f	\N	2025-09-10 16:36:30.899	2025-09-10 16:36:30.899
412	31	9	f	\N	2025-09-10 16:36:30.902	2025-09-10 16:36:30.902
413	31	10	f	\N	2025-09-10 16:36:30.906	2025-09-10 16:36:30.906
414	31	11	f	\N	2025-09-10 16:36:30.909	2025-09-10 16:36:30.909
415	31	12	f	\N	2025-09-10 16:36:30.911	2025-09-10 16:36:30.911
416	31	13	f	\N	2025-09-10 16:36:30.914	2025-09-10 16:36:30.914
417	31	14	f	\N	2025-09-10 16:36:30.916	2025-09-10 16:36:30.916
418	31	15	f	\N	2025-09-10 16:36:30.917	2025-09-10 16:36:30.917
434	33	1	f	\N	2025-09-11 18:24:42.529	2025-09-11 18:24:42.529
435	33	2	f	\N	2025-09-11 18:24:42.531	2025-09-11 18:24:42.531
436	33	3	f	\N	2025-09-11 18:24:42.534	2025-09-11 18:24:42.534
437	33	4	f	\N	2025-09-11 18:24:42.536	2025-09-11 18:24:42.536
438	33	5	f	\N	2025-09-11 18:24:42.54	2025-09-11 18:24:42.54
439	33	6	f	\N	2025-09-11 18:24:42.542	2025-09-11 18:24:42.542
440	33	7	f	\N	2025-09-11 18:24:42.545	2025-09-11 18:24:42.545
441	33	8	f	\N	2025-09-11 18:24:42.548	2025-09-11 18:24:42.548
442	33	9	f	\N	2025-09-11 18:24:42.551	2025-09-11 18:24:42.551
443	33	10	f	\N	2025-09-11 18:24:42.554	2025-09-11 18:24:42.554
444	33	11	f	\N	2025-09-11 18:24:42.556	2025-09-11 18:24:42.556
445	33	12	f	\N	2025-09-11 18:24:42.557	2025-09-11 18:24:42.557
446	33	13	f	\N	2025-09-11 18:24:42.56	2025-09-11 18:24:42.56
447	33	14	f	\N	2025-09-11 18:24:42.561	2025-09-11 18:24:42.561
448	33	15	f	\N	2025-09-11 18:24:42.566	2025-09-11 18:24:42.566
464	34	1	f	\N	2025-09-13 20:20:44.684	2025-09-13 20:20:44.684
465	34	2	f	\N	2025-09-13 20:20:44.687	2025-09-13 20:20:44.687
466	34	3	f	\N	2025-09-13 20:20:44.69	2025-09-13 20:20:44.69
467	34	4	f	\N	2025-09-13 20:20:44.695	2025-09-13 20:20:44.695
468	34	5	f	\N	2025-09-13 20:20:44.697	2025-09-13 20:20:44.697
469	34	6	f	\N	2025-09-13 20:20:44.7	2025-09-13 20:20:44.7
470	34	7	f	\N	2025-09-13 20:20:44.702	2025-09-13 20:20:44.702
471	34	8	f	\N	2025-09-13 20:20:44.704	2025-09-13 20:20:44.704
472	34	9	f	\N	2025-09-13 20:20:44.707	2025-09-13 20:20:44.707
473	34	10	f	\N	2025-09-13 20:20:44.711	2025-09-13 20:20:44.711
474	34	11	f	\N	2025-09-13 20:20:44.715	2025-09-13 20:20:44.715
475	34	12	f	\N	2025-09-13 20:20:44.718	2025-09-13 20:20:44.718
476	34	13	f	\N	2025-09-13 20:20:44.72	2025-09-13 20:20:44.72
477	34	14	f	\N	2025-09-13 20:20:44.726	2025-09-13 20:20:44.726
478	34	15	f	\N	2025-09-13 20:20:44.728	2025-09-13 20:20:44.728
539	36	1	f	\N	2025-09-13 23:50:25.199	2025-09-13 23:50:25.199
540	36	2	f	\N	2025-09-13 23:50:25.202	2025-09-13 23:50:25.202
541	36	3	f	\N	2025-09-13 23:50:25.204	2025-09-13 23:50:25.204
542	36	4	f	\N	2025-09-13 23:50:25.207	2025-09-13 23:50:25.207
543	36	5	f	\N	2025-09-13 23:50:25.209	2025-09-13 23:50:25.209
544	36	6	f	\N	2025-09-13 23:50:25.211	2025-09-13 23:50:25.211
545	36	7	f	\N	2025-09-13 23:50:25.213	2025-09-13 23:50:25.213
546	36	8	f	\N	2025-09-13 23:50:25.216	2025-09-13 23:50:25.216
547	36	9	f	\N	2025-09-13 23:50:25.218	2025-09-13 23:50:25.218
548	36	10	f	\N	2025-09-13 23:50:25.22	2025-09-13 23:50:25.22
549	36	11	f	\N	2025-09-13 23:50:25.222	2025-09-13 23:50:25.222
550	36	12	f	\N	2025-09-13 23:50:25.226	2025-09-13 23:50:25.226
551	36	13	f	\N	2025-09-13 23:50:25.228	2025-09-13 23:50:25.228
552	36	14	f	\N	2025-09-13 23:50:25.231	2025-09-13 23:50:25.231
553	36	15	f	\N	2025-09-13 23:50:25.233	2025-09-13 23:50:25.233
569	41	1	f	\N	2025-09-17 20:02:44.808	2025-09-17 20:02:44.808
570	41	2	f	\N	2025-09-17 20:02:44.81	2025-09-17 20:02:44.81
571	41	3	f	\N	2025-09-17 20:02:44.812	2025-09-17 20:02:44.812
572	41	4	f	\N	2025-09-17 20:02:44.814	2025-09-17 20:02:44.814
573	41	5	f	\N	2025-09-17 20:02:44.816	2025-09-17 20:02:44.816
574	41	6	f	\N	2025-09-17 20:02:44.817	2025-09-17 20:02:44.817
575	41	7	f	\N	2025-09-17 20:02:44.819	2025-09-17 20:02:44.819
576	41	8	f	\N	2025-09-17 20:02:44.821	2025-09-17 20:02:44.821
577	41	9	f	\N	2025-09-17 20:02:44.823	2025-09-17 20:02:44.823
578	41	10	f	\N	2025-09-17 20:02:44.825	2025-09-17 20:02:44.825
579	41	11	f	\N	2025-09-17 20:02:44.826	2025-09-17 20:02:44.826
580	41	12	f	\N	2025-09-17 20:02:44.828	2025-09-17 20:02:44.828
581	41	13	f	\N	2025-09-17 20:02:44.83	2025-09-17 20:02:44.83
582	41	14	f	\N	2025-09-17 20:02:44.831	2025-09-17 20:02:44.831
583	41	15	f	\N	2025-09-17 20:02:44.833	2025-09-17 20:02:44.833
599	43	15	f	\N	2025-09-21 00:04:47.522	2025-09-21 00:04:47.522
600	43	1	f	\N	2025-09-21 00:04:47.526	2025-09-21 00:04:47.526
601	43	2	t	\N	2025-09-21 00:04:47.529	2025-09-21 00:04:47.529
602	43	3	f	\N	2025-09-21 00:04:47.531	2025-09-21 00:04:47.531
603	43	4	f	\N	2025-09-21 00:04:47.534	2025-09-21 00:04:47.534
604	43	5	f	\N	2025-09-21 00:04:47.537	2025-09-21 00:04:47.537
605	43	6	f	\N	2025-09-21 00:04:47.54	2025-09-21 00:04:47.54
606	43	7	f	\N	2025-09-21 00:04:47.543	2025-09-21 00:04:47.543
607	43	8	f	\N	2025-09-21 00:04:47.546	2025-09-21 00:04:47.546
608	43	9	f	\N	2025-09-21 00:04:47.55	2025-09-21 00:04:47.55
609	43	10	f	\N	2025-09-21 00:04:47.56	2025-09-21 00:04:47.56
610	43	11	f	\N	2025-09-21 00:04:47.567	2025-09-21 00:04:47.567
611	43	12	f	\N	2025-09-21 00:04:47.576	2025-09-21 00:04:47.576
612	43	13	f	\N	2025-09-21 00:04:47.583	2025-09-21 00:04:47.583
613	43	14	f	\N	2025-09-21 00:04:47.586	2025-09-21 00:04:47.586
614	45	1	f	\N	2025-09-21 00:07:12.082	2025-09-21 00:07:12.082
615	45	2	t	\N	2025-09-21 00:07:12.085	2025-09-21 00:07:12.085
616	45	3	f	\N	2025-09-21 00:07:12.088	2025-09-21 00:07:12.088
617	45	4	f	\N	2025-09-21 00:07:12.091	2025-09-21 00:07:12.091
618	45	5	f	\N	2025-09-21 00:07:12.095	2025-09-21 00:07:12.095
619	45	6	f	\N	2025-09-21 00:07:12.098	2025-09-21 00:07:12.098
620	45	7	f	\N	2025-09-21 00:07:12.1	2025-09-21 00:07:12.1
621	45	8	f	\N	2025-09-21 00:07:12.103	2025-09-21 00:07:12.103
622	45	9	f	\N	2025-09-21 00:07:12.106	2025-09-21 00:07:12.106
623	45	10	f	\N	2025-09-21 00:07:12.11	2025-09-21 00:07:12.11
624	45	11	f	\N	2025-09-21 00:07:12.113	2025-09-21 00:07:12.113
625	45	12	f	\N	2025-09-21 00:07:12.115	2025-09-21 00:07:12.115
626	45	13	f	\N	2025-09-21 00:07:12.118	2025-09-21 00:07:12.118
627	45	14	f	\N	2025-09-21 00:07:12.12	2025-09-21 00:07:12.12
628	45	15	f	\N	2025-09-21 00:07:12.124	2025-09-21 00:07:12.124
629	46	1	f	\N	2025-09-21 20:58:13.929	2025-09-21 20:58:13.929
630	46	2	f	\N	2025-09-21 20:58:13.932	2025-09-21 20:58:13.932
631	46	3	f	\N	2025-09-21 20:58:13.935	2025-09-21 20:58:13.935
632	46	4	f	\N	2025-09-21 20:58:13.938	2025-09-21 20:58:13.938
633	46	5	f	\N	2025-09-21 20:58:13.941	2025-09-21 20:58:13.941
634	46	6	f	\N	2025-09-21 20:58:13.944	2025-09-21 20:58:13.944
635	46	7	f	\N	2025-09-21 20:58:13.948	2025-09-21 20:58:13.948
636	46	8	f	\N	2025-09-21 20:58:13.95	2025-09-21 20:58:13.95
637	46	9	f	\N	2025-09-21 20:58:13.956	2025-09-21 20:58:13.956
638	46	10	f	\N	2025-09-21 20:58:13.96	2025-09-21 20:58:13.96
639	46	11	f	\N	2025-09-21 20:58:13.962	2025-09-21 20:58:13.962
640	46	12	f	\N	2025-09-21 20:58:13.965	2025-09-21 20:58:13.965
641	46	13	f	\N	2025-09-21 20:58:13.967	2025-09-21 20:58:13.967
642	46	14	f	\N	2025-09-21 20:58:13.97	2025-09-21 20:58:13.97
314	24	1	t	tapa dañada (estrellada)	2025-09-06 22:37:30.117	2025-09-06 22:37:30.117
315	24	2	t	\N	2025-09-06 22:37:30.121	2025-09-06 22:37:30.121
316	24	3	t	\N	2025-09-06 22:37:30.125	2025-09-06 22:37:30.125
317	24	4	t	\N	2025-09-06 22:37:30.128	2025-09-06 22:37:30.128
318	24	5	t	\N	2025-09-06 22:37:30.132	2025-09-06 22:37:30.132
319	24	6	t	\N	2025-09-06 22:37:30.135	2025-09-06 22:37:30.135
320	24	7	t	\N	2025-09-06 22:37:30.14	2025-09-06 22:37:30.14
321	24	8	f	\N	2025-09-06 22:37:30.144	2025-09-06 22:37:30.144
322	24	9	f	\N	2025-09-06 22:37:30.148	2025-09-06 22:37:30.148
323	24	10	t	\N	2025-09-06 22:37:30.153	2025-09-06 22:37:30.153
324	24	11	t	\N	2025-09-06 22:37:30.156	2025-09-06 22:37:30.156
325	24	12	t	\N	2025-09-06 22:37:30.161	2025-09-06 22:37:30.161
326	24	13	t	\N	2025-09-06 22:37:30.164	2025-09-06 22:37:30.164
327	24	14	t	\N	2025-09-06 22:37:30.168	2025-09-06 22:37:30.168
328	24	15	f	\N	2025-09-06 22:37:30.17	2025-09-06 22:37:30.17
779	56	1	f	\N	2025-09-26 22:45:40.607	2025-09-26 22:45:40.607
239	20	1	f	\N	2025-09-01 17:36:29.603	2025-09-01 17:36:29.603
240	20	2	t	\N	2025-09-01 17:36:29.606	2025-09-01 17:36:29.606
241	20	3	t	\N	2025-09-01 17:36:29.608	2025-09-01 17:36:29.608
242	20	4	t	\N	2025-09-01 17:36:29.611	2025-09-01 17:36:29.611
243	20	5	t	\N	2025-09-01 17:36:29.613	2025-09-01 17:36:29.613
244	20	6	t	\N	2025-09-01 17:36:29.614	2025-09-01 17:36:29.614
245	20	7	t	\N	2025-09-01 17:36:29.616	2025-09-01 17:36:29.616
246	20	8	f	\N	2025-09-01 17:36:29.619	2025-09-01 17:36:29.619
247	20	9	f	\N	2025-09-01 17:36:29.621	2025-09-01 17:36:29.621
248	20	10	f	\N	2025-09-01 17:36:29.624	2025-09-01 17:36:29.624
249	20	11	f	\N	2025-09-01 17:36:29.626	2025-09-01 17:36:29.626
250	20	12	t	\N	2025-09-01 17:36:29.628	2025-09-01 17:36:29.628
251	20	13	f	\N	2025-09-01 17:36:29.629	2025-09-01 17:36:29.629
252	20	14	t	\N	2025-09-01 17:36:29.633	2025-09-01 17:36:29.633
253	20	15	f	\N	2025-09-01 17:36:29.637	2025-09-01 17:36:29.637
780	56	2	f	\N	2025-09-26 22:45:40.611	2025-09-26 22:45:40.611
781	56	3	f	\N	2025-09-26 22:45:40.613	2025-09-26 22:45:40.613
782	56	4	f	\N	2025-09-26 22:45:40.615	2025-09-26 22:45:40.615
783	56	5	f	\N	2025-09-26 22:45:40.62	2025-09-26 22:45:40.62
784	56	6	f	\N	2025-09-26 22:45:40.623	2025-09-26 22:45:40.623
785	56	7	f	\N	2025-09-26 22:45:40.627	2025-09-26 22:45:40.627
786	56	8	f	\N	2025-09-26 22:45:40.629	2025-09-26 22:45:40.629
787	56	9	f	\N	2025-09-26 22:45:40.633	2025-09-26 22:45:40.633
788	56	10	f	\N	2025-09-26 22:45:40.637	2025-09-26 22:45:40.637
789	56	11	f	\N	2025-09-26 22:45:40.638	2025-09-26 22:45:40.638
790	56	12	f	\N	2025-09-26 22:45:40.641	2025-09-26 22:45:40.641
791	56	13	f	\N	2025-09-26 22:45:40.643	2025-09-26 22:45:40.643
792	56	14	f	\N	2025-09-26 22:45:40.645	2025-09-26 22:45:40.645
793	56	15	f	\N	2025-09-26 22:45:40.647	2025-09-26 22:45:40.647
524	38	1	f	\N	2025-09-13 23:49:46.782	2025-09-13 23:49:46.782
269	21	1	f	\N	2025-09-01 19:00:42.412	2025-09-01 19:00:42.412
270	21	2	f	\N	2025-09-01 19:00:42.415	2025-09-01 19:00:42.415
271	21	3	f	\N	2025-09-01 19:00:42.417	2025-09-01 19:00:42.417
272	21	4	f	\N	2025-09-01 19:00:42.419	2025-09-01 19:00:42.419
273	21	5	f	\N	2025-09-01 19:00:42.423	2025-09-01 19:00:42.423
274	21	6	f	\N	2025-09-01 19:00:42.425	2025-09-01 19:00:42.425
275	21	7	f	\N	2025-09-01 19:00:42.427	2025-09-01 19:00:42.427
276	21	8	f	\N	2025-09-01 19:00:42.428	2025-09-01 19:00:42.428
277	21	9	f	\N	2025-09-01 19:00:42.431	2025-09-01 19:00:42.431
278	21	10	f	\N	2025-09-01 19:00:42.432	2025-09-01 19:00:42.432
279	21	11	f	\N	2025-09-01 19:00:42.434	2025-09-01 19:00:42.434
280	21	12	f	\N	2025-09-01 19:00:42.435	2025-09-01 19:00:42.435
281	21	13	f	\N	2025-09-01 19:00:42.439	2025-09-01 19:00:42.439
282	21	14	f	\N	2025-09-01 19:00:42.441	2025-09-01 19:00:42.441
283	21	15	f	\N	2025-09-01 19:00:42.443	2025-09-01 19:00:42.443
284	23	1	f	\N	2025-09-01 21:17:46.394	2025-09-01 21:17:46.394
285	23	2	f	\N	2025-09-01 21:17:46.396	2025-09-01 21:17:46.396
286	23	3	f	\N	2025-09-01 21:17:46.398	2025-09-01 21:17:46.398
287	23	4	f	\N	2025-09-01 21:17:46.402	2025-09-01 21:17:46.402
288	23	5	f	\N	2025-09-01 21:17:46.403	2025-09-01 21:17:46.403
289	23	6	f	\N	2025-09-01 21:17:46.405	2025-09-01 21:17:46.405
290	23	7	f	\N	2025-09-01 21:17:46.406	2025-09-01 21:17:46.406
291	23	8	f	\N	2025-09-01 21:17:46.408	2025-09-01 21:17:46.408
292	23	9	f	\N	2025-09-01 21:17:46.409	2025-09-01 21:17:46.409
293	23	10	f	\N	2025-09-01 21:17:46.412	2025-09-01 21:17:46.412
294	23	11	f	\N	2025-09-01 21:17:46.414	2025-09-01 21:17:46.414
295	23	12	f	\N	2025-09-01 21:17:46.417	2025-09-01 21:17:46.417
296	23	13	f	\N	2025-09-01 21:17:46.418	2025-09-01 21:17:46.418
297	23	14	f	\N	2025-09-01 21:17:46.421	2025-09-01 21:17:46.421
298	23	15	f	\N	2025-09-01 21:17:46.423	2025-09-01 21:17:46.423
525	38	2	f	\N	2025-09-13 23:49:46.784	2025-09-13 23:49:46.784
526	38	3	f	\N	2025-09-13 23:49:46.787	2025-09-13 23:49:46.787
527	38	4	f	\N	2025-09-13 23:49:46.79	2025-09-13 23:49:46.79
528	38	5	f	\N	2025-09-13 23:49:46.792	2025-09-13 23:49:46.792
529	38	6	f	\N	2025-09-13 23:49:46.795	2025-09-13 23:49:46.795
530	38	7	f	\N	2025-09-13 23:49:46.798	2025-09-13 23:49:46.798
531	38	8	f	\N	2025-09-13 23:49:46.802	2025-09-13 23:49:46.802
532	38	9	f	\N	2025-09-13 23:49:46.806	2025-09-13 23:49:46.806
533	38	10	f	\N	2025-09-13 23:49:46.811	2025-09-13 23:49:46.811
534	38	11	f	\N	2025-09-13 23:49:46.814	2025-09-13 23:49:46.814
535	38	12	f	\N	2025-09-13 23:49:46.818	2025-09-13 23:49:46.818
536	38	13	f	\N	2025-09-13 23:49:46.821	2025-09-13 23:49:46.821
537	38	14	f	\N	2025-09-13 23:49:46.825	2025-09-13 23:49:46.825
538	38	15	f	\N	2025-09-13 23:49:46.828	2025-09-13 23:49:46.828
389	30	1	f	\N	2025-09-10 00:00:51.275	2025-09-10 00:00:51.275
390	30	2	f	\N	2025-09-10 00:00:51.277	2025-09-10 00:00:51.277
391	30	3	f	\N	2025-09-10 00:00:51.28	2025-09-10 00:00:51.28
392	30	4	f	\N	2025-09-10 00:00:51.281	2025-09-10 00:00:51.281
393	30	5	f	\N	2025-09-10 00:00:51.283	2025-09-10 00:00:51.283
394	30	6	f	\N	2025-09-10 00:00:51.285	2025-09-10 00:00:51.285
395	30	7	f	\N	2025-09-10 00:00:51.287	2025-09-10 00:00:51.287
396	30	8	f	\N	2025-09-10 00:00:51.289	2025-09-10 00:00:51.289
397	30	9	f	\N	2025-09-10 00:00:51.292	2025-09-10 00:00:51.292
398	30	10	f	\N	2025-09-10 00:00:51.293	2025-09-10 00:00:51.293
399	30	11	f	\N	2025-09-10 00:00:51.296	2025-09-10 00:00:51.296
400	30	12	f	\N	2025-09-10 00:00:51.297	2025-09-10 00:00:51.297
401	30	13	f	\N	2025-09-10 00:00:51.299	2025-09-10 00:00:51.299
402	30	14	f	\N	2025-09-10 00:00:51.3	2025-09-10 00:00:51.3
403	30	15	f	\N	2025-09-10 00:00:51.303	2025-09-10 00:00:51.303
419	26	1	f	\N	2025-09-10 18:43:21.406	2025-09-10 18:43:21.406
420	26	2	f	\N	2025-09-10 18:43:21.409	2025-09-10 18:43:21.409
421	26	3	f	\N	2025-09-10 18:43:21.411	2025-09-10 18:43:21.411
422	26	4	f	\N	2025-09-10 18:43:21.414	2025-09-10 18:43:21.414
423	26	5	f	\N	2025-09-10 18:43:21.416	2025-09-10 18:43:21.416
424	26	6	f	\N	2025-09-10 18:43:21.418	2025-09-10 18:43:21.418
425	26	7	f	\N	2025-09-10 18:43:21.42	2025-09-10 18:43:21.42
426	26	8	f	\N	2025-09-10 18:43:21.423	2025-09-10 18:43:21.423
427	26	9	f	\N	2025-09-10 18:43:21.425	2025-09-10 18:43:21.425
428	26	10	f	\N	2025-09-10 18:43:21.427	2025-09-10 18:43:21.427
429	26	11	f	\N	2025-09-10 18:43:21.429	2025-09-10 18:43:21.429
430	26	12	f	\N	2025-09-10 18:43:21.431	2025-09-10 18:43:21.431
431	26	13	f	\N	2025-09-10 18:43:21.433	2025-09-10 18:43:21.433
432	26	14	f	\N	2025-09-10 18:43:21.435	2025-09-10 18:43:21.435
433	26	15	f	\N	2025-09-10 18:43:21.439	2025-09-10 18:43:21.439
818	57	10	f	\N	2025-09-26 23:07:45.288	2025-09-26 23:07:45.288
819	57	11	f	\N	2025-09-26 23:07:45.295	2025-09-26 23:07:45.295
820	57	12	f	\N	2025-09-26 23:07:45.297	2025-09-26 23:07:45.297
821	57	13	f	\N	2025-09-26 23:07:45.299	2025-09-26 23:07:45.299
822	57	14	f	\N	2025-09-26 23:07:45.3	2025-09-26 23:07:45.3
823	57	15	f	\N	2025-09-26 23:07:45.301	2025-09-26 23:07:45.301
839	60	1	f	\N	2025-09-27 20:11:05.259	2025-09-27 20:11:05.259
840	60	2	f	\N	2025-09-27 20:11:05.263	2025-09-27 20:11:05.263
841	60	3	f	\N	2025-09-27 20:11:05.265	2025-09-27 20:11:05.265
842	60	4	f	\N	2025-09-27 20:11:05.267	2025-09-27 20:11:05.267
843	60	5	f	\N	2025-09-27 20:11:05.269	2025-09-27 20:11:05.269
844	60	6	f	\N	2025-09-27 20:11:05.271	2025-09-27 20:11:05.271
845	60	7	t	\N	2025-09-27 20:11:05.273	2025-09-27 20:11:05.273
846	60	8	t	\N	2025-09-27 20:11:05.275	2025-09-27 20:11:05.275
847	60	9	f	\N	2025-09-27 20:11:05.277	2025-09-27 20:11:05.277
643	46	15	f	\N	2025-09-21 20:58:13.973	2025-09-21 20:58:13.973
644	47	1	f	\N	2025-09-22 23:41:30.063	2025-09-22 23:41:30.063
645	47	2	f	\N	2025-09-22 23:41:30.065	2025-09-22 23:41:30.065
646	47	3	f	\N	2025-09-22 23:41:30.067	2025-09-22 23:41:30.067
647	47	4	f	\N	2025-09-22 23:41:30.071	2025-09-22 23:41:30.071
648	47	5	f	\N	2025-09-22 23:41:30.073	2025-09-22 23:41:30.073
649	47	6	f	\N	2025-09-22 23:41:30.076	2025-09-22 23:41:30.076
650	47	7	f	\N	2025-09-22 23:41:30.077	2025-09-22 23:41:30.077
651	47	8	f	\N	2025-09-22 23:41:30.083	2025-09-22 23:41:30.083
652	47	9	f	\N	2025-09-22 23:41:30.085	2025-09-22 23:41:30.085
653	47	10	f	\N	2025-09-22 23:41:30.088	2025-09-22 23:41:30.088
654	47	11	f	\N	2025-09-22 23:41:30.091	2025-09-22 23:41:30.091
655	47	12	f	\N	2025-09-22 23:41:30.094	2025-09-22 23:41:30.094
656	47	13	f	\N	2025-09-22 23:41:30.097	2025-09-22 23:41:30.097
657	47	14	f	\N	2025-09-22 23:41:30.099	2025-09-22 23:41:30.099
658	47	15	f	\N	2025-09-22 23:41:30.102	2025-09-22 23:41:30.102
659	48	1	f	\N	2025-09-23 16:35:11.396	2025-09-23 16:35:11.396
660	48	2	t	\N	2025-09-23 16:35:11.401	2025-09-23 16:35:11.401
661	48	3	t	\N	2025-09-23 16:35:11.404	2025-09-23 16:35:11.404
662	48	4	t	\N	2025-09-23 16:35:11.407	2025-09-23 16:35:11.407
663	48	5	t	\N	2025-09-23 16:35:11.41	2025-09-23 16:35:11.41
664	48	6	t	\N	2025-09-23 16:35:11.413	2025-09-23 16:35:11.413
665	48	7	t	\N	2025-09-23 16:35:11.415	2025-09-23 16:35:11.415
666	48	8	t	\N	2025-09-23 16:35:11.418	2025-09-23 16:35:11.418
667	48	9	f	\N	2025-09-23 16:35:11.421	2025-09-23 16:35:11.421
668	48	10	f	\N	2025-09-23 16:35:11.424	2025-09-23 16:35:11.424
669	48	11	f	\N	2025-09-23 16:35:11.426	2025-09-23 16:35:11.426
670	48	12	f	\N	2025-09-23 16:35:11.429	2025-09-23 16:35:11.429
671	48	13	f	\N	2025-09-23 16:35:11.432	2025-09-23 16:35:11.432
672	48	14	f	\N	2025-09-23 16:35:11.434	2025-09-23 16:35:11.434
673	48	15	f	\N	2025-09-23 16:35:11.436	2025-09-23 16:35:11.436
2144	147	1	f	\N	2025-11-01 18:13:32.147	2025-11-01 18:13:32.147
2145	147	2	f	\N	2025-11-01 18:13:32.15	2025-11-01 18:13:32.15
2146	147	3	f	\N	2025-11-01 18:13:32.152	2025-11-01 18:13:32.152
2147	147	4	f	\N	2025-11-01 18:13:32.155	2025-11-01 18:13:32.155
2148	147	5	f	\N	2025-11-01 18:13:32.157	2025-11-01 18:13:32.157
2149	147	6	f	\N	2025-11-01 18:13:32.159	2025-11-01 18:13:32.159
2150	147	7	f	\N	2025-11-01 18:13:32.16	2025-11-01 18:13:32.16
2151	147	8	f	\N	2025-11-01 18:13:32.162	2025-11-01 18:13:32.162
2152	147	9	f	\N	2025-11-01 18:13:32.163	2025-11-01 18:13:32.163
2153	147	10	f	\N	2025-11-01 18:13:32.165	2025-11-01 18:13:32.165
2154	147	11	f	\N	2025-11-01 18:13:32.167	2025-11-01 18:13:32.167
2155	147	12	f	\N	2025-11-01 18:13:32.169	2025-11-01 18:13:32.169
2156	147	13	f	\N	2025-11-01 18:13:32.171	2025-11-01 18:13:32.171
2157	147	14	f	\N	2025-11-01 18:13:32.173	2025-11-01 18:13:32.173
2158	147	15	f	\N	2025-11-01 18:13:32.175	2025-11-01 18:13:32.175
689	49	1	f	\N	2025-09-23 16:41:08.979	2025-09-23 16:41:08.979
690	49	2	t	\N	2025-09-23 16:41:08.982	2025-09-23 16:41:08.982
691	49	3	t	\N	2025-09-23 16:41:08.984	2025-09-23 16:41:08.984
692	49	4	t	\N	2025-09-23 16:41:08.986	2025-09-23 16:41:08.986
693	49	5	t	\N	2025-09-23 16:41:08.988	2025-09-23 16:41:08.988
694	49	6	t	\N	2025-09-23 16:41:08.99	2025-09-23 16:41:08.99
695	49	7	t	\N	2025-09-23 16:41:08.994	2025-09-23 16:41:08.994
696	49	8	t	\N	2025-09-23 16:41:08.996	2025-09-23 16:41:08.997
697	49	9	f	\N	2025-09-23 16:41:08.999	2025-09-23 16:41:08.999
698	49	10	f	\N	2025-09-23 16:41:09.001	2025-09-23 16:41:09.001
699	49	11	f	\N	2025-09-23 16:41:09.004	2025-09-23 16:41:09.004
700	49	12	f	\N	2025-09-23 16:41:09.005	2025-09-23 16:41:09.005
701	49	13	f	\N	2025-09-23 16:41:09.008	2025-09-23 16:41:09.008
702	49	14	f	\N	2025-09-23 16:41:09.01	2025-09-23 16:41:09.01
703	49	15	f	\N	2025-09-23 16:41:09.015	2025-09-23 16:41:09.015
704	51	1	f	\N	2025-09-23 22:05:35.801	2025-09-23 22:05:35.801
705	51	2	f	\N	2025-09-23 22:05:35.804	2025-09-23 22:05:35.804
706	51	3	f	\N	2025-09-23 22:05:35.808	2025-09-23 22:05:35.808
707	51	4	f	\N	2025-09-23 22:05:35.811	2025-09-23 22:05:35.811
708	51	5	f	\N	2025-09-23 22:05:35.814	2025-09-23 22:05:35.814
709	51	6	f	\N	2025-09-23 22:05:35.817	2025-09-23 22:05:35.817
710	51	7	f	\N	2025-09-23 22:05:35.82	2025-09-23 22:05:35.82
711	51	8	f	\N	2025-09-23 22:05:35.822	2025-09-23 22:05:35.822
712	51	9	f	\N	2025-09-23 22:05:35.824	2025-09-23 22:05:35.824
713	51	10	f	\N	2025-09-23 22:05:35.827	2025-09-23 22:05:35.827
714	51	11	f	\N	2025-09-23 22:05:35.829	2025-09-23 22:05:35.829
715	51	12	f	\N	2025-09-23 22:05:35.831	2025-09-23 22:05:35.831
716	51	13	f	\N	2025-09-23 22:05:35.835	2025-09-23 22:05:35.835
717	51	14	f	\N	2025-09-23 22:05:35.838	2025-09-23 22:05:35.838
718	51	15	f	\N	2025-09-23 22:05:35.841	2025-09-23 22:05:35.841
809	57	1	f	\N	2025-09-26 23:07:45.272	2025-09-26 23:07:45.272
810	57	2	f	\N	2025-09-26 23:07:45.274	2025-09-26 23:07:45.274
811	57	3	f	\N	2025-09-26 23:07:45.276	2025-09-26 23:07:45.276
812	57	4	f	\N	2025-09-26 23:07:45.278	2025-09-26 23:07:45.278
813	57	5	f	\N	2025-09-26 23:07:45.28	2025-09-26 23:07:45.28
814	57	6	f	\N	2025-09-26 23:07:45.281	2025-09-26 23:07:45.281
815	57	7	f	\N	2025-09-26 23:07:45.283	2025-09-26 23:07:45.283
816	57	8	f	\N	2025-09-26 23:07:45.285	2025-09-26 23:07:45.285
817	57	9	f	\N	2025-09-26 23:07:45.287	2025-09-26 23:07:45.287
824	59	1	f	\N	2025-09-26 23:51:09.295	2025-09-26 23:51:09.295
825	59	2	f	\N	2025-09-26 23:51:09.3	2025-09-26 23:51:09.3
826	59	3	f	\N	2025-09-26 23:51:09.303	2025-09-26 23:51:09.303
827	59	4	f	\N	2025-09-26 23:51:09.306	2025-09-26 23:51:09.306
828	59	5	f	\N	2025-09-26 23:51:09.308	2025-09-26 23:51:09.308
829	59	6	f	\N	2025-09-26 23:51:09.311	2025-09-26 23:51:09.311
734	52	1	f	\N	2025-09-23 22:12:55.945	2025-09-23 22:12:55.945
735	52	2	t	\N	2025-09-23 22:12:55.947	2025-09-23 22:12:55.947
736	52	3	t	\N	2025-09-23 22:12:55.95	2025-09-23 22:12:55.95
737	52	4	f	\N	2025-09-23 22:12:55.953	2025-09-23 22:12:55.953
738	52	5	f	\N	2025-09-23 22:12:55.955	2025-09-23 22:12:55.955
739	52	6	f	\N	2025-09-23 22:12:55.957	2025-09-23 22:12:55.957
740	52	7	f	\N	2025-09-23 22:12:55.96	2025-09-23 22:12:55.96
741	52	8	f	\N	2025-09-23 22:12:55.963	2025-09-23 22:12:55.963
742	52	9	f	\N	2025-09-23 22:12:55.965	2025-09-23 22:12:55.965
743	52	10	f	\N	2025-09-23 22:12:55.968	2025-09-23 22:12:55.968
744	52	11	f	\N	2025-09-23 22:12:55.972	2025-09-23 22:12:55.972
745	52	12	f	\N	2025-09-23 22:12:55.978	2025-09-23 22:12:55.978
746	52	13	f	\N	2025-09-23 22:12:55.984	2025-09-23 22:12:55.984
747	52	14	f	\N	2025-09-23 22:12:55.991	2025-09-23 22:12:55.991
748	52	15	f	\N	2025-09-23 22:12:55.995	2025-09-23 22:12:55.995
830	59	7	f	\N	2025-09-26 23:51:09.315	2025-09-26 23:51:09.315
831	59	8	f	\N	2025-09-26 23:51:09.317	2025-09-26 23:51:09.317
832	59	9	f	\N	2025-09-26 23:51:09.32	2025-09-26 23:51:09.32
833	59	10	f	\N	2025-09-26 23:51:09.323	2025-09-26 23:51:09.323
834	59	11	f	\N	2025-09-26 23:51:09.326	2025-09-26 23:51:09.326
835	59	12	f	\N	2025-09-26 23:51:09.329	2025-09-26 23:51:09.329
836	59	13	f	\N	2025-09-26 23:51:09.332	2025-09-26 23:51:09.332
837	59	14	f	\N	2025-09-26 23:51:09.335	2025-09-26 23:51:09.335
838	59	15	f	\N	2025-09-26 23:51:09.338	2025-09-26 23:51:09.338
848	60	10	f	\N	2025-09-27 20:11:05.279	2025-09-27 20:11:05.279
849	60	11	f	\N	2025-09-27 20:11:05.281	2025-09-27 20:11:05.281
850	60	12	f	\N	2025-09-27 20:11:05.283	2025-09-27 20:11:05.283
851	60	13	f	\N	2025-09-27 20:11:05.285	2025-09-27 20:11:05.285
852	60	14	f	\N	2025-09-27 20:11:05.287	2025-09-27 20:11:05.287
853	60	15	f	\N	2025-09-27 20:11:05.29	2025-09-27 20:11:05.29
764	54	1	f	\N	2025-09-23 22:16:51.929	2025-09-23 22:16:51.929
765	54	2	t	\N	2025-09-23 22:16:51.932	2025-09-23 22:16:51.932
766	54	3	t	\N	2025-09-23 22:16:51.934	2025-09-23 22:16:51.934
767	54	4	f	\N	2025-09-23 22:16:51.937	2025-09-23 22:16:51.937
768	54	5	f	\N	2025-09-23 22:16:51.939	2025-09-23 22:16:51.939
769	54	6	f	\N	2025-09-23 22:16:51.941	2025-09-23 22:16:51.941
770	54	7	f	\N	2025-09-23 22:16:51.944	2025-09-23 22:16:51.944
771	54	8	f	\N	2025-09-23 22:16:51.946	2025-09-23 22:16:51.946
772	54	9	f	\N	2025-09-23 22:16:51.948	2025-09-23 22:16:51.948
773	54	10	f	\N	2025-09-23 22:16:51.951	2025-09-23 22:16:51.951
774	54	11	f	\N	2025-09-23 22:16:51.952	2025-09-23 22:16:51.952
775	54	12	f	\N	2025-09-23 22:16:51.955	2025-09-23 22:16:51.955
776	54	13	f	\N	2025-09-23 22:16:51.959	2025-09-23 22:16:51.959
777	54	14	f	\N	2025-09-23 22:16:51.962	2025-09-23 22:16:51.962
778	54	15	f	\N	2025-09-23 22:16:51.964	2025-09-23 22:16:51.964
869	61	1	f	\N	2025-09-27 20:13:12.959	2025-09-27 20:13:12.959
870	61	2	f	\N	2025-09-27 20:13:12.962	2025-09-27 20:13:12.962
871	61	3	f	\N	2025-09-27 20:13:12.965	2025-09-27 20:13:12.965
872	61	4	f	\N	2025-09-27 20:13:12.967	2025-09-27 20:13:12.967
873	61	5	f	\N	2025-09-27 20:13:12.97	2025-09-27 20:13:12.97
874	61	6	f	\N	2025-09-27 20:13:12.972	2025-09-27 20:13:12.972
875	61	7	f	\N	2025-09-27 20:13:12.975	2025-09-27 20:13:12.975
876	61	8	f	\N	2025-09-27 20:13:12.977	2025-09-27 20:13:12.977
877	61	9	f	\N	2025-09-27 20:13:12.98	2025-09-27 20:13:12.98
878	61	10	f	\N	2025-09-27 20:13:12.982	2025-09-27 20:13:12.982
879	61	11	f	\N	2025-09-27 20:13:12.986	2025-09-27 20:13:12.986
880	61	12	f	\N	2025-09-27 20:13:12.988	2025-09-27 20:13:12.988
881	61	13	f	\N	2025-09-27 20:13:12.992	2025-09-27 20:13:12.992
882	61	14	f	\N	2025-09-27 20:13:12.995	2025-09-27 20:13:12.995
883	61	15	f	\N	2025-09-27 20:13:12.997	2025-09-27 20:13:12.997
884	63	1	f	\N	2025-09-27 20:16:57.502	2025-09-27 20:16:57.502
885	63	2	f	\N	2025-09-27 20:16:57.508	2025-09-27 20:16:57.508
886	63	3	f	\N	2025-09-27 20:16:57.511	2025-09-27 20:16:57.511
887	63	4	f	\N	2025-09-27 20:16:57.513	2025-09-27 20:16:57.513
888	63	5	f	\N	2025-09-27 20:16:57.518	2025-09-27 20:16:57.518
889	63	6	f	\N	2025-09-27 20:16:57.52	2025-09-27 20:16:57.52
890	63	7	f	\N	2025-09-27 20:16:57.523	2025-09-27 20:16:57.523
891	63	8	f	\N	2025-09-27 20:16:57.525	2025-09-27 20:16:57.525
892	63	9	f	\N	2025-09-27 20:16:57.527	2025-09-27 20:16:57.527
893	63	10	f	\N	2025-09-27 20:16:57.53	2025-09-27 20:16:57.53
894	63	11	f	\N	2025-09-27 20:16:57.533	2025-09-27 20:16:57.533
895	63	12	f	\N	2025-09-27 20:16:57.538	2025-09-27 20:16:57.538
896	63	13	f	\N	2025-09-27 20:16:57.541	2025-09-27 20:16:57.541
897	63	14	f	\N	2025-09-27 20:16:57.546	2025-09-27 20:16:57.546
898	63	15	f	\N	2025-09-27 20:16:57.55	2025-09-27 20:16:57.55
899	64	1	f	\N	2025-09-27 23:40:17.222	2025-09-27 23:40:17.222
900	64	2	f	\N	2025-09-27 23:40:17.226	2025-09-27 23:40:17.226
901	64	3	f	\N	2025-09-27 23:40:17.229	2025-09-27 23:40:17.229
902	64	4	f	\N	2025-09-27 23:40:17.231	2025-09-27 23:40:17.231
903	64	5	f	\N	2025-09-27 23:40:17.233	2025-09-27 23:40:17.233
904	64	6	f	\N	2025-09-27 23:40:17.236	2025-09-27 23:40:17.236
905	64	7	f	\N	2025-09-27 23:40:17.238	2025-09-27 23:40:17.238
906	64	8	f	\N	2025-09-27 23:40:17.241	2025-09-27 23:40:17.241
907	64	9	f	\N	2025-09-27 23:40:17.244	2025-09-27 23:40:17.244
908	64	10	f	\N	2025-09-27 23:40:17.246	2025-09-27 23:40:17.246
909	64	11	f	\N	2025-09-27 23:40:17.249	2025-09-27 23:40:17.249
910	64	12	f	\N	2025-09-27 23:40:17.251	2025-09-27 23:40:17.251
911	64	13	f	\N	2025-09-27 23:40:17.255	2025-09-27 23:40:17.255
912	64	14	f	\N	2025-09-27 23:40:17.257	2025-09-27 23:40:17.257
913	64	15	f	\N	2025-09-27 23:40:17.259	2025-09-27 23:40:17.259
914	65	1	f	\N	2025-09-28 19:35:28.163	2025-09-28 19:35:28.163
915	65	2	f	\N	2025-09-28 19:35:28.167	2025-09-28 19:35:28.167
916	65	3	f	\N	2025-09-28 19:35:28.17	2025-09-28 19:35:28.17
917	65	4	f	\N	2025-09-28 19:35:28.173	2025-09-28 19:35:28.173
918	65	5	f	\N	2025-09-28 19:35:28.176	2025-09-28 19:35:28.176
919	65	6	f	\N	2025-09-28 19:35:28.18	2025-09-28 19:35:28.18
920	65	7	f	\N	2025-09-28 19:35:28.182	2025-09-28 19:35:28.182
921	65	8	f	\N	2025-09-28 19:35:28.186	2025-09-28 19:35:28.186
922	65	9	f	\N	2025-09-28 19:35:28.188	2025-09-28 19:35:28.188
923	65	10	f	\N	2025-09-28 19:35:28.191	2025-09-28 19:35:28.191
924	65	11	f	\N	2025-09-28 19:35:28.194	2025-09-28 19:35:28.194
925	65	12	f	\N	2025-09-28 19:35:28.197	2025-09-28 19:35:28.197
926	65	13	f	\N	2025-09-28 19:35:28.199	2025-09-28 19:35:28.199
927	65	14	f	\N	2025-09-28 19:35:28.202	2025-09-28 19:35:28.202
928	65	15	f	\N	2025-09-28 19:35:28.205	2025-09-28 19:35:28.205
929	66	1	f	\N	2025-09-28 21:06:57.562	2025-09-28 21:06:57.562
930	66	2	f	\N	2025-09-28 21:06:57.566	2025-09-28 21:06:57.566
931	66	3	f	\N	2025-09-28 21:06:57.569	2025-09-28 21:06:57.569
932	66	4	f	\N	2025-09-28 21:06:57.572	2025-09-28 21:06:57.572
933	66	5	f	\N	2025-09-28 21:06:57.575	2025-09-28 21:06:57.575
934	66	6	f	\N	2025-09-28 21:06:57.577	2025-09-28 21:06:57.577
935	66	7	f	\N	2025-09-28 21:06:57.579	2025-09-28 21:06:57.579
936	66	8	f	\N	2025-09-28 21:06:57.581	2025-09-28 21:06:57.581
937	66	9	f	\N	2025-09-28 21:06:57.584	2025-09-28 21:06:57.584
938	66	10	f	\N	2025-09-28 21:06:57.586	2025-09-28 21:06:57.586
939	66	11	f	\N	2025-09-28 21:06:57.591	2025-09-28 21:06:57.591
940	66	12	f	\N	2025-09-28 21:06:57.594	2025-09-28 21:06:57.594
941	66	13	f	\N	2025-09-28 21:06:57.597	2025-09-28 21:06:57.597
942	66	14	f	\N	2025-09-28 21:06:57.6	2025-09-28 21:06:57.6
943	66	15	f	\N	2025-09-28 21:06:57.603	2025-09-28 21:06:57.603
944	67	1	f	\N	2025-09-29 21:48:59.791	2025-09-29 21:48:59.791
945	67	2	f	\N	2025-09-29 21:48:59.795	2025-09-29 21:48:59.795
946	67	3	f	\N	2025-09-29 21:48:59.798	2025-09-29 21:48:59.798
947	67	4	f	\N	2025-09-29 21:48:59.802	2025-09-29 21:48:59.802
948	67	5	f	\N	2025-09-29 21:48:59.806	2025-09-29 21:48:59.806
949	67	6	f	\N	2025-09-29 21:48:59.809	2025-09-29 21:48:59.809
950	67	7	f	\N	2025-09-29 21:48:59.812	2025-09-29 21:48:59.812
951	67	8	f	\N	2025-09-29 21:48:59.815	2025-09-29 21:48:59.815
952	67	9	f	\N	2025-09-29 21:48:59.818	2025-09-29 21:48:59.818
953	67	10	f	\N	2025-09-29 21:48:59.821	2025-09-29 21:48:59.821
954	67	11	f	\N	2025-09-29 21:48:59.826	2025-09-29 21:48:59.826
955	67	12	f	\N	2025-09-29 21:48:59.829	2025-09-29 21:48:59.829
956	67	13	f	\N	2025-09-29 21:48:59.831	2025-09-29 21:48:59.831
957	67	14	f	\N	2025-09-29 21:48:59.834	2025-09-29 21:48:59.834
958	67	15	f	\N	2025-09-29 21:48:59.837	2025-09-29 21:48:59.837
974	68	1	f	\N	2025-09-30 22:49:17.45	2025-09-30 22:49:17.45
975	68	2	f	\N	2025-09-30 22:49:17.453	2025-09-30 22:49:17.453
976	68	3	f	\N	2025-09-30 22:49:17.456	2025-09-30 22:49:17.456
977	68	4	f	\N	2025-09-30 22:49:17.459	2025-09-30 22:49:17.459
978	68	5	f	\N	2025-09-30 22:49:17.464	2025-09-30 22:49:17.464
979	68	6	f	\N	2025-09-30 22:49:17.467	2025-09-30 22:49:17.467
980	68	7	f	\N	2025-09-30 22:49:17.469	2025-09-30 22:49:17.469
981	68	8	f	\N	2025-09-30 22:49:17.472	2025-09-30 22:49:17.472
982	68	9	f	\N	2025-09-30 22:49:17.475	2025-09-30 22:49:17.475
983	68	10	f	\N	2025-09-30 22:49:17.478	2025-09-30 22:49:17.478
984	68	11	f	\N	2025-09-30 22:49:17.481	2025-09-30 22:49:17.481
985	68	12	f	\N	2025-09-30 22:49:17.483	2025-09-30 22:49:17.483
986	68	13	f	\N	2025-09-30 22:49:17.485	2025-09-30 22:49:17.485
987	68	14	f	\N	2025-09-30 22:49:17.487	2025-09-30 22:49:17.487
988	68	15	f	\N	2025-09-30 22:49:17.49	2025-09-30 22:49:17.49
989	70	1	f	\N	2025-09-30 23:03:39.121	2025-09-30 23:03:39.121
990	70	2	f	\N	2025-09-30 23:03:39.124	2025-09-30 23:03:39.124
991	70	3	f	\N	2025-09-30 23:03:39.127	2025-09-30 23:03:39.127
992	70	4	f	\N	2025-09-30 23:03:39.13	2025-09-30 23:03:39.13
993	70	5	f	\N	2025-09-30 23:03:39.134	2025-09-30 23:03:39.134
994	70	6	f	\N	2025-09-30 23:03:39.138	2025-09-30 23:03:39.138
995	70	7	f	\N	2025-09-30 23:03:39.143	2025-09-30 23:03:39.143
996	70	8	f	\N	2025-09-30 23:03:39.145	2025-09-30 23:03:39.145
997	70	9	f	\N	2025-09-30 23:03:39.147	2025-09-30 23:03:39.147
998	70	10	f	\N	2025-09-30 23:03:39.151	2025-09-30 23:03:39.151
999	70	11	f	\N	2025-09-30 23:03:39.154	2025-09-30 23:03:39.154
1000	70	12	f	\N	2025-09-30 23:03:39.156	2025-09-30 23:03:39.156
1001	70	13	f	\N	2025-09-30 23:03:39.158	2025-09-30 23:03:39.158
1002	70	14	f	\N	2025-09-30 23:03:39.161	2025-09-30 23:03:39.161
1003	70	15	f	\N	2025-09-30 23:03:39.163	2025-09-30 23:03:39.163
1004	71	1	f	\N	2025-10-01 21:25:29.234	2025-10-01 21:25:29.234
1005	71	2	f	\N	2025-10-01 21:25:29.242	2025-10-01 21:25:29.242
1006	71	3	f	\N	2025-10-01 21:25:29.247	2025-10-01 21:25:29.247
1007	71	4	f	\N	2025-10-01 21:25:29.25	2025-10-01 21:25:29.25
1008	71	5	f	\N	2025-10-01 21:25:29.254	2025-10-01 21:25:29.254
1009	71	6	f	\N	2025-10-01 21:25:29.26	2025-10-01 21:25:29.26
1010	71	7	f	\N	2025-10-01 21:25:29.264	2025-10-01 21:25:29.264
1011	71	8	f	\N	2025-10-01 21:25:29.268	2025-10-01 21:25:29.268
1012	71	9	f	\N	2025-10-01 21:25:29.27	2025-10-01 21:25:29.27
1013	71	10	f	\N	2025-10-01 21:25:29.276	2025-10-01 21:25:29.276
1014	71	11	f	\N	2025-10-01 21:25:29.278	2025-10-01 21:25:29.278
1015	71	12	f	\N	2025-10-01 21:25:29.282	2025-10-01 21:25:29.282
1016	71	13	f	\N	2025-10-01 21:25:29.285	2025-10-01 21:25:29.285
1017	71	14	f	\N	2025-10-01 21:25:29.293	2025-10-01 21:25:29.293
1018	71	15	f	\N	2025-10-01 21:25:29.297	2025-10-01 21:25:29.297
1364	94	1	f	\N	2025-10-09 23:05:22.628	2025-10-09 23:05:22.628
1365	94	2	f	\N	2025-10-09 23:05:22.63	2025-10-09 23:05:22.63
1366	94	3	f	\N	2025-10-09 23:05:22.633	2025-10-09 23:05:22.633
1367	94	4	f	\N	2025-10-09 23:05:22.635	2025-10-09 23:05:22.635
1368	94	5	f	\N	2025-10-09 23:05:22.638	2025-10-09 23:05:22.638
1369	94	6	f	\N	2025-10-09 23:05:22.639	2025-10-09 23:05:22.639
1370	94	7	f	\N	2025-10-09 23:05:22.641	2025-10-09 23:05:22.641
1371	94	8	f	\N	2025-10-09 23:05:22.643	2025-10-09 23:05:22.643
1372	94	9	f	\N	2025-10-09 23:05:22.645	2025-10-09 23:05:22.645
1373	94	10	f	\N	2025-10-09 23:05:22.649	2025-10-09 23:05:22.649
1374	94	11	f	\N	2025-10-09 23:05:22.651	2025-10-09 23:05:22.651
1375	94	12	f	\N	2025-10-09 23:05:22.653	2025-10-09 23:05:22.653
1376	94	13	f	\N	2025-10-09 23:05:22.656	2025-10-09 23:05:22.656
1377	94	14	f	\N	2025-10-09 23:05:22.658	2025-10-09 23:05:22.658
1378	94	15	f	\N	2025-10-09 23:05:22.661	2025-10-09 23:05:22.661
1034	72	1	f	\N	2025-10-01 23:20:49.659	2025-10-01 23:20:49.659
1035	72	2	f	\N	2025-10-01 23:20:49.661	2025-10-01 23:20:49.661
1036	72	3	f	\N	2025-10-01 23:20:49.664	2025-10-01 23:20:49.664
1037	72	4	f	\N	2025-10-01 23:20:49.665	2025-10-01 23:20:49.665
1038	72	5	f	\N	2025-10-01 23:20:49.668	2025-10-01 23:20:49.668
1039	72	6	f	\N	2025-10-01 23:20:49.671	2025-10-01 23:20:49.671
1040	72	7	f	\N	2025-10-01 23:20:49.673	2025-10-01 23:20:49.673
1041	72	8	f	\N	2025-10-01 23:20:49.674	2025-10-01 23:20:49.674
1042	72	9	f	\N	2025-10-01 23:20:49.676	2025-10-01 23:20:49.676
1043	72	10	f	\N	2025-10-01 23:20:49.678	2025-10-01 23:20:49.678
1044	72	11	f	\N	2025-10-01 23:20:49.68	2025-10-01 23:20:49.68
1045	72	12	f	\N	2025-10-01 23:20:49.684	2025-10-01 23:20:49.684
1046	72	13	f	\N	2025-10-01 23:20:49.687	2025-10-01 23:20:49.687
1047	72	14	f	\N	2025-10-01 23:20:49.688	2025-10-01 23:20:49.688
1048	72	15	f	\N	2025-10-01 23:20:49.689	2025-10-01 23:20:49.689
1049	74	1	f	\N	2025-10-01 23:57:46.106	2025-10-01 23:57:46.106
1050	74	2	f	\N	2025-10-01 23:57:46.109	2025-10-01 23:57:46.109
1051	74	3	f	\N	2025-10-01 23:57:46.112	2025-10-01 23:57:46.112
1052	74	4	f	\N	2025-10-01 23:57:46.116	2025-10-01 23:57:46.116
1053	74	5	f	\N	2025-10-01 23:57:46.12	2025-10-01 23:57:46.12
1054	74	6	f	\N	2025-10-01 23:57:46.122	2025-10-01 23:57:46.122
1055	74	7	f	\N	2025-10-01 23:57:46.124	2025-10-01 23:57:46.124
1056	74	8	f	\N	2025-10-01 23:57:46.126	2025-10-01 23:57:46.126
1057	74	9	f	\N	2025-10-01 23:57:46.128	2025-10-01 23:57:46.128
1058	74	10	f	\N	2025-10-01 23:57:46.132	2025-10-01 23:57:46.132
1059	74	11	f	\N	2025-10-01 23:57:46.137	2025-10-01 23:57:46.137
1060	74	12	f	\N	2025-10-01 23:57:46.142	2025-10-01 23:57:46.142
1061	74	13	f	\N	2025-10-01 23:57:46.147	2025-10-01 23:57:46.147
1062	74	14	f	\N	2025-10-01 23:57:46.151	2025-10-01 23:57:46.151
1063	74	15	f	\N	2025-10-01 23:57:46.158	2025-10-01 23:57:46.158
1079	75	1	f	\N	2025-10-04 16:49:31.346	2025-10-04 16:49:31.346
1080	75	2	f	\N	2025-10-04 16:49:31.349	2025-10-04 16:49:31.349
1081	75	3	f	\N	2025-10-04 16:49:31.352	2025-10-04 16:49:31.352
1082	75	4	f	\N	2025-10-04 16:49:31.355	2025-10-04 16:49:31.355
1083	75	5	f	\N	2025-10-04 16:49:31.359	2025-10-04 16:49:31.359
1084	75	6	f	\N	2025-10-04 16:49:31.361	2025-10-04 16:49:31.361
1085	75	7	f	\N	2025-10-04 16:49:31.363	2025-10-04 16:49:31.363
1086	75	8	f	\N	2025-10-04 16:49:31.367	2025-10-04 16:49:31.367
1087	75	9	f	\N	2025-10-04 16:49:31.369	2025-10-04 16:49:31.369
1088	75	10	f	\N	2025-10-04 16:49:31.372	2025-10-04 16:49:31.372
1089	75	11	f	\N	2025-10-04 16:49:31.375	2025-10-04 16:49:31.375
1090	75	12	f	\N	2025-10-04 16:49:31.377	2025-10-04 16:49:31.377
1091	75	13	f	\N	2025-10-04 16:49:31.379	2025-10-04 16:49:31.379
1092	75	14	f	\N	2025-10-04 16:49:31.382	2025-10-04 16:49:31.382
1093	75	15	f	\N	2025-10-04 16:49:31.384	2025-10-04 16:49:31.384
1094	77	1	f	\N	2025-10-06 21:42:02.332	2025-10-06 21:42:02.332
1095	77	2	f	\N	2025-10-06 21:42:02.339	2025-10-06 21:42:02.339
1096	77	3	f	\N	2025-10-06 21:42:02.341	2025-10-06 21:42:02.341
1097	77	4	f	\N	2025-10-06 21:42:02.344	2025-10-06 21:42:02.344
1098	77	5	f	\N	2025-10-06 21:42:02.346	2025-10-06 21:42:02.346
1099	77	6	f	\N	2025-10-06 21:42:02.349	2025-10-06 21:42:02.349
1100	77	7	f	\N	2025-10-06 21:42:02.352	2025-10-06 21:42:02.352
1101	77	8	f	\N	2025-10-06 21:42:02.354	2025-10-06 21:42:02.354
1102	77	9	f	\N	2025-10-06 21:42:02.357	2025-10-06 21:42:02.357
1103	77	10	f	\N	2025-10-06 21:42:02.361	2025-10-06 21:42:02.361
1104	77	11	f	\N	2025-10-06 21:42:02.363	2025-10-06 21:42:02.363
1105	77	12	f	\N	2025-10-06 21:42:02.365	2025-10-06 21:42:02.365
1106	77	13	f	\N	2025-10-06 21:42:02.368	2025-10-06 21:42:02.368
1107	77	14	f	\N	2025-10-06 21:42:02.371	2025-10-06 21:42:02.371
1108	77	15	f	\N	2025-10-06 21:42:02.373	2025-10-06 21:42:02.373
1109	78	1	f	\N	2025-10-07 16:05:13.828	2025-10-07 16:05:13.828
1110	78	2	f	\N	2025-10-07 16:05:13.831	2025-10-07 16:05:13.831
1111	78	3	f	\N	2025-10-07 16:05:13.835	2025-10-07 16:05:13.835
1112	78	4	f	\N	2025-10-07 16:05:13.838	2025-10-07 16:05:13.838
1113	78	5	f	\N	2025-10-07 16:05:13.84	2025-10-07 16:05:13.84
1114	78	6	f	\N	2025-10-07 16:05:13.843	2025-10-07 16:05:13.843
1115	78	7	f	\N	2025-10-07 16:05:13.846	2025-10-07 16:05:13.846
1116	78	8	f	\N	2025-10-07 16:05:13.849	2025-10-07 16:05:13.849
1117	78	9	f	\N	2025-10-07 16:05:13.852	2025-10-07 16:05:13.852
1118	78	10	f	\N	2025-10-07 16:05:13.855	2025-10-07 16:05:13.855
1119	78	11	f	\N	2025-10-07 16:05:13.857	2025-10-07 16:05:13.857
1120	78	12	f	\N	2025-10-07 16:05:13.86	2025-10-07 16:05:13.86
1121	78	13	f	\N	2025-10-07 16:05:13.864	2025-10-07 16:05:13.864
1122	78	14	f	\N	2025-10-07 16:05:13.87	2025-10-07 16:05:13.87
1123	78	15	f	\N	2025-10-07 16:05:13.873	2025-10-07 16:05:13.873
1124	79	1	f	\N	2025-10-07 23:21:43.261	2025-10-07 23:21:43.261
1125	79	2	f	\N	2025-10-07 23:21:43.266	2025-10-07 23:21:43.266
1126	79	3	f	\N	2025-10-07 23:21:43.274	2025-10-07 23:21:43.274
1127	79	4	f	\N	2025-10-07 23:21:43.279	2025-10-07 23:21:43.279
1128	79	5	f	\N	2025-10-07 23:21:43.284	2025-10-07 23:21:43.284
1129	79	6	f	\N	2025-10-07 23:21:43.287	2025-10-07 23:21:43.287
1130	79	7	f	\N	2025-10-07 23:21:43.29	2025-10-07 23:21:43.29
1131	79	8	f	\N	2025-10-07 23:21:43.299	2025-10-07 23:21:43.299
1132	79	9	f	\N	2025-10-07 23:21:43.302	2025-10-07 23:21:43.302
1133	79	10	f	\N	2025-10-07 23:21:43.306	2025-10-07 23:21:43.306
1134	79	11	f	\N	2025-10-07 23:21:43.31	2025-10-07 23:21:43.31
1135	79	12	f	\N	2025-10-07 23:21:43.314	2025-10-07 23:21:43.314
1136	79	13	f	\N	2025-10-07 23:21:43.316	2025-10-07 23:21:43.316
1137	79	14	f	\N	2025-10-07 23:21:43.319	2025-10-07 23:21:43.319
1138	79	15	f	\N	2025-10-07 23:21:43.321	2025-10-07 23:21:43.321
1154	81	1	f	\N	2025-10-08 20:09:07.269	2025-10-08 20:09:07.269
1155	81	2	f	\N	2025-10-08 20:09:07.271	2025-10-08 20:09:07.271
1156	81	3	f	\N	2025-10-08 20:09:07.273	2025-10-08 20:09:07.273
1157	81	4	f	\N	2025-10-08 20:09:07.275	2025-10-08 20:09:07.275
1158	81	5	f	\N	2025-10-08 20:09:07.278	2025-10-08 20:09:07.278
1159	81	6	f	\N	2025-10-08 20:09:07.28	2025-10-08 20:09:07.28
1160	81	7	f	\N	2025-10-08 20:09:07.286	2025-10-08 20:09:07.286
1161	81	8	f	\N	2025-10-08 20:09:07.289	2025-10-08 20:09:07.289
1162	81	9	f	\N	2025-10-08 20:09:07.291	2025-10-08 20:09:07.291
1163	81	10	f	\N	2025-10-08 20:09:07.292	2025-10-08 20:09:07.292
1164	81	11	f	\N	2025-10-08 20:09:07.294	2025-10-08 20:09:07.294
1165	81	12	f	\N	2025-10-08 20:09:07.295	2025-10-08 20:09:07.295
1166	81	13	f	\N	2025-10-08 20:09:07.298	2025-10-08 20:09:07.298
1167	81	14	f	\N	2025-10-08 20:09:07.303	2025-10-08 20:09:07.303
1168	81	15	f	\N	2025-10-08 20:09:07.305	2025-10-08 20:09:07.305
1169	82	1	f	\N	2025-10-08 20:22:07.291	2025-10-08 20:22:07.291
1170	82	2	f	\N	2025-10-08 20:22:07.297	2025-10-08 20:22:07.297
1171	82	3	f	\N	2025-10-08 20:22:07.3	2025-10-08 20:22:07.3
1172	82	4	f	\N	2025-10-08 20:22:07.303	2025-10-08 20:22:07.303
1173	82	5	f	\N	2025-10-08 20:22:07.305	2025-10-08 20:22:07.305
1174	82	6	f	\N	2025-10-08 20:22:07.308	2025-10-08 20:22:07.308
1175	82	7	f	\N	2025-10-08 20:22:07.312	2025-10-08 20:22:07.312
1176	82	8	f	\N	2025-10-08 20:22:07.314	2025-10-08 20:22:07.314
1177	82	9	f	\N	2025-10-08 20:22:07.316	2025-10-08 20:22:07.316
1178	82	10	f	\N	2025-10-08 20:22:07.319	2025-10-08 20:22:07.319
1179	82	11	f	\N	2025-10-08 20:22:07.324	2025-10-08 20:22:07.324
1180	82	12	f	\N	2025-10-08 20:22:07.328	2025-10-08 20:22:07.328
1181	82	13	f	\N	2025-10-08 20:22:07.33	2025-10-08 20:22:07.33
1182	82	14	f	\N	2025-10-08 20:22:07.333	2025-10-08 20:22:07.333
1183	82	15	f	\N	2025-10-08 20:22:07.335	2025-10-08 20:22:07.335
1184	80	1	f	\N	2025-10-08 22:25:00.635	2025-10-08 22:25:00.635
1185	80	2	f	\N	2025-10-08 22:25:00.64	2025-10-08 22:25:00.64
1186	80	3	f	\N	2025-10-08 22:25:00.643	2025-10-08 22:25:00.643
1187	80	4	f	\N	2025-10-08 22:25:00.648	2025-10-08 22:25:00.648
1188	80	5	f	\N	2025-10-08 22:25:00.652	2025-10-08 22:25:00.652
1189	80	6	f	\N	2025-10-08 22:25:00.658	2025-10-08 22:25:00.658
1190	80	7	f	\N	2025-10-08 22:25:00.662	2025-10-08 22:25:00.662
1191	80	8	f	\N	2025-10-08 22:25:00.665	2025-10-08 22:25:00.665
1192	80	9	f	\N	2025-10-08 22:25:00.67	2025-10-08 22:25:00.67
1193	80	10	f	\N	2025-10-08 22:25:00.673	2025-10-08 22:25:00.673
1194	80	11	f	\N	2025-10-08 22:25:00.675	2025-10-08 22:25:00.675
1195	80	12	f	\N	2025-10-08 22:25:00.68	2025-10-08 22:25:00.68
1196	80	13	f	\N	2025-10-08 22:25:00.686	2025-10-08 22:25:00.686
1197	80	14	f	\N	2025-10-08 22:25:00.69	2025-10-08 22:25:00.69
1198	80	15	f	\N	2025-10-08 22:25:00.696	2025-10-08 22:25:00.696
2159	148	1	f	\N	2025-11-01 18:16:14.467	2025-11-01 18:16:14.467
2160	148	2	f	\N	2025-11-01 18:16:14.47	2025-11-01 18:16:14.47
2161	148	3	f	\N	2025-11-01 18:16:14.474	2025-11-01 18:16:14.474
2162	148	4	f	\N	2025-11-01 18:16:14.476	2025-11-01 18:16:14.476
2163	148	5	f	\N	2025-11-01 18:16:14.481	2025-11-01 18:16:14.481
2164	148	6	f	\N	2025-11-01 18:16:14.483	2025-11-01 18:16:14.483
2165	148	7	f	\N	2025-11-01 18:16:14.489	2025-11-01 18:16:14.489
2166	148	8	f	\N	2025-11-01 18:16:14.492	2025-11-01 18:16:14.492
2167	148	9	f	\N	2025-11-01 18:16:14.495	2025-11-01 18:16:14.495
2168	148	10	f	\N	2025-11-01 18:16:14.498	2025-11-01 18:16:14.498
2169	148	11	f	\N	2025-11-01 18:16:14.501	2025-11-01 18:16:14.501
2170	148	12	f	\N	2025-11-01 18:16:14.503	2025-11-01 18:16:14.503
2171	148	13	f	\N	2025-11-01 18:16:14.506	2025-11-01 18:16:14.506
2172	148	14	f	\N	2025-11-01 18:16:14.509	2025-11-01 18:16:14.509
2173	148	15	f	\N	2025-11-01 18:16:14.512	2025-11-01 18:16:14.512
1394	97	1	f	\N	2025-10-10 22:20:55.542	2025-10-10 22:20:55.542
1395	97	2	f	\N	2025-10-10 22:20:55.544	2025-10-10 22:20:55.544
1396	97	3	f	\N	2025-10-10 22:20:55.545	2025-10-10 22:20:55.545
1397	97	4	f	\N	2025-10-10 22:20:55.547	2025-10-10 22:20:55.547
1398	97	5	f	\N	2025-10-10 22:20:55.549	2025-10-10 22:20:55.549
1399	97	6	f	\N	2025-10-10 22:20:55.55	2025-10-10 22:20:55.55
1400	97	7	f	\N	2025-10-10 22:20:55.551	2025-10-10 22:20:55.551
1401	97	8	f	\N	2025-10-10 22:20:55.553	2025-10-10 22:20:55.553
1402	97	9	f	\N	2025-10-10 22:20:55.554	2025-10-10 22:20:55.554
1403	97	10	f	\N	2025-10-10 22:20:55.556	2025-10-10 22:20:55.556
1404	97	11	f	\N	2025-10-10 22:20:55.557	2025-10-10 22:20:55.557
1405	97	12	f	\N	2025-10-10 22:20:55.558	2025-10-10 22:20:55.558
1406	97	13	f	\N	2025-10-10 22:20:55.56	2025-10-10 22:20:55.56
1407	97	14	f	\N	2025-10-10 22:20:55.562	2025-10-10 22:20:55.562
1408	97	15	f	\N	2025-10-10 22:20:55.563	2025-10-10 22:20:55.563
1409	98	1	f	\N	2025-10-10 22:30:11.402	2025-10-10 22:30:11.402
1410	98	2	f	\N	2025-10-10 22:30:11.406	2025-10-10 22:30:11.406
1411	98	3	f	\N	2025-10-10 22:30:11.41	2025-10-10 22:30:11.41
1412	98	4	f	\N	2025-10-10 22:30:11.412	2025-10-10 22:30:11.412
1413	98	5	f	\N	2025-10-10 22:30:11.415	2025-10-10 22:30:11.415
1414	98	6	f	\N	2025-10-10 22:30:11.418	2025-10-10 22:30:11.418
1415	98	7	f	\N	2025-10-10 22:30:11.421	2025-10-10 22:30:11.421
1416	98	8	f	\N	2025-10-10 22:30:11.424	2025-10-10 22:30:11.424
1417	98	9	f	\N	2025-10-10 22:30:11.428	2025-10-10 22:30:11.428
1418	98	10	f	\N	2025-10-10 22:30:11.43	2025-10-10 22:30:11.43
1419	98	11	f	\N	2025-10-10 22:30:11.432	2025-10-10 22:30:11.432
1420	98	12	f	\N	2025-10-10 22:30:11.434	2025-10-10 22:30:11.434
1421	98	13	f	\N	2025-10-10 22:30:11.437	2025-10-10 22:30:11.437
1422	98	14	f	\N	2025-10-10 22:30:11.438	2025-10-10 22:30:11.438
1423	98	15	f	\N	2025-10-10 22:30:11.441	2025-10-10 22:30:11.441
1424	99	1	f	\N	2025-10-10 22:31:30.917	2025-10-10 22:31:30.917
1425	99	2	f	\N	2025-10-10 22:31:30.92	2025-10-10 22:31:30.92
1426	99	3	f	\N	2025-10-10 22:31:30.922	2025-10-10 22:31:30.922
1427	99	4	f	\N	2025-10-10 22:31:30.924	2025-10-10 22:31:30.924
1428	99	5	f	\N	2025-10-10 22:31:30.925	2025-10-10 22:31:30.925
1429	99	6	f	\N	2025-10-10 22:31:30.928	2025-10-10 22:31:30.928
1430	99	7	f	\N	2025-10-10 22:31:30.929	2025-10-10 22:31:30.929
1431	99	8	f	\N	2025-10-10 22:31:30.932	2025-10-10 22:31:30.932
1432	99	9	f	\N	2025-10-10 22:31:30.933	2025-10-10 22:31:30.933
1433	99	10	f	\N	2025-10-10 22:31:30.935	2025-10-10 22:31:30.935
1434	99	11	f	\N	2025-10-10 22:31:30.936	2025-10-10 22:31:30.936
1435	99	12	f	\N	2025-10-10 22:31:30.941	2025-10-10 22:31:30.941
1436	99	13	f	\N	2025-10-10 22:31:30.943	2025-10-10 22:31:30.943
1437	99	14	f	\N	2025-10-10 22:31:30.945	2025-10-10 22:31:30.945
1438	99	15	f	\N	2025-10-10 22:31:30.947	2025-10-10 22:31:30.947
2219	152	1	f	\N	2025-11-01 23:19:11.498	2025-11-01 23:19:11.498
2220	152	2	f	\N	2025-11-01 23:19:11.502	2025-11-01 23:19:11.502
2221	152	3	f	\N	2025-11-01 23:19:11.504	2025-11-01 23:19:11.504
2222	152	4	f	\N	2025-11-01 23:19:11.506	2025-11-01 23:19:11.506
2223	152	5	f	\N	2025-11-01 23:19:11.509	2025-11-01 23:19:11.509
2224	152	6	f	\N	2025-11-01 23:19:11.512	2025-11-01 23:19:11.512
2225	152	7	f	\N	2025-11-01 23:19:11.514	2025-11-01 23:19:11.514
2226	152	8	f	\N	2025-11-01 23:19:11.516	2025-11-01 23:19:11.516
2227	152	9	f	\N	2025-11-01 23:19:11.518	2025-11-01 23:19:11.518
2228	152	10	f	\N	2025-11-01 23:19:11.52	2025-11-01 23:19:11.52
2229	152	11	f	\N	2025-11-01 23:19:11.522	2025-11-01 23:19:11.522
2230	152	12	f	\N	2025-11-01 23:19:11.525	2025-11-01 23:19:11.525
2231	152	13	f	\N	2025-11-01 23:19:11.527	2025-11-01 23:19:11.527
2232	152	14	f	\N	2025-11-01 23:19:11.529	2025-11-01 23:19:11.529
2233	152	15	f	\N	2025-11-01 23:19:11.531	2025-11-01 23:19:11.531
2279	156	1	f	\N	2025-11-04 23:20:37.039	2025-11-04 23:20:37.039
2280	156	2	f	\N	2025-11-04 23:20:37.043	2025-11-04 23:20:37.043
2281	156	3	f	\N	2025-11-04 23:20:37.048	2025-11-04 23:20:37.048
2282	156	4	f	\N	2025-11-04 23:20:37.05	2025-11-04 23:20:37.05
2283	156	5	f	\N	2025-11-04 23:20:37.052	2025-11-04 23:20:37.052
2284	156	6	f	\N	2025-11-04 23:20:37.054	2025-11-04 23:20:37.054
2285	156	7	f	\N	2025-11-04 23:20:37.057	2025-11-04 23:20:37.057
2286	156	8	f	\N	2025-11-04 23:20:37.061	2025-11-04 23:20:37.061
2287	156	9	f	\N	2025-11-04 23:20:37.065	2025-11-04 23:20:37.065
2288	156	10	f	\N	2025-11-04 23:20:37.068	2025-11-04 23:20:37.068
2289	156	11	f	\N	2025-11-04 23:20:37.071	2025-11-04 23:20:37.071
2290	156	12	f	\N	2025-11-04 23:20:37.076	2025-11-04 23:20:37.076
2291	156	13	f	\N	2025-11-04 23:20:37.079	2025-11-04 23:20:37.079
2292	156	14	f	\N	2025-11-04 23:20:37.081	2025-11-04 23:20:37.081
2293	156	15	f	\N	2025-11-04 23:20:37.084	2025-11-04 23:20:37.084
1469	96	1	f	\N	2025-10-11 19:21:07.057	2025-10-11 19:21:07.057
1470	96	2	f	\N	2025-10-11 19:21:07.064	2025-10-11 19:21:07.064
1471	96	3	f	\N	2025-10-11 19:21:07.067	2025-10-11 19:21:07.067
1472	96	4	f	\N	2025-10-11 19:21:07.069	2025-10-11 19:21:07.069
1473	96	5	f	\N	2025-10-11 19:21:07.072	2025-10-11 19:21:07.072
1474	96	6	f	\N	2025-10-11 19:21:07.074	2025-10-11 19:21:07.074
1475	96	7	f	\N	2025-10-11 19:21:07.076	2025-10-11 19:21:07.077
1476	96	8	f	\N	2025-10-11 19:21:07.079	2025-10-11 19:21:07.079
1477	96	9	f	\N	2025-10-11 19:21:07.081	2025-10-11 19:21:07.081
1478	96	10	f	\N	2025-10-11 19:21:07.085	2025-10-11 19:21:07.085
1479	96	11	f	\N	2025-10-11 19:21:07.087	2025-10-11 19:21:07.087
1480	96	12	f	\N	2025-10-11 19:21:07.089	2025-10-11 19:21:07.089
1481	96	13	f	\N	2025-10-11 19:21:07.092	2025-10-11 19:21:07.092
1482	96	14	f	\N	2025-10-11 19:21:07.094	2025-10-11 19:21:07.094
1483	96	15	f	\N	2025-10-11 19:21:07.096	2025-10-11 19:21:07.096
2939	179	1	f	\N	2025-11-13 18:11:26.502	2025-11-13 18:11:26.502
2940	179	2	f	\N	2025-11-13 18:11:26.505	2025-11-13 18:11:26.505
1499	103	1	f	\N	2025-10-11 22:40:53.778	2025-10-11 22:40:53.778
1500	103	2	f	\N	2025-10-11 22:40:53.781	2025-10-11 22:40:53.781
1501	103	3	f	\N	2025-10-11 22:40:53.783	2025-10-11 22:40:53.783
1502	103	4	f	\N	2025-10-11 22:40:53.785	2025-10-11 22:40:53.785
1503	103	5	f	\N	2025-10-11 22:40:53.788	2025-10-11 22:40:53.788
1504	103	6	f	\N	2025-10-11 22:40:53.79	2025-10-11 22:40:53.79
1505	103	7	f	\N	2025-10-11 22:40:53.792	2025-10-11 22:40:53.792
1506	103	8	f	\N	2025-10-11 22:40:53.795	2025-10-11 22:40:53.795
1507	103	9	f	\N	2025-10-11 22:40:53.798	2025-10-11 22:40:53.798
1508	103	10	f	\N	2025-10-11 22:40:53.8	2025-10-11 22:40:53.801
1509	103	11	f	\N	2025-10-11 22:40:53.803	2025-10-11 22:40:53.803
1510	103	12	f	\N	2025-10-11 22:40:53.805	2025-10-11 22:40:53.805
1511	103	13	f	\N	2025-10-11 22:40:53.808	2025-10-11 22:40:53.808
1512	103	14	f	\N	2025-10-11 22:40:53.812	2025-10-11 22:40:53.812
1513	103	15	f	\N	2025-10-11 22:40:53.814	2025-10-11 22:40:53.814
1514	105	1	f	\N	2025-10-11 23:24:27.943	2025-10-11 23:24:27.943
1515	105	2	f	\N	2025-10-11 23:24:27.946	2025-10-11 23:24:27.946
1516	105	3	f	\N	2025-10-11 23:24:27.948	2025-10-11 23:24:27.948
1517	105	4	f	\N	2025-10-11 23:24:27.951	2025-10-11 23:24:27.951
1518	105	5	f	\N	2025-10-11 23:24:27.954	2025-10-11 23:24:27.954
1519	105	6	f	\N	2025-10-11 23:24:27.956	2025-10-11 23:24:27.956
1520	105	7	f	\N	2025-10-11 23:24:27.958	2025-10-11 23:24:27.958
1521	105	8	f	\N	2025-10-11 23:24:27.96	2025-10-11 23:24:27.96
1522	105	9	f	\N	2025-10-11 23:24:27.962	2025-10-11 23:24:27.962
1523	105	10	f	\N	2025-10-11 23:24:27.964	2025-10-11 23:24:27.964
1524	105	11	f	\N	2025-10-11 23:24:27.967	2025-10-11 23:24:27.967
1525	105	12	f	\N	2025-10-11 23:24:27.969	2025-10-11 23:24:27.969
1526	105	13	f	\N	2025-10-11 23:24:27.971	2025-10-11 23:24:27.971
1527	105	14	f	\N	2025-10-11 23:24:27.973	2025-10-11 23:24:27.973
1528	105	15	f	\N	2025-10-11 23:24:27.975	2025-10-11 23:24:27.975
1529	100	1	f	\N	2025-10-13 20:32:54.115	2025-10-13 20:32:54.115
1530	100	2	f	\N	2025-10-13 20:32:54.118	2025-10-13 20:32:54.118
1531	100	3	f	\N	2025-10-13 20:32:54.121	2025-10-13 20:32:54.121
1532	100	4	f	\N	2025-10-13 20:32:54.123	2025-10-13 20:32:54.123
1533	100	5	f	\N	2025-10-13 20:32:54.126	2025-10-13 20:32:54.126
1534	100	6	f	\N	2025-10-13 20:32:54.128	2025-10-13 20:32:54.128
1535	100	7	f	\N	2025-10-13 20:32:54.13	2025-10-13 20:32:54.13
1536	100	8	f	\N	2025-10-13 20:32:54.132	2025-10-13 20:32:54.132
1537	100	9	f	\N	2025-10-13 20:32:54.135	2025-10-13 20:32:54.135
1538	100	10	f	\N	2025-10-13 20:32:54.137	2025-10-13 20:32:54.137
1539	100	11	f	\N	2025-10-13 20:32:54.139	2025-10-13 20:32:54.139
1540	100	12	f	\N	2025-10-13 20:32:54.141	2025-10-13 20:32:54.141
1541	100	13	f	\N	2025-10-13 20:32:54.144	2025-10-13 20:32:54.144
1542	100	14	f	\N	2025-10-13 20:32:54.146	2025-10-13 20:32:54.146
1543	100	15	f	\N	2025-10-13 20:32:54.148	2025-10-13 20:32:54.148
1544	107	1	f	\N	2025-10-13 23:30:11.136	2025-10-13 23:30:11.136
1545	107	2	f	\N	2025-10-13 23:30:11.138	2025-10-13 23:30:11.138
1546	107	3	f	\N	2025-10-13 23:30:11.14	2025-10-13 23:30:11.14
1547	107	4	f	\N	2025-10-13 23:30:11.141	2025-10-13 23:30:11.141
1548	107	5	f	\N	2025-10-13 23:30:11.142	2025-10-13 23:30:11.142
1549	107	6	f	\N	2025-10-13 23:30:11.144	2025-10-13 23:30:11.144
1550	107	7	f	\N	2025-10-13 23:30:11.145	2025-10-13 23:30:11.145
1551	107	8	f	\N	2025-10-13 23:30:11.146	2025-10-13 23:30:11.146
1552	107	9	f	\N	2025-10-13 23:30:11.147	2025-10-13 23:30:11.147
1553	107	10	f	\N	2025-10-13 23:30:11.148	2025-10-13 23:30:11.148
1554	107	11	f	\N	2025-10-13 23:30:11.149	2025-10-13 23:30:11.149
1555	107	12	f	\N	2025-10-13 23:30:11.151	2025-10-13 23:30:11.151
1556	107	13	f	\N	2025-10-13 23:30:11.152	2025-10-13 23:30:11.152
1557	107	14	f	\N	2025-10-13 23:30:11.153	2025-10-13 23:30:11.153
1558	107	15	f	\N	2025-10-13 23:30:11.155	2025-10-13 23:30:11.155
2234	127	1	f	\N	2025-11-02 21:20:55.604	2025-11-02 21:20:55.604
2235	127	2	f	\N	2025-11-02 21:20:55.608	2025-11-02 21:20:55.608
2236	127	3	f	\N	2025-11-02 21:20:55.61	2025-11-02 21:20:55.61
2237	127	4	f	\N	2025-11-02 21:20:55.613	2025-11-02 21:20:55.613
2238	127	5	f	\N	2025-11-02 21:20:55.615	2025-11-02 21:20:55.615
2239	127	6	f	\N	2025-11-02 21:20:55.617	2025-11-02 21:20:55.617
2240	127	7	f	\N	2025-11-02 21:20:55.619	2025-11-02 21:20:55.619
2241	127	8	f	\N	2025-11-02 21:20:55.621	2025-11-02 21:20:55.621
2242	127	9	f	\N	2025-11-02 21:20:55.623	2025-11-02 21:20:55.623
2243	127	10	f	\N	2025-11-02 21:20:55.625	2025-11-02 21:20:55.625
2244	127	11	f	\N	2025-11-02 21:20:55.627	2025-11-02 21:20:55.627
2245	127	12	f	\N	2025-11-02 21:20:55.629	2025-11-02 21:20:55.629
2246	127	13	f	\N	2025-11-02 21:20:55.632	2025-11-02 21:20:55.632
2247	127	14	f	\N	2025-11-02 21:20:55.634	2025-11-02 21:20:55.634
2248	127	15	f	\N	2025-11-02 21:20:55.637	2025-11-02 21:20:55.637
1589	109	1	f	\N	2025-10-14 19:07:01.821	2025-10-14 19:07:01.821
1590	109	2	f	\N	2025-10-14 19:07:01.822	2025-10-14 19:07:01.822
1591	109	3	f	\N	2025-10-14 19:07:01.824	2025-10-14 19:07:01.824
1592	109	4	f	\N	2025-10-14 19:07:01.827	2025-10-14 19:07:01.827
1593	109	5	f	\N	2025-10-14 19:07:01.829	2025-10-14 19:07:01.829
1594	109	6	f	\N	2025-10-14 19:07:01.831	2025-10-14 19:07:01.831
1595	109	7	f	\N	2025-10-14 19:07:01.833	2025-10-14 19:07:01.833
1596	109	8	f	\N	2025-10-14 19:07:01.834	2025-10-14 19:07:01.834
1597	109	9	f	\N	2025-10-14 19:07:01.836	2025-10-14 19:07:01.836
1598	109	10	f	\N	2025-10-14 19:07:01.839	2025-10-14 19:07:01.839
1599	109	11	f	\N	2025-10-14 19:07:01.841	2025-10-14 19:07:01.841
1600	109	12	f	\N	2025-10-14 19:07:01.843	2025-10-14 19:07:01.843
1601	109	13	f	\N	2025-10-14 19:07:01.846	2025-10-14 19:07:01.846
1602	109	14	f	\N	2025-10-14 19:07:01.848	2025-10-14 19:07:01.848
1603	109	15	f	\N	2025-10-14 19:07:01.85	2025-10-14 19:07:01.85
1619	111	1	f	\N	2025-10-14 21:32:42.53	2025-10-14 21:32:42.53
1620	111	2	f	\N	2025-10-14 21:32:42.532	2025-10-14 21:32:42.532
1621	111	3	f	\N	2025-10-14 21:32:42.536	2025-10-14 21:32:42.536
1622	111	4	f	\N	2025-10-14 21:32:42.54	2025-10-14 21:32:42.54
1623	111	5	f	\N	2025-10-14 21:32:42.542	2025-10-14 21:32:42.542
1624	111	6	f	\N	2025-10-14 21:32:42.546	2025-10-14 21:32:42.546
1625	111	7	f	\N	2025-10-14 21:32:42.549	2025-10-14 21:32:42.549
1626	111	8	f	\N	2025-10-14 21:32:42.551	2025-10-14 21:32:42.551
1627	111	9	f	\N	2025-10-14 21:32:42.554	2025-10-14 21:32:42.554
1628	111	10	f	\N	2025-10-14 21:32:42.556	2025-10-14 21:32:42.556
1629	111	11	f	\N	2025-10-14 21:32:42.558	2025-10-14 21:32:42.558
1630	111	12	f	\N	2025-10-14 21:32:42.56	2025-10-14 21:32:42.56
1631	111	13	f	\N	2025-10-14 21:32:42.563	2025-10-14 21:32:42.563
1632	111	14	f	\N	2025-10-14 21:32:42.565	2025-10-14 21:32:42.565
1633	111	15	f	\N	2025-10-14 21:32:42.568	2025-10-14 21:32:42.568
1649	113	1	f	\N	2025-10-16 21:12:42.161	2025-10-16 21:12:42.161
1650	113	2	f	\N	2025-10-16 21:12:42.163	2025-10-16 21:12:42.163
1651	113	3	f	\N	2025-10-16 21:12:42.165	2025-10-16 21:12:42.165
1652	113	4	f	\N	2025-10-16 21:12:42.168	2025-10-16 21:12:42.168
1653	113	5	f	\N	2025-10-16 21:12:42.172	2025-10-16 21:12:42.172
1654	113	6	f	\N	2025-10-16 21:12:42.174	2025-10-16 21:12:42.174
1655	113	7	f	\N	2025-10-16 21:12:42.178	2025-10-16 21:12:42.178
1656	113	8	f	\N	2025-10-16 21:12:42.183	2025-10-16 21:12:42.183
1657	113	9	f	\N	2025-10-16 21:12:42.185	2025-10-16 21:12:42.185
1658	113	10	f	\N	2025-10-16 21:12:42.187	2025-10-16 21:12:42.187
1659	113	11	f	\N	2025-10-16 21:12:42.189	2025-10-16 21:12:42.189
1660	113	12	f	\N	2025-10-16 21:12:42.191	2025-10-16 21:12:42.191
1661	113	13	f	\N	2025-10-16 21:12:42.193	2025-10-16 21:12:42.193
1662	113	14	f	\N	2025-10-16 21:12:42.197	2025-10-16 21:12:42.197
1663	113	15	f	\N	2025-10-16 21:12:42.199	2025-10-16 21:12:42.199
1664	115	1	f	\N	2025-10-16 21:22:56.636	2025-10-16 21:22:56.636
1665	115	2	f	\N	2025-10-16 21:22:56.639	2025-10-16 21:22:56.639
1666	115	3	f	\N	2025-10-16 21:22:56.641	2025-10-16 21:22:56.641
1667	115	4	f	\N	2025-10-16 21:22:56.644	2025-10-16 21:22:56.644
1668	115	5	f	\N	2025-10-16 21:22:56.646	2025-10-16 21:22:56.646
1669	115	6	f	\N	2025-10-16 21:22:56.649	2025-10-16 21:22:56.649
1670	115	7	f	\N	2025-10-16 21:22:56.653	2025-10-16 21:22:56.653
1671	115	8	f	\N	2025-10-16 21:22:56.655	2025-10-16 21:22:56.655
1672	115	9	f	\N	2025-10-16 21:22:56.658	2025-10-16 21:22:56.658
1673	115	10	f	\N	2025-10-16 21:22:56.661	2025-10-16 21:22:56.661
1674	115	11	f	\N	2025-10-16 21:22:56.665	2025-10-16 21:22:56.665
1675	115	12	f	\N	2025-10-16 21:22:56.669	2025-10-16 21:22:56.669
1676	115	13	f	\N	2025-10-16 21:22:56.672	2025-10-16 21:22:56.672
1677	115	14	f	\N	2025-10-16 21:22:56.676	2025-10-16 21:22:56.676
1678	115	15	f	\N	2025-10-16 21:22:56.679	2025-10-16 21:22:56.679
1679	101	1	f	\N	2025-10-16 23:19:54.337	2025-10-16 23:19:54.337
1680	101	2	f	\N	2025-10-16 23:19:54.343	2025-10-16 23:19:54.343
1681	101	3	f	\N	2025-10-16 23:19:54.347	2025-10-16 23:19:54.347
1682	101	4	f	\N	2025-10-16 23:19:54.35	2025-10-16 23:19:54.35
1683	101	5	f	\N	2025-10-16 23:19:54.354	2025-10-16 23:19:54.354
1684	101	6	f	\N	2025-10-16 23:19:54.358	2025-10-16 23:19:54.358
1685	101	7	f	\N	2025-10-16 23:19:54.362	2025-10-16 23:19:54.362
1686	101	8	f	\N	2025-10-16 23:19:54.364	2025-10-16 23:19:54.364
1687	101	9	f	\N	2025-10-16 23:19:54.368	2025-10-16 23:19:54.368
1688	101	10	f	\N	2025-10-16 23:19:54.37	2025-10-16 23:19:54.37
1689	101	11	f	\N	2025-10-16 23:19:54.377	2025-10-16 23:19:54.377
1690	101	12	f	\N	2025-10-16 23:19:54.379	2025-10-16 23:19:54.379
1691	101	13	f	\N	2025-10-16 23:19:54.384	2025-10-16 23:19:54.384
1692	101	14	f	\N	2025-10-16 23:19:54.386	2025-10-16 23:19:54.386
1693	101	15	f	\N	2025-10-16 23:19:54.391	2025-10-16 23:19:54.391
1694	108	1	f	\N	2025-10-17 20:59:59.757	2025-10-17 20:59:59.757
1695	108	2	f	\N	2025-10-17 20:59:59.76	2025-10-17 20:59:59.76
1696	108	3	f	\N	2025-10-17 20:59:59.763	2025-10-17 20:59:59.763
1697	108	4	f	\N	2025-10-17 20:59:59.766	2025-10-17 20:59:59.766
1698	108	5	f	\N	2025-10-17 20:59:59.768	2025-10-17 20:59:59.768
1699	108	6	f	\N	2025-10-17 20:59:59.771	2025-10-17 20:59:59.771
1700	108	7	f	\N	2025-10-17 20:59:59.774	2025-10-17 20:59:59.774
1701	108	8	f	\N	2025-10-17 20:59:59.777	2025-10-17 20:59:59.777
1702	108	9	f	\N	2025-10-17 20:59:59.78	2025-10-17 20:59:59.78
1703	108	10	f	\N	2025-10-17 20:59:59.782	2025-10-17 20:59:59.782
1704	108	11	f	\N	2025-10-17 20:59:59.785	2025-10-17 20:59:59.785
1705	108	12	f	\N	2025-10-17 20:59:59.787	2025-10-17 20:59:59.787
1706	108	13	f	\N	2025-10-17 20:59:59.79	2025-10-17 20:59:59.79
1707	108	14	f	\N	2025-10-17 20:59:59.792	2025-10-17 20:59:59.792
1708	108	15	f	\N	2025-10-17 20:59:59.794	2025-10-17 20:59:59.794
2189	149	1	f	\N	2025-11-01 20:55:34.491	2025-11-01 20:55:34.491
2190	149	2	f	\N	2025-11-01 20:55:34.493	2025-11-01 20:55:34.493
2191	149	3	f	\N	2025-11-01 20:55:34.495	2025-11-01 20:55:34.495
2192	149	4	f	\N	2025-11-01 20:55:34.497	2025-11-01 20:55:34.497
2193	149	5	f	\N	2025-11-01 20:55:34.499	2025-11-01 20:55:34.499
2194	149	6	f	\N	2025-11-01 20:55:34.5	2025-11-01 20:55:34.5
2195	149	7	f	\N	2025-11-01 20:55:34.502	2025-11-01 20:55:34.502
2196	149	8	f	\N	2025-11-01 20:55:34.504	2025-11-01 20:55:34.504
2197	149	9	f	\N	2025-11-01 20:55:34.506	2025-11-01 20:55:34.506
1724	118	1	f	\N	2025-10-17 21:53:01.29	2025-10-17 21:53:01.29
1725	118	2	f	\N	2025-10-17 21:53:01.292	2025-10-17 21:53:01.292
1726	118	3	f	\N	2025-10-17 21:53:01.296	2025-10-17 21:53:01.296
1727	118	4	f	\N	2025-10-17 21:53:01.298	2025-10-17 21:53:01.298
1728	118	5	f	\N	2025-10-17 21:53:01.301	2025-10-17 21:53:01.301
1729	118	6	f	\N	2025-10-17 21:53:01.303	2025-10-17 21:53:01.303
1730	118	7	f	\N	2025-10-17 21:53:01.306	2025-10-17 21:53:01.306
1731	118	8	f	\N	2025-10-17 21:53:01.308	2025-10-17 21:53:01.308
1732	118	9	f	\N	2025-10-17 21:53:01.311	2025-10-17 21:53:01.311
1733	118	10	f	\N	2025-10-17 21:53:01.314	2025-10-17 21:53:01.314
1734	118	11	f	\N	2025-10-17 21:53:01.317	2025-10-17 21:53:01.317
1735	118	12	f	\N	2025-10-17 21:53:01.319	2025-10-17 21:53:01.319
1736	118	13	f	\N	2025-10-17 21:53:01.321	2025-10-17 21:53:01.321
1737	118	14	f	\N	2025-10-17 21:53:01.325	2025-10-17 21:53:01.325
1738	118	15	f	\N	2025-10-17 21:53:01.328	2025-10-17 21:53:01.328
1739	120	1	f	\N	2025-10-18 19:50:53.654	2025-10-18 19:50:53.654
1740	120	2	f	\N	2025-10-18 19:50:53.657	2025-10-18 19:50:53.657
1741	120	3	f	\N	2025-10-18 19:50:53.659	2025-10-18 19:50:53.659
1742	120	4	f	\N	2025-10-18 19:50:53.662	2025-10-18 19:50:53.662
1743	120	5	f	\N	2025-10-18 19:50:53.664	2025-10-18 19:50:53.664
1744	120	6	f	\N	2025-10-18 19:50:53.667	2025-10-18 19:50:53.667
1745	120	7	f	\N	2025-10-18 19:50:53.669	2025-10-18 19:50:53.669
1746	120	8	f	\N	2025-10-18 19:50:53.672	2025-10-18 19:50:53.672
1747	120	9	f	\N	2025-10-18 19:50:53.674	2025-10-18 19:50:53.674
1748	120	10	f	\N	2025-10-18 19:50:53.677	2025-10-18 19:50:53.677
1749	120	11	f	\N	2025-10-18 19:50:53.68	2025-10-18 19:50:53.68
1750	120	12	f	\N	2025-10-18 19:50:53.683	2025-10-18 19:50:53.683
1751	120	13	f	\N	2025-10-18 19:50:53.686	2025-10-18 19:50:53.686
1752	120	14	f	\N	2025-10-18 19:50:53.689	2025-10-18 19:50:53.689
1753	120	15	f	\N	2025-10-18 19:50:53.692	2025-10-18 19:50:53.692
1769	121	1	f	\N	2025-10-18 20:37:04.693	2025-10-18 20:37:04.693
1770	121	2	f	\N	2025-10-18 20:37:04.697	2025-10-18 20:37:04.697
1771	121	3	f	\N	2025-10-18 20:37:04.699	2025-10-18 20:37:04.699
1772	121	4	f	\N	2025-10-18 20:37:04.701	2025-10-18 20:37:04.701
1773	121	5	f	\N	2025-10-18 20:37:04.703	2025-10-18 20:37:04.703
1774	121	6	f	\N	2025-10-18 20:37:04.709	2025-10-18 20:37:04.709
1775	121	7	f	\N	2025-10-18 20:37:04.71	2025-10-18 20:37:04.71
1776	121	8	f	\N	2025-10-18 20:37:04.712	2025-10-18 20:37:04.712
1777	121	9	f	\N	2025-10-18 20:37:04.713	2025-10-18 20:37:04.713
1778	121	10	f	\N	2025-10-18 20:37:04.715	2025-10-18 20:37:04.715
1779	121	11	f	\N	2025-10-18 20:37:04.716	2025-10-18 20:37:04.716
1780	121	12	f	\N	2025-10-18 20:37:04.718	2025-10-18 20:37:04.718
1781	121	13	f	\N	2025-10-18 20:37:04.72	2025-10-18 20:37:04.72
1782	121	14	f	\N	2025-10-18 20:37:04.723	2025-10-18 20:37:04.723
1783	121	15	f	\N	2025-10-18 20:37:04.725	2025-10-18 20:37:04.725
1784	123	1	f	\N	2025-10-19 19:49:34.564	2025-10-19 19:49:34.564
1785	123	2	f	\N	2025-10-19 19:49:34.568	2025-10-19 19:49:34.568
1786	123	3	f	\N	2025-10-19 19:49:34.57	2025-10-19 19:49:34.57
1787	123	4	f	\N	2025-10-19 19:49:34.573	2025-10-19 19:49:34.573
1788	123	5	f	\N	2025-10-19 19:49:34.575	2025-10-19 19:49:34.575
1789	123	6	f	\N	2025-10-19 19:49:34.578	2025-10-19 19:49:34.578
1790	123	7	f	\N	2025-10-19 19:49:34.58	2025-10-19 19:49:34.58
1791	123	8	f	\N	2025-10-19 19:49:34.582	2025-10-19 19:49:34.582
1792	123	9	f	\N	2025-10-19 19:49:34.587	2025-10-19 19:49:34.587
1793	123	10	f	\N	2025-10-19 19:49:34.59	2025-10-19 19:49:34.59
1794	123	11	f	\N	2025-10-19 19:49:34.594	2025-10-19 19:49:34.594
1795	123	12	f	\N	2025-10-19 19:49:34.597	2025-10-19 19:49:34.597
1796	123	13	f	\N	2025-10-19 19:49:34.6	2025-10-19 19:49:34.6
1797	123	14	f	\N	2025-10-19 19:49:34.603	2025-10-19 19:49:34.603
1798	123	15	f	\N	2025-10-19 19:49:34.606	2025-10-19 19:49:34.606
1799	124	1	f	\N	2025-10-22 19:26:09.913	2025-10-22 19:26:09.913
1800	124	2	f	\N	2025-10-22 19:26:09.916	2025-10-22 19:26:09.916
1801	124	3	f	\N	2025-10-22 19:26:09.919	2025-10-22 19:26:09.919
1802	124	4	f	\N	2025-10-22 19:26:09.922	2025-10-22 19:26:09.922
1803	124	5	f	\N	2025-10-22 19:26:09.925	2025-10-22 19:26:09.925
1804	124	6	f	\N	2025-10-22 19:26:09.928	2025-10-22 19:26:09.928
1805	124	7	f	\N	2025-10-22 19:26:09.93	2025-10-22 19:26:09.93
1806	124	8	f	\N	2025-10-22 19:26:09.933	2025-10-22 19:26:09.933
1807	124	9	f	\N	2025-10-22 19:26:09.936	2025-10-22 19:26:09.936
1808	124	10	f	\N	2025-10-22 19:26:09.941	2025-10-22 19:26:09.941
1809	124	11	f	\N	2025-10-22 19:26:09.943	2025-10-22 19:26:09.943
1810	124	12	f	\N	2025-10-22 19:26:09.946	2025-10-22 19:26:09.946
1811	124	13	f	\N	2025-10-22 19:26:09.948	2025-10-22 19:26:09.948
1812	124	14	f	\N	2025-10-22 19:26:09.954	2025-10-22 19:26:09.954
1813	124	15	f	\N	2025-10-22 19:26:09.96	2025-10-22 19:26:09.96
1814	125	1	f	\N	2025-10-23 15:35:42.51	2025-10-23 15:35:42.51
1815	125	2	f	\N	2025-10-23 15:35:42.513	2025-10-23 15:35:42.513
1816	125	3	f	\N	2025-10-23 15:35:42.515	2025-10-23 15:35:42.515
1817	125	4	f	\N	2025-10-23 15:35:42.517	2025-10-23 15:35:42.517
1818	125	5	f	\N	2025-10-23 15:35:42.519	2025-10-23 15:35:42.519
1819	125	6	f	\N	2025-10-23 15:35:42.521	2025-10-23 15:35:42.521
1820	125	7	f	\N	2025-10-23 15:35:42.524	2025-10-23 15:35:42.524
1821	125	8	f	\N	2025-10-23 15:35:42.527	2025-10-23 15:35:42.527
1822	125	9	f	\N	2025-10-23 15:35:42.529	2025-10-23 15:35:42.529
1823	125	10	f	\N	2025-10-23 15:35:42.531	2025-10-23 15:35:42.531
1824	125	11	f	\N	2025-10-23 15:35:42.533	2025-10-23 15:35:42.533
1825	125	12	f	\N	2025-10-23 15:35:42.535	2025-10-23 15:35:42.535
1826	125	13	f	\N	2025-10-23 15:35:42.538	2025-10-23 15:35:42.538
1827	125	14	f	\N	2025-10-23 15:35:42.54	2025-10-23 15:35:42.54
1828	125	15	f	\N	2025-10-23 15:35:42.543	2025-10-23 15:35:42.543
1829	126	1	f	\N	2025-10-23 16:22:28.886	2025-10-23 16:22:28.886
1830	126	2	f	\N	2025-10-23 16:22:28.889	2025-10-23 16:22:28.889
1831	126	3	f	\N	2025-10-23 16:22:28.891	2025-10-23 16:22:28.891
1832	126	4	f	\N	2025-10-23 16:22:28.893	2025-10-23 16:22:28.893
1833	126	5	f	\N	2025-10-23 16:22:28.895	2025-10-23 16:22:28.895
1834	126	6	f	\N	2025-10-23 16:22:28.897	2025-10-23 16:22:28.897
1835	126	7	f	\N	2025-10-23 16:22:28.9	2025-10-23 16:22:28.9
1836	126	8	f	\N	2025-10-23 16:22:28.901	2025-10-23 16:22:28.901
1837	126	9	f	\N	2025-10-23 16:22:28.903	2025-10-23 16:22:28.903
1838	126	10	f	\N	2025-10-23 16:22:28.905	2025-10-23 16:22:28.905
1839	126	11	f	\N	2025-10-23 16:22:28.907	2025-10-23 16:22:28.907
1840	126	12	f	\N	2025-10-23 16:22:28.91	2025-10-23 16:22:28.91
1841	126	13	f	\N	2025-10-23 16:22:28.913	2025-10-23 16:22:28.913
1842	126	14	f	\N	2025-10-23 16:22:28.915	2025-10-23 16:22:28.915
1843	126	15	f	\N	2025-10-23 16:22:28.917	2025-10-23 16:22:28.917
2198	149	10	f	\N	2025-11-01 20:55:34.507	2025-11-01 20:55:34.507
2199	149	11	f	\N	2025-11-01 20:55:34.509	2025-11-01 20:55:34.509
2200	149	12	f	\N	2025-11-01 20:55:34.511	2025-11-01 20:55:34.511
2201	149	13	f	\N	2025-11-01 20:55:34.512	2025-11-01 20:55:34.512
2202	149	14	f	\N	2025-11-01 20:55:34.514	2025-11-01 20:55:34.514
2203	149	15	f	\N	2025-11-01 20:55:34.516	2025-11-01 20:55:34.516
1874	129	1	f	\N	2025-10-25 18:04:57.381	2025-10-25 18:04:57.381
1875	129	2	f	\N	2025-10-25 18:04:57.387	2025-10-25 18:04:57.387
1876	129	3	f	\N	2025-10-25 18:04:57.39	2025-10-25 18:04:57.39
1877	129	4	f	\N	2025-10-25 18:04:57.392	2025-10-25 18:04:57.392
1878	129	5	f	\N	2025-10-25 18:04:57.395	2025-10-25 18:04:57.395
1879	129	6	f	\N	2025-10-25 18:04:57.399	2025-10-25 18:04:57.399
1880	129	7	f	\N	2025-10-25 18:04:57.402	2025-10-25 18:04:57.402
1881	129	8	f	\N	2025-10-25 18:04:57.404	2025-10-25 18:04:57.404
1882	129	9	f	\N	2025-10-25 18:04:57.407	2025-10-25 18:04:57.407
1883	129	10	f	\N	2025-10-25 18:04:57.412	2025-10-25 18:04:57.412
1884	129	11	f	\N	2025-10-25 18:04:57.418	2025-10-25 18:04:57.418
1885	129	12	f	\N	2025-10-25 18:04:57.421	2025-10-25 18:04:57.421
1886	129	13	f	\N	2025-10-25 18:04:57.425	2025-10-25 18:04:57.425
1887	129	14	f	\N	2025-10-25 18:04:57.428	2025-10-25 18:04:57.428
1888	129	15	f	\N	2025-10-25 18:04:57.431	2025-10-25 18:04:57.431
1889	130	1	f	\N	2025-10-27 19:59:06.285	2025-10-27 19:59:06.285
1890	130	2	f	\N	2025-10-27 19:59:06.289	2025-10-27 19:59:06.289
1891	130	3	f	\N	2025-10-27 19:59:06.291	2025-10-27 19:59:06.291
1892	130	4	f	\N	2025-10-27 19:59:06.294	2025-10-27 19:59:06.294
1893	130	5	f	\N	2025-10-27 19:59:06.297	2025-10-27 19:59:06.297
1894	130	6	f	\N	2025-10-27 19:59:06.301	2025-10-27 19:59:06.301
1895	130	7	f	\N	2025-10-27 19:59:06.303	2025-10-27 19:59:06.303
1896	130	8	f	\N	2025-10-27 19:59:06.305	2025-10-27 19:59:06.305
1897	130	9	f	\N	2025-10-27 19:59:06.313	2025-10-27 19:59:06.313
1898	130	10	f	\N	2025-10-27 19:59:06.315	2025-10-27 19:59:06.315
1899	130	11	f	\N	2025-10-27 19:59:06.319	2025-10-27 19:59:06.319
1900	130	12	f	\N	2025-10-27 19:59:06.322	2025-10-27 19:59:06.322
1901	130	13	f	\N	2025-10-27 19:59:06.326	2025-10-27 19:59:06.326
1902	130	14	f	\N	2025-10-27 19:59:06.33	2025-10-27 19:59:06.33
1903	130	15	f	\N	2025-10-27 19:59:06.333	2025-10-27 19:59:06.333
1904	131	1	f	\N	2025-10-27 22:36:32.518	2025-10-27 22:36:32.518
1905	131	2	f	\N	2025-10-27 22:36:32.523	2025-10-27 22:36:32.523
1906	131	3	f	\N	2025-10-27 22:36:32.526	2025-10-27 22:36:32.526
1907	131	4	f	\N	2025-10-27 22:36:32.529	2025-10-27 22:36:32.529
1908	131	5	f	\N	2025-10-27 22:36:32.533	2025-10-27 22:36:32.533
1909	131	6	f	\N	2025-10-27 22:36:32.536	2025-10-27 22:36:32.536
1910	131	7	f	\N	2025-10-27 22:36:32.541	2025-10-27 22:36:32.541
1911	131	8	f	\N	2025-10-27 22:36:32.544	2025-10-27 22:36:32.544
1912	131	9	f	\N	2025-10-27 22:36:32.548	2025-10-27 22:36:32.548
1913	131	10	f	\N	2025-10-27 22:36:32.552	2025-10-27 22:36:32.552
1914	131	11	f	\N	2025-10-27 22:36:32.555	2025-10-27 22:36:32.555
1915	131	12	f	\N	2025-10-27 22:36:32.558	2025-10-27 22:36:32.558
1916	131	13	f	\N	2025-10-27 22:36:32.562	2025-10-27 22:36:32.562
1917	131	14	f	\N	2025-10-27 22:36:32.57	2025-10-27 22:36:32.57
1918	131	15	f	\N	2025-10-27 22:36:32.573	2025-10-27 22:36:32.573
1919	132	1	f	\N	2025-10-27 22:47:27.185	2025-10-27 22:47:27.185
1920	132	2	f	\N	2025-10-27 22:47:27.19	2025-10-27 22:47:27.19
1921	132	3	f	\N	2025-10-27 22:47:27.193	2025-10-27 22:47:27.193
1922	132	4	f	\N	2025-10-27 22:47:27.196	2025-10-27 22:47:27.196
1923	132	5	f	\N	2025-10-27 22:47:27.198	2025-10-27 22:47:27.198
1924	132	6	f	\N	2025-10-27 22:47:27.2	2025-10-27 22:47:27.2
1925	132	7	f	\N	2025-10-27 22:47:27.203	2025-10-27 22:47:27.203
1926	132	8	f	\N	2025-10-27 22:47:27.205	2025-10-27 22:47:27.205
1927	132	9	f	\N	2025-10-27 22:47:27.207	2025-10-27 22:47:27.207
1928	132	10	f	\N	2025-10-27 22:47:27.211	2025-10-27 22:47:27.211
1929	132	11	f	\N	2025-10-27 22:47:27.213	2025-10-27 22:47:27.213
1930	132	12	f	\N	2025-10-27 22:47:27.218	2025-10-27 22:47:27.218
1931	132	13	f	\N	2025-10-27 22:47:27.22	2025-10-27 22:47:27.22
1932	132	14	f	\N	2025-10-27 22:47:27.222	2025-10-27 22:47:27.222
1933	132	15	f	\N	2025-10-27 22:47:27.224	2025-10-27 22:47:27.224
2249	154	1	f	\N	2025-11-02 22:00:38.712	2025-11-02 22:00:38.712
2250	154	2	f	\N	2025-11-02 22:00:38.716	2025-11-02 22:00:38.716
2251	154	3	f	\N	2025-11-02 22:00:38.72	2025-11-02 22:00:38.72
2252	154	4	f	\N	2025-11-02 22:00:38.725	2025-11-02 22:00:38.725
2253	154	5	f	\N	2025-11-02 22:00:38.729	2025-11-02 22:00:38.729
2254	154	6	f	\N	2025-11-02 22:00:38.732	2025-11-02 22:00:38.732
2255	154	7	f	\N	2025-11-02 22:00:38.735	2025-11-02 22:00:38.735
2256	154	8	f	\N	2025-11-02 22:00:38.737	2025-11-02 22:00:38.737
2257	154	9	f	\N	2025-11-02 22:00:38.742	2025-11-02 22:00:38.742
2258	154	10	f	\N	2025-11-02 22:00:38.745	2025-11-02 22:00:38.745
2259	154	11	f	\N	2025-11-02 22:00:38.749	2025-11-02 22:00:38.749
2260	154	12	f	\N	2025-11-02 22:00:38.753	2025-11-02 22:00:38.753
2261	154	13	f	\N	2025-11-02 22:00:38.757	2025-11-02 22:00:38.757
2262	154	14	f	\N	2025-11-02 22:00:38.76	2025-11-02 22:00:38.76
2263	154	15	f	\N	2025-11-02 22:00:38.763	2025-11-02 22:00:38.763
2294	157	1	f	\N	2025-11-05 16:28:10.194	2025-11-05 16:28:10.194
2295	157	2	f	\N	2025-11-05 16:28:10.199	2025-11-05 16:28:10.199
2296	157	3	f	\N	2025-11-05 16:28:10.204	2025-11-05 16:28:10.204
2297	157	4	f	\N	2025-11-05 16:28:10.209	2025-11-05 16:28:10.209
2298	157	5	f	\N	2025-11-05 16:28:10.212	2025-11-05 16:28:10.212
2299	157	6	f	\N	2025-11-05 16:28:10.219	2025-11-05 16:28:10.219
2300	157	7	f	\N	2025-11-05 16:28:10.223	2025-11-05 16:28:10.223
2301	157	8	f	\N	2025-11-05 16:28:10.227	2025-11-05 16:28:10.227
1964	133	1	f	\N	2025-10-28 00:31:24.754	2025-10-28 00:31:24.754
1965	133	2	f	\N	2025-10-28 00:31:24.757	2025-10-28 00:31:24.757
1966	133	3	f	\N	2025-10-28 00:31:24.759	2025-10-28 00:31:24.759
1967	133	4	f	\N	2025-10-28 00:31:24.762	2025-10-28 00:31:24.762
1968	133	5	f	\N	2025-10-28 00:31:24.765	2025-10-28 00:31:24.765
1969	133	6	f	\N	2025-10-28 00:31:24.769	2025-10-28 00:31:24.769
1970	133	7	f	\N	2025-10-28 00:31:24.771	2025-10-28 00:31:24.771
1971	133	8	f	\N	2025-10-28 00:31:24.773	2025-10-28 00:31:24.773
1972	133	9	f	\N	2025-10-28 00:31:24.776	2025-10-28 00:31:24.776
1973	133	10	f	\N	2025-10-28 00:31:24.778	2025-10-28 00:31:24.778
1974	133	11	f	\N	2025-10-28 00:31:24.78	2025-10-28 00:31:24.78
1975	133	12	f	\N	2025-10-28 00:31:24.783	2025-10-28 00:31:24.783
1976	133	13	f	\N	2025-10-28 00:31:24.785	2025-10-28 00:31:24.785
1977	133	14	f	\N	2025-10-28 00:31:24.788	2025-10-28 00:31:24.788
1978	133	15	f	\N	2025-10-28 00:31:24.79	2025-10-28 00:31:24.79
1979	136	1	f	\N	2025-10-28 00:33:11.948	2025-10-28 00:33:11.948
1980	136	2	f	\N	2025-10-28 00:33:11.952	2025-10-28 00:33:11.952
1981	136	3	f	\N	2025-10-28 00:33:11.954	2025-10-28 00:33:11.954
1982	136	4	f	\N	2025-10-28 00:33:11.958	2025-10-28 00:33:11.958
1983	136	5	f	\N	2025-10-28 00:33:11.96	2025-10-28 00:33:11.96
1984	136	6	f	\N	2025-10-28 00:33:11.963	2025-10-28 00:33:11.963
1985	136	7	f	\N	2025-10-28 00:33:11.965	2025-10-28 00:33:11.965
1986	136	8	f	\N	2025-10-28 00:33:11.968	2025-10-28 00:33:11.968
1987	136	9	f	\N	2025-10-28 00:33:11.971	2025-10-28 00:33:11.971
1988	136	10	f	\N	2025-10-28 00:33:11.974	2025-10-28 00:33:11.974
1989	136	11	f	\N	2025-10-28 00:33:11.977	2025-10-28 00:33:11.977
1990	136	12	f	\N	2025-10-28 00:33:11.979	2025-10-28 00:33:11.979
1991	136	13	f	\N	2025-10-28 00:33:11.981	2025-10-28 00:33:11.981
1992	136	14	f	\N	2025-10-28 00:33:11.983	2025-10-28 00:33:11.983
1993	136	15	f	\N	2025-10-28 00:33:11.986	2025-10-28 00:33:11.986
1994	137	1	f	\N	2025-10-28 20:12:22.55	2025-10-28 20:12:22.55
1995	137	2	f	\N	2025-10-28 20:12:22.554	2025-10-28 20:12:22.554
1996	137	3	f	\N	2025-10-28 20:12:22.556	2025-10-28 20:12:22.556
1997	137	4	f	\N	2025-10-28 20:12:22.558	2025-10-28 20:12:22.558
1998	137	5	f	\N	2025-10-28 20:12:22.56	2025-10-28 20:12:22.56
1999	137	6	f	\N	2025-10-28 20:12:22.562	2025-10-28 20:12:22.562
2000	137	7	f	\N	2025-10-28 20:12:22.565	2025-10-28 20:12:22.565
2001	137	8	f	\N	2025-10-28 20:12:22.566	2025-10-28 20:12:22.566
2002	137	9	f	\N	2025-10-28 20:12:22.568	2025-10-28 20:12:22.568
2003	137	10	f	\N	2025-10-28 20:12:22.572	2025-10-28 20:12:22.572
2004	137	11	f	\N	2025-10-28 20:12:22.574	2025-10-28 20:12:22.574
2005	137	12	f	\N	2025-10-28 20:12:22.576	2025-10-28 20:12:22.576
2006	137	13	f	\N	2025-10-28 20:12:22.579	2025-10-28 20:12:22.579
2007	137	14	f	\N	2025-10-28 20:12:22.584	2025-10-28 20:12:22.584
2008	137	15	f	\N	2025-10-28 20:12:22.587	2025-10-28 20:12:22.587
2204	151	1	f	\N	2025-11-01 23:18:32.678	2025-11-01 23:18:32.678
2205	151	2	f	\N	2025-11-01 23:18:32.681	2025-11-01 23:18:32.681
2206	151	3	f	\N	2025-11-01 23:18:32.684	2025-11-01 23:18:32.684
2207	151	4	f	\N	2025-11-01 23:18:32.687	2025-11-01 23:18:32.687
2208	151	5	f	\N	2025-11-01 23:18:32.689	2025-11-01 23:18:32.689
2209	151	6	f	\N	2025-11-01 23:18:32.691	2025-11-01 23:18:32.691
2210	151	7	f	\N	2025-11-01 23:18:32.696	2025-11-01 23:18:32.696
2211	151	8	f	\N	2025-11-01 23:18:32.698	2025-11-01 23:18:32.698
2212	151	9	f	\N	2025-11-01 23:18:32.7	2025-11-01 23:18:32.7
2213	151	10	f	\N	2025-11-01 23:18:32.703	2025-11-01 23:18:32.703
2214	151	11	f	\N	2025-11-01 23:18:32.705	2025-11-01 23:18:32.705
2215	151	12	f	\N	2025-11-01 23:18:32.707	2025-11-01 23:18:32.707
2216	151	13	f	\N	2025-11-01 23:18:32.709	2025-11-01 23:18:32.709
2217	151	14	f	\N	2025-11-01 23:18:32.712	2025-11-01 23:18:32.712
2218	151	15	f	\N	2025-11-01 23:18:32.715	2025-11-01 23:18:32.715
2264	155	1	f	\N	2025-11-03 22:41:08.645	2025-11-03 22:41:08.645
2265	155	2	f	\N	2025-11-03 22:41:08.65	2025-11-03 22:41:08.65
2039	139	1	f	\N	2025-10-29 23:11:18.638	2025-10-29 23:11:18.638
2040	139	2	f	\N	2025-10-29 23:11:18.64	2025-10-29 23:11:18.64
2041	139	3	f	\N	2025-10-29 23:11:18.642	2025-10-29 23:11:18.642
2042	139	4	f	\N	2025-10-29 23:11:18.645	2025-10-29 23:11:18.645
2043	139	5	f	\N	2025-10-29 23:11:18.647	2025-10-29 23:11:18.647
2044	139	6	f	\N	2025-10-29 23:11:18.649	2025-10-29 23:11:18.649
2045	139	7	f	\N	2025-10-29 23:11:18.652	2025-10-29 23:11:18.652
2046	139	8	f	\N	2025-10-29 23:11:18.654	2025-10-29 23:11:18.654
2047	139	9	f	\N	2025-10-29 23:11:18.655	2025-10-29 23:11:18.655
2048	139	10	f	\N	2025-10-29 23:11:18.657	2025-10-29 23:11:18.657
2049	139	11	f	\N	2025-10-29 23:11:18.659	2025-10-29 23:11:18.659
2050	139	12	f	\N	2025-10-29 23:11:18.661	2025-10-29 23:11:18.661
2051	139	13	f	\N	2025-10-29 23:11:18.663	2025-10-29 23:11:18.663
2052	139	14	f	\N	2025-10-29 23:11:18.664	2025-10-29 23:11:18.664
2053	139	15	f	\N	2025-10-29 23:11:18.666	2025-10-29 23:11:18.666
2054	141	1	f	\N	2025-10-30 18:52:04.963	2025-10-30 18:52:04.963
2055	141	2	f	\N	2025-10-30 18:52:04.967	2025-10-30 18:52:04.967
2056	141	3	f	\N	2025-10-30 18:52:04.969	2025-10-30 18:52:04.969
2057	141	4	f	\N	2025-10-30 18:52:04.971	2025-10-30 18:52:04.971
2058	141	5	f	\N	2025-10-30 18:52:04.974	2025-10-30 18:52:04.974
2059	141	6	f	\N	2025-10-30 18:52:04.976	2025-10-30 18:52:04.976
2060	141	7	f	\N	2025-10-30 18:52:04.979	2025-10-30 18:52:04.979
2061	141	8	f	\N	2025-10-30 18:52:04.981	2025-10-30 18:52:04.981
2062	141	9	f	\N	2025-10-30 18:52:04.984	2025-10-30 18:52:04.984
2063	141	10	f	\N	2025-10-30 18:52:04.986	2025-10-30 18:52:04.986
2064	141	11	f	\N	2025-10-30 18:52:04.99	2025-10-30 18:52:04.99
2065	141	12	f	\N	2025-10-30 18:52:04.993	2025-10-30 18:52:04.993
2066	141	13	f	\N	2025-10-30 18:52:04.995	2025-10-30 18:52:04.995
2067	141	14	f	\N	2025-10-30 18:52:04.997	2025-10-30 18:52:04.997
2068	141	15	f	\N	2025-10-30 18:52:05	2025-10-30 18:52:05
2266	155	3	f	\N	2025-11-03 22:41:08.653	2025-11-03 22:41:08.653
2267	155	4	f	\N	2025-11-03 22:41:08.656	2025-11-03 22:41:08.656
2268	155	5	f	\N	2025-11-03 22:41:08.658	2025-11-03 22:41:08.658
2269	155	6	f	\N	2025-11-03 22:41:08.661	2025-11-03 22:41:08.661
2270	155	7	f	\N	2025-11-03 22:41:08.664	2025-11-03 22:41:08.664
2271	155	8	f	\N	2025-11-03 22:41:08.666	2025-11-03 22:41:08.666
2272	155	9	f	\N	2025-11-03 22:41:08.668	2025-11-03 22:41:08.668
2273	155	10	f	\N	2025-11-03 22:41:08.673	2025-11-03 22:41:08.673
2274	155	11	f	\N	2025-11-03 22:41:08.675	2025-11-03 22:41:08.675
2275	155	12	f	\N	2025-11-03 22:41:08.678	2025-11-03 22:41:08.678
2276	155	13	f	\N	2025-11-03 22:41:08.681	2025-11-03 22:41:08.681
2277	155	14	f	\N	2025-11-03 22:41:08.683	2025-11-03 22:41:08.683
2278	155	15	f	\N	2025-11-03 22:41:08.687	2025-11-03 22:41:08.687
2302	157	9	f	\N	2025-11-05 16:28:10.232	2025-11-05 16:28:10.232
2303	157	10	f	\N	2025-11-05 16:28:10.236	2025-11-05 16:28:10.236
2304	157	11	f	\N	2025-11-05 16:28:10.238	2025-11-05 16:28:10.238
2305	157	12	f	\N	2025-11-05 16:28:10.24	2025-11-05 16:28:10.24
2306	157	13	f	\N	2025-11-05 16:28:10.242	2025-11-05 16:28:10.242
2307	157	14	f	\N	2025-11-05 16:28:10.244	2025-11-05 16:28:10.244
2308	157	15	f	\N	2025-11-05 16:28:10.246	2025-11-05 16:28:10.246
2941	179	3	f	\N	2025-11-13 18:11:26.506	2025-11-13 18:11:26.506
2942	179	4	f	\N	2025-11-13 18:11:26.508	2025-11-13 18:11:26.508
2943	179	5	f	\N	2025-11-13 18:11:26.509	2025-11-13 18:11:26.509
2944	179	6	f	\N	2025-11-13 18:11:26.511	2025-11-13 18:11:26.511
2945	179	7	f	\N	2025-11-13 18:11:26.513	2025-11-13 18:11:26.513
2946	179	8	f	\N	2025-11-13 18:11:26.514	2025-11-13 18:11:26.514
2947	179	9	f	\N	2025-11-13 18:11:26.516	2025-11-13 18:11:26.516
2948	179	10	f	\N	2025-11-13 18:11:26.517	2025-11-13 18:11:26.517
2949	179	11	f	\N	2025-11-13 18:11:26.519	2025-11-13 18:11:26.519
2950	179	12	f	\N	2025-11-13 18:11:26.52	2025-11-13 18:11:26.52
2099	138	1	f	\N	2025-10-31 19:52:02.485	2025-10-31 19:52:02.485
2100	138	2	f	\N	2025-10-31 19:52:02.492	2025-10-31 19:52:02.492
2101	138	3	f	\N	2025-10-31 19:52:02.496	2025-10-31 19:52:02.496
2102	138	4	f	\N	2025-10-31 19:52:02.5	2025-10-31 19:52:02.5
2103	138	5	f	\N	2025-10-31 19:52:02.505	2025-10-31 19:52:02.505
2104	138	6	f	\N	2025-10-31 19:52:02.514	2025-10-31 19:52:02.514
2105	138	7	f	\N	2025-10-31 19:52:02.519	2025-10-31 19:52:02.519
2106	138	8	f	\N	2025-10-31 19:52:02.524	2025-10-31 19:52:02.524
2107	138	9	f	\N	2025-10-31 19:52:02.531	2025-10-31 19:52:02.531
2108	138	10	f	\N	2025-10-31 19:52:02.539	2025-10-31 19:52:02.539
2109	138	11	f	\N	2025-10-31 19:52:02.543	2025-10-31 19:52:02.543
2110	138	12	f	\N	2025-10-31 19:52:02.546	2025-10-31 19:52:02.546
2111	138	13	f	\N	2025-10-31 19:52:02.55	2025-10-31 19:52:02.55
2112	138	14	f	\N	2025-10-31 19:52:02.555	2025-10-31 19:52:02.555
2113	138	15	f	\N	2025-10-31 19:52:02.557	2025-10-31 19:52:02.557
2114	142	1	f	\N	2025-10-31 20:55:03.313	2025-10-31 20:55:03.313
2115	142	2	f	\N	2025-10-31 20:55:03.319	2025-10-31 20:55:03.319
2116	142	3	f	\N	2025-10-31 20:55:03.322	2025-10-31 20:55:03.322
2117	142	4	f	\N	2025-10-31 20:55:03.325	2025-10-31 20:55:03.325
2118	142	5	f	\N	2025-10-31 20:55:03.328	2025-10-31 20:55:03.328
2119	142	6	f	\N	2025-10-31 20:55:03.332	2025-10-31 20:55:03.332
2120	142	7	f	\N	2025-10-31 20:55:03.335	2025-10-31 20:55:03.335
2121	142	8	f	\N	2025-10-31 20:55:03.338	2025-10-31 20:55:03.338
2122	142	9	f	\N	2025-10-31 20:55:03.342	2025-10-31 20:55:03.342
2123	142	10	f	\N	2025-10-31 20:55:03.345	2025-10-31 20:55:03.345
2124	142	11	f	\N	2025-10-31 20:55:03.348	2025-10-31 20:55:03.348
2125	142	12	f	\N	2025-10-31 20:55:03.351	2025-10-31 20:55:03.351
2126	142	13	f	\N	2025-10-31 20:55:03.354	2025-10-31 20:55:03.354
2127	142	14	f	\N	2025-10-31 20:55:03.358	2025-10-31 20:55:03.358
2128	142	15	f	\N	2025-10-31 20:55:03.36	2025-10-31 20:55:03.36
2129	143	1	f	\N	2025-10-31 21:41:36.722	2025-10-31 21:41:36.722
2130	143	2	f	\N	2025-10-31 21:41:36.725	2025-10-31 21:41:36.725
2131	143	3	f	\N	2025-10-31 21:41:36.728	2025-10-31 21:41:36.728
2132	143	4	f	\N	2025-10-31 21:41:36.73	2025-10-31 21:41:36.73
2133	143	5	f	\N	2025-10-31 21:41:36.733	2025-10-31 21:41:36.733
2134	143	6	f	\N	2025-10-31 21:41:36.737	2025-10-31 21:41:36.737
2135	143	7	f	\N	2025-10-31 21:41:36.739	2025-10-31 21:41:36.739
2136	143	8	f	\N	2025-10-31 21:41:36.742	2025-10-31 21:41:36.742
2137	143	9	f	\N	2025-10-31 21:41:36.745	2025-10-31 21:41:36.745
2138	143	10	f	\N	2025-10-31 21:41:36.747	2025-10-31 21:41:36.747
2139	143	11	f	\N	2025-10-31 21:41:36.749	2025-10-31 21:41:36.749
2140	143	12	f	\N	2025-10-31 21:41:36.752	2025-10-31 21:41:36.752
2141	143	13	f	\N	2025-10-31 21:41:36.755	2025-10-31 21:41:36.755
2142	143	14	f	\N	2025-10-31 21:41:36.758	2025-10-31 21:41:36.758
2143	143	15	f	\N	2025-10-31 21:41:36.76	2025-10-31 21:41:36.76
2951	179	13	f	\N	2025-11-13 18:11:26.522	2025-11-13 18:11:26.522
2952	179	14	f	\N	2025-11-13 18:11:26.523	2025-11-13 18:11:26.523
2953	179	15	f	\N	2025-11-13 18:11:26.525	2025-11-13 18:11:26.525
2324	158	1	f	\N	2025-11-05 23:28:21.517	2025-11-05 23:28:21.517
2325	158	2	f	\N	2025-11-05 23:28:21.521	2025-11-05 23:28:21.521
2326	158	3	f	\N	2025-11-05 23:28:21.525	2025-11-05 23:28:21.525
2327	158	4	f	\N	2025-11-05 23:28:21.527	2025-11-05 23:28:21.527
2328	158	5	f	\N	2025-11-05 23:28:21.529	2025-11-05 23:28:21.529
2329	158	6	f	\N	2025-11-05 23:28:21.531	2025-11-05 23:28:21.531
2330	158	7	f	\N	2025-11-05 23:28:21.533	2025-11-05 23:28:21.533
2331	158	8	f	\N	2025-11-05 23:28:21.535	2025-11-05 23:28:21.535
2332	158	9	f	\N	2025-11-05 23:28:21.539	2025-11-05 23:28:21.539
2333	158	10	f	\N	2025-11-05 23:28:21.541	2025-11-05 23:28:21.541
2334	158	11	f	\N	2025-11-05 23:28:21.544	2025-11-05 23:28:21.544
2335	158	12	f	\N	2025-11-05 23:28:21.546	2025-11-05 23:28:21.546
2336	158	13	f	\N	2025-11-05 23:28:21.549	2025-11-05 23:28:21.549
2337	158	14	f	\N	2025-11-05 23:28:21.551	2025-11-05 23:28:21.551
2338	158	15	f	\N	2025-11-05 23:28:21.553	2025-11-05 23:28:21.553
2954	183	1	f	\N	2025-11-13 18:12:11.253	2025-11-13 18:12:11.253
2955	183	2	f	\N	2025-11-13 18:12:11.256	2025-11-13 18:12:11.256
2956	183	3	f	\N	2025-11-13 18:12:11.259	2025-11-13 18:12:11.259
2957	183	4	f	\N	2025-11-13 18:12:11.261	2025-11-13 18:12:11.261
2958	183	5	f	\N	2025-11-13 18:12:11.263	2025-11-13 18:12:11.263
2959	183	6	f	\N	2025-11-13 18:12:11.266	2025-11-13 18:12:11.266
2960	183	7	f	\N	2025-11-13 18:12:11.268	2025-11-13 18:12:11.268
2961	183	8	f	\N	2025-11-13 18:12:11.271	2025-11-13 18:12:11.271
2962	183	9	f	\N	2025-11-13 18:12:11.273	2025-11-13 18:12:11.273
2963	183	10	f	\N	2025-11-13 18:12:11.275	2025-11-13 18:12:11.275
2964	183	11	f	\N	2025-11-13 18:12:11.278	2025-11-13 18:12:11.278
2965	183	12	f	\N	2025-11-13 18:12:11.28	2025-11-13 18:12:11.28
2966	183	13	f	\N	2025-11-13 18:12:11.283	2025-11-13 18:12:11.283
2967	183	14	f	\N	2025-11-13 18:12:11.286	2025-11-13 18:12:11.286
2968	183	15	f	\N	2025-11-13 18:12:11.29	2025-11-13 18:12:11.29
2354	161	1	f	\N	2025-11-06 22:22:35.51	2025-11-06 22:22:35.51
2355	161	2	f	\N	2025-11-06 22:22:35.514	2025-11-06 22:22:35.514
2356	161	3	f	\N	2025-11-06 22:22:35.517	2025-11-06 22:22:35.517
2357	161	4	f	\N	2025-11-06 22:22:35.519	2025-11-06 22:22:35.519
2358	161	5	f	\N	2025-11-06 22:22:35.521	2025-11-06 22:22:35.521
2359	161	6	f	\N	2025-11-06 22:22:35.523	2025-11-06 22:22:35.523
2360	161	7	f	\N	2025-11-06 22:22:35.526	2025-11-06 22:22:35.526
2361	161	8	f	\N	2025-11-06 22:22:35.528	2025-11-06 22:22:35.528
2362	161	9	f	\N	2025-11-06 22:22:35.53	2025-11-06 22:22:35.53
2363	161	10	f	\N	2025-11-06 22:22:35.533	2025-11-06 22:22:35.533
2364	161	11	f	\N	2025-11-06 22:22:35.535	2025-11-06 22:22:35.535
2365	161	12	f	\N	2025-11-06 22:22:35.538	2025-11-06 22:22:35.538
2366	161	13	f	\N	2025-11-06 22:22:35.541	2025-11-06 22:22:35.541
2367	161	14	f	\N	2025-11-06 22:22:35.543	2025-11-06 22:22:35.543
2368	161	15	f	\N	2025-11-06 22:22:35.546	2025-11-06 22:22:35.546
2969	181	1	f	\N	2025-11-13 18:12:33.491	2025-11-13 18:12:33.491
2970	181	2	f	\N	2025-11-13 18:12:33.494	2025-11-13 18:12:33.494
2971	181	3	f	\N	2025-11-13 18:12:33.496	2025-11-13 18:12:33.496
2972	181	4	f	\N	2025-11-13 18:12:33.498	2025-11-13 18:12:33.498
2973	181	5	f	\N	2025-11-13 18:12:33.5	2025-11-13 18:12:33.5
2974	181	6	f	\N	2025-11-13 18:12:33.502	2025-11-13 18:12:33.502
2975	181	7	f	\N	2025-11-13 18:12:33.504	2025-11-13 18:12:33.504
2976	181	8	f	\N	2025-11-13 18:12:33.506	2025-11-13 18:12:33.506
2977	181	9	f	\N	2025-11-13 18:12:33.509	2025-11-13 18:12:33.509
2399	164	1	f	\N	2025-11-07 16:01:04.953	2025-11-07 16:01:04.953
2400	164	2	f	\N	2025-11-07 16:01:04.956	2025-11-07 16:01:04.956
2401	164	3	f	\N	2025-11-07 16:01:04.958	2025-11-07 16:01:04.958
2402	164	4	f	\N	2025-11-07 16:01:04.959	2025-11-07 16:01:04.959
2403	164	5	f	\N	2025-11-07 16:01:04.961	2025-11-07 16:01:04.961
2404	164	6	f	\N	2025-11-07 16:01:04.963	2025-11-07 16:01:04.963
2405	164	7	f	\N	2025-11-07 16:01:04.965	2025-11-07 16:01:04.965
2406	164	8	f	\N	2025-11-07 16:01:04.968	2025-11-07 16:01:04.968
2407	164	9	f	\N	2025-11-07 16:01:04.969	2025-11-07 16:01:04.969
2408	164	10	f	\N	2025-11-07 16:01:04.971	2025-11-07 16:01:04.971
2409	164	11	f	\N	2025-11-07 16:01:04.974	2025-11-07 16:01:04.974
2410	164	12	f	\N	2025-11-07 16:01:04.977	2025-11-07 16:01:04.977
2411	164	13	f	\N	2025-11-07 16:01:04.981	2025-11-07 16:01:04.981
2412	164	14	f	\N	2025-11-07 16:01:04.982	2025-11-07 16:01:04.982
2413	164	15	f	\N	2025-11-07 16:01:04.984	2025-11-07 16:01:04.984
2414	162	1	f	\N	2025-11-07 22:29:58.451	2025-11-07 22:29:58.451
2415	162	2	f	\N	2025-11-07 22:29:58.453	2025-11-07 22:29:58.453
2416	162	3	f	\N	2025-11-07 22:29:58.454	2025-11-07 22:29:58.454
2417	162	4	f	\N	2025-11-07 22:29:58.457	2025-11-07 22:29:58.457
2418	162	5	f	\N	2025-11-07 22:29:58.46	2025-11-07 22:29:58.46
2419	162	6	f	\N	2025-11-07 22:29:58.461	2025-11-07 22:29:58.461
2420	162	7	f	\N	2025-11-07 22:29:58.462	2025-11-07 22:29:58.462
2421	162	8	f	\N	2025-11-07 22:29:58.463	2025-11-07 22:29:58.463
2422	162	9	f	\N	2025-11-07 22:29:58.465	2025-11-07 22:29:58.465
2423	162	10	f	\N	2025-11-07 22:29:58.466	2025-11-07 22:29:58.466
2424	162	11	f	\N	2025-11-07 22:29:58.468	2025-11-07 22:29:58.468
2425	162	12	f	\N	2025-11-07 22:29:58.47	2025-11-07 22:29:58.47
2426	162	13	f	\N	2025-11-07 22:29:58.471	2025-11-07 22:29:58.471
2427	162	14	f	\N	2025-11-07 22:29:58.472	2025-11-07 22:29:58.472
2428	162	15	f	\N	2025-11-07 22:29:58.473	2025-11-07 22:29:58.473
2429	166	1	f	\N	2025-11-08 20:56:56.917	2025-11-08 20:56:56.917
2430	166	2	f	\N	2025-11-08 20:56:56.92	2025-11-08 20:56:56.92
2431	166	3	f	\N	2025-11-08 20:56:56.922	2025-11-08 20:56:56.922
2432	166	4	f	\N	2025-11-08 20:56:56.924	2025-11-08 20:56:56.924
2433	166	5	f	\N	2025-11-08 20:56:56.926	2025-11-08 20:56:56.926
2434	166	6	f	\N	2025-11-08 20:56:56.93	2025-11-08 20:56:56.93
2435	166	7	f	\N	2025-11-08 20:56:56.932	2025-11-08 20:56:56.932
2436	166	8	f	\N	2025-11-08 20:56:56.933	2025-11-08 20:56:56.933
2437	166	9	f	\N	2025-11-08 20:56:56.935	2025-11-08 20:56:56.935
2438	166	10	f	\N	2025-11-08 20:56:56.937	2025-11-08 20:56:56.937
2439	166	11	f	\N	2025-11-08 20:56:56.939	2025-11-08 20:56:56.939
2440	166	12	f	\N	2025-11-08 20:56:56.941	2025-11-08 20:56:56.941
2441	166	13	f	\N	2025-11-08 20:56:56.945	2025-11-08 20:56:56.945
2442	166	14	f	\N	2025-11-08 20:56:56.947	2025-11-08 20:56:56.947
2443	166	15	f	\N	2025-11-08 20:56:56.949	2025-11-08 20:56:56.949
2444	160	1	f	\N	2025-11-08 21:05:07.7	2025-11-08 21:05:07.7
2445	160	2	f	\N	2025-11-08 21:05:07.703	2025-11-08 21:05:07.703
2446	160	3	f	\N	2025-11-08 21:05:07.706	2025-11-08 21:05:07.706
2447	160	4	f	\N	2025-11-08 21:05:07.708	2025-11-08 21:05:07.708
2448	160	5	f	\N	2025-11-08 21:05:07.71	2025-11-08 21:05:07.71
2449	160	6	f	\N	2025-11-08 21:05:07.712	2025-11-08 21:05:07.712
2450	160	7	f	\N	2025-11-08 21:05:07.714	2025-11-08 21:05:07.714
2451	160	8	f	\N	2025-11-08 21:05:07.716	2025-11-08 21:05:07.716
2452	160	9	f	\N	2025-11-08 21:05:07.718	2025-11-08 21:05:07.718
2453	160	10	f	\N	2025-11-08 21:05:07.719	2025-11-08 21:05:07.719
2454	160	11	f	\N	2025-11-08 21:05:07.722	2025-11-08 21:05:07.722
2455	160	12	f	\N	2025-11-08 21:05:07.724	2025-11-08 21:05:07.724
2456	160	13	f	\N	2025-11-08 21:05:07.726	2025-11-08 21:05:07.726
2457	160	14	f	\N	2025-11-08 21:05:07.728	2025-11-08 21:05:07.728
2458	160	15	f	\N	2025-11-08 21:05:07.73	2025-11-08 21:05:07.73
2474	168	1	f	\N	2025-11-08 21:53:18.639	2025-11-08 21:53:18.639
2475	168	2	f	\N	2025-11-08 21:53:18.641	2025-11-08 21:53:18.641
2476	168	3	f	\N	2025-11-08 21:53:18.643	2025-11-08 21:53:18.643
2477	168	4	f	\N	2025-11-08 21:53:18.645	2025-11-08 21:53:18.645
2478	168	5	f	\N	2025-11-08 21:53:18.647	2025-11-08 21:53:18.647
2479	168	6	f	\N	2025-11-08 21:53:18.649	2025-11-08 21:53:18.649
2480	168	7	f	\N	2025-11-08 21:53:18.65	2025-11-08 21:53:18.65
2481	168	8	f	\N	2025-11-08 21:53:18.652	2025-11-08 21:53:18.652
2482	168	9	f	\N	2025-11-08 21:53:18.654	2025-11-08 21:53:18.654
2483	168	10	f	\N	2025-11-08 21:53:18.655	2025-11-08 21:53:18.655
2484	168	11	f	\N	2025-11-08 21:53:18.657	2025-11-08 21:53:18.657
2485	168	12	f	\N	2025-11-08 21:53:18.659	2025-11-08 21:53:18.659
2486	168	13	f	\N	2025-11-08 21:53:18.66	2025-11-08 21:53:18.66
2487	168	14	f	\N	2025-11-08 21:53:18.662	2025-11-08 21:53:18.662
2488	168	15	f	\N	2025-11-08 21:53:18.664	2025-11-08 21:53:18.664
2489	163	1	f	\N	2025-11-09 19:16:34.146	2025-11-09 19:16:34.146
2490	163	2	f	\N	2025-11-09 19:16:34.149	2025-11-09 19:16:34.149
2491	163	3	f	\N	2025-11-09 19:16:34.151	2025-11-09 19:16:34.151
2492	163	4	f	\N	2025-11-09 19:16:34.154	2025-11-09 19:16:34.154
2493	163	5	f	\N	2025-11-09 19:16:34.157	2025-11-09 19:16:34.157
2494	163	6	f	\N	2025-11-09 19:16:34.161	2025-11-09 19:16:34.161
2495	163	7	f	\N	2025-11-09 19:16:34.164	2025-11-09 19:16:34.164
2496	163	8	f	\N	2025-11-09 19:16:34.168	2025-11-09 19:16:34.168
2497	163	9	f	\N	2025-11-09 19:16:34.17	2025-11-09 19:16:34.17
2498	163	10	f	\N	2025-11-09 19:16:34.173	2025-11-09 19:16:34.173
2499	163	11	f	\N	2025-11-09 19:16:34.175	2025-11-09 19:16:34.175
2500	163	12	f	\N	2025-11-09 19:16:34.177	2025-11-09 19:16:34.177
2501	163	13	f	\N	2025-11-09 19:16:34.18	2025-11-09 19:16:34.18
2502	163	14	f	\N	2025-11-09 19:16:34.182	2025-11-09 19:16:34.182
2503	163	15	f	\N	2025-11-09 19:16:34.184	2025-11-09 19:16:34.184
2978	181	10	f	\N	2025-11-13 18:12:33.511	2025-11-13 18:12:33.511
2979	181	11	f	\N	2025-11-13 18:12:33.514	2025-11-13 18:12:33.514
2980	181	12	f	\N	2025-11-13 18:12:33.517	2025-11-13 18:12:33.517
2981	181	13	f	\N	2025-11-13 18:12:33.519	2025-11-13 18:12:33.519
2982	181	14	f	\N	2025-11-13 18:12:33.522	2025-11-13 18:12:33.522
2983	181	15	f	\N	2025-11-13 18:12:33.524	2025-11-13 18:12:33.524
3014	205	1	f	\N	2025-11-14 20:00:50.684	2025-11-14 20:00:50.684
2534	171	1	f	\N	2025-11-09 22:19:10.431	2025-11-09 22:19:10.431
2535	171	2	f	\N	2025-11-09 22:19:10.434	2025-11-09 22:19:10.434
2536	171	3	f	\N	2025-11-09 22:19:10.437	2025-11-09 22:19:10.437
2537	171	4	f	\N	2025-11-09 22:19:10.44	2025-11-09 22:19:10.44
2538	171	5	f	\N	2025-11-09 22:19:10.443	2025-11-09 22:19:10.443
2539	171	6	f	\N	2025-11-09 22:19:10.445	2025-11-09 22:19:10.445
2540	171	7	f	\N	2025-11-09 22:19:10.447	2025-11-09 22:19:10.447
2541	171	8	f	\N	2025-11-09 22:19:10.449	2025-11-09 22:19:10.449
2542	171	9	f	\N	2025-11-09 22:19:10.451	2025-11-09 22:19:10.451
2543	171	10	f	\N	2025-11-09 22:19:10.453	2025-11-09 22:19:10.453
2544	171	11	f	\N	2025-11-09 22:19:10.455	2025-11-09 22:19:10.455
2545	171	12	f	\N	2025-11-09 22:19:10.457	2025-11-09 22:19:10.457
2546	171	13	f	\N	2025-11-09 22:19:10.459	2025-11-09 22:19:10.459
2547	171	14	f	\N	2025-11-09 22:19:10.461	2025-11-09 22:19:10.461
2548	171	15	f	\N	2025-11-09 22:19:10.463	2025-11-09 22:19:10.463
2549	172	1	f	\N	2025-11-10 20:42:12.898	2025-11-10 20:42:12.898
2550	172	2	f	\N	2025-11-10 20:42:12.901	2025-11-10 20:42:12.901
2551	172	3	f	\N	2025-11-10 20:42:12.903	2025-11-10 20:42:12.903
2552	172	4	f	\N	2025-11-10 20:42:12.904	2025-11-10 20:42:12.904
2553	172	5	f	\N	2025-11-10 20:42:12.907	2025-11-10 20:42:12.907
2554	172	6	f	\N	2025-11-10 20:42:12.909	2025-11-10 20:42:12.909
2555	172	7	f	\N	2025-11-10 20:42:12.91	2025-11-10 20:42:12.91
2556	172	8	f	\N	2025-11-10 20:42:12.912	2025-11-10 20:42:12.912
2557	172	9	f	\N	2025-11-10 20:42:12.913	2025-11-10 20:42:12.913
2558	172	10	f	\N	2025-11-10 20:42:12.915	2025-11-10 20:42:12.915
2559	172	11	f	\N	2025-11-10 20:42:12.917	2025-11-10 20:42:12.917
2560	172	12	f	\N	2025-11-10 20:42:12.92	2025-11-10 20:42:12.92
2561	172	13	f	\N	2025-11-10 20:42:12.922	2025-11-10 20:42:12.922
2562	172	14	f	\N	2025-11-10 20:42:12.924	2025-11-10 20:42:12.924
2563	172	15	f	\N	2025-11-10 20:42:12.928	2025-11-10 20:42:12.928
2564	175	1	f	\N	2025-11-10 21:14:39.431	2025-11-10 21:14:39.431
2565	175	2	f	\N	2025-11-10 21:14:39.434	2025-11-10 21:14:39.434
2566	175	3	f	\N	2025-11-10 21:14:39.437	2025-11-10 21:14:39.437
2567	175	4	f	\N	2025-11-10 21:14:39.44	2025-11-10 21:14:39.44
2568	175	5	f	\N	2025-11-10 21:14:39.442	2025-11-10 21:14:39.442
2569	175	6	f	\N	2025-11-10 21:14:39.444	2025-11-10 21:14:39.444
2570	175	7	f	\N	2025-11-10 21:14:39.447	2025-11-10 21:14:39.447
2571	175	8	f	\N	2025-11-10 21:14:39.449	2025-11-10 21:14:39.449
2572	175	9	f	\N	2025-11-10 21:14:39.451	2025-11-10 21:14:39.451
2573	175	10	f	\N	2025-11-10 21:14:39.453	2025-11-10 21:14:39.453
2574	175	11	f	\N	2025-11-10 21:14:39.455	2025-11-10 21:14:39.455
2575	175	12	f	\N	2025-11-10 21:14:39.457	2025-11-10 21:14:39.457
2576	175	13	f	\N	2025-11-10 21:14:39.459	2025-11-10 21:14:39.459
2577	175	14	f	\N	2025-11-10 21:14:39.461	2025-11-10 21:14:39.461
2578	175	15	f	\N	2025-11-10 21:14:39.463	2025-11-10 21:14:39.463
3015	205	2	f	\N	2025-11-14 20:00:50.689	2025-11-14 20:00:50.689
3016	205	3	f	\N	2025-11-14 20:00:50.692	2025-11-14 20:00:50.692
3017	205	4	f	\N	2025-11-14 20:00:50.694	2025-11-14 20:00:50.694
3018	205	5	f	\N	2025-11-14 20:00:50.697	2025-11-14 20:00:50.697
3019	205	6	f	\N	2025-11-14 20:00:50.699	2025-11-14 20:00:50.699
3020	205	7	f	\N	2025-11-14 20:00:50.702	2025-11-14 20:00:50.702
3021	205	8	f	\N	2025-11-14 20:00:50.704	2025-11-14 20:00:50.704
3022	205	9	f	\N	2025-11-14 20:00:50.707	2025-11-14 20:00:50.707
3023	205	10	f	\N	2025-11-14 20:00:50.709	2025-11-14 20:00:50.709
3024	205	11	f	\N	2025-11-14 20:00:50.711	2025-11-14 20:00:50.711
3025	205	12	f	\N	2025-11-14 20:00:50.713	2025-11-14 20:00:50.713
3026	205	13	f	\N	2025-11-14 20:00:50.716	2025-11-14 20:00:50.716
3027	205	14	f	\N	2025-11-14 20:00:50.719	2025-11-14 20:00:50.719
3028	205	15	f	\N	2025-11-14 20:00:50.721	2025-11-14 20:00:50.721
3074	208	1	f	\N	2025-11-15 18:49:00.443	2025-11-15 18:49:00.443
2609	176	1	f	\N	2025-11-10 21:55:54.212	2025-11-10 21:55:54.212
2610	176	2	f	\N	2025-11-10 21:55:54.214	2025-11-10 21:55:54.214
2611	176	3	f	\N	2025-11-10 21:55:54.216	2025-11-10 21:55:54.216
2612	176	4	f	\N	2025-11-10 21:55:54.219	2025-11-10 21:55:54.219
2613	176	5	f	\N	2025-11-10 21:55:54.221	2025-11-10 21:55:54.221
2614	176	6	f	\N	2025-11-10 21:55:54.223	2025-11-10 21:55:54.223
2615	176	7	f	\N	2025-11-10 21:55:54.225	2025-11-10 21:55:54.225
2616	176	8	f	\N	2025-11-10 21:55:54.227	2025-11-10 21:55:54.227
2617	176	9	f	\N	2025-11-10 21:55:54.23	2025-11-10 21:55:54.23
2618	176	10	f	\N	2025-11-10 21:55:54.232	2025-11-10 21:55:54.232
2619	176	11	f	\N	2025-11-10 21:55:54.235	2025-11-10 21:55:54.235
2620	176	12	f	\N	2025-11-10 21:55:54.237	2025-11-10 21:55:54.237
2621	176	13	f	\N	2025-11-10 21:55:54.239	2025-11-10 21:55:54.239
2622	176	14	f	\N	2025-11-10 21:55:54.241	2025-11-10 21:55:54.241
2623	176	15	f	\N	2025-11-10 21:55:54.243	2025-11-10 21:55:54.243
3075	208	2	f	\N	2025-11-15 18:49:00.446	2025-11-15 18:49:00.446
3076	208	3	f	\N	2025-11-15 18:49:00.448	2025-11-15 18:49:00.448
3077	208	4	f	\N	2025-11-15 18:49:00.449	2025-11-15 18:49:00.449
3078	208	5	f	\N	2025-11-15 18:49:00.451	2025-11-15 18:49:00.451
3079	208	6	f	\N	2025-11-15 18:49:00.453	2025-11-15 18:49:00.453
3080	208	7	f	\N	2025-11-15 18:49:00.455	2025-11-15 18:49:00.455
3081	208	8	f	\N	2025-11-15 18:49:00.456	2025-11-15 18:49:00.456
3082	208	9	f	\N	2025-11-15 18:49:00.458	2025-11-15 18:49:00.458
3083	208	10	f	\N	2025-11-15 18:49:00.46	2025-11-15 18:49:00.46
3084	208	11	f	\N	2025-11-15 18:49:00.462	2025-11-15 18:49:00.462
3085	208	12	f	\N	2025-11-15 18:49:00.463	2025-11-15 18:49:00.463
3086	208	13	f	\N	2025-11-15 18:49:00.465	2025-11-15 18:49:00.465
3087	208	14	f	\N	2025-11-15 18:49:00.467	2025-11-15 18:49:00.467
3088	208	15	f	\N	2025-11-15 18:49:00.469	2025-11-15 18:49:00.469
3119	207	1	f	\N	2025-11-18 21:36:36.002	2025-11-18 21:36:36.002
2639	180	1	f	\N	2025-11-12 18:37:26.92	2025-11-12 18:37:26.92
2640	180	2	f	\N	2025-11-12 18:37:26.923	2025-11-12 18:37:26.923
2641	180	3	f	\N	2025-11-12 18:37:26.926	2025-11-12 18:37:26.926
2642	180	4	f	\N	2025-11-12 18:37:26.93	2025-11-12 18:37:26.93
2643	180	5	f	\N	2025-11-12 18:37:26.933	2025-11-12 18:37:26.933
2644	180	6	f	\N	2025-11-12 18:37:26.936	2025-11-12 18:37:26.936
2645	180	7	f	\N	2025-11-12 18:37:26.939	2025-11-12 18:37:26.939
2646	180	8	f	\N	2025-11-12 18:37:26.941	2025-11-12 18:37:26.941
2647	180	9	f	\N	2025-11-12 18:37:26.943	2025-11-12 18:37:26.943
2648	180	10	f	\N	2025-11-12 18:37:26.946	2025-11-12 18:37:26.946
2649	180	11	f	\N	2025-11-12 18:37:26.948	2025-11-12 18:37:26.948
2650	180	12	f	\N	2025-11-12 18:37:26.952	2025-11-12 18:37:26.952
2651	180	13	f	\N	2025-11-12 18:37:26.954	2025-11-12 18:37:26.954
2652	180	14	f	\N	2025-11-12 18:37:26.957	2025-11-12 18:37:26.957
2653	180	15	f	\N	2025-11-12 18:37:26.961	2025-11-12 18:37:26.961
3120	207	2	f	\N	2025-11-18 21:36:36.005	2025-11-18 21:36:36.005
3121	207	3	f	\N	2025-11-18 21:36:36.008	2025-11-18 21:36:36.008
3122	207	4	f	\N	2025-11-18 21:36:36.01	2025-11-18 21:36:36.01
3123	207	5	f	\N	2025-11-18 21:36:36.012	2025-11-18 21:36:36.012
3124	207	6	f	\N	2025-11-18 21:36:36.015	2025-11-18 21:36:36.015
3125	207	7	f	\N	2025-11-18 21:36:36.017	2025-11-18 21:36:36.017
3126	207	8	f	\N	2025-11-18 21:36:36.019	2025-11-18 21:36:36.019
3127	207	9	f	\N	2025-11-18 21:36:36.022	2025-11-18 21:36:36.022
3128	207	10	f	\N	2025-11-18 21:36:36.025	2025-11-18 21:36:36.025
3129	207	11	f	\N	2025-11-18 21:36:36.027	2025-11-18 21:36:36.027
3130	207	12	f	\N	2025-11-18 21:36:36.03	2025-11-18 21:36:36.03
3131	207	13	f	\N	2025-11-18 21:36:36.032	2025-11-18 21:36:36.032
3132	207	14	f	\N	2025-11-18 21:36:36.035	2025-11-18 21:36:36.035
3133	207	15	f	\N	2025-11-18 21:36:36.037	2025-11-18 21:36:36.037
3164	215	1	f	\N	2025-11-19 18:11:25.319	2025-11-19 18:11:25.319
3165	215	2	f	\N	2025-11-19 18:11:25.322	2025-11-19 18:11:25.322
3166	215	3	f	\N	2025-11-19 18:11:25.324	2025-11-19 18:11:25.324
3167	215	4	f	\N	2025-11-19 18:11:25.327	2025-11-19 18:11:25.327
3168	215	5	f	\N	2025-11-19 18:11:25.329	2025-11-19 18:11:25.329
3169	215	6	f	\N	2025-11-19 18:11:25.332	2025-11-19 18:11:25.332
3170	215	7	f	\N	2025-11-19 18:11:25.334	2025-11-19 18:11:25.334
2699	182	1	f	\N	2025-11-12 23:28:50.973	2025-11-12 23:28:50.973
2700	182	2	f	\N	2025-11-12 23:28:50.976	2025-11-12 23:28:50.976
2701	182	3	f	\N	2025-11-12 23:28:50.978	2025-11-12 23:28:50.978
2702	182	4	f	\N	2025-11-12 23:28:50.98	2025-11-12 23:28:50.98
2703	182	5	f	\N	2025-11-12 23:28:50.982	2025-11-12 23:28:50.982
2704	182	6	f	\N	2025-11-12 23:28:50.983	2025-11-12 23:28:50.983
2705	182	7	f	\N	2025-11-12 23:28:50.985	2025-11-12 23:28:50.985
2706	182	8	f	\N	2025-11-12 23:28:50.986	2025-11-12 23:28:50.986
2707	182	9	f	\N	2025-11-12 23:28:50.988	2025-11-12 23:28:50.988
2708	182	10	f	\N	2025-11-12 23:28:50.989	2025-11-12 23:28:50.989
2709	182	11	f	\N	2025-11-12 23:28:50.99	2025-11-12 23:28:50.99
2710	182	12	f	\N	2025-11-12 23:28:50.992	2025-11-12 23:28:50.992
2711	182	13	f	\N	2025-11-12 23:28:50.993	2025-11-12 23:28:50.993
2712	182	14	f	\N	2025-11-12 23:28:50.995	2025-11-12 23:28:50.995
2713	182	15	f	\N	2025-11-12 23:28:50.996	2025-11-12 23:28:50.996
2984	203	1	f	\N	2025-11-14 18:56:49.656	2025-11-14 18:56:49.656
2985	203	2	f	\N	2025-11-14 18:56:49.66	2025-11-14 18:56:49.66
2986	203	3	f	\N	2025-11-14 18:56:49.662	2025-11-14 18:56:49.662
2987	203	4	f	\N	2025-11-14 18:56:49.665	2025-11-14 18:56:49.665
2988	203	5	f	\N	2025-11-14 18:56:49.667	2025-11-14 18:56:49.667
2989	203	6	f	\N	2025-11-14 18:56:49.671	2025-11-14 18:56:49.671
2990	203	7	f	\N	2025-11-14 18:56:49.673	2025-11-14 18:56:49.673
2991	203	8	f	\N	2025-11-14 18:56:49.675	2025-11-14 18:56:49.675
2992	203	9	f	\N	2025-11-14 18:56:49.677	2025-11-14 18:56:49.677
2993	203	10	f	\N	2025-11-14 18:56:49.68	2025-11-14 18:56:49.68
2994	203	11	f	\N	2025-11-14 18:56:49.682	2025-11-14 18:56:49.682
2995	203	12	f	\N	2025-11-14 18:56:49.684	2025-11-14 18:56:49.684
2996	203	13	f	\N	2025-11-14 18:56:49.687	2025-11-14 18:56:49.687
2997	203	14	f	\N	2025-11-14 18:56:49.689	2025-11-14 18:56:49.689
2998	203	15	f	\N	2025-11-14 18:56:49.692	2025-11-14 18:56:49.692
3029	204	1	f	\N	2025-11-14 22:05:12.084	2025-11-14 22:05:12.084
3030	204	2	f	\N	2025-11-14 22:05:12.086	2025-11-14 22:05:12.086
3031	204	3	f	\N	2025-11-14 22:05:12.089	2025-11-14 22:05:12.089
3032	204	4	f	\N	2025-11-14 22:05:12.091	2025-11-14 22:05:12.091
3033	204	5	f	\N	2025-11-14 22:05:12.093	2025-11-14 22:05:12.093
3034	204	6	f	\N	2025-11-14 22:05:12.096	2025-11-14 22:05:12.096
3035	204	7	f	\N	2025-11-14 22:05:12.097	2025-11-14 22:05:12.097
3036	204	8	f	\N	2025-11-14 22:05:12.099	2025-11-14 22:05:12.099
3037	204	9	f	\N	2025-11-14 22:05:12.1	2025-11-14 22:05:12.1
3038	204	10	f	\N	2025-11-14 22:05:12.102	2025-11-14 22:05:12.102
3039	204	11	f	\N	2025-11-14 22:05:12.105	2025-11-14 22:05:12.105
3040	204	12	f	\N	2025-11-14 22:05:12.109	2025-11-14 22:05:12.109
3041	204	13	f	\N	2025-11-14 22:05:12.111	2025-11-14 22:05:12.111
3042	204	14	f	\N	2025-11-14 22:05:12.113	2025-11-14 22:05:12.113
3043	204	15	f	\N	2025-11-14 22:05:12.114	2025-11-14 22:05:12.114
3089	210	1	f	\N	2025-11-15 23:44:30.829	2025-11-15 23:44:30.829
3090	210	2	f	\N	2025-11-15 23:44:30.832	2025-11-15 23:44:30.832
3091	210	3	f	\N	2025-11-15 23:44:30.835	2025-11-15 23:44:30.835
3092	210	4	f	\N	2025-11-15 23:44:30.838	2025-11-15 23:44:30.838
3093	210	5	f	\N	2025-11-15 23:44:30.841	2025-11-15 23:44:30.841
3094	210	6	f	\N	2025-11-15 23:44:30.844	2025-11-15 23:44:30.844
3095	210	7	f	\N	2025-11-15 23:44:30.847	2025-11-15 23:44:30.847
3096	210	8	f	\N	2025-11-15 23:44:30.85	2025-11-15 23:44:30.85
3097	210	9	f	\N	2025-11-15 23:44:30.852	2025-11-15 23:44:30.852
3098	210	10	f	\N	2025-11-15 23:44:30.854	2025-11-15 23:44:30.854
3099	210	11	f	\N	2025-11-15 23:44:30.858	2025-11-15 23:44:30.858
3100	210	12	f	\N	2025-11-15 23:44:30.861	2025-11-15 23:44:30.861
3101	210	13	f	\N	2025-11-15 23:44:30.862	2025-11-15 23:44:30.862
3102	210	14	f	\N	2025-11-15 23:44:30.865	2025-11-15 23:44:30.865
3103	210	15	f	\N	2025-11-15 23:44:30.869	2025-11-15 23:44:30.869
3149	213	1	t	marco roto sin cubre polvo de auricular	2025-11-19 15:03:10.74	2025-11-19 15:03:10.74
3150	213	2	f	\N	2025-11-19 15:03:10.742	2025-11-19 15:03:10.742
3151	213	3	f	\N	2025-11-19 15:03:10.744	2025-11-19 15:03:10.744
3152	213	4	f	\N	2025-11-19 15:03:10.746	2025-11-19 15:03:10.746
3153	213	5	f	\N	2025-11-19 15:03:10.748	2025-11-19 15:03:10.748
3154	213	6	f	\N	2025-11-19 15:03:10.75	2025-11-19 15:03:10.75
3155	213	7	f	\N	2025-11-19 15:03:10.752	2025-11-19 15:03:10.752
3156	213	8	f	\N	2025-11-19 15:03:10.756	2025-11-19 15:03:10.756
3157	213	9	f	\N	2025-11-19 15:03:10.758	2025-11-19 15:03:10.758
3158	213	10	f	\N	2025-11-19 15:03:10.761	2025-11-19 15:03:10.761
3159	213	11	f	\N	2025-11-19 15:03:10.763	2025-11-19 15:03:10.763
3160	213	12	f	\N	2025-11-19 15:03:10.765	2025-11-19 15:03:10.765
3161	213	13	f	\N	2025-11-19 15:03:10.767	2025-11-19 15:03:10.767
3162	213	14	f	\N	2025-11-19 15:03:10.769	2025-11-19 15:03:10.77
2789	185	1	f	\N	2025-11-12 23:58:22.614	2025-11-12 23:58:22.614
2790	185	2	f	\N	2025-11-12 23:58:22.616	2025-11-12 23:58:22.616
2791	185	3	f	\N	2025-11-12 23:58:22.618	2025-11-12 23:58:22.618
2792	185	4	f	\N	2025-11-12 23:58:22.622	2025-11-12 23:58:22.622
2793	185	5	f	\N	2025-11-12 23:58:22.625	2025-11-12 23:58:22.625
2794	185	6	f	\N	2025-11-12 23:58:22.627	2025-11-12 23:58:22.627
2795	185	7	f	\N	2025-11-12 23:58:22.63	2025-11-12 23:58:22.63
2796	185	8	f	\N	2025-11-12 23:58:22.632	2025-11-12 23:58:22.632
2797	185	9	f	\N	2025-11-12 23:58:22.64	2025-11-12 23:58:22.64
2798	185	10	f	\N	2025-11-12 23:58:22.644	2025-11-12 23:58:22.644
2799	185	11	f	\N	2025-11-12 23:58:22.646	2025-11-12 23:58:22.646
2800	185	12	f	\N	2025-11-12 23:58:22.648	2025-11-12 23:58:22.648
2801	185	13	f	\N	2025-11-12 23:58:22.65	2025-11-12 23:58:22.65
2802	185	14	f	\N	2025-11-12 23:58:22.652	2025-11-12 23:58:22.652
2803	185	15	f	\N	2025-11-12 23:58:22.654	2025-11-12 23:58:22.654
2804	191	1	f	\N	2025-11-13 15:35:29.13	2025-11-13 15:35:29.13
2805	191	2	f	\N	2025-11-13 15:35:29.133	2025-11-13 15:35:29.133
2806	191	3	f	\N	2025-11-13 15:35:29.135	2025-11-13 15:35:29.135
2807	191	4	f	\N	2025-11-13 15:35:29.138	2025-11-13 15:35:29.138
2808	191	5	f	\N	2025-11-13 15:35:29.142	2025-11-13 15:35:29.142
2809	191	6	f	\N	2025-11-13 15:35:29.145	2025-11-13 15:35:29.145
2810	191	7	f	\N	2025-11-13 15:35:29.149	2025-11-13 15:35:29.149
2811	191	8	f	\N	2025-11-13 15:35:29.151	2025-11-13 15:35:29.151
2812	191	9	f	\N	2025-11-13 15:35:29.154	2025-11-13 15:35:29.154
2813	191	10	f	\N	2025-11-13 15:35:29.157	2025-11-13 15:35:29.157
2814	191	11	f	\N	2025-11-13 15:35:29.16	2025-11-13 15:35:29.16
2815	191	12	f	\N	2025-11-13 15:35:29.162	2025-11-13 15:35:29.162
2816	191	13	f	\N	2025-11-13 15:35:29.165	2025-11-13 15:35:29.165
2817	191	14	f	\N	2025-11-13 15:35:29.167	2025-11-13 15:35:29.167
2818	191	15	f	\N	2025-11-13 15:35:29.17	2025-11-13 15:35:29.17
2819	192	1	f	\N	2025-11-13 15:54:23.471	2025-11-13 15:54:23.471
2820	192	2	f	\N	2025-11-13 15:54:23.475	2025-11-13 15:54:23.475
2821	192	3	f	\N	2025-11-13 15:54:23.478	2025-11-13 15:54:23.478
2822	192	4	f	\N	2025-11-13 15:54:23.481	2025-11-13 15:54:23.481
2823	192	5	f	\N	2025-11-13 15:54:23.484	2025-11-13 15:54:23.484
2824	192	6	f	\N	2025-11-13 15:54:23.487	2025-11-13 15:54:23.487
2825	192	7	f	\N	2025-11-13 15:54:23.49	2025-11-13 15:54:23.49
2826	192	8	f	\N	2025-11-13 15:54:23.492	2025-11-13 15:54:23.492
2827	192	9	f	\N	2025-11-13 15:54:23.498	2025-11-13 15:54:23.498
2828	192	10	f	\N	2025-11-13 15:54:23.501	2025-11-13 15:54:23.501
2829	192	11	f	\N	2025-11-13 15:54:23.504	2025-11-13 15:54:23.504
2830	192	12	f	\N	2025-11-13 15:54:23.506	2025-11-13 15:54:23.506
2831	192	13	f	\N	2025-11-13 15:54:23.509	2025-11-13 15:54:23.509
2832	192	14	f	\N	2025-11-13 15:54:23.512	2025-11-13 15:54:23.512
2833	192	15	f	\N	2025-11-13 15:54:23.514	2025-11-13 15:54:23.514
2849	193	1	f	\N	2025-11-13 17:15:17.213	2025-11-13 17:15:17.213
2850	193	2	f	\N	2025-11-13 17:15:17.215	2025-11-13 17:15:17.215
2851	193	3	f	\N	2025-11-13 17:15:17.217	2025-11-13 17:15:17.217
2852	193	4	f	\N	2025-11-13 17:15:17.218	2025-11-13 17:15:17.218
2853	193	5	f	\N	2025-11-13 17:15:17.22	2025-11-13 17:15:17.22
2854	193	6	f	\N	2025-11-13 17:15:17.222	2025-11-13 17:15:17.222
2855	193	7	f	\N	2025-11-13 17:15:17.223	2025-11-13 17:15:17.223
2856	193	8	f	\N	2025-11-13 17:15:17.225	2025-11-13 17:15:17.225
2857	193	9	f	\N	2025-11-13 17:15:17.227	2025-11-13 17:15:17.227
2858	193	10	f	\N	2025-11-13 17:15:17.229	2025-11-13 17:15:17.229
2859	193	11	f	\N	2025-11-13 17:15:17.231	2025-11-13 17:15:17.231
2860	193	12	f	\N	2025-11-13 17:15:17.232	2025-11-13 17:15:17.232
2861	193	13	f	\N	2025-11-13 17:15:17.234	2025-11-13 17:15:17.234
2862	193	14	f	\N	2025-11-13 17:15:17.236	2025-11-13 17:15:17.236
2863	193	15	f	\N	2025-11-13 17:15:17.237	2025-11-13 17:15:17.237
3104	211	1	f	\N	2025-11-18 21:31:33.418	2025-11-18 21:31:33.418
3105	211	2	f	\N	2025-11-18 21:31:33.422	2025-11-18 21:31:33.422
3106	211	3	f	\N	2025-11-18 21:31:33.426	2025-11-18 21:31:33.426
3107	211	4	f	\N	2025-11-18 21:31:33.429	2025-11-18 21:31:33.429
3108	211	5	f	\N	2025-11-18 21:31:33.432	2025-11-18 21:31:33.432
3109	211	6	f	\N	2025-11-18 21:31:33.435	2025-11-18 21:31:33.435
3110	211	7	f	\N	2025-11-18 21:31:33.439	2025-11-18 21:31:33.439
3111	211	8	f	\N	2025-11-18 21:31:33.442	2025-11-18 21:31:33.442
3112	211	9	f	\N	2025-11-18 21:31:33.445	2025-11-18 21:31:33.445
3113	211	10	f	\N	2025-11-18 21:31:33.447	2025-11-18 21:31:33.447
3114	211	11	f	\N	2025-11-18 21:31:33.452	2025-11-18 21:31:33.452
3115	211	12	f	\N	2025-11-18 21:31:33.456	2025-11-18 21:31:33.456
3116	211	13	f	\N	2025-11-18 21:31:33.458	2025-11-18 21:31:33.458
3117	211	14	f	\N	2025-11-18 21:31:33.461	2025-11-18 21:31:33.461
3118	211	15	f	\N	2025-11-18 21:31:33.466	2025-11-18 21:31:33.466
3163	213	15	f	\N	2025-11-19 15:03:10.772	2025-11-19 15:03:10.772
3171	215	8	f	\N	2025-11-19 18:11:25.336	2025-11-19 18:11:25.336
3172	215	9	f	\N	2025-11-19 18:11:25.338	2025-11-19 18:11:25.338
3173	215	10	f	\N	2025-11-19 18:11:25.341	2025-11-19 18:11:25.341
3174	215	11	f	\N	2025-11-19 18:11:25.344	2025-11-19 18:11:25.344
3175	215	12	f	\N	2025-11-19 18:11:25.346	2025-11-19 18:11:25.346
3176	215	13	f	\N	2025-11-19 18:11:25.348	2025-11-19 18:11:25.348
3177	215	14	f	\N	2025-11-19 18:11:25.351	2025-11-19 18:11:25.351
3178	215	15	f	\N	2025-11-19 18:11:25.353	2025-11-19 18:11:25.353
3209	216	1	f	\N	2025-11-20 19:21:54.952	2025-11-20 19:21:54.952
3210	216	2	f	\N	2025-11-20 19:21:54.955	2025-11-20 19:21:54.955
3211	216	3	f	\N	2025-11-20 19:21:54.958	2025-11-20 19:21:54.958
3212	216	4	f	\N	2025-11-20 19:21:54.961	2025-11-20 19:21:54.961
3213	216	5	f	\N	2025-11-20 19:21:54.963	2025-11-20 19:21:54.963
3214	216	6	f	\N	2025-11-20 19:21:54.965	2025-11-20 19:21:54.965
3215	216	7	f	\N	2025-11-20 19:21:54.967	2025-11-20 19:21:54.967
3216	216	8	f	\N	2025-11-20 19:21:54.971	2025-11-20 19:21:54.971
3217	216	9	f	\N	2025-11-20 19:21:54.975	2025-11-20 19:21:54.975
3218	216	10	f	\N	2025-11-20 19:21:54.979	2025-11-20 19:21:54.979
3219	216	11	f	\N	2025-11-20 19:21:54.982	2025-11-20 19:21:54.982
3220	216	12	f	\N	2025-11-20 19:21:54.986	2025-11-20 19:21:54.986
3221	216	13	f	\N	2025-11-20 19:21:54.989	2025-11-20 19:21:54.989
3222	216	14	f	\N	2025-11-20 19:21:54.992	2025-11-20 19:21:54.992
3223	216	15	f	\N	2025-11-20 19:21:54.995	2025-11-20 19:21:54.995
3254	219	1	f	\N	2025-11-21 18:29:10.132	2025-11-21 18:29:10.132
3255	219	2	f	\N	2025-11-21 18:29:10.134	2025-11-21 18:29:10.134
3256	219	3	f	\N	2025-11-21 18:29:10.137	2025-11-21 18:29:10.137
3257	219	4	f	\N	2025-11-21 18:29:10.141	2025-11-21 18:29:10.141
3258	219	5	f	\N	2025-11-21 18:29:10.143	2025-11-21 18:29:10.143
3259	219	6	f	\N	2025-11-21 18:29:10.146	2025-11-21 18:29:10.146
3260	219	7	f	\N	2025-11-21 18:29:10.15	2025-11-21 18:29:10.15
3261	219	8	f	\N	2025-11-21 18:29:10.155	2025-11-21 18:29:10.155
3262	219	9	f	\N	2025-11-21 18:29:10.158	2025-11-21 18:29:10.158
3263	219	10	f	\N	2025-11-21 18:29:10.162	2025-11-21 18:29:10.162
3264	219	11	f	\N	2025-11-21 18:29:10.164	2025-11-21 18:29:10.164
3265	219	12	f	\N	2025-11-21 18:29:10.167	2025-11-21 18:29:10.167
3266	219	13	f	\N	2025-11-21 18:29:10.17	2025-11-21 18:29:10.17
3267	219	14	f	\N	2025-11-21 18:29:10.172	2025-11-21 18:29:10.172
3268	219	15	f	\N	2025-11-21 18:29:10.174	2025-11-21 18:29:10.174
3269	220	1	f	\N	2025-11-21 18:29:38.195	2025-11-21 18:29:38.195
3270	220	2	f	\N	2025-11-21 18:29:38.2	2025-11-21 18:29:38.2
3271	220	3	f	\N	2025-11-21 18:29:38.204	2025-11-21 18:29:38.204
3272	220	4	f	\N	2025-11-21 18:29:38.207	2025-11-21 18:29:38.207
3273	220	5	f	\N	2025-11-21 18:29:38.211	2025-11-21 18:29:38.211
3274	220	6	f	\N	2025-11-21 18:29:38.213	2025-11-21 18:29:38.213
3275	220	7	f	\N	2025-11-21 18:29:38.215	2025-11-21 18:29:38.215
3276	220	8	f	\N	2025-11-21 18:29:38.217	2025-11-21 18:29:38.217
3277	220	9	f	\N	2025-11-21 18:29:38.22	2025-11-21 18:29:38.22
3278	220	10	f	\N	2025-11-21 18:29:38.223	2025-11-21 18:29:38.223
3279	220	11	f	\N	2025-11-21 18:29:38.225	2025-11-21 18:29:38.225
3280	220	12	f	\N	2025-11-21 18:29:38.228	2025-11-21 18:29:38.228
3281	220	13	f	\N	2025-11-21 18:29:38.23	2025-11-21 18:29:38.23
3282	220	14	f	\N	2025-11-21 18:29:38.232	2025-11-21 18:29:38.232
3283	220	15	f	\N	2025-11-21 18:29:38.234	2025-11-21 18:29:38.234
3284	223	1	f	\N	2025-11-21 18:30:43.327	2025-11-21 18:30:43.327
3285	223	2	f	\N	2025-11-21 18:30:43.329	2025-11-21 18:30:43.329
3286	223	3	f	\N	2025-11-21 18:30:43.331	2025-11-21 18:30:43.331
3287	223	4	f	\N	2025-11-21 18:30:43.336	2025-11-21 18:30:43.336
3288	223	5	f	\N	2025-11-21 18:30:43.339	2025-11-21 18:30:43.339
3289	223	6	f	\N	2025-11-21 18:30:43.344	2025-11-21 18:30:43.344
3290	223	7	f	\N	2025-11-21 18:30:43.346	2025-11-21 18:30:43.346
3291	223	8	f	\N	2025-11-21 18:30:43.351	2025-11-21 18:30:43.351
3292	223	9	f	\N	2025-11-21 18:30:43.355	2025-11-21 18:30:43.355
3293	223	10	f	\N	2025-11-21 18:30:43.358	2025-11-21 18:30:43.358
3294	223	11	f	\N	2025-11-21 18:30:43.362	2025-11-21 18:30:43.362
3295	223	12	f	\N	2025-11-21 18:30:43.365	2025-11-21 18:30:43.365
3296	223	13	f	\N	2025-11-21 18:30:43.367	2025-11-21 18:30:43.367
3297	223	14	f	\N	2025-11-21 18:30:43.37	2025-11-21 18:30:43.37
3298	223	15	f	\N	2025-11-21 18:30:43.373	2025-11-21 18:30:43.373
3299	217	1	f	\N	2025-11-21 20:34:12.821	2025-11-21 20:34:12.821
3300	217	2	f	\N	2025-11-21 20:34:12.824	2025-11-21 20:34:12.824
3301	217	3	f	\N	2025-11-21 20:34:12.827	2025-11-21 20:34:12.827
3302	217	4	f	\N	2025-11-21 20:34:12.829	2025-11-21 20:34:12.829
3303	217	5	f	\N	2025-11-21 20:34:12.832	2025-11-21 20:34:12.832
3304	217	6	f	\N	2025-11-21 20:34:12.835	2025-11-21 20:34:12.835
3305	217	7	f	\N	2025-11-21 20:34:12.837	2025-11-21 20:34:12.837
3306	217	8	f	\N	2025-11-21 20:34:12.839	2025-11-21 20:34:12.839
3307	217	9	f	\N	2025-11-21 20:34:12.841	2025-11-21 20:34:12.841
3308	217	10	f	\N	2025-11-21 20:34:12.844	2025-11-21 20:34:12.844
3309	217	11	f	\N	2025-11-21 20:34:12.846	2025-11-21 20:34:12.846
3310	217	12	f	\N	2025-11-21 20:34:12.848	2025-11-21 20:34:12.848
3311	217	13	f	\N	2025-11-21 20:34:12.851	2025-11-21 20:34:12.851
3312	217	14	f	\N	2025-11-21 20:34:12.853	2025-11-21 20:34:12.853
3313	217	15	f	\N	2025-11-21 20:34:12.856	2025-11-21 20:34:12.856
3314	225	1	f	\N	2025-11-21 21:19:07.037	2025-11-21 21:19:07.037
3315	225	2	f	\N	2025-11-21 21:19:07.041	2025-11-21 21:19:07.041
3316	225	3	f	\N	2025-11-21 21:19:07.044	2025-11-21 21:19:07.044
3317	225	4	f	\N	2025-11-21 21:19:07.046	2025-11-21 21:19:07.046
3318	225	5	f	\N	2025-11-21 21:19:07.049	2025-11-21 21:19:07.049
3319	225	6	f	\N	2025-11-21 21:19:07.054	2025-11-21 21:19:07.054
3320	225	7	f	\N	2025-11-21 21:19:07.056	2025-11-21 21:19:07.056
3321	225	8	f	\N	2025-11-21 21:19:07.058	2025-11-21 21:19:07.058
3322	225	9	f	\N	2025-11-21 21:19:07.06	2025-11-21 21:19:07.06
3323	225	10	f	\N	2025-11-21 21:19:07.062	2025-11-21 21:19:07.062
3324	225	11	f	\N	2025-11-21 21:19:07.064	2025-11-21 21:19:07.064
3325	225	12	f	\N	2025-11-21 21:19:07.066	2025-11-21 21:19:07.066
3326	225	13	f	\N	2025-11-21 21:19:07.068	2025-11-21 21:19:07.068
3327	225	14	f	\N	2025-11-21 21:19:07.07	2025-11-21 21:19:07.07
3328	225	15	f	\N	2025-11-21 21:19:07.072	2025-11-21 21:19:07.072
3329	226	1	f	\N	2025-11-22 19:52:40.609	2025-11-22 19:52:40.609
3330	226	2	f	\N	2025-11-22 19:52:40.612	2025-11-22 19:52:40.612
3331	226	3	f	\N	2025-11-22 19:52:40.614	2025-11-22 19:52:40.614
3332	226	4	f	\N	2025-11-22 19:52:40.616	2025-11-22 19:52:40.616
3333	226	5	f	\N	2025-11-22 19:52:40.617	2025-11-22 19:52:40.617
3334	226	6	f	\N	2025-11-22 19:52:40.619	2025-11-22 19:52:40.619
3335	226	7	f	\N	2025-11-22 19:52:40.621	2025-11-22 19:52:40.621
3336	226	8	f	\N	2025-11-22 19:52:40.622	2025-11-22 19:52:40.622
3337	226	9	f	\N	2025-11-22 19:52:40.624	2025-11-22 19:52:40.624
3338	226	10	f	\N	2025-11-22 19:52:40.625	2025-11-22 19:52:40.625
3339	226	11	f	\N	2025-11-22 19:52:40.627	2025-11-22 19:52:40.627
3340	226	12	f	\N	2025-11-22 19:52:40.628	2025-11-22 19:52:40.628
3341	226	13	f	\N	2025-11-22 19:52:40.629	2025-11-22 19:52:40.629
3342	226	14	f	\N	2025-11-22 19:52:40.631	2025-11-22 19:52:40.631
3343	226	15	f	\N	2025-11-22 19:52:40.633	2025-11-22 19:52:40.633
3344	227	1	f	\N	2025-11-22 22:07:53.211	2025-11-22 22:07:53.211
3345	227	2	f	\N	2025-11-22 22:07:53.216	2025-11-22 22:07:53.216
3346	227	3	f	\N	2025-11-22 22:07:53.218	2025-11-22 22:07:53.218
3347	227	4	f	\N	2025-11-22 22:07:53.22	2025-11-22 22:07:53.22
3348	227	5	f	\N	2025-11-22 22:07:53.223	2025-11-22 22:07:53.223
3349	227	6	f	\N	2025-11-22 22:07:53.225	2025-11-22 22:07:53.225
3350	227	7	f	\N	2025-11-22 22:07:53.227	2025-11-22 22:07:53.227
3351	227	8	f	\N	2025-11-22 22:07:53.23	2025-11-22 22:07:53.23
3352	227	9	f	\N	2025-11-22 22:07:53.232	2025-11-22 22:07:53.232
3353	227	10	f	\N	2025-11-22 22:07:53.234	2025-11-22 22:07:53.234
3354	227	11	f	\N	2025-11-22 22:07:53.237	2025-11-22 22:07:53.237
3355	227	12	f	\N	2025-11-22 22:07:53.239	2025-11-22 22:07:53.239
3356	227	13	f	\N	2025-11-22 22:07:53.241	2025-11-22 22:07:53.241
3357	227	14	f	\N	2025-11-22 22:07:53.244	2025-11-22 22:07:53.244
3358	227	15	f	\N	2025-11-22 22:07:53.246	2025-11-22 22:07:53.246
3359	228	1	f	\N	2025-11-22 22:08:00.887	2025-11-22 22:08:00.887
3360	228	2	f	\N	2025-11-22 22:08:00.89	2025-11-22 22:08:00.89
3361	228	3	f	\N	2025-11-22 22:08:00.893	2025-11-22 22:08:00.893
3362	228	4	f	\N	2025-11-22 22:08:00.895	2025-11-22 22:08:00.895
3363	228	5	f	\N	2025-11-22 22:08:00.897	2025-11-22 22:08:00.897
3364	228	6	f	\N	2025-11-22 22:08:00.9	2025-11-22 22:08:00.9
3365	228	7	f	\N	2025-11-22 22:08:00.902	2025-11-22 22:08:00.902
3366	228	8	f	\N	2025-11-22 22:08:00.905	2025-11-22 22:08:00.905
3367	228	9	f	\N	2025-11-22 22:08:00.907	2025-11-22 22:08:00.907
3368	228	10	f	\N	2025-11-22 22:08:00.909	2025-11-22 22:08:00.909
3369	228	11	f	\N	2025-11-22 22:08:00.911	2025-11-22 22:08:00.911
3370	228	12	f	\N	2025-11-22 22:08:00.913	2025-11-22 22:08:00.913
3371	228	13	f	\N	2025-11-22 22:08:00.915	2025-11-22 22:08:00.915
3372	228	14	f	\N	2025-11-22 22:08:00.918	2025-11-22 22:08:00.918
3373	228	15	f	\N	2025-11-22 22:08:00.92	2025-11-22 22:08:00.92
3374	229	1	f	\N	2025-11-23 19:21:18.319	2025-11-23 19:21:18.319
3375	229	2	f	\N	2025-11-23 19:21:18.322	2025-11-23 19:21:18.322
3376	229	3	f	\N	2025-11-23 19:21:18.325	2025-11-23 19:21:18.325
3377	229	4	f	\N	2025-11-23 19:21:18.327	2025-11-23 19:21:18.327
3378	229	5	f	\N	2025-11-23 19:21:18.33	2025-11-23 19:21:18.33
3379	229	6	f	\N	2025-11-23 19:21:18.333	2025-11-23 19:21:18.333
3380	229	7	f	\N	2025-11-23 19:21:18.335	2025-11-23 19:21:18.335
3381	229	8	f	\N	2025-11-23 19:21:18.337	2025-11-23 19:21:18.337
3382	229	9	f	\N	2025-11-23 19:21:18.339	2025-11-23 19:21:18.339
3383	229	10	f	\N	2025-11-23 19:21:18.341	2025-11-23 19:21:18.341
3384	229	11	f	\N	2025-11-23 19:21:18.344	2025-11-23 19:21:18.344
3385	229	12	f	\N	2025-11-23 19:21:18.346	2025-11-23 19:21:18.346
3386	229	13	f	\N	2025-11-23 19:21:18.348	2025-11-23 19:21:18.348
3387	229	14	f	\N	2025-11-23 19:21:18.351	2025-11-23 19:21:18.351
3388	229	15	f	\N	2025-11-23 19:21:18.353	2025-11-23 19:21:18.353
3389	230	1	f	\N	2025-11-24 18:25:29.811	2025-11-24 18:25:29.811
3390	230	2	f	\N	2025-11-24 18:25:29.814	2025-11-24 18:25:29.814
3391	230	3	f	\N	2025-11-24 18:25:29.818	2025-11-24 18:25:29.818
3392	230	4	f	\N	2025-11-24 18:25:29.82	2025-11-24 18:25:29.82
3393	230	5	f	\N	2025-11-24 18:25:29.822	2025-11-24 18:25:29.822
3394	230	6	f	\N	2025-11-24 18:25:29.825	2025-11-24 18:25:29.825
3395	230	7	f	\N	2025-11-24 18:25:29.827	2025-11-24 18:25:29.827
3396	230	8	f	\N	2025-11-24 18:25:29.829	2025-11-24 18:25:29.829
3397	230	9	f	\N	2025-11-24 18:25:29.831	2025-11-24 18:25:29.831
3398	230	10	f	\N	2025-11-24 18:25:29.833	2025-11-24 18:25:29.833
3399	230	11	f	\N	2025-11-24 18:25:29.836	2025-11-24 18:25:29.836
3400	230	12	f	\N	2025-11-24 18:25:29.838	2025-11-24 18:25:29.838
3401	230	13	f	\N	2025-11-24 18:25:29.84	2025-11-24 18:25:29.84
3402	230	14	f	\N	2025-11-24 18:25:29.842	2025-11-24 18:25:29.842
3403	230	15	f	\N	2025-11-24 18:25:29.844	2025-11-24 18:25:29.844
3404	231	1	f	\N	2025-11-24 23:00:57.94	2025-11-24 23:00:57.94
3405	231	2	f	\N	2025-11-24 23:00:57.943	2025-11-24 23:00:57.943
3406	231	3	f	\N	2025-11-24 23:00:57.946	2025-11-24 23:00:57.946
3407	231	4	f	\N	2025-11-24 23:00:57.948	2025-11-24 23:00:57.948
3408	231	5	f	\N	2025-11-24 23:00:57.95	2025-11-24 23:00:57.95
3409	231	6	f	\N	2025-11-24 23:00:57.952	2025-11-24 23:00:57.952
3410	231	7	f	\N	2025-11-24 23:00:57.955	2025-11-24 23:00:57.955
3411	231	8	f	\N	2025-11-24 23:00:57.957	2025-11-24 23:00:57.957
3412	231	9	f	\N	2025-11-24 23:00:57.959	2025-11-24 23:00:57.959
3413	231	10	f	\N	2025-11-24 23:00:57.961	2025-11-24 23:00:57.961
3414	231	11	f	\N	2025-11-24 23:00:57.964	2025-11-24 23:00:57.964
3415	231	12	f	\N	2025-11-24 23:00:57.966	2025-11-24 23:00:57.966
3416	231	13	f	\N	2025-11-24 23:00:57.968	2025-11-24 23:00:57.968
3417	231	14	f	\N	2025-11-24 23:00:57.97	2025-11-24 23:00:57.97
3418	231	15	f	\N	2025-11-24 23:00:57.972	2025-11-24 23:00:57.972
3419	232	1	f	\N	2025-11-24 23:56:43.801	2025-11-24 23:56:43.801
3420	232	2	f	\N	2025-11-24 23:56:43.804	2025-11-24 23:56:43.804
3421	232	3	f	\N	2025-11-24 23:56:43.807	2025-11-24 23:56:43.807
3422	232	4	f	\N	2025-11-24 23:56:43.809	2025-11-24 23:56:43.809
3423	232	5	f	\N	2025-11-24 23:56:43.812	2025-11-24 23:56:43.812
3424	232	6	f	\N	2025-11-24 23:56:43.815	2025-11-24 23:56:43.815
3425	232	7	f	\N	2025-11-24 23:56:43.817	2025-11-24 23:56:43.817
3426	232	8	f	\N	2025-11-24 23:56:43.82	2025-11-24 23:56:43.82
3427	232	9	f	\N	2025-11-24 23:56:43.823	2025-11-24 23:56:43.823
3428	232	10	f	\N	2025-11-24 23:56:43.825	2025-11-24 23:56:43.825
3429	232	11	f	\N	2025-11-24 23:56:43.828	2025-11-24 23:56:43.828
3430	232	12	f	\N	2025-11-24 23:56:43.83	2025-11-24 23:56:43.83
3431	232	13	f	\N	2025-11-24 23:56:43.833	2025-11-24 23:56:43.833
3432	232	14	f	\N	2025-11-24 23:56:43.835	2025-11-24 23:56:43.835
3433	232	15	f	\N	2025-11-24 23:56:43.838	2025-11-24 23:56:43.838
\.
COPY public.clientes (id, nombre, apellido_paterno, apellido_materno, telefono_celular, telefono_contacto, email, calle, numero_exterior, numero_interior, colonia, ciudad, estado, codigo_postal, latitud, longitud, fuente_referencia, rfc, password_hash, created_at, updated_at, creado_por_id, tipo_registro, punto_recoleccion_id) FROM stdin;
13	Rosa Maria 	Ramos 		5636714550	5636714550	rosamari@gmail.com								\N	\N			\N	2025-09-01 17:20:42.95	2025-09-01 17:24:58.768	17	SISTEMA_CENTRAL	\N
14	Christopher 	Dominguez 		5517158257	5517158257	chriscarmona34@outlook.es								\N	\N			\N	2025-09-01 18:54:39.543	2025-09-01 18:54:39.542	17	SISTEMA_CENTRAL	\N
15	Susana 	Lira	Saldivar 	7299291944	7299291944	susisald@gmail.com								\N	\N			\N	2025-09-01 20:05:35.883	2025-09-01 20:05:35.881	17	SISTEMA_CENTRAL	\N
16	Yoselin 	Velasco		5578963215	5578963215	yoooosss@gmail.com								\N	\N			\N	2025-09-03 19:55:06.468	2025-09-03 19:55:16.738	17	SISTEMA_CENTRAL	\N
17	Público 	General 		5565987456	5565987456	profesora.montserrat21@gmail.com				RINCONADA SAN FELIPE		MÉXICO		\N	\N			\N	2025-09-03 22:40:46.452	2025-09-03 22:41:04.76	17	SISTEMA_CENTRAL	\N
18	Gabriela	Chavez	Acosta	5514679024	5614156500	gdavasan@gmail.com								\N	\N			\N	2025-09-05 16:19:35.708	2025-09-05 16:19:35.706	17	SISTEMA_CENTRAL	\N
19	Damian 	Torres	Rodriguez 	5528289251	5528289251	damiantr31@gmail.com								\N	\N		YAA125	\N	2025-09-06 19:19:49.727	2025-09-06 19:19:49.725	17	SISTEMA_CENTRAL	\N
21	Gabriel 	Carrillo		5565987456		gabocvf21@gmail.com	RINCONADA DE ALERCES	90		RINCONADA SAN FELIPE	EL PANTANO	MÉXICO	55719	\N	\N			\N	2025-09-06 23:50:56.968	2025-09-06 23:50:56.967	17	SISTEMA_CENTRAL	\N
22	Oscar 	Dominguez		5578242511		oscarsold@gmail.com								\N	\N			\N	2025-09-09 23:13:49.925	2025-09-09 23:13:49.924	17	SISTEMA_CENTRAL	\N
23	Michelle	Rojas		5585603289	5585603289	michrojas@gmail.com								\N	\N			\N	2025-09-10 16:33:53.267	2025-09-10 16:33:53.266	17	SISTEMA_CENTRAL	\N
24	Benjamin 	Rodriguez 	Ontiveros 	5617615055	5617615055	benja@gmail.com								\N	\N			\N	2025-09-11 23:40:30.628	2025-09-11 23:40:30.626	17	SISTEMA_CENTRAL	\N
25	Noemi 	Hernandez 	Rubio	5549665564	5549665564	asesornoemi01@gmail.com								\N	\N			\N	2025-09-13 17:44:58.623	2025-09-13 17:44:58.622	17	SISTEMA_CENTRAL	\N
26	Alfredo	Ramirez		5610152997		opporamirez@gmail.com								\N	\N			\N	2025-09-17 18:38:24.715	2025-09-17 18:38:24.714	17	SISTEMA_CENTRAL	\N
27	Emanuel 	Breton		56268966		ema@gmail.com								\N	\N			\N	2025-09-21 20:53:59.177	2025-09-21 20:53:59.176	16	SISTEMA_CENTRAL	\N
28	Christian 	Chavez 		5521345067	5521345067	dent_lindasonrisa@gmail.com								\N	\N			\N	2025-09-23 16:28:47.086	2025-09-23 16:28:47.083	17	SISTEMA_CENTRAL	\N
29	Enrique 	Trejo		5615267193		damiantrejo0535@gmail.com								\N	\N			\N	2025-09-23 17:34:45.356	2025-09-23 17:34:45.354	17	SISTEMA_CENTRAL	\N
30	Luis Enrique	Lopez 	Molina	5542184966	5542184966	luisenriquelopezmolina@gmail.com								\N	\N			\N	2025-09-23 19:30:37.541	2025-09-23 19:30:37.539	17	SISTEMA_CENTRAL	\N
31	Joe 	Esquivel 	Cruz	5532147437	5532147437	esquivelmarco851@gmail.com								\N	\N			\N	2025-09-23 22:14:24.866	2025-09-23 22:14:24.864	17	SISTEMA_CENTRAL	\N
32	Hector 	Bustamante	Romero	5554597380	5554597380	hector.bustamante53@hotmail.com								\N	\N			\N	2025-09-25 23:00:40.55	2025-09-25 23:00:40.548	17	SISTEMA_CENTRAL	\N
34	Axel Arturo	Trejo	Callejas	5561586643	5561586643	aatrejocallejas@gmail.com								\N	\N			\N	2025-09-26 20:39:27.115	2025-09-26 20:39:27.114	17	SISTEMA_CENTRAL	\N
35	Araceli	Ruiz		5543065549		vogus63alejandra@gmail.com								\N	\N			\N	2025-09-26 22:17:08.423	2025-09-26 22:17:08.422	17	SISTEMA_CENTRAL	\N
36	Andres	Perez		5578242522	5578242522	anhty@gmail.com								\N	\N			\N	2025-09-26 22:56:50.851	2025-09-26 22:56:50.85	17	SISTEMA_CENTRAL	\N
60	Aidet Yaneli	Moncayo 	Sanchez	5584821581		aidet.moncayo@yaavs.com.mx								\N	\N			\N	2025-10-10 22:40:03.964	2025-10-10 22:40:03.963	17	SISTEMA_CENTRAL	\N
37	Jose Emmanuel 	Mendoza 	García	5535355787	5535355787	emackgel@gmail.com								\N	\N			\N	2025-09-27 19:46:33.569	2025-09-27 19:46:33.568	17	SISTEMA_CENTRAL	\N
38	Público 	General		5543065549		public@gmail.com								\N	\N			\N	2025-09-27 20:09:41.407	2025-09-27 20:09:41.406	17	SISTEMA_CENTRAL	\N
39	Joel	Gamero	Limon	5534567412	5535038328	joel.gamero@essity.com								\N	\N			\N	2025-09-28 18:15:58.067	2025-09-28 18:15:58.065	17	SISTEMA_CENTRAL	\N
40	Nataly	Ramos		5516820573		natalyramos807@gmail.com								\N	\N			\N	2025-09-28 19:33:56.681	2025-09-28 19:33:56.679	17	SISTEMA_CENTRAL	\N
41	Roberto Octavio	Mendoza	Sanchez	5611652658	5611652658	roberto.mendoza.sanchez@gmail.com								\N	\N			\N	2025-09-29 21:47:37.109	2025-09-29 21:47:37.108	17	SISTEMA_CENTRAL	\N
42	Jose Elias 	Sánchez 	Olvera	5564999526	5564999526	jse3lias97@hotmail.com								\N	\N			\N	2025-09-30 17:28:23.531	2025-09-30 17:28:23.53	17	SISTEMA_CENTRAL	\N
43	Laura Itzel	Argueta 	OsNAYA	5588291226	5588291226	lauraosnaya19@gmail.com								\N	\N			\N	2025-09-30 21:00:16.879	2025-09-30 21:00:16.877	17	SISTEMA_CENTRAL	\N
44	Marcos 	Guevara 	Garcia 	5540979056	5540979056	mgg5540979056@gmail.com								\N	\N			\N	2025-09-30 23:31:56.528	2025-09-30 23:31:56.526	17	SISTEMA_CENTRAL	\N
45	Jorge Eduardo	Davila	Sánchez	5649046332		jorge@gmail.com								\N	\N			\N	2025-10-01 17:46:52.355	2025-10-01 17:46:52.353	17	SISTEMA_CENTRAL	\N
46	Irene 	Saldivar		5564059040	5564059040	irenezaldivar33@gmail.com								\N	\N			\N	2025-10-01 21:17:58.274	2025-10-01 21:17:58.273	17	SISTEMA_CENTRAL	\N
47	Claudia 	Villagran 	Mendoza	5520875811	5520875811	claufrt@gmail.com								\N	\N			\N	2025-10-02 19:24:01.378	2025-10-02 19:24:01.377	17	SISTEMA_CENTRAL	\N
48	Brenda	Garcia		5557709364		breigarzi000@gmail.com								\N	\N			\N	2025-10-03 23:12:34.394	2025-10-03 23:12:34.393	17	SISTEMA_CENTRAL	\N
33	Blanca 	Cárdenas 		5576414418		blanca@gmail.com								\N	\N			\N	2025-09-26 15:54:46.809	2025-10-04 14:19:39.455	17	SISTEMA_CENTRAL	\N
49	Blanca 	Cardenas		5576414418		bla@gmail.com								\N	\N			\N	2025-10-04 14:21:13.764	2025-10-04 14:21:13.763	17	SISTEMA_CENTRAL	\N
50	Eusebio	Espinosa	Palma 	5664256093	5664256093	eusebio@outlook.es								\N	\N			\N	2025-10-05 18:57:51.991	2025-10-05 18:57:51.989	17	SISTEMA_CENTRAL	\N
51	Liliana 	Gasca 	Torres 	5657000386	5657000386 	lilianagasca407@gmail.com								\N	\N			\N	2025-10-05 22:57:20.261	2025-10-05 22:57:20.259	17	SISTEMA_CENTRAL	\N
52	Javier 	Sanchez		5515809562		j@gmail.com								\N	\N			\N	2025-10-06 21:15:59.97	2025-10-06 21:15:59.968	17	SISTEMA_CENTRAL	\N
53	Jonathan 	Cano		7201502693		jonathanadair.1001@gmail.com								\N	\N			\N	2025-10-07 16:03:36.12	2025-10-07 16:03:36.119	17	SISTEMA_CENTRAL	\N
54	Laura 	Lopez	Reyes	5520885950	5520885950	lauiop@gmail.com								\N	\N			\N	2025-10-07 17:31:58.377	2025-10-07 17:31:58.375	17	SISTEMA_CENTRAL	\N
55	Alfredo	Becerril 	Rodriguez	5545138131	5545138131	alfbr00@yahoo.com.mx								\N	\N			\N	2025-10-07 23:38:53.423	2025-10-07 23:38:53.421	17	SISTEMA_CENTRAL	\N
56	prueba 	1		556986876		huh1@gmail.com	RINCONADA DE ALERCES	90		RINCONADA SAN FELIPE	EL PANTANO	MÉXICO	55719	\N	\N			\N	2025-10-09 15:17:47.59	2025-10-09 15:17:47.589	17	SISTEMA_CENTRAL	\N
57	Miguel Angel	Gonzalez		5520626160		mikgonzalez40@gmail.com								\N	\N			\N	2025-10-09 18:15:37.86	2025-10-09 18:15:37.859	17	SISTEMA_CENTRAL	\N
58	Edgar 	Flores	Montiel 	5511742678	5511742678	edgar@gmail.com								\N	\N			\N	2025-10-09 23:03:55.497	2025-10-09 23:03:55.495	17	SISTEMA_CENTRAL	\N
59	Carlos Alberto	Meneses 	Guillen	5540300282		carlosamguillen@outlook.co								\N	\N			\N	2025-10-10 17:41:04.702	2025-10-10 17:41:04.701	17	SISTEMA_CENTRAL	\N
61	Jorge 	Pacheco 	Rodriguez	3314453328	3314453328	pach@hotmail.com								\N	\N			\N	2025-10-11 16:05:30.335	2025-10-11 16:05:30.333	17	SISTEMA_CENTRAL	\N
62	Diego Armando 	Jimenez	Martinez 	5572317398	5572317398	diegoajmartinez23@gmail.com								\N	\N			\N	2025-10-11 19:09:32.989	2025-10-11 19:09:32.987	17	SISTEMA_CENTRAL	\N
63	ameyali	calderon	aguilar	5518399051		ameyali.andovas@gmail.com								\N	\N			\N	2025-10-12 19:06:40.464	2025-10-12 20:42:06.222	17	SISTEMA_CENTRAL	\N
64	Elena Beatriz	Gonzalez 	Campos 	5523998872	5523998872	elena@gmail.com								\N	\N			\N	2025-10-13 18:02:17.059	2025-10-13 18:02:17.057	17	SISTEMA_CENTRAL	\N
65	David	Jimenez		5528533648		davjim@gmail.com								\N	\N			\N	2025-10-13 20:37:11.374	2025-10-13 20:37:11.373	17	SISTEMA_CENTRAL	\N
66	Mariana	Ruiz		5619854310	5619854310	mariana@gmail.com								\N	\N			\N	2025-10-14 19:03:35.942	2025-10-14 19:03:35.941	17	SISTEMA_CENTRAL	\N
67	Antonio 	Hernandez		5637049466	5637049466	ant@gmail.com								\N	\N			\N	2025-10-15 21:57:27.975	2025-10-15 21:57:27.974	17	SISTEMA_CENTRAL	\N
68	Mario 	Parada 		5564020217	5564020217	vinnypetrone@yahoo.com.mx								\N	\N			\N	2025-10-16 18:27:29.345	2025-10-16 18:27:29.343	17	SISTEMA_CENTRAL	\N
69	Ivan Francisco 	Garcia 	Saavedra 	5563182370	5563182370	igsaavedra76@yahoo.com								\N	\N			\N	2025-10-16 21:16:20.708	2025-10-16 21:16:20.706	17	SISTEMA_CENTRAL	\N
70	Luis Raul	Ramos 	Omaña	5540357808	5540357808	lauvero5810@hotmail.com								\N	\N			\N	2025-10-17 17:56:36.212	2025-10-17 17:56:36.211	17	SISTEMA_CENTRAL	\N
71	Angel jair	jaramillo		7205628920		angeljaramillo1951@outlook.com								\N	\N			\N	2025-10-18 14:55:53.752	2025-10-18 14:55:53.75	17	SISTEMA_CENTRAL	\N
72	Isabel 	Ibarra		5511539836		isa@gmail.com								\N	\N			\N	2025-10-19 19:46:38.996	2025-10-19 19:46:38.994	17	SISTEMA_CENTRAL	\N
73	Sandy	Valiente	Flores	5587957246		sandyitzel61@gmail.com								\N	\N			\N	2025-10-20 16:06:06.878	2025-10-20 16:06:06.876	17	SISTEMA_CENTRAL	\N
74	Cesar 	Trejo 		3339054401	3339054401	cesartrejo@gmail.com								\N	\N			\N	2025-10-20 19:57:18.071	2025-10-20 19:57:18.07	17	SISTEMA_CENTRAL	\N
75	yohni	Calvo	Castro	57707258		yohni@gmail.com								\N	\N			\N	2025-10-22 17:04:21.579	2025-10-22 17:04:21.575	17	SISTEMA_CENTRAL	\N
76	Saul	Telles		8713489383		saul@gmail.com								\N	\N			\N	2025-10-22 18:01:16.736	2025-10-22 18:01:16.735	17	SISTEMA_CENTRAL	\N
77	Claudia 	Martines 		7711410517		clausmy23@gmail.com								\N	\N			\N	2025-10-22 20:53:47.849	2025-10-22 20:53:47.848	17	SISTEMA_CENTRAL	\N
78	Liliana 	Carrillo		5560618644	5560618644	naydelynsegura@gmail.com								\N	\N			\N	2025-10-23 18:12:27.116	2025-10-23 18:12:27.115	17	SISTEMA_CENTRAL	\N
79	Cristel 	Ayala 	Romero 	5632299032		crishji@gmail.com								\N	\N			\N	2025-10-27 19:36:17.849	2025-10-27 19:36:17.848	17	SISTEMA_CENTRAL	\N
80	Pedro	Gomez		557896451265	557896451265	toni@gmail.com								\N	\N			\N	2025-10-27 22:30:00.638	2025-10-27 22:30:00.637	17	SISTEMA_CENTRAL	\N
81	Sergio	Ocampo		5554519415	5554519415	sergio@gmail.com								\N	\N			\N	2025-10-27 22:43:24.54	2025-10-27 22:43:24.539	17	SISTEMA_CENTRAL	\N
82	Gustavo	Díaz	Martinez 	\t5610988977	\t5610988977	gusdiaz5779@gmail.com								\N	\N			\N	2025-10-28 00:07:36.436	2025-10-28 00:07:36.435	17	SISTEMA_CENTRAL	\N
83	Maria de Lourdes 	Ruiz 	Juarez 	5572129743		lulusalila66@gmail.com								\N	\N			\N	2025-10-28 00:20:06.942	2025-10-28 00:20:06.941	17	SISTEMA_CENTRAL	\N
84	Gustavo 	Eumaña 		56453837337		eumana@gmail.com								\N	\N			\N	2025-10-28 20:04:46.525	2025-10-28 20:04:46.524	17	SISTEMA_CENTRAL	\N
85	Rodolfo 	Velazquez		5578245896		rodo_vls@gmail.com								\N	\N			\N	2025-10-28 21:34:21.121	2025-10-28 21:34:21.119	17	SISTEMA_CENTRAL	\N
86	Margarita 	Montes de Oca		5520324254	5520324254	margarita@gmail.com								\N	\N			\N	2025-10-28 23:13:26.685	2025-10-28 23:13:26.684	17	SISTEMA_CENTRAL	\N
87	Tere 	Montes de Oca		5613385774	5613385774	tmontesdeoca863@gmail.com								\N	\N			\N	2025-10-28 23:38:50.718	2025-10-28 23:38:50.716	17	SISTEMA_CENTRAL	\N
88	Karen Abigail 	Orduña 	Sanchez 	5539364116	5539364116	karenorduna09@gmail.com								\N	\N			\N	2025-10-29 17:34:37.625	2025-10-29 17:34:37.623	17	SISTEMA_CENTRAL	\N
89	Carlos Alberto	Gonzalez 		5621570060	5621570060	carlosamguillen@outlook.com								\N	\N			\N	2025-10-29 22:57:49.21	2025-10-29 22:57:49.209	17	SISTEMA_CENTRAL	\N
91	Carmen 	Hernandez 	García	7207040077		carmen@gmail.com								\N	\N			\N	2025-10-31 14:53:57.541	2025-10-31 14:53:57.539	17	SISTEMA_CENTRAL	\N
92	SARA	VALDEZ		5520870556	5520870556	sara.sara@gmail.com								\N	\N			\N	2025-10-31 16:35:53.016	2025-10-31 16:35:53.015	17	SISTEMA_CENTRAL	\N
93	Oscar	Martinez 	Gonzalez	5612049696		oscar@gmail.com								\N	\N			\N	2025-10-31 16:53:53.003	2025-10-31 16:53:53.002	17	SISTEMA_CENTRAL	\N
94	Ulises 	Hernandez	Patiño	5529200043		ulises@hotmail.com								\N	\N			\N	2025-10-31 21:10:56.869	2025-10-31 21:10:56.868	17	SISTEMA_CENTRAL	\N
95	Javier 	orozco		5611828732	5611828732	javier.orozco@gmail.com								\N	\N			\N	2025-11-01 17:48:04.731	2025-11-01 17:48:04.73	17	SISTEMA_CENTRAL	\N
96	Luis Ernesto	Morales 	Perez	5584438913		luis@gmail.com								\N	\N			\N	2025-11-01 18:27:38.202	2025-11-01 18:27:38.201	17	SISTEMA_CENTRAL	\N
97	Ivan Francisco 	Avila		5634752532		ivan@gmail.com								\N	\N			\N	2025-11-02 21:57:09.411	2025-11-02 21:57:09.409	17	SISTEMA_CENTRAL	\N
98	Jose Alfredo 	Moreno 	Monroy	7209264649	7209264649	jose@gmail.com								\N	\N			\N	2025-11-03 19:00:55.831	2025-11-03 19:00:55.83	17	SISTEMA_CENTRAL	\N
99	Guillermo	Luna		5610696615		guillermo@gmail.com								\N	\N			\N	2025-11-04 20:37:23.459	2025-11-04 20:37:23.457	24	SISTEMA_CENTRAL	\N
100	Daniel 	Lecona		5548285191	5548285191	Qdaniel@gmail.com								\N	\N			\N	2025-11-05 16:26:53.446	2025-11-05 16:26:53.445	24	SISTEMA_CENTRAL	\N
101	Pedro	García		7711437942		pedrogarcia@prueba.com								\N	\N			\N	2025-11-06 16:31:58.274	2025-11-06 16:31:58.273	16	SISTEMA_CENTRAL	\N
102	Guillermo	Corona	Juarez	5520924862		guillermo01@gmail.com								\N	\N			\N	2025-11-06 16:51:51.557	2025-11-06 16:51:51.556	24	SISTEMA_CENTRAL	\N
103	Vaanessa	Perez		6671771181	6671771181	cliente01@gmail.com								\N	\N			\N	2025-11-06 17:51:09.435	2025-11-06 17:51:09.434	24	SISTEMA_CENTRAL	\N
104	Lucia	Martinez		5566297077	5539748428	lucia01@gmail.com								\N	\N			\N	2025-11-06 23:52:42.542	2025-11-06 23:52:42.541	24	SISTEMA_CENTRAL	\N
105	Vianey	Sarabi	Ramirez	5951143769	5523576677	cliente@gmail.com								\N	\N			\N	2025-11-08 19:13:57.77	2025-11-08 19:13:57.768	24	SISTEMA_CENTRAL	\N
107	Vianey	Sarabi	Ramirez	5951143769	5523576677	cliente00@gmail.com								\N	\N			\N	2025-11-08 19:14:00.04	2025-11-08 19:14:00.039	24	SISTEMA_CENTRAL	\N
108	Miguel 	Mejia	Martinez	4151973158	4151973158	Martinez00@gmail.com								\N	\N			\N	2025-11-08 20:23:20.774	2025-11-08 20:23:20.772	24	SISTEMA_CENTRAL	\N
109	Fernando	Mena		5554783062	5554783062	fernando0164@gmail.com								\N	\N			\N	2025-11-10 21:02:27.454	2025-11-10 21:02:27.452	24	SISTEMA_CENTRAL	\N
110	Julio Cesar	Vega		5514528451	5527729119	juceve93@gmail.com								\N	\N			\N	2025-11-10 23:59:09.017	2025-11-10 23:59:09.016	24	SISTEMA_CENTRAL	\N
111	Javier 	Gallardo		5661240277	5661240277	jav@gmail.com								\N	\N			\N	2025-11-12 17:19:02.782	2025-11-12 17:19:02.781	24	SISTEMA_CENTRAL	\N
112	Alexis	Nova		4471180773	4471180773	alexis@gmail.com								\N	\N			\N	2025-11-12 17:53:46.42	2025-11-12 17:53:46.417	24	SISTEMA_CENTRAL	\N
113	Daniela	Reyes		5577619779	5577619779	dani@gmail.com								\N	\N			\N	2025-11-12 18:27:32.27	2025-11-12 18:27:32.269	24	SISTEMA_CENTRAL	\N
114	Abdiel	Mendoza		5566723948		abdiel@gmail.com								\N	\N			\N	2025-11-12 22:37:24.698	2025-11-12 22:37:24.696	24	SISTEMA_CENTRAL	\N
115	Cristina	Quiroga	Castillo	5520055118	5520055118	cristina@gmail.com								\N	\N			\N	2025-11-12 23:03:16.727	2025-11-12 23:03:16.724	24	SISTEMA_CENTRAL	\N
116	Alejandro	Miranda		5529693271	5529693271	amrmiranda@hotmail.com								\N	\N			\N	2025-11-12 23:35:58.075	2025-11-12 23:35:58.074	24	SISTEMA_CENTRAL	\N
117	Conrrado	Mendez		5524932721	5549535275	conrrado@gmail.com								\N	\N			\N	2025-11-13 00:16:49.433	2025-11-13 23:52:48.1	24	SISTEMA_CENTRAL	\N
118	Gabriela 	Galindo	Solis	5531312509		gab@gmail.com								\N	\N			\N	2025-11-14 15:25:43.851	2025-11-14 15:25:43.849	24	SISTEMA_CENTRAL	\N
119	Julia	Servin		5512446640		julia@gmail.com								\N	\N			\N	2025-11-15 18:30:25.012	2025-11-15 18:30:25.01	24	SISTEMA_CENTRAL	\N
120	Demetrio	Martinez	Cruz	5522959810	5561412737	demetrio@gmail.com								\N	\N			\N	2025-11-15 18:42:17.101	2025-11-15 18:42:17.1	24	SISTEMA_CENTRAL	\N
121	Juan Carlos	Mendoza	Martinez	5569056474	5569056474	juancarlos@gmail.com								\N	\N			\N	2025-11-15 19:07:55.429	2025-11-15 19:07:55.427	24	SISTEMA_CENTRAL	\N
90	Brandon Arath 	Merino 		5536775119	5613832025	brandon@gmail.com								\N	\N			\N	2025-10-30 23:23:28.905	2025-11-17 16:32:30.538	17	SISTEMA_CENTRAL	\N
122	Gael	Figeroa		5523050525	5523050525	gael@gmail.com								\N	\N			\N	2025-11-17 20:35:58.408	2025-11-17 20:35:58.407	24	SISTEMA_CENTRAL	\N
123	Carmen	Sanchez		5529529037		carmen00@gmail.com								\N	\N			\N	2025-11-18 20:16:42.648	2025-11-18 20:16:42.647	24	SISTEMA_CENTRAL	\N
124	Luis Enrique	na		5555555555	5555555555	112315555555555@gmail.com								\N	\N			\N	2025-11-18 20:28:49.291	2025-11-18 20:28:49.29	24	SISTEMA_CENTRAL	\N
125	Jorge	Garcia	MArtinez	5573315328		jorge00@gmail.com								\N	\N			\N	2025-11-19 17:19:35.243	2025-11-19 17:19:35.242	24	SISTEMA_CENTRAL	\N
126	Edith	Morales		7298070941		edith@gmail.com								\N	\N			\N	2025-11-19 17:29:29.642	2025-11-19 17:29:29.64	24	SISTEMA_CENTRAL	\N
127	Natali	Bautista		5659468419		natalui@gmail.com								\N	\N			\N	2025-11-19 20:13:12.825	2025-11-19 20:13:12.824	24	SISTEMA_CENTRAL	\N
128	Oscar	Martinez	TI	5518785488		oscar0@gmail.com								\N	\N			\N	2025-11-20 21:42:58.513	2025-11-20 21:42:58.512	24	SISTEMA_CENTRAL	\N
129	Marcos 	Hernández 		5543671303		marco@gmail.com								\N	\N			\N	2025-11-21 17:36:27.073	2025-11-21 17:36:27.071	24	SISTEMA_CENTRAL	\N
130	Esperanza	Cruz		5587804325		esperanza@gmail.com								\N	\N		esperanza@gmail.com	\N	2025-11-22 17:41:24.593	2025-11-22 17:41:24.592	24	SISTEMA_CENTRAL	\N
131	Andres	Gil		5512878315		rudyygz63@gmail.com								\N	\N			\N	2025-11-22 18:25:48.34	2025-11-22 18:25:48.339	24	SISTEMA_CENTRAL	\N
132	Isacc Noe	Miranda	Hernandez	5615937160		veriuxagin@gmail.com								\N	\N			\N	2025-11-22 18:57:34.578	2025-11-22 18:57:34.576	24	SISTEMA_CENTRAL	\N
133	Gustavo Eduardo	Miranda	Hernandez	5615937160		miuugus09@gmail.com								\N	\N			\N	2025-11-22 18:58:29.825	2025-11-22 18:58:29.824	24	SISTEMA_CENTRAL	\N
134	jesus	Esquivel 		5540501330		jesus.esqui@gmail.com								\N	\N			\N	2025-11-22 23:37:58.88	2025-11-22 23:37:58.878	24	SISTEMA_CENTRAL	\N
135	Adriana	Flores		5537919395		adriana.adri@gmail.com								\N	\N			\N	2025-11-22 23:44:51.535	2025-11-22 23:44:51.533	24	SISTEMA_CENTRAL	\N
136	Juan Carlos	Aviles		5612000271		juanaavilesangeles@gmail.com								\N	\N			\N	2025-11-23 20:57:39.579	2025-11-23 20:57:39.577	24	SISTEMA_CENTRAL	\N
137	Cesar Ivan	Castro	Lopez	5548990641	5548990641	castro.cesarivan17@gmail.com								\N	\N			\N	2025-11-23 21:09:45.825	2025-11-23 21:09:45.823	24	SISTEMA_CENTRAL	\N
138	Brandon Ivan	Ramirez	Cabrera	7207088147	7207088147	brandonirc1995@gmail.com								\N	\N			\N	2025-11-23 21:28:47.586	2025-11-23 21:28:47.585	24	SISTEMA_CENTRAL	\N
140	Nilvis	Baselo		5569739664		nilvis@gmail.com								\N	\N			\N	2025-11-24 15:59:01.32	2025-11-24 15:59:01.318	24	SISTEMA_CENTRAL	\N
139	Adrian	Rosendo		5574081561	5533434785	adrian@gmail.com								\N	\N			\N	2025-11-24 15:49:31.048	2025-11-24 16:36:04.546	24	SISTEMA_CENTRAL	\N
141	Susana	Rivas		5585751435		Rivas@gmail.com								\N	\N			\N	2025-11-24 23:35:32.211	2025-11-24 23:35:32.21	24	SISTEMA_CENTRAL	\N
\.
COPY public.conceptos_presupuesto (id, presupuesto_id, descripcion, cantidad, precio_unitario, total, created_at, updated_at) FROM stdin;
197	73	Servicio a centro de carga tipo C	1	200	200	2025-10-09 23:05:11.814	2025-10-09 23:05:11.812
199	72	Display Honor X6/X8A 5G ORIG	1	625	625	2025-10-10 16:44:50.943	2025-10-10 16:44:50.942
201	75	Diagnóstico	1	600	600	2025-10-10 22:20:45.725	2025-10-10 22:20:45.723
204	76	Display Honor 70 ORIG OLED	1	1500	1500	2025-10-10 22:41:41.188	2025-10-10 22:41:41.187
205	77	Desbloqueo básico	1	500	500	2025-10-11 16:06:45.495	2025-10-11 16:06:45.494
95	24	PUNTA K	1	125	125	2025-09-20 23:53:29.105	2025-09-20 23:53:29.103
96	24	PUNTA RECTA	1	125	125	2025-09-20 23:53:29.105	2025-09-20 23:53:29.103
97	24	ROSIN	1	25	25	2025-09-20 23:53:29.105	2025-09-20 23:53:29.103
98	24	Caja organizadora grande	1	50	50	2025-09-20 23:53:29.105	2025-09-20 23:53:29.103
99	26	Pinzas rectas	2	99	198	2025-09-21 00:04:10.451	2025-09-21 00:04:10.449
100	26	Alcohol isopropilico	1	100	100	2025-09-21 00:04:10.451	2025-09-21 00:04:10.449
101	26	Chip AT&T	1	50	50	2025-09-21 00:04:10.451	2025-09-21 00:04:10.449
102	27	Centro de carga tipo C	1	100	100	2025-09-21 00:06:43.428	2025-09-21 00:06:43.427
103	28	Display Apple HG X11PRO(MOVIL IC)	1	1700	1700	2025-09-21 20:55:58.786	2025-09-21 20:55:58.785
104	29	servicio a centro de carga 	1	200	200	2025-09-21 20:58:01.934	2025-09-21 20:58:01.933
105	30	Batería ZTE V2020 5G	1	600	600	2025-09-22 22:46:17.016	2025-09-22 22:46:17.015
106	31	Cables Pulpo	1	60	60	2025-09-22 23:41:14.5	2025-09-22 23:41:14.499
107	32	Auricular iPhone	1	300	300	2025-09-23 16:34:48.393	2025-09-23 16:34:48.391
108	32	Cámaras iPhone 11 pro max	1	1700	1700	2025-09-23 16:34:48.393	2025-09-23 16:34:48.391
109	33	Display Apple  X  OLed	1	700	700	2025-09-23 16:40:47.298	2025-09-23 16:40:47.297
110	33	Auricular iPhone	1	300	300	2025-09-23 16:40:47.298	2025-09-23 16:40:47.297
111	34	Altavoz Android	1	350	350	2025-09-23 17:36:27.43	2025-09-23 17:36:27.429
206	78	micrófono Android	1	500	500	2025-10-11 19:12:05.28	2025-10-11 19:12:05.278
208	80	Display Motorola G85/S50 NEO/EDGE 50	1	2000	2000	2025-10-13 20:31:27.813	2025-10-13 20:31:27.812
25	13	servicio a centro de carga 	1	200	200	2025-09-01 17:35:05.663	2025-09-01 17:35:05.661
26	14	varios	1	50	50	2025-09-01 19:00:06.854	2025-09-01 19:00:06.853
211	82	Diagnóstico	1	200	200	2025-10-14 19:04:57.304	2025-10-14 19:04:57.303
28	15	varios	1	300	300	2025-09-01 21:16:33.398	2025-09-01 21:16:33.397
29	16	Display Apple HG X11(MOVIL IC)	1	950	950	2025-09-05 16:21:20.948	2025-09-05 16:21:20.946
31	18	Desbloqueo básico	1	100	100	2025-09-08 19:52:55.284	2025-09-08 19:52:55.282
32	19	Flux	1	290	290	2025-09-09 23:20:37.945	2025-09-09 23:20:37.943
33	19	Mini drill	1	760	760	2025-09-09 23:20:37.945	2025-09-09 23:20:37.943
34	19	Oppener de plastico	2	10	20	2025-09-09 23:20:37.945	2025-09-09 23:20:37.943
35	19	Paquete oppener de metal	1	90	90	2025-09-09 23:20:37.945	2025-09-09 23:20:37.943
36	19	Alcoholera de vidrio	1	150	150	2025-09-09 23:20:37.945	2025-09-09 23:20:37.943
37	19	Tester 	1	600	600	2025-09-09 23:20:37.945	2025-09-09 23:20:37.943
38	19	Pegamento negro para pantalla	1	89	89	2025-09-09 23:20:37.945	2025-09-09 23:20:37.943
39	19	Toallitas limpiadoras	1	200	200	2025-09-09 23:20:37.945	2025-09-09 23:20:37.943
40	19	Espatula para baterias	1	90	90	2025-09-09 23:20:37.945	2025-09-09 23:20:37.943
41	20	Batería Apple iPhone 13	1	800	800	2025-09-10 16:36:11.37	2025-09-10 16:36:11.368
116	25	Pegamento negro para pantalla	1	89	89	2025-09-23 21:15:05.182	2025-09-23 21:15:05.18
43	17	Bateria moto E13	1	550	550	2025-09-10 18:32:59.56	2025-09-10 18:32:59.558
44	21	Caja organizadora grande	1	50	50	2025-09-11 18:24:25.507	2025-09-11 18:24:25.506
45	22	Desbloqueo básico	1	250	250	2025-09-11 23:42:40.051	2025-09-11 23:42:40.049
46	23	Centro de carga tipo V8	1	300	300	2025-09-13 20:17:46.227	2025-09-13 20:17:46.225
215	85	Ipad 6ta	1	800	800	2025-10-16 21:17:34.543	2025-10-16 21:17:34.542
218	88	servicio a centro de carga 	1	350	350	2025-10-19 19:49:25.294	2025-10-19 19:49:25.292
117	25	Oppener de metal	1	39	39	2025-09-23 21:15:05.182	2025-09-23 21:15:05.18
118	25	Desarmador de cruz	1	49	49	2025-09-23 21:15:05.182	2025-09-23 21:15:05.18
119	25	Desarmador plano	1	49	49	2025-09-23 21:15:05.182	2025-09-23 21:15:05.18
120	25	Alcohol isopropilico	1	100	100	2025-09-23 21:15:05.182	2025-09-23 21:15:05.18
121	25	Gotero	1	25	25	2025-09-23 21:15:05.182	2025-09-23 21:15:05.18
122	25	Espatula para baterias	1	75	75	2025-09-23 21:15:05.182	2025-09-23 21:15:05.18
123	25	Caja organizadora grande	1	50	50	2025-09-23 21:15:05.182	2025-09-23 21:15:05.18
124	25	Cinta Kapton 	1	80	80	2025-09-23 21:15:05.182	2025-09-23 21:15:05.18
125	36	Batería Samsung A13 5G / A136B	1	600	600	2025-09-23 22:16:07.163	2025-09-23 22:16:07.162
126	37	Desbloqueo básico	1	400	400	2025-09-25 23:01:47.329	2025-09-25 23:01:47.328
128	38	Display Motorola E14/G04/G04S/G24/G24 POWER ORIG	1	600	600	2025-09-26 15:57:14.348	2025-09-26 15:57:14.347
130	35	Centro de carga tipo C	1	350	350	2025-09-26 20:15:56.328	2025-09-26 20:15:56.326
131	39	Centro de carga tipo V8	1	300	300	2025-09-26 20:56:50.461	2025-09-26 20:56:50.46
133	40	Desbloqueo básico	1	199.97	199.97	2025-09-26 22:18:29.289	2025-09-26 22:18:29.288
134	41	Desbloqueo básico	1	480	480	2025-09-26 22:58:16.55	2025-09-26 22:58:16.549
135	42	Centro de carga tipo C	1	350	350	2025-09-27 19:49:14.177	2025-09-27 19:49:14.176
136	43	Cargador tipo IPhone YA! 	1	80	80	2025-09-27 20:10:43.695	2025-09-27 20:10:43.694
137	44	Cargador Motorola 	1	150	150	2025-09-27 20:12:40.234	2025-09-27 20:12:40.232
138	45	e-Sim	1	250	250	2025-09-27 20:16:30.285	2025-09-27 20:16:30.284
140	47	servicio a centro de carga 	1	200	200	2025-09-28 19:34:53.505	2025-09-28 19:34:53.504
144	49	Servicio a centro de carga tipo C	1	200	200	2025-09-29 21:48:45.028	2025-09-29 21:48:45.027
147	51	servicio a teléfonos mojados 	1	200	200	2025-09-30 21:02:00.102	2025-09-30 21:02:00.101
148	52	Display Motorola G20/G10/G30 ORIG S/M	1	600	600	2025-09-30 23:33:59.769	2025-09-30 23:33:59.767
149	46	diagnostico	1	200	200	2025-10-01 17:40:25.483	2025-10-01 17:40:25.482
150	53	Display Oppo A53 4G/1+N100/A32/A33/A53S/A11S/ REALME7I/REALME	1	600	600	2025-10-01 17:50:33.114	2025-10-01 17:50:33.112
155	55	Batería Apple iPhone 12/12PRO	1	800	800	2025-10-02 19:25:41.236	2025-10-02 19:25:41.235
176	59	Centro de carga tipo C	1	500	500	2025-10-05 18:59:32.206	2025-10-05 18:59:32.204
177	60	Desbloqueo básico	1	300	300	2025-10-06 19:40:06.87	2025-10-06 19:40:06.869
178	61	Desbloqueo básico	1	200	200	2025-10-06 21:17:07.461	2025-10-06 21:17:07.46
179	62	servicio a centro de carga 	1	200	200	2025-10-07 16:05:02.534	2025-10-07 16:05:02.532
181	63	Display Samsung A02S/A03/A03S/A04E ORIG S/M	1	600	600	2025-10-07 17:35:30.459	2025-10-07 17:35:30.458
182	63	Marco Android 	1	200	200	2025-10-07 17:35:30.459	2025-10-07 17:35:30.458
184	64	Diagnóstico	1	200	200	2025-10-08 20:12:33.517	2025-10-08 20:12:33.516
186	57	Desbloqueo básico	1	700	700	2025-10-08 20:25:41.253	2025-10-08 20:25:41.252
200	74	Display Xiaomi POCO M4/M5/REDMI10 5G/NOTE 11	1	700	700	2025-10-10 17:43:13.136	2025-10-10 17:43:13.135
202	48	Desbloqueo básico	1	400	400	2025-10-10 22:25:41.729	2025-10-10 22:25:41.727
203	58	Display ZTE AXON 50 LITE	1	675	675	2025-10-10 22:26:48.287	2025-10-10 22:26:48.285
207	79	Display Honor X7A ORIG S/M	1	600	600	2025-10-13 18:04:16.211	2025-10-13 18:04:16.209
210	81	Display Huawei Y9S ORIG C/M(BOUTIQUE)	1	1000	1000	2025-10-13 20:39:25.183	2025-10-13 20:39:25.182
212	83	Display Huawei Y9S ORIG C/M(BOUTIQUE)	1	675	675	2025-10-15 21:59:09.304	2025-10-15 21:59:09.303
214	84	Centro de carga tipo C	1	350	350	2025-10-16 20:27:10.317	2025-10-16 20:27:10.316
216	86	Display Motorola EDGE50 PRO AMOLED	1	2000	2000	2025-10-17 17:58:15.451	2025-10-17 17:58:15.449
217	87	Display Xiaomi POCO M4/M5/REDMI10 5G/NOTE 11	1	1500	1500	2025-10-18 14:57:33.068	2025-10-18 14:57:33.066
219	89	Tapa Android	1	700	700	2025-10-20 16:07:47.435	2025-10-20 16:07:47.433
220	90	Lector de SIM	1	300	300	2025-10-20 19:58:40.049	2025-10-20 19:58:40.048
221	91	Diagnóstico	1	200	200	2025-10-22 17:06:26.711	2025-10-22 17:06:26.71
222	92	Display Motorola G20/G10/G30 ORIG S/M	1	650	650	2025-10-22 20:55:32.399	2025-10-22 20:55:32.398
224	94	Centro de carga tipo V8	1	200	200	2025-10-23 18:13:52.831	2025-10-23 18:13:52.83
225	95	servicio a centro de carga 	1	200	200	2025-10-27 19:37:52.91	2025-10-27 19:37:52.909
226	96	Display Apple HG X11(MOVIL IC)	1	1057	1057	2025-10-27 22:32:47.882	2025-10-27 22:32:47.881
228	97	Display Oppo A16 ORIG C/M(BOUTIQUE)	1	600	600	2025-10-27 22:46:52.944	2025-10-27 22:46:52.942
229	98	servicio a centro de carga 	1	200	200	2025-10-28 00:10:35.501	2025-10-28 00:10:35.5
230	99	Centro de carga tipo C	1	200	200	2025-10-28 00:21:27.883	2025-10-28 00:21:27.882
231	100	Centro de carga tipo C	1	200	200	2025-10-28 20:10:59.598	2025-10-28 20:10:59.597
233	102	Desbloqueo básico	1	250	250	2025-10-28 23:14:40.106	2025-10-28 23:14:40.105
235	104	servicio a botones	1	150	150	2025-10-29 22:58:51.795	2025-10-29 22:58:51.793
237	106	Display Xiaomi REDMI 9 ORIG	1	600	600	2025-10-31 14:55:53.481	2025-10-31 14:55:53.48
238	107	batería Android	1	400	400	2025-10-31 16:38:28.973	2025-10-31 16:38:28.972
239	108	servicio altavoz 	1	150	150	2025-10-31 16:55:26.114	2025-10-31 16:55:26.113
240	103	Display Samsung A30S INCELL S/M	1	1100	1100	2025-10-31 19:51:04.586	2025-10-31 19:51:04.584
242	110	Centro de carga tipo C	1	200	200	2025-11-01 17:50:05.916	2025-11-01 17:50:05.915
243	101	Display Motorola G10/G20/G30 INCELL300+ C/M	1	600	600	2025-11-01 18:16:03.606	2025-11-01 18:16:03.605
244	111	Display Motorola E20 ORIG C/M	1	600	600	2025-11-01 18:29:59.247	2025-11-01 18:29:59.245
245	112	Display Motorola G13/G23 ORIG C/M(BOUTIQUE)	1	600	600	2025-11-01 18:30:18.838	2025-11-01 18:30:18.836
246	113	Centro de carga tipo C	1	200	200	2025-11-01 20:55:08.94	2025-11-01 20:55:08.939
247	93	Diagnóstico	1	200	200	2025-11-02 21:20:36.347	2025-11-02 21:20:36.345
248	114	diagnostico	1	200	200	2025-11-02 22:00:31.131	2025-11-02 22:00:31.13
249	115	Desbloqueo básico	1	550	550	2025-11-03 16:23:18.201	2025-11-03 16:23:18.2
250	116	Display Oppo A16/A16S/A54S/A56/4G/C25/C25S/NARZO50A ORIG S/M	1	600	600	2025-11-03 19:02:14.744	2025-11-03 19:02:14.743
251	117	varios	1	130	130	2025-11-04 23:15:49.215	2025-11-04 23:15:49.214
252	118	servicio de auricular	1	200	200	2025-11-05 16:27:47.177	2025-11-05 16:27:47.176
253	119	Display Motorola E14/G04/G04S/G24/G24 POWER ORIG	1	600	600	2025-11-05 17:36:57.531	2025-11-05 17:36:57.53
254	120	Desbloqueo básico	1	350	350	2025-11-05 23:16:57.149	2025-11-05 23:16:57.147
257	121	servicio a teléfonos mojados 	1	200	200	2025-11-06 17:00:07.558	2025-11-06 17:00:07.557
258	122	Centro de carga tipo C	1	350	350	2025-11-06 17:53:17.415	2025-11-06 17:53:17.414
259	123	Cepillo de limpieza	1	25	25	2025-11-06 22:22:25.134	2025-11-06 22:22:25.133
264	124	Batería iPhone 16 Pro	1	1300	1300	2025-11-07 00:23:14.219	2025-11-07 00:23:14.217
265	124	Mano de Obra	1	900	900	2025-11-07 00:23:14.219	2025-11-07 00:23:14.217
266	125	Centro de carga tipo V8	1	150	150	2025-11-07 16:01:01.563	2025-11-07 16:01:01.562
268	109	Display Motorola E22 ORIG C/M(BOUTIQUE)	1	650	650	2025-11-09 18:57:35.587	2025-11-09 18:57:35.585
279	126	servicio a centro de carga 	1	200	200	2025-11-09 19:26:32.4	2025-11-09 19:26:32.399
280	126	Display Motorola E20 ORIG C/M	1	600	600	2025-11-09 19:26:32.4	2025-11-09 19:26:32.399
282	127	servicio a centro de carga 	1	200	200	2025-11-09 21:35:28.647	2025-11-09 21:35:28.646
284	128	servicio a centro de carga 	1	200	200	2025-11-09 22:13:27.512	2025-11-09 22:13:27.511
286	129	servicio a centro de carga 	1	200	200	2025-11-10 21:14:27.025	2025-11-10 21:14:27.024
290	54	Desbloqueo básico	1	350	350	2025-11-10 22:00:03.033	2025-11-10 22:00:03.032
292	130	Desbloqueo básico	1	350	350	2025-11-10 22:02:23.849	2025-11-10 22:02:23.847
293	131	servicio a centro de carga 	1	50	50	2025-11-11 22:16:46.987	2025-11-11 22:16:46.986
294	132	Bateria Iphone 15	1	3000	3000	2025-11-12 00:09:04.013	2025-11-12 00:09:04.011
295	133	Desbloqueo básico	1	900	900	2025-11-12 17:29:16.508	2025-11-12 17:29:16.506
298	135	servicio a centro de carga 	1	200	200	2025-11-12 18:37:19.74	2025-11-12 18:37:19.739
299	134	Display Apple HG XR FHD	1	800	800	2025-11-12 19:25:41.827	2025-11-12 19:25:41.824
300	134	Batería Apple iPhone XR	1	250	250	2025-11-12 19:25:41.827	2025-11-12 19:25:41.824
304	136	Cargador Motorola 	1	150	150	2025-11-12 22:47:07.932	2025-11-12 22:47:07.931
305	136	servicio a centro de carga 	1	200	200	2025-11-12 22:47:07.932	2025-11-12 22:47:07.931
308	137	servicio a centro de carga 	1	200	200	2025-11-12 23:06:49.493	2025-11-12 23:06:49.491
309	137	servicio a centro de carga 	1	200	200	2025-11-12 23:06:49.493	2025-11-12 23:06:49.491
310	138	Bateria moto E13	1	600	600	2025-11-12 23:38:12.313	2025-11-12 23:38:12.312
311	139	servicio a botones	1	50	50	2025-11-12 23:57:49.575	2025-11-12 23:57:49.574
314	140	Display Motorola E22/E22i ORIG S/M	1	600	600	2025-11-13 00:18:01.836	2025-11-13 00:18:01.835
317	141	Logica	1	750	750	2025-11-13 17:15:11.337	2025-11-13 17:15:11.336
320	143	Display Apple 7PLUS AAA NEGRO	1	600	600	2025-11-14 15:27:48.621	2025-11-14 15:27:48.619
321	144	Logica	1	500	500	2025-11-14 15:59:35.829	2025-11-14 15:59:35.828
322	145	servicio a centro de carga 	1	200	200	2025-11-15 18:48:57.706	2025-11-15 18:48:57.705
323	146	Desbloqueo básico	1	150	150	2025-11-15 18:57:59.68	2025-11-15 18:57:59.679
327	147	Display Samsung S23 ULTRA SOFT	1	7200	7200	2025-11-15 19:11:38.836	2025-11-15 19:11:38.835
328	147	Tapa Android	1	100	100	2025-11-15 19:11:38.836	2025-11-15 19:11:38.835
332	105	Bateria Iphone 15	1	600	600	2025-11-17 16:25:08.554	2025-11-17 16:25:08.552
333	148	Tapa IOS	1	600	600	2025-11-17 20:45:27.278	2025-11-17 20:45:27.276
334	149	Display Motorola E7 ORIG C/M(BOUTIQUE)	1	600	600	2025-11-18 20:23:28.206	2025-11-18 20:23:28.205
335	150	Display Motorola G85/S50 NEO/EDGE 50	1	2000	2000	2025-11-18 20:31:58.732	2025-11-18 20:31:58.73
336	150	Desbloqueo básico	1	500	500	2025-11-18 20:31:58.732	2025-11-18 20:31:58.73
337	151	servicio a botones	1	150	150	2025-11-19 17:31:17.249	2025-11-19 17:31:17.247
338	152	Centro de carga tipo C	1	700	700	2025-11-19 17:33:10.366	2025-11-19 17:33:10.365
339	153	servicio a botones	1	200	200	2025-11-19 20:17:52.287	2025-11-19 20:17:52.285
340	154	Diagnóstico	1	2000	2000	2025-11-20 19:55:38.897	2025-11-20 19:55:38.896
341	155	servicio de auricular	1	350	350	2025-11-20 21:45:06.86	2025-11-20 21:45:06.859
342	156	Desbloqueo básico	1	150	150	2025-11-21 18:29:00.479	2025-11-21 18:29:00.478
343	157	Desbloqueo básico	1	200	200	2025-11-21 18:29:27.379	2025-11-21 18:29:27.378
344	158	Logica	1	1000	1000	2025-11-21 21:19:03.989	2025-11-21 21:19:03.988
345	159	Display Motorola G9PLAY/E7PLUS ORIG C/M(BOUTIQUE)	1	550	550	2025-11-22 19:00:35.144	2025-11-22 19:00:35.143
346	160	Display Motorola G9 PLAY INCELL300+	1	550	550	2025-11-22 19:08:17.865	2025-11-22 19:08:17.864
347	161	servicio a centro de carga 	1	200	200	2025-11-22 19:52:30.206	2025-11-22 19:52:30.205
354	162	Pegamento para pantalla N	1	89	89	2025-11-23 19:21:08.521	2025-11-23 19:21:08.519
355	162	Caja organizadora grande	1	50	50	2025-11-23 19:21:08.521	2025-11-23 19:21:08.519
356	162	Espatula para soldar	1	49	49	2025-11-23 19:21:08.521	2025-11-23 19:21:08.519
357	163	Tapa Android 2	1	450	450	2025-11-23 21:31:35.348	2025-11-23 21:31:35.347
358	164	Display ZTE AXON 60 LITE	1	650	650	2025-11-24 15:53:33.716	2025-11-24 15:53:33.715
359	165	servicio a teléfonos mojados 	1	600	600	2025-11-24 16:47:52.56	2025-11-24 16:47:52.559
361	166	Pegamento para pantalla N	1	89	89	2025-11-24 18:25:18.251	2025-11-24 18:25:18.25
363	167	servicio a botones	1	250	250	2025-11-24 23:37:53.08	2025-11-24 23:37:53.079
\.
COPY public.cupones (id, codigo, nombre, descripcion, tipo, tipo_descuento, valor_descuento, monto_minimo, fecha_inicio, fecha_expiracion, limite_usos, usos_actuales, activo, created_at, updated_at) FROM stdin;
1	DESCUENTO1	Descuento Prueba 1	Descuento de Prueba #1	GENERAL	PORCENTAJE	10	1000	2025-08-12 00:00:00	2025-09-11 00:00:00	1	0	t	2025-08-12 21:03:27.315	2025-08-12 21:03:27.311
2	DESCUENTO20	DESCUENTO20	2da visita y reparacion 	GENERAL	PORCENTAJE	20	700	2025-08-12 00:00:00	2025-09-11 00:00:00	1	0	t	2025-08-12 22:16:53.304	2025-08-12 22:16:53.303
3	50%	curso MARCO Fdz	comunidad	GENERAL	MONTO_FIJO	50	9000	2025-08-12 00:00:00	2025-09-11 00:00:00	1	0	t	2025-08-12 23:00:05.469	2025-08-12 23:00:05.468
4	FBARMX1234	CUPON DE LANZAMIENTO - facebook	cupon para campaña de facebook	GENERAL	PORCENTAJE	5	500	2025-08-15 00:00:00	2025-09-14 00:00:00	1	0	t	2025-08-15 18:12:27.883	2025-08-15 18:12:27.882
5	LBD5GT3D	Cupon para Escuela X	cupones para todos los estudiantes de la escuela X	PERSONALIZADO	MONTO_FIJO	50	300	2025-08-15 00:00:00	2025-09-14 00:00:00	10	0	t	2025-08-15 18:13:45.11	2025-08-15 18:13:45.108
7	UNIVERSIDAD GTU	TALLERES	10%.   	GENERAL	PORCENTAJE	10	0	2025-08-18 00:00:00	2025-09-17 00:00:00	\N	0	t	2025-08-18 16:40:22.312	2025-08-18 16:40:22.311
8	30	CURSO MARCO	curso marco intermedio	GENERAL	PORCENTAJE	30	6000	2025-09-26 00:00:00	2025-10-29 00:00:00	\N	0	t	2025-09-26 20:42:08.957	2025-09-26 20:42:08.956
\.
COPY public.detalle_ventas (id, venta_id, producto_id, cantidad, precio_unitario, subtotal, created_at, updated_at) FROM stdin;
12	10	1055	1	60	60	2025-09-19 20:01:52.22	2025-09-19 20:01:52.22
13	11	1095	1	1	1	2025-09-20 18:12:00.708	2025-09-20 18:12:00.708
14	12	1096	1	99	99	2025-10-02 17:35:08.44	2025-10-02 17:35:08.44
18	16	1059	1	290	290	2025-11-10 16:10:44.503	2025-11-10 16:10:44.503
19	17	1063	1	200	200	2025-11-10 16:29:18.838	2025-11-10 16:29:18.838
20	18	1116	1	50	50	2025-11-14 22:49:45.083	2025-11-14 22:49:45.083
21	19	1087	1	54	54	2025-11-16 17:46:58.927	2025-11-16 17:46:58.927
22	19	1076	2	25	50	2025-11-16 17:46:58.935	2025-11-16 17:46:58.935
23	19	1064	2	10	20	2025-11-16 17:46:58.939	2025-11-16 17:46:58.939
24	19	1122	1	260	260	2025-11-16 17:46:58.945	2025-11-16 17:46:58.945
25	19	1075	1	100	100	2025-11-16 17:46:58.949	2025-11-16 17:46:58.949
26	20	1048	1	60	60	2025-11-17 23:35:27.279	2025-11-17 23:35:27.279
27	21	1031	1	150	150	2025-11-20 21:37:05.302	2025-11-20 21:37:05.302
28	22	1059	1	290	290	2025-11-22 23:38:17.654	2025-11-22 23:38:17.654
\.
COPY public.direcciones (id, cliente_id, calle, numero_exterior, numero_interior, colonia, ciudad, estado, codigo_postal, latitud, longitud, created_at, updated_at) FROM stdin;
\.
COPY public.dispositivos (id, ticket_id, tipo, marca, modelo, serie, created_at, updated_at) FROM stdin;
\.
COPY public.entradas_almacen (id, producto_id, cantidad, precio_compra, notas, fecha, usuario_id, proveedor_id, created_at, updated_at) FROM stdin;
3	6	10	2000		2025-06-17 21:35:56.032	2	3	2025-06-17 21:35:56.032	2025-06-17 21:35:56.032
4	5	10	3000		2025-06-17 21:36:05.529	2	3	2025-06-17 21:36:05.529	2025-06-17 21:36:05.529
5	6	5	2200		2025-06-18 16:13:32.27	2	3	2025-06-18 16:13:32.27	2025-06-18 16:13:32.27
6	11	10	100		2025-08-08 16:26:18.041	15	3	2025-08-08 16:26:18.041	2025-08-08 16:26:18.039
7	14	12	150		2025-08-19 15:54:46.337	15	5	2025-08-19 15:54:46.337	2025-08-19 15:54:46.333
8	19	1	150		2025-08-20 20:50:12.611	17	5	2025-08-20 20:50:12.611	2025-08-20 20:50:12.609
9	1042	3	300		2025-09-05 17:29:54.578	17	5	2025-09-05 17:29:54.578	2025-09-05 17:29:54.576
10	1042	3	300		2025-09-05 17:35:06.514	17	7	2025-09-05 17:35:06.514	2025-09-05 17:35:06.513
11	1033	3	350		2025-09-05 17:35:20.048	17	7	2025-09-05 17:35:20.048	2025-09-05 17:35:20.047
12	1031	3	65		2025-09-05 17:36:04.175	17	7	2025-09-05 17:36:04.175	2025-09-05 17:36:04.174
13	1043	10	55		2025-09-05 18:02:13.374	17	7	2025-09-05 18:02:13.374	2025-09-05 18:02:13.372
14	1044	10	26		2025-09-05 18:02:45.965	17	7	2025-09-05 18:02:45.965	2025-09-05 18:02:45.963
15	1046	10	26		2025-09-05 18:03:29.416	17	7	2025-09-05 18:03:29.416	2025-09-05 18:03:29.415
16	1045	2	26		2025-09-05 18:04:03.734	17	7	2025-09-05 18:04:03.734	2025-09-05 18:04:03.733
17	1047	10	21		2025-09-05 18:04:31.374	17	7	2025-09-05 18:04:31.374	2025-09-05 18:04:31.373
18	1048	10	25		2025-09-05 18:04:57.521	17	7	2025-09-05 18:04:57.521	2025-09-05 18:04:57.519
19	1055	10	60		2025-09-05 18:25:02.849	17	7	2025-09-05 18:25:02.849	2025-09-05 18:25:02.847
20	1036	20	12		2025-09-15 17:43:18.151	17	7	2025-09-15 17:43:18.151	2025-09-15 17:43:18.149
21	1095	3	1		2025-09-20 18:08:55.169	17	7	2025-09-20 18:08:55.169	2025-09-20 18:08:55.168
22	1092	2	1		2025-09-20 18:09:09.481	17	7	2025-09-20 18:09:09.481	2025-09-20 18:09:09.48
23	1093	2	1		2025-09-20 18:09:22.314	17	7	2025-09-20 18:09:22.314	2025-09-20 18:09:22.313
24	1094	1	1		2025-09-20 18:10:01.544	17	7	2025-09-20 18:10:01.544	2025-09-20 18:10:01.543
25	1075	5	65		2025-09-20 23:46:52.919	17	3	2025-09-20 23:46:52.919	2025-09-20 23:46:52.917
26	1096	8	75		2025-09-20 23:50:53.207	17	3	2025-09-20 23:50:53.207	2025-09-20 23:50:53.206
27	933	1	255		2025-10-02 22:04:14.952	17	5	2025-10-02 22:04:14.952	2025-10-02 22:04:14.95
28	1104	1	500		2025-10-08 20:29:49.576	17	5	2025-10-08 20:29:49.576	2025-10-08 20:29:49.574
29	1104	1	350		2025-10-08 20:33:56.253	17	5	2025-10-08 20:33:56.253	2025-10-08 20:33:56.252
30	1105	1	380	Display samsung a04 	2025-10-08 20:38:15.441	17	5	2025-10-08 20:38:15.441	2025-10-08 20:38:15.439
31	1106	1	0.1		2025-10-09 15:20:40.864	17	5	2025-10-09 15:20:40.864	2025-10-09 15:20:40.862
32	1106	1	0.1		2025-10-09 16:35:33.909	17	5	2025-10-09 16:35:33.909	2025-10-09 16:35:33.907
33	1106	1	0.1		2025-10-09 16:42:09.238	17	5	2025-10-09 16:42:09.238	2025-10-09 16:42:09.236
34	1106	1	0.1		2025-10-09 16:46:06.128	17	5	2025-10-09 16:46:06.128	2025-10-09 16:46:06.126
35	1106	2	0.1		2025-10-09 16:58:38.522	17	5	2025-10-09 16:58:38.522	2025-10-09 16:58:38.52
36	1106	2	0.1		2025-10-09 17:35:25.2	17	5	2025-10-09 17:35:25.2	2025-10-09 17:35:25.197
37	303	1	225		2025-10-09 20:34:25.471	17	5	2025-10-09 20:34:25.471	2025-10-09 20:34:25.469
38	1108	1	120	Desbloqueo cuenta google 	2025-10-11 23:06:50.589	17	5	2025-10-11 23:06:50.589	2025-10-11 23:06:50.587
39	270	1	700		2025-10-11 23:08:17.266	17	5	2025-10-11 23:08:17.266	2025-10-11 23:08:17.264
40	1109	1	150	Se coloca bateria nueva 	2025-10-11 23:10:26.409	17	5	2025-10-11 23:10:26.409	2025-10-11 23:10:26.407
41	286	1	250		2025-10-11 23:12:57.801	17	5	2025-10-11 23:12:57.801	2025-10-11 23:12:57.8
42	853	1	255		2025-10-11 23:17:52.783	17	5	2025-10-11 23:17:52.783	2025-10-11 23:17:52.782
43	14	1	200		2025-10-11 23:19:34.96	17	5	2025-10-11 23:19:34.96	2025-10-11 23:19:34.958
44	432	1	945		2025-10-14 21:42:57.951	17	5	2025-10-14 21:42:57.951	2025-10-14 21:42:57.949
45	365	1	497		2025-10-14 21:45:25.999	17	5	2025-10-14 21:45:25.999	2025-10-14 21:45:25.997
46	275	1	295		2025-10-14 21:48:46.202	17	5	2025-10-14 21:48:46.202	2025-10-14 21:48:46.201
47	1104	1	250	Se regresa el dinero ya que el equipo venia bastante manipulado	2025-10-14 21:54:10.907	17	5	2025-10-14 21:54:10.907	2025-10-14 21:54:10.906
48	372	1	290		2025-10-16 20:25:31.538	17	5	2025-10-16 20:25:31.538	2025-10-16 20:25:31.536
49	432	1	940		2025-10-17 20:50:01.849	17	5	2025-10-17 20:50:01.849	2025-10-17 20:50:01.846
50	1103	1	600		2025-10-18 20:55:13.952	17	5	2025-10-18 20:55:13.952	2025-10-18 20:55:13.95
52	564	1	210		2025-10-27 23:03:42.352	17	5	2025-10-27 23:03:42.352	2025-10-27 23:03:42.35
53	212	1	155		2025-10-28 21:47:07.108	17	5	2025-10-28 21:47:07.108	2025-10-28 21:47:07.105
54	1113	1	90		2025-10-28 21:49:57.99	17	5	2025-10-28 21:49:57.99	2025-10-28 21:49:57.988
55	496	1	260		2025-10-28 21:51:34.357	17	5	2025-10-28 21:51:34.357	2025-10-28 21:51:34.356
56	544	1	220		2025-10-28 21:52:40.597	17	5	2025-10-28 21:52:40.597	2025-10-28 21:52:40.596
57	933	1	265		2025-10-28 21:58:54.157	17	5	2025-10-28 21:58:54.157	2025-10-28 21:58:54.154
58	303	1	225		2025-10-28 22:00:22.337	17	5	2025-10-28 22:00:22.337	2025-10-28 22:00:22.336
59	241	1	270		2025-10-28 22:02:33.145	17	5	2025-10-28 22:02:33.145	2025-10-28 22:02:33.143
60	885	1	250		2025-10-28 22:03:44.881	17	5	2025-10-28 22:03:44.881	2025-10-28 22:03:44.879
61	245	1	260		2025-10-28 22:06:31.909	17	5	2025-10-28 22:06:31.909	2025-10-28 22:06:31.908
62	141	1	180		2025-10-28 22:10:02.498	17	5	2025-10-28 22:10:02.498	2025-10-28 22:10:02.496
63	434	1	220		2025-10-28 22:17:10.298	17	5	2025-10-28 22:17:10.298	2025-10-28 22:17:10.296
64	1026	1	210		2025-10-28 22:19:08.736	17	5	2025-10-28 22:19:08.736	2025-10-28 22:19:08.735
65	431	1	970		2025-10-28 22:19:53.714	17	5	2025-10-28 22:19:53.714	2025-10-28 22:19:53.713
66	1026	1	180		2025-10-28 22:20:43.97	17	5	2025-10-28 22:20:43.97	2025-10-28 22:20:43.969
67	958	1	395		2025-10-28 22:22:01.289	17	5	2025-10-28 22:22:01.289	2025-10-28 22:22:01.288
68	467	1	240		2025-10-28 22:23:30.618	17	5	2025-10-28 22:23:30.618	2025-10-28 22:23:30.616
69	379	1	245		2025-10-28 22:24:06.523	17	5	2025-10-28 22:24:06.523	2025-10-28 22:24:06.521
70	660	1	260		2025-10-28 22:24:52.886	17	5	2025-10-28 22:24:52.886	2025-10-28 22:24:52.884
71	826	1	220		2025-10-28 22:27:08.493	17	5	2025-10-28 22:27:08.493	2025-10-28 22:27:08.492
72	810	1	200		2025-10-31 22:20:04.167	17	5	2025-10-31 22:20:04.167	2025-10-31 22:20:04.165
73	152	1	200		2025-10-31 22:21:14.686	17	5	2025-10-31 22:21:14.686	2025-10-31 22:21:14.685
74	412	1	190		2025-11-01 21:55:27.319	17	5	2025-11-01 21:55:27.319	2025-11-01 21:55:27.317
75	417	1	190		2025-11-01 21:57:25.916	17	5	2025-11-01 21:57:25.916	2025-11-01 21:57:25.914
76	1114	1	250	Colocacion de pieza	2025-11-01 21:58:27.872	17	5	2025-11-01 21:58:27.872	2025-11-01 21:58:27.871
77	423	1	210		2025-11-01 21:59:39.277	17	5	2025-11-01 21:59:39.277	2025-11-01 21:59:39.276
78	1104	1	200		2025-11-02 21:22:56.638	17	5	2025-11-02 21:22:56.638	2025-11-02 21:22:56.636
79	467	1	190		2025-11-05 22:23:26.839	16	5	2025-11-05 22:23:26.839	2025-11-05 22:23:26.837
80	1116	10	15		2025-11-06 18:38:44.567	24	5	2025-11-06 18:38:44.567	2025-11-06 18:38:44.565
81	1117	1	29	Entrega de centros de carga tipo C con fecha del 06/11/2025	2025-11-06 19:06:03.702	24	8	2025-11-06 19:06:03.702	2025-11-06 19:06:03.7
82	1108	1	150	Desbloqueo de equipo.	2025-11-06 22:41:14.743	24	5	2025-11-06 22:41:14.743	2025-11-06 22:41:14.741
83	626	1	600	Display Samsung SM-a15 OLED	2025-11-08 21:46:34.642	24	5	2025-11-08 21:46:34.642	2025-11-08 21:46:34.639
84	1114	1	490	Se compra refacción para reparación con ticket #TICK-1762473272836	2025-11-08 22:43:42.455	24	5	2025-11-08 22:43:42.455	2025-11-08 22:43:42.452
85	1118	1	115	Se realiza reparación con ticket #TICK-1762473272836	2025-11-08 22:48:37.925	24	5	2025-11-08 22:48:37.925	2025-11-08 22:48:37.923
86	1117	2	30	Servicio de entrega de refacciones.	2025-11-08 22:49:35.61	24	8	2025-11-08 22:49:35.61	2025-11-08 22:49:35.608
87	1059	1	0.01		2025-11-10 16:10:20.915	24	5	2025-11-10 16:10:20.915	2025-11-10 16:10:20.913
88	1063	1	0.1		2025-11-10 16:26:42.983	16	5	2025-11-10 16:26:42.983	2025-11-10 16:26:42.982
89	1119	1	400	Compra de Tarjeta Lógica Redmi Note11 Ticket #TICK-1762288770175	2025-11-12 17:16:06.498	24	9	2025-11-12 17:16:06.498	2025-11-12 17:16:06.496
90	1117	1	29	TICK-1762970205831	2025-11-12 20:35:09.926	24	8	2025-11-12 20:35:09.926	2025-11-12 20:35:09.922
91	1117	1	29	Entrega de pantalla, Motorola E22i\nTicket #TICK-1762993061755\n	2025-11-13 17:06:25.873	24	8	2025-11-13 17:06:25.873	2025-11-13 17:06:25.87
92	1120	1	400	Logica de un Redmi Note 11	2025-11-13 17:12:55.878	24	9	2025-11-13 17:12:55.878	2025-11-13 17:12:55.876
93	937	1	165	Se compra batería para XR	2025-11-13 18:21:28.619	24	9	2025-11-13 18:21:28.619	2025-11-13 18:21:28.617
94	961	1	310	Display de iPhone XR	2025-11-13 18:22:18.37	24	9	2025-11-13 18:22:18.37	2025-11-13 18:22:18.368
95	423	1	170	Se compra display para Motorola E22i\n	2025-11-13 19:17:38.941	24	9	2025-11-13 19:17:38.941	2025-11-13 19:17:38.938
96	1120	1	200	Se compra lógica para Moto g8	2025-11-15 16:20:33.235	24	9	2025-11-15 16:20:33.235	2025-11-15 16:20:33.233
97	1121	1	190	Se pide pieza para reparación de iPhone 7 plus	2025-11-15 17:00:33.696	24	9	2025-11-15 17:00:33.696	2025-11-15 17:00:33.694
98	1108	1	230	Se pide desbloqueo para Moto g53	2025-11-15 17:19:39.473	24	9	2025-11-15 17:19:39.473	2025-11-15 17:19:39.471
99	1117	1	29	Se pide refacción	2025-11-15 19:32:13.623	24	8	2025-11-15 19:32:13.623	2025-11-15 19:32:13.622
100	1076	2	0.01	Venta de 2 goteros	2025-11-16 17:35:51.017	24	11	2025-11-16 17:35:51.017	2025-11-16 17:35:51.015
101	1064	2	0.01	Se ingresa para venta	2025-11-16 17:39:43.39	24	11	2025-11-16 17:39:43.39	2025-11-16 17:39:43.388
102	1087	1	0.01	Se ingresa para venta	2025-11-16 17:41:37.827	24	11	2025-11-16 17:41:37.827	2025-11-16 17:41:37.826
103	1122	1	0.01	Se ingresa para venta	2025-11-16 17:46:23.257	24	11	2025-11-16 17:46:23.257	2025-11-16 17:46:23.254
104	1086	6	0.01	Inventario actual	2025-11-17 18:35:56.355	24	11	2025-11-17 18:35:56.355	2025-11-17 18:35:56.353
105	1091	27	0.01	Inventario actual	2025-11-17 18:36:29.51	24	11	2025-11-17 18:36:29.51	2025-11-17 18:36:29.509
106	1076	15	0.01	Inventario Actual	2025-11-17 18:45:40.358	24	11	2025-11-17 18:45:40.358	2025-11-17 18:45:40.356
107	1063	12	0.01	Inventario Actual.	2025-11-17 18:46:07.448	24	11	2025-11-17 18:46:07.448	2025-11-17 18:46:07.447
108	1085	15	0.01	Inventario Actual	2025-11-17 18:46:40.49	24	11	2025-11-17 18:46:40.49	2025-11-17 18:46:40.488
109	1059	15	0.01	Inventario Actual	2025-11-17 18:47:04.167	24	11	2025-11-17 18:47:04.167	2025-11-17 18:47:04.166
110	1058	16	0.01	Inventario Actual	2025-11-17 18:48:22.591	24	11	2025-11-17 18:48:22.591	2025-11-17 18:48:22.589
111	1064	298	0.01	Inventario Actual	2025-11-17 18:49:38.114	24	11	2025-11-17 18:49:38.114	2025-11-17 18:49:38.113
112	1077	3	0.01	Inventario Actual	2025-11-17 18:50:37.378	24	11	2025-11-17 18:50:37.378	2025-11-17 18:50:37.376
113	1072	1	0.01	Inventario actual	2025-11-17 19:08:17.772	24	11	2025-11-17 19:08:17.772	2025-11-17 19:08:17.77
114	1124	11	0.01	Inventario actual	2025-11-17 19:12:50.247	24	11	2025-11-17 19:12:50.247	2025-11-17 19:12:50.246
115	1125	11	0.01	Inventario actual	2025-11-17 19:13:04.93	24	11	2025-11-17 19:13:04.93	2025-11-17 19:13:04.929
116	1126	8	0.01	Inventario actual	2025-11-17 19:13:17.428	24	11	2025-11-17 19:13:17.428	2025-11-17 19:13:17.427
117	1127	10	0.01	Inventario actual	2025-11-17 19:13:40.9	24	11	2025-11-17 19:13:40.9	2025-11-17 19:13:40.899
118	1128	12	0.01	Inventario actual	2025-11-17 19:13:59.65	24	11	2025-11-17 19:13:59.65	2025-11-17 19:13:59.648
119	1129	8	0.01	Inventario actual	2025-11-17 19:14:33.925	24	11	2025-11-17 19:14:33.925	2025-11-17 19:14:33.924
120	1131	8	0.01	Inventario actual	2025-11-17 19:14:41.378	24	11	2025-11-17 19:14:41.378	2025-11-17 19:14:41.376
121	1132	9	0.01	Inventario actual	2025-11-17 19:14:52.021	24	11	2025-11-17 19:14:52.021	2025-11-17 19:14:52.02
122	1133	1	0.01	Inventario actual	2025-11-17 19:15:24.918	24	11	2025-11-17 19:15:24.918	2025-11-17 19:15:24.917
123	1134	5	0.01	Inventario actual	2025-11-17 19:15:39.889	24	11	2025-11-17 19:15:39.889	2025-11-17 19:15:39.888
124	1135	6	0.01	Inventario actual	2025-11-17 19:15:55.032	24	11	2025-11-17 19:15:55.032	2025-11-17 19:15:55.031
125	1139	4	0.01	Inventario actual	2025-11-17 19:17:52.849	24	11	2025-11-17 19:17:52.849	2025-11-17 19:17:52.847
126	1140	8	0.01	Inventario actual	2025-11-17 19:18:11.7	24	11	2025-11-17 19:18:11.7	2025-11-17 19:18:11.698
127	1142	3	0.01	Inventario actual	2025-11-17 19:18:35.814	24	11	2025-11-17 19:18:35.814	2025-11-17 19:18:35.812
128	1143	5	0.01	Inventario actual	2025-11-17 19:19:08.785	24	11	2025-11-17 19:19:08.785	2025-11-17 19:19:08.784
129	1144	3	0.01	Inventario actual	2025-11-17 19:19:21.014	24	11	2025-11-17 19:19:21.014	2025-11-17 19:19:21.013
130	1145	15	0.01	Inventario actual	2025-11-17 19:19:45.435	24	11	2025-11-17 19:19:45.435	2025-11-17 19:19:45.433
131	1146	28	0.01	Inventario actual	2025-11-17 19:20:10.225	24	11	2025-11-17 19:20:10.225	2025-11-17 19:20:10.224
132	1148	4	0.01	Inventario actual	2025-11-17 19:20:35.103	24	11	2025-11-17 19:20:35.103	2025-11-17 19:20:35.102
133	1147	4	0.01	Inventario actual	2025-11-17 19:20:47.922	24	11	2025-11-17 19:20:47.922	2025-11-17 19:20:47.921
134	1149	1	0.01	Inventario actual	2025-11-17 19:21:04.13	24	11	2025-11-17 19:21:04.13	2025-11-17 19:21:04.129
135	1151	19	0.01	Inventario actual	2025-11-17 19:21:37.321	24	11	2025-11-17 19:21:37.321	2025-11-17 19:21:37.32
136	1122	9	0.01	Inventario actual	2025-11-17 19:22:03.416	24	11	2025-11-17 19:22:03.416	2025-11-17 19:22:03.415
137	427	1	170	Se compra refacción Motorola E7	2025-11-18 21:53:04.33	24	9	2025-11-18 21:53:04.33	2025-11-18 21:53:04.329
138	1117	1	30	Se pide display para reparación #TICK-1763497875867	2025-11-18 21:54:58.616	24	8	2025-11-18 21:54:58.616	2025-11-18 21:54:58.614
139	1078	10	0.01	Se ingresa Inventario.	2025-11-19 18:55:09.343	24	11	2025-11-19 18:55:09.343	2025-11-19 18:55:09.342
140	1079	8	0.01	Se ingresa a inventario.	2025-11-19 18:55:28.436	24	11	2025-11-19 18:55:28.436	2025-11-19 18:55:28.434
141	1082	10	0.01	Se ingresa inventario	2025-11-19 18:55:57.153	24	11	2025-11-19 18:55:57.153	2025-11-19 18:55:57.151
142	1084	10	0.01	Se ingresa inventario	2025-11-19 18:56:08.041	24	11	2025-11-19 18:56:08.041	2025-11-19 18:56:08.039
143	1067	8	0.01	Se ingresa inventario	2025-11-19 18:56:31.732	24	11	2025-11-19 18:56:31.732	2025-11-19 18:56:31.731
144	1066	2	0.01	Se ingresa inventario	2025-11-19 18:56:42.861	24	11	2025-11-19 18:56:42.861	2025-11-19 18:56:42.86
145	1108	1	250	Se solicita desbloqueó Motorola G85	2025-11-20 21:48:03.055	24	9	2025-11-20 21:48:03.055	2025-11-20 21:48:03.052
146	447	2	170	Se piden display para reparación	2025-11-22 20:07:42.777	24	9	2025-11-22 20:07:42.777	2025-11-22 20:07:42.775
147	1118	1	160	Se solicita refacción de iPhone 14 pro	2025-11-22 20:10:08.507	24	9	2025-11-22 20:10:08.507	2025-11-22 20:10:08.505
148	626	1	800	Se añade a inventario	2025-11-23 19:53:29.171	24	9	2025-11-23 19:53:29.171	2025-11-23 19:53:29.169
\.
COPY public.entregas (id, ticket_id, tipo, direccion, notas, created_at, updated_at) FROM stdin;
\.
COPY public.estatus_reparacion (id, nombre, descripcion, created_at, updated_at, activo, color, orden) FROM stdin;
28	Recibido	El dispositivo ha sido recibido y está pendiente de diagnóstico	2025-06-17 21:30:43.446	2025-06-17 21:30:43.446	t	\N	1
29	En Diagnóstico	El dispositivo está siendo analizado para determinar el problema	2025-06-17 21:30:43.447	2025-06-17 21:30:43.447	t	\N	2
30	Presupuesto Generado	Se ha generado el presupuesto para la reparación	2025-06-17 21:30:43.448	2025-06-17 21:30:43.448	t	\N	3
31	En Reparación	El dispositivo está siendo reparado	2025-06-17 21:30:43.448	2025-06-17 21:30:43.448	t	\N	4
32	Reparado	La reparación del dispositivo ha sido completada	2025-06-17 21:30:43.449	2025-06-17 21:30:43.449	t	\N	5
33	Entregado	El dispositivo ha sido entregado al cliente	2025-06-17 21:30:43.449	2025-06-17 21:30:43.449	t	\N	6
34	Cancelado	La reparación ha sido cancelada	2025-06-17 21:30:43.45	2025-06-17 21:30:43.45	t	\N	7
\.
COPY public.fotos_producto (id, producto_id, url, created_at, updated_at) FROM stdin;
\.
COPY public.marcas (id, nombre, descripcion, created_at, updated_at) FROM stdin;
37	Apple	\N	2025-06-17 21:30:43.453	2025-06-17 21:30:43.453
38	Samsung	\N	2025-06-17 21:30:43.453	2025-06-17 21:30:43.453
39	OnePlus	\N	2025-06-17 21:30:43.453	2025-06-17 21:30:43.453
40	Huawei	\N	2025-06-17 21:30:43.453	2025-06-17 21:30:43.453
42	LG	\N	2025-06-17 21:30:43.453	2025-06-17 21:30:43.453
43	Sony	\N	2025-06-17 21:30:43.453	2025-06-17 21:30:43.453
44	Xiaomi	\N	2025-06-17 21:30:43.453	2025-06-17 21:30:43.453
45	Google	\N	2025-06-17 21:30:43.453	2025-06-17 21:30:43.453
48	Alcatel	\N	2025-08-20 16:43:12.281	2025-08-20 16:43:12.279
49	Hisense	\N	2025-08-20 16:43:24.4	2025-08-20 16:43:24.399
51	Infinix	\N	2025-08-20 16:43:46.466	2025-08-20 16:43:46.466
52	Nokia	\N	2025-08-20 16:44:06.615	2025-08-20 16:44:06.614
53	TLC	\N	2025-08-20 16:44:26.422	2025-08-20 16:44:26.421
54	Vivo	\N	2025-08-20 16:44:32.59	2025-08-20 16:44:32.589
55	Wiko	\N	2025-08-20 16:45:53.647	2025-08-20 16:45:53.646
56	ZTE	\N	2025-08-20 16:46:13.134	2025-08-20 16:46:13.133
57	Honor	\N	2025-08-26 18:18:03.05	2025-08-26 18:18:03.049
59	YA!	\N	2025-09-03 19:49:24.092	2025-09-03 19:49:24.091
46	Oppo	\N	2025-08-08 16:24:18.597	2025-09-05 18:12:53.679
60	Varios	\N	2025-09-05 18:13:02.601	2025-09-05 18:13:02.601
47	Android	Todos los modelos de Android	2025-08-19 15:38:23.059	2025-09-05 18:13:55.04
61	DKT	\N	2025-09-09 22:46:07.637	2025-09-09 22:46:07.636
62	ZHANLIDA	\N	2025-09-09 22:46:26.526	2025-09-09 22:46:26.525
63	KAISI	\N	2025-09-09 22:46:39.617	2025-09-09 22:46:39.616
64	MECHANIC	\N	2025-09-09 22:46:51.105	2025-09-09 22:46:51.104
65	PR	\N	2025-09-09 22:47:39.995	2025-09-09 22:47:39.995
66	SUNSHINE 	\N	2025-09-09 22:59:18.198	2025-09-09 22:59:18.197
67	2UUL	\N	2025-09-09 23:11:11.938	2025-09-09 23:11:11.938
68	AT&T	\N	2025-09-20 18:01:10.954	2025-09-20 18:01:10.953
69	MOVISTAR	\N	2025-09-20 18:01:21.436	2025-09-20 18:01:21.435
70	TELCEL	\N	2025-09-20 18:01:32.35	2025-09-20 18:01:32.349
71	BAIT	\N	2025-09-20 18:01:43.809	2025-09-20 18:01:43.809
72	prueba	\N	2025-10-09 15:18:08.291	2025-10-09 15:18:08.29
41	Motorola	\N	2025-06-17 21:30:43.453	2025-10-12 19:51:30.196
73	JBL	\N	2025-10-22 18:01:55.433	2025-10-22 18:01:55.432
74	Tableta Android 	\N	2025-10-23 18:12:07.284	2025-10-23 18:12:07.283
\.
COPY public.modelos (id, nombre, marca_id, created_at, updated_at, descripcion) FROM stdin;
110	iPhone 15 Pro	37	2025-06-17 21:30:43.475	2025-06-17 21:30:43.475	\N
111	iPhone 15	37	2025-06-17 21:30:43.479	2025-06-17 21:30:43.479	\N
112	iPhone 14 Pro	37	2025-06-17 21:30:43.48	2025-06-17 21:30:43.48	\N
113	iPhone 14	37	2025-06-17 21:30:43.481	2025-06-17 21:30:43.481	\N
114	Galaxy S24 Ultra	38	2025-06-17 21:30:43.482	2025-06-17 21:30:43.482	\N
115	Galaxy S24+	38	2025-06-17 21:30:43.483	2025-06-17 21:30:43.483	\N
116	Galaxy S24	38	2025-06-17 21:30:43.484	2025-06-17 21:30:43.484	\N
117	Galaxy Z Fold 5	38	2025-06-17 21:30:43.485	2025-06-17 21:30:43.485	\N
118	Galaxy Z Flip 5	38	2025-06-17 21:30:43.487	2025-06-17 21:30:43.487	\N
119	Xiaomi 14 Ultra	44	2025-06-17 21:30:43.487	2025-06-17 21:30:43.487	\N
120	Xiaomi 14 Pro	44	2025-06-17 21:30:43.488	2025-06-17 21:30:43.488	\N
121	Xiaomi 14	44	2025-06-17 21:30:43.489	2025-06-17 21:30:43.489	\N
122	P60 Pro	40	2025-06-17 21:30:43.49	2025-06-17 21:30:43.49	\N
123	P60	40	2025-06-17 21:30:43.491	2025-06-17 21:30:43.491	\N
124	Mate 60 Pro	40	2025-06-17 21:30:43.492	2025-06-17 21:30:43.492	\N
125	Edge 40 Pro	41	2025-06-17 21:30:43.492	2025-06-17 21:30:43.492	\N
126	Edge 40	41	2025-06-17 21:30:43.493	2025-06-17 21:30:43.493	\N
127	G8	42	2025-06-17 21:30:43.494	2025-06-17 21:30:43.494	\N
128	V60	42	2025-06-17 21:30:43.495	2025-06-17 21:30:43.495	\N
129	Xperia 1 V	43	2025-06-17 21:30:43.496	2025-06-17 21:30:43.496	\N
130	Xperia 5 V	43	2025-06-17 21:30:43.497	2025-06-17 21:30:43.497	\N
131	OnePlus 12	39	2025-06-17 21:30:43.497	2025-06-17 21:30:43.497	\N
132	OnePlus Open	39	2025-06-17 21:30:43.498	2025-06-17 21:30:43.498	\N
133	Pixel 8 Pro	45	2025-06-17 21:30:43.499	2025-06-17 21:30:43.499	\N
134	Pixel 8	45	2025-06-17 21:30:43.5	2025-06-17 21:30:43.5	\N
135	iPhone 16	37	2025-06-17 21:31:43.224	2025-06-17 21:31:43.224	\N
136	iPhone 16 Pro	37	2025-06-17 21:31:48.281	2025-06-17 21:31:48.281	\N
137	iPhone 16 Ultra	37	2025-06-17 21:31:54.785	2025-06-17 21:31:54.785	\N
138	iPhone 16 Pro Max	37	2025-06-17 21:32:01.797	2025-06-17 21:32:01.797	\N
139	iPhone 12	37	2025-06-18 16:10:29.67	2025-06-18 16:10:29.67	\N
140	a15	46	2025-08-08 16:24:33.291	2025-08-08 16:24:33.29	\N
141	VARIOS	47	2025-08-19 15:39:14.134	2025-08-19 15:39:14.133	Android todos 
142	F23	49	2025-08-20 16:47:23.889	2025-08-20 16:47:23.888	\N
143	E50 Lite	49	2025-08-20 16:47:34.271	2025-08-20 16:47:34.27	\N
144	H40 Lite	49	2025-08-20 16:47:46.257	2025-08-20 16:47:46.256	\N
145	E40	49	2025-08-20 16:47:53.722	2025-08-20 16:47:53.721	\N
146	V40	49	2025-08-20 16:47:58.938	2025-08-20 16:47:58.938	\N
213	HOT10 PLAY	51	2025-08-26 17:36:44.087	2025-08-26 17:36:44.085	\N
214	HOT30	51	2025-08-26 17:36:44.106	2025-08-26 17:36:44.105	\N
215	HOT 30i	51	2025-08-26 17:36:44.111	2025-08-26 17:36:44.11	\N
216	Note 30	51	2025-08-26 17:36:44.118	2025-08-26 17:36:44.117	\N
217	Note 30 4G	51	2025-08-26 17:36:44.123	2025-08-26 17:36:44.122	\N
218	Note 30 PRO	51	2025-08-26 17:36:44.132	2025-08-26 17:36:44.131	\N
219	SMART 7	51	2025-08-26 17:36:44.137	2025-08-26 17:36:44.136	\N
220	X6515	51	2025-08-26 17:36:44.144	2025-08-26 17:36:44.144	\N
221	X669	51	2025-08-26 17:36:44.162	2025-08-26 17:36:44.161	\N
222	X678B	51	2025-08-26 17:36:44.167	2025-08-26 17:36:44.166	\N
223	X6831	51	2025-08-26 17:36:44.173	2025-08-26 17:36:44.172	\N
224	X6833	51	2025-08-26 17:36:44.179	2025-08-26 17:36:44.179	\N
225	X688	51	2025-08-26 17:36:44.187	2025-08-26 17:36:44.185	\N
226	ANE LX3	40	2025-08-26 17:40:50.169	2025-08-26 17:40:50.166	\N
227	MATE 10	40	2025-08-26 17:40:50.177	2025-08-26 17:40:50.176	\N
228	MATE 20 LITE	40	2025-08-26 17:40:50.182	2025-08-26 17:40:50.181	\N
229	MATE 20 PRO	40	2025-08-26 17:40:50.185	2025-08-26 17:40:50.184	\N
230	MATE 40 E PRO	40	2025-08-26 17:40:50.192	2025-08-26 17:40:50.191	\N
231	MATE 40 PRO	40	2025-08-26 17:40:50.198	2025-08-26 17:40:50.197	\N
232	MATE 40 PRO +	40	2025-08-26 17:40:50.206	2025-08-26 17:40:50.203	\N
233	MATE 9	40	2025-08-26 17:40:50.214	2025-08-26 17:40:50.211	\N
234	MATE 10 LITE	40	2025-08-26 17:40:50.222	2025-08-26 17:40:50.221	\N
235	MATE 10 PRO	40	2025-08-26 17:40:50.231	2025-08-26 17:40:50.229	\N
236	MATE 20	40	2025-08-26 17:40:50.236	2025-08-26 17:40:50.236	\N
237	MatePad C3	40	2025-08-26 17:40:50.243	2025-08-26 17:40:50.242	\N
238	MatePad C5e	40	2025-08-26 17:40:50.25	2025-08-26 17:40:50.25	\N
239	MatePad Pro	40	2025-08-26 17:40:50.254	2025-08-26 17:40:50.253	\N
240	MatePad Pro 5G	40	2025-08-26 17:40:50.263	2025-08-26 17:40:50.262	\N
241	MatePad SE	40	2025-08-26 17:40:50.27	2025-08-26 17:40:50.269	\N
242	MediaPad M5	40	2025-08-26 17:40:50.274	2025-08-26 17:40:50.273	\N
243	MediaPad M5 lite	40	2025-08-26 17:40:50.281	2025-08-26 17:40:50.28	\N
244	MediaPad M5 Pro	40	2025-08-26 17:40:50.287	2025-08-26 17:40:50.286	\N
245	MediaPad M6	40	2025-08-26 17:40:50.292	2025-08-26 17:40:50.292	\N
246	MediaPad T5	40	2025-08-26 17:40:50.3	2025-08-26 17:40:50.299	\N
247	NOVA 10	40	2025-08-26 17:40:50.305	2025-08-26 17:40:50.304	\N
248	NOVA 10 SE	40	2025-08-26 17:40:50.311	2025-08-26 17:40:50.31	\N
249	NOVA 11 i	40	2025-08-26 17:40:50.315	2025-08-26 17:40:50.315	\N
250	NOVA 11 SE	40	2025-08-26 17:40:50.323	2025-08-26 17:40:50.322	\N
251	NOVA 12 SE	40	2025-08-26 17:40:50.332	2025-08-26 17:40:50.331	\N
252	NOVA 2 Lite	40	2025-08-26 17:40:50.338	2025-08-26 17:40:50.337	\N
253	NOVA 2 Plus	40	2025-08-26 17:40:50.343	2025-08-26 17:40:50.342	\N
254	NOVA 3	40	2025-08-26 17:40:50.349	2025-08-26 17:40:50.349	\N
255	NOVA 3e	40	2025-08-26 17:40:50.354	2025-08-26 17:40:50.354	\N
256	NOVA 3i	40	2025-08-26 17:40:50.36	2025-08-26 17:40:50.36	\N
257	NOVA 4E	40	2025-08-26 17:40:50.366	2025-08-26 17:40:50.365	\N
258	NOVA 5i	40	2025-08-26 17:40:50.375	2025-08-26 17:40:50.375	\N
259	NOVA 5T	40	2025-08-26 17:40:50.383	2025-08-26 17:40:50.381	\N
260	NOVA 6 SE	40	2025-08-26 17:40:50.388	2025-08-26 17:40:50.388	\N
261	NOVA 8	40	2025-08-26 17:40:50.393	2025-08-26 17:40:50.392	\N
262	NOVA 8i	40	2025-08-26 17:40:50.401	2025-08-26 17:40:50.4	\N
263	NOVA 9	40	2025-08-26 17:40:50.409	2025-08-26 17:40:50.408	\N
264	NOVA 9 SE	40	2025-08-26 17:40:50.416	2025-08-26 17:40:50.415	\N
265	NOVA Y60	40	2025-08-26 17:40:50.422	2025-08-26 17:40:50.421	\N
266	NOVA Y70	40	2025-08-26 17:40:50.426	2025-08-26 17:40:50.425	\N
267	NOVA Y71	40	2025-08-26 17:40:50.431	2025-08-26 17:40:50.43	\N
268	NOVA Y70 PLUS	40	2025-08-26 17:40:50.437	2025-08-26 17:40:50.437	\N
269	NOVA Y90	40	2025-08-26 17:40:50.442	2025-08-26 17:40:50.442	\N
270	NOVA10 SE	40	2025-08-26 17:40:50.447	2025-08-26 17:40:50.446	\N
271	P SMART +	40	2025-08-26 17:40:50.453	2025-08-26 17:40:50.452	\N
272	P SMART 2018	40	2025-08-26 17:40:50.457	2025-08-26 17:40:50.456	\N
273	P SMART 2019	40	2025-08-26 17:40:50.465	2025-08-26 17:40:50.463	\N
274	P SMART 2020	40	2025-08-26 17:40:50.474	2025-08-26 17:40:50.472	\N
275	P SMART 2021	40	2025-08-26 17:40:50.481	2025-08-26 17:40:50.481	\N
276	P SMART PRO	40	2025-08-26 17:40:50.488	2025-08-26 17:40:50.487	\N
277	P SMART S	40	2025-08-26 17:40:50.493	2025-08-26 17:40:50.492	\N
212	P20	40	2025-08-20 17:01:07.841	2025-08-20 17:01:07.84	\N
278	P SMART Z	40	2025-08-26 17:40:50.503	2025-08-26 17:40:50.502	\N
279	P10	40	2025-08-26 17:40:50.509	2025-08-26 17:40:50.509	\N
280	P10 Plus	40	2025-08-26 17:40:50.514	2025-08-26 17:40:50.514	\N
281	P20 LITE	40	2025-08-26 17:40:50.523	2025-08-26 17:40:50.522	\N
282	P20 PRO	40	2025-08-26 17:40:50.527	2025-08-26 17:40:50.526	\N
283	P30	40	2025-08-26 17:40:50.535	2025-08-26 17:40:50.534	\N
284	P30 LITE	40	2025-08-26 17:40:50.543	2025-08-26 17:40:50.543	\N
285	P30 PRO	40	2025-08-26 17:40:50.55	2025-08-26 17:40:50.549	\N
286	P40 Lite	40	2025-08-26 17:40:50.555	2025-08-26 17:40:50.554	\N
287	P40 LITE 4G	40	2025-08-26 17:40:50.559	2025-08-26 17:40:50.559	\N
288	P40 LITE E	40	2025-08-26 17:40:50.565	2025-08-26 17:40:50.565	\N
289	P40 PRO	40	2025-08-26 17:40:50.572	2025-08-26 17:40:50.571	\N
290	P50 E	40	2025-08-26 17:40:50.576	2025-08-26 17:40:50.575	\N
291	P50 LITE	40	2025-08-26 17:40:50.581	2025-08-26 17:40:50.58	\N
292	P50 PRO	40	2025-08-26 17:40:50.585	2025-08-26 17:40:50.585	\N
293	P9 Lite 2017	40	2025-08-26 17:40:50.59	2025-08-26 17:40:50.589	\N
294	Watch D	40	2025-08-26 17:40:50.595	2025-08-26 17:40:50.594	\N
295	Watch GT 2	40	2025-08-26 17:40:50.599	2025-08-26 17:40:50.598	\N
296	Watch GT 2 Pro	40	2025-08-26 17:40:50.603	2025-08-26 17:40:50.602	\N
297	Watch GT 2e	40	2025-08-26 17:40:50.607	2025-08-26 17:40:50.607	\N
298	Watch GT 3	40	2025-08-26 17:40:50.614	2025-08-26 17:40:50.613	\N
299	Watch GT Runner	40	2025-08-26 17:40:50.619	2025-08-26 17:40:50.618	\N
300	Y5 2018	40	2025-08-26 17:40:50.624	2025-08-26 17:40:50.623	\N
301	Y5 2019	40	2025-08-26 17:40:50.63	2025-08-26 17:40:50.63	\N
302	Y6 2018	40	2025-08-26 17:40:50.634	2025-08-26 17:40:50.633	\N
303	Y6 2019	40	2025-08-26 17:40:50.638	2025-08-26 17:40:50.637	\N
304	Y6P	40	2025-08-26 17:40:50.641	2025-08-26 17:40:50.641	\N
305	Y6S	40	2025-08-26 17:40:50.647	2025-08-26 17:40:50.646	\N
306	Y7 2018	40	2025-08-26 17:40:50.65	2025-08-26 17:40:50.65	\N
307	Y7 2019	40	2025-08-26 17:40:50.657	2025-08-26 17:40:50.657	\N
308	Y7 Prime	40	2025-08-26 17:40:50.661	2025-08-26 17:40:50.66	\N
309	Y7 Prime 2018	40	2025-08-26 17:40:50.666	2025-08-26 17:40:50.665	\N
310	Y7A	40	2025-08-26 17:40:50.67	2025-08-26 17:40:50.669	\N
311	Y7P	40	2025-08-26 17:40:50.677	2025-08-26 17:40:50.676	\N
312	Y7S	40	2025-08-26 17:40:50.683	2025-08-26 17:40:50.682	\N
313	Y8P	40	2025-08-26 17:40:50.694	2025-08-26 17:40:50.693	\N
314	Y8S	40	2025-08-26 17:40:50.7	2025-08-26 17:40:50.699	\N
315	Y9 2018	40	2025-08-26 17:40:50.704	2025-08-26 17:40:50.703	\N
316	Y9 2019	40	2025-08-26 17:40:50.709	2025-08-26 17:40:50.708	\N
317	Y9 PRIME	40	2025-08-26 17:40:50.714	2025-08-26 17:40:50.713	\N
318	Y9 prime 2019	40	2025-08-26 17:40:50.719	2025-08-26 17:40:50.718	\N
319	Y9A	40	2025-08-26 17:40:50.725	2025-08-26 17:40:50.724	\N
320	Y9P	40	2025-08-26 17:40:50.733	2025-08-26 17:40:50.732	\N
321	Y9S	40	2025-08-26 17:40:50.74	2025-08-26 17:40:50.737	\N
322	10	57	2025-08-26 18:18:10.814	2025-08-26 18:18:10.813	\N
323	70	57	2025-08-26 18:18:10.825	2025-08-26 18:18:10.823	\N
324	90	57	2025-08-26 18:18:10.838	2025-08-26 18:18:10.835	\N
325	10 LITE	57	2025-08-26 18:18:10.847	2025-08-26 18:18:10.845	\N
326	50 LITE	57	2025-08-26 18:18:10.852	2025-08-26 18:18:10.851	\N
327	8X	57	2025-08-26 18:18:10.859	2025-08-26 18:18:10.858	\N
328	90 LITE	57	2025-08-26 18:18:10.868	2025-08-26 18:18:10.867	\N
329	Magic 6	57	2025-08-26 18:18:10.877	2025-08-26 18:18:10.876	\N
330	MAGIC5 LITE	57	2025-08-26 18:18:10.884	2025-08-26 18:18:10.881	\N
331	NOVA 8i	57	2025-08-26 18:18:10.892	2025-08-26 18:18:10.891	\N
332	X5	57	2025-08-26 18:18:10.897	2025-08-26 18:18:10.896	\N
333	X5 PLUS	57	2025-08-26 18:18:10.908	2025-08-26 18:18:10.908	\N
334	X50 PRO	57	2025-08-26 18:18:10.913	2025-08-26 18:18:10.912	\N
335	X50i	57	2025-08-26 18:18:10.919	2025-08-26 18:18:10.918	\N
336	X6	57	2025-08-26 18:18:10.925	2025-08-26 18:18:10.924	\N
337	X6A	57	2025-08-26 18:18:10.933	2025-08-26 18:18:10.932	\N
338	X7	57	2025-08-26 18:18:10.943	2025-08-26 18:18:10.942	\N
339	X7A	57	2025-08-26 18:18:10.949	2025-08-26 18:18:10.948	\N
340	X7B	57	2025-08-26 18:18:10.954	2025-08-26 18:18:10.953	\N
341	X8	57	2025-08-26 18:18:10.958	2025-08-26 18:18:10.957	\N
342	X8A	57	2025-08-26 18:18:10.962	2025-08-26 18:18:10.961	\N
343	X8A 4G	57	2025-08-26 18:18:10.967	2025-08-26 18:18:10.966	\N
344	X8A 5G	57	2025-08-26 18:18:10.974	2025-08-26 18:18:10.972	\N
345	X8B	57	2025-08-26 18:18:10.979	2025-08-26 18:18:10.979	\N
346	X9	57	2025-08-26 18:18:10.984	2025-08-26 18:18:10.983	\N
347	X9A	57	2025-08-26 18:18:10.987	2025-08-26 18:18:10.986	\N
348	X9B	57	2025-08-26 18:18:10.991	2025-08-26 18:18:10.99	\N
349	E30	49	2025-08-26 18:21:13.756	2025-08-26 18:21:13.753	\N
350	E50	49	2025-08-26 18:21:13.775	2025-08-26 18:21:13.773	\N
351	E50i	49	2025-08-26 18:21:13.784	2025-08-26 18:21:13.783	\N
352	E50S	49	2025-08-26 18:21:13.794	2025-08-26 18:21:13.792	\N
353	E60	49	2025-08-26 18:21:13.805	2025-08-26 18:21:13.804	\N
354	E60 LITE	49	2025-08-26 18:21:13.822	2025-08-26 18:21:13.819	\N
355	F20	49	2025-08-26 18:21:13.831	2025-08-26 18:21:13.83	\N
356	H30 LITE	49	2025-08-26 18:21:13.847	2025-08-26 18:21:13.845	\N
357	H40	49	2025-08-26 18:21:13.863	2025-08-26 18:21:13.861	\N
358	H50	49	2025-08-26 18:21:13.871	2025-08-26 18:21:13.87	\N
359	H50 LITE	49	2025-08-26 18:21:13.88	2025-08-26 18:21:13.879	\N
360	H60 LITE	49	2025-08-26 18:21:13.886	2025-08-26 18:21:13.886	\N
361	U50 4G	49	2025-08-26 18:21:13.895	2025-08-26 18:21:13.894	\N
362	V40S	49	2025-08-26 18:21:13.903	2025-08-26 18:21:13.902	\N
363	V50	49	2025-08-26 18:21:13.908	2025-08-26 18:21:13.908	\N
364	V60	49	2025-08-26 18:21:13.915	2025-08-26 18:21:13.915	\N
365	K22	42	2025-08-26 18:24:38.345	2025-08-26 18:24:38.344	\N
366	K42	42	2025-08-26 18:24:38.352	2025-08-26 18:24:38.352	\N
367	K50	42	2025-08-26 18:24:38.358	2025-08-26 18:24:38.357	\N
368	K51	42	2025-08-26 18:24:38.372	2025-08-26 18:24:38.366	\N
369	K52	42	2025-08-26 18:24:38.379	2025-08-26 18:24:38.378	\N
370	K62	42	2025-08-26 18:24:38.386	2025-08-26 18:24:38.386	\N
371	K41S	42	2025-08-26 18:24:38.396	2025-08-26 18:24:38.394	\N
372	K51S	42	2025-08-26 18:24:38.405	2025-08-26 18:24:38.404	\N
373	1+N10	39	2025-08-26 18:26:42.285	2025-08-26 18:26:42.284	\N
374	G10	52	2025-08-26 18:27:03.124	2025-08-26 18:27:03.123	\N
375	G20	52	2025-08-26 18:27:07.105	2025-08-26 18:27:07.104	\N
376	E13	41	2025-08-26 18:32:52.059	2025-08-26 18:32:52.057	\N
377	E14	41	2025-08-26 18:32:52.069	2025-08-26 18:32:52.068	\N
378	E20	41	2025-08-26 18:32:52.083	2025-08-26 18:32:52.078	\N
379	E22	41	2025-08-26 18:32:52.092	2025-08-26 18:32:52.09	\N
380	E22i	41	2025-08-26 18:32:52.104	2025-08-26 18:32:52.103	\N
381	E22S	41	2025-08-26 18:32:52.114	2025-08-26 18:32:52.113	\N
382	E30	41	2025-08-26 18:32:52.121	2025-08-26 18:32:52.119	\N
383	E32	41	2025-08-26 18:32:52.129	2025-08-26 18:32:52.128	\N
384	E32S	41	2025-08-26 18:32:52.136	2025-08-26 18:32:52.135	\N
385	E40	41	2025-08-26 18:32:52.149	2025-08-26 18:32:52.144	\N
386	E5 PLAY GO	41	2025-08-26 18:32:52.158	2025-08-26 18:32:52.157	\N
387	E5 PLUS	41	2025-08-26 18:32:52.174	2025-08-26 18:32:52.174	\N
388	E6 PLAY	41	2025-08-26 18:32:52.179	2025-08-26 18:32:52.178	\N
389	E6I	41	2025-08-26 18:32:52.183	2025-08-26 18:32:52.182	\N
390	E6PLAY	41	2025-08-26 18:32:52.188	2025-08-26 18:32:52.187	\N
391	E6PLUS	41	2025-08-26 18:32:52.193	2025-08-26 18:32:52.192	\N
392	E6S	41	2025-08-26 18:32:52.198	2025-08-26 18:32:52.197	\N
393	E7	41	2025-08-26 18:32:52.205	2025-08-26 18:32:52.203	\N
394	E7 PLUS	41	2025-08-26 18:32:52.221	2025-08-26 18:32:52.22	\N
395	E7 POWER	41	2025-08-26 18:32:52.233	2025-08-26 18:32:52.228	\N
396	E7i	41	2025-08-26 18:32:52.24	2025-08-26 18:32:52.239	\N
397	E7i POWER	41	2025-08-26 18:32:52.245	2025-08-26 18:32:52.244	\N
398	E7PLUS	41	2025-08-26 18:32:52.255	2025-08-26 18:32:52.252	\N
399	EDGE	41	2025-08-26 18:32:52.261	2025-08-26 18:32:52.26	\N
400	EDGE 20	41	2025-08-26 18:32:52.269	2025-08-26 18:32:52.268	\N
401	EDGE 20 LITE	41	2025-08-26 18:32:52.276	2025-08-26 18:32:52.275	\N
402	EDGE 20 PRO	41	2025-08-26 18:32:52.288	2025-08-26 18:32:52.287	\N
403	EDGE 2021	41	2025-08-26 18:32:52.3	2025-08-26 18:32:52.299	\N
404	EDGE 2023	41	2025-08-26 18:32:52.312	2025-08-26 18:32:52.311	\N
405	EDGE 30	41	2025-08-26 18:32:52.318	2025-08-26 18:32:52.316	\N
406	EDGE 30 NEO	41	2025-08-26 18:32:52.326	2025-08-26 18:32:52.325	\N
407	EDGE 30 PRO	41	2025-08-26 18:32:52.335	2025-08-26 18:32:52.334	\N
408	EDGE 40 NEO	41	2025-08-26 18:32:52.345	2025-08-26 18:32:52.344	\N
409	EDGE 50 FUSION	41	2025-08-26 18:32:52.355	2025-08-26 18:32:52.354	\N
410	EDGE 50 PRO	41	2025-08-26 18:32:52.363	2025-08-26 18:32:52.362	\N
411	EDGE S	41	2025-08-26 18:32:52.373	2025-08-26 18:32:52.372	\N
412	G PLAY 2021 4G	41	2025-08-26 18:32:52.383	2025-08-26 18:32:52.381	\N
413	G POWER 2021	41	2025-08-26 18:32:52.39	2025-08-26 18:32:52.389	\N
414	G POWER 2022 4G	41	2025-08-26 18:32:52.397	2025-08-26 18:32:52.396	\N
415	G PURE 4G	41	2025-08-26 18:32:52.405	2025-08-26 18:32:52.404	\N
416	G STYLUS 2021 5G	41	2025-08-26 18:32:52.412	2025-08-26 18:32:52.411	\N
417	G STYLUS 2022	41	2025-08-26 18:32:52.416	2025-08-26 18:32:52.415	\N
418	G STYLUS 2022 4G/5G	41	2025-08-26 18:32:52.423	2025-08-26 18:32:52.423	\N
419	G STYLUS 5G 2023 ORIG S/M	41	2025-08-26 18:32:52.428	2025-08-26 18:32:52.427	\N
420	G04	41	2025-08-26 18:32:52.434	2025-08-26 18:32:52.433	\N
421	G04S	41	2025-08-26 18:32:52.444	2025-08-26 18:32:52.443	\N
422	G10	41	2025-08-26 18:32:52.449	2025-08-26 18:32:52.448	\N
423	G10 PLAY	41	2025-08-26 18:32:52.453	2025-08-26 18:32:52.452	\N
424	G100	41	2025-08-26 18:32:52.458	2025-08-26 18:32:52.458	\N
425	G13	41	2025-08-26 18:32:52.463	2025-08-26 18:32:52.463	\N
426	G14	41	2025-08-26 18:32:52.47	2025-08-26 18:32:52.47	\N
427	G20	41	2025-08-26 18:32:52.476	2025-08-26 18:32:52.475	\N
428	G200 5G	41	2025-08-26 18:32:52.483	2025-08-26 18:32:52.483	\N
429	G22	41	2025-08-26 18:32:52.488	2025-08-26 18:32:52.487	\N
430	G23	41	2025-08-26 18:32:52.493	2025-08-26 18:32:52.492	\N
431	G24	41	2025-08-26 18:32:52.499	2025-08-26 18:32:52.498	\N
432	G24 POWER	41	2025-08-26 18:32:52.504	2025-08-26 18:32:52.504	\N
433	G30	41	2025-08-26 18:32:52.509	2025-08-26 18:32:52.508	\N
434	G31	41	2025-08-26 18:32:52.516	2025-08-26 18:32:52.515	\N
435	G32	41	2025-08-26 18:32:52.526	2025-08-26 18:32:52.525	\N
436	G34	41	2025-08-26 18:32:52.533	2025-08-26 18:32:52.532	\N
437	G40 FUSION	41	2025-08-26 18:32:52.537	2025-08-26 18:32:52.537	\N
438	G41	41	2025-08-26 18:32:52.544	2025-08-26 18:32:52.543	\N
439	G42	41	2025-08-26 18:32:52.551	2025-08-26 18:32:52.55	\N
440	G50	41	2025-08-26 18:32:52.555	2025-08-26 18:32:52.554	\N
441	G50 4G	41	2025-08-26 18:32:52.561	2025-08-26 18:32:52.56	\N
442	G50 5G	41	2025-08-26 18:32:52.567	2025-08-26 18:32:52.566	\N
443	G51 5G	41	2025-08-26 18:32:52.573	2025-08-26 18:32:52.573	\N
444	G52	41	2025-08-26 18:32:52.578	2025-08-26 18:32:52.577	\N
445	G53	41	2025-08-26 18:32:52.585	2025-08-26 18:32:52.584	\N
446	G54	41	2025-08-26 18:32:52.598	2025-08-26 18:32:52.597	\N
447	G55	41	2025-08-26 18:32:52.605	2025-08-26 18:32:52.604	\N
448	G5G	41	2025-08-26 18:32:52.612	2025-08-26 18:32:52.61	\N
449	G5G 2022 4G	41	2025-08-26 18:32:52.615	2025-08-26 18:32:52.615	\N
450	G5G 2023	41	2025-08-26 18:32:52.621	2025-08-26 18:32:52.62	\N
451	G6	41	2025-08-26 18:32:52.626	2025-08-26 18:32:52.625	\N
452	G6 PLAY/E5	41	2025-08-26 18:32:52.633	2025-08-26 18:32:52.631	\N
453	G6 PLUS	41	2025-08-26 18:32:52.639	2025-08-26 18:32:52.639	\N
454	G60	41	2025-08-26 18:32:52.645	2025-08-26 18:32:52.644	\N
455	G60S	41	2025-08-26 18:32:52.65	2025-08-26 18:32:52.649	\N
456	G62	41	2025-08-26 18:32:52.656	2025-08-26 18:32:52.655	\N
457	G64	41	2025-08-26 18:32:52.662	2025-08-26 18:32:52.661	\N
458	G6PLAY/E5	41	2025-08-26 18:32:52.667	2025-08-26 18:32:52.666	\N
459	G6PLUS	41	2025-08-26 18:32:52.672	2025-08-26 18:32:52.671	\N
460	G7	41	2025-08-26 18:32:52.679	2025-08-26 18:32:52.678	\N
461	G7 PLAY	41	2025-08-26 18:32:52.685	2025-08-26 18:32:52.684	\N
462	G7 PLUS	41	2025-08-26 18:32:52.689	2025-08-26 18:32:52.688	\N
463	G7 POWER	41	2025-08-26 18:32:52.693	2025-08-26 18:32:52.692	\N
464	G71	41	2025-08-26 18:32:52.697	2025-08-26 18:32:52.696	\N
465	G71S	41	2025-08-26 18:32:52.701	2025-08-26 18:32:52.7	\N
466	G72	41	2025-08-26 18:32:52.706	2025-08-26 18:32:52.705	\N
467	G73	41	2025-08-26 18:32:52.716	2025-08-26 18:32:52.712	\N
468	G73 5G	41	2025-08-26 18:32:52.724	2025-08-26 18:32:52.723	\N
469	G7PLAY	41	2025-08-26 18:32:52.728	2025-08-26 18:32:52.727	\N
470	G7POWER	41	2025-08-26 18:32:52.732	2025-08-26 18:32:52.732	\N
471	G8	41	2025-08-26 18:32:52.736	2025-08-26 18:32:52.735	\N
472	G8 PLAY	41	2025-08-26 18:32:52.741	2025-08-26 18:32:52.74	\N
473	G8 PLAY/ONE MACRO	41	2025-08-26 18:32:52.744	2025-08-26 18:32:52.744	\N
474	G8 PLUS	41	2025-08-26 18:32:52.749	2025-08-26 18:32:52.748	\N
475	G8 POWER	41	2025-08-26 18:32:52.753	2025-08-26 18:32:52.752	\N
476	G82	41	2025-08-26 18:32:52.76	2025-08-26 18:32:52.759	\N
477	G84	41	2025-08-26 18:32:52.768	2025-08-26 18:32:52.767	\N
478	G85	41	2025-08-26 18:32:52.773	2025-08-26 18:32:52.772	\N
479	G8PLAY	41	2025-08-26 18:32:52.777	2025-08-26 18:32:52.776	\N
480	G8PLUS	41	2025-08-26 18:32:52.782	2025-08-26 18:32:52.781	\N
481	G8POWER	41	2025-08-26 18:32:52.786	2025-08-26 18:32:52.786	\N
482	G8POWER LITE	41	2025-08-26 18:32:52.794	2025-08-26 18:32:52.793	\N
483	G9	41	2025-08-26 18:32:52.804	2025-08-26 18:32:52.803	\N
484	G9 PLAY	41	2025-08-26 18:32:52.809	2025-08-26 18:32:52.808	\N
485	G9 PLUS	41	2025-08-26 18:32:52.817	2025-08-26 18:32:52.816	\N
486	G9 POWER	41	2025-08-26 18:32:52.821	2025-08-26 18:32:52.82	\N
487	LITE	41	2025-08-26 18:32:52.828	2025-08-26 18:32:52.827	\N
488	ONE	41	2025-08-26 18:32:52.833	2025-08-26 18:32:52.833	\N
489	ONE 5G ACE	41	2025-08-26 18:32:52.839	2025-08-26 18:32:52.838	\N
490	ONE ATION	41	2025-08-26 18:32:52.845	2025-08-26 18:32:52.844	\N
491	ONE FUSION	41	2025-08-26 18:32:52.85	2025-08-26 18:32:52.849	\N
492	ONE FUSION PLUS	41	2025-08-26 18:32:52.854	2025-08-26 18:32:52.853	\N
493	ONE HYPER	41	2025-08-26 18:32:52.86	2025-08-26 18:32:52.859	\N
494	ONE MACRO	41	2025-08-26 18:32:52.866	2025-08-26 18:32:52.863	\N
495	ONE VISION	41	2025-08-26 18:32:52.872	2025-08-26 18:32:52.871	\N
496	ONE ZOOM	41	2025-08-26 18:32:52.878	2025-08-26 18:32:52.876	\N
497	S50 NEO	41	2025-08-26 18:32:52.885	2025-08-26 18:32:52.885	\N
498	X4	41	2025-08-26 18:32:52.891	2025-08-26 18:32:52.89	\N
499	XT2010	41	2025-08-26 18:32:52.896	2025-08-26 18:32:52.895	\N
500	XT2027	41	2025-08-26 18:32:52.903	2025-08-26 18:32:52.902	\N
501	XT2131	41	2025-08-26 18:32:52.913	2025-08-26 18:32:52.912	\N
502	XT2155	41	2025-08-26 18:32:52.92	2025-08-26 18:32:52.919	\N
503	XT2231-2	41	2025-08-26 18:32:52.929	2025-08-26 18:32:52.928	\N
504	XT2335-3	41	2025-08-26 18:32:52.934	2025-08-26 18:32:52.933	\N
505	Z PLAY	41	2025-08-26 18:32:52.941	2025-08-26 18:32:52.94	\N
506	Z2 PLAY	41	2025-08-26 18:32:52.946	2025-08-26 18:32:52.945	\N
507	Z3 PLAY	41	2025-08-26 18:32:52.958	2025-08-26 18:32:52.957	\N
508	1+N100	46	2025-08-26 18:36:21.704	2025-08-26 18:36:21.703	\N
509	1+NORD CE2	46	2025-08-26 18:36:21.713	2025-08-26 18:36:21.712	\N
510	11X	46	2025-08-26 18:36:21.72	2025-08-26 18:36:21.718	\N
511	8I	46	2025-08-26 18:36:21.729	2025-08-26 18:36:21.727	\N
512	9i	46	2025-08-26 18:36:21.737	2025-08-26 18:36:21.736	\N
513	A1 5G	46	2025-08-26 18:36:21.744	2025-08-26 18:36:21.743	\N
514	A1 PRO	46	2025-08-26 18:36:21.75	2025-08-26 18:36:21.749	\N
515	A11	46	2025-08-26 18:36:21.76	2025-08-26 18:36:21.758	\N
516	A11K	46	2025-08-26 18:36:21.773	2025-08-26 18:36:21.77	\N
517	A11S	46	2025-08-26 18:36:21.78	2025-08-26 18:36:21.777	\N
518	A11X	46	2025-08-26 18:36:21.785	2025-08-26 18:36:21.783	\N
519	A12	46	2025-08-26 18:36:21.792	2025-08-26 18:36:21.792	\N
520	A12s	46	2025-08-26 18:36:21.802	2025-08-26 18:36:21.801	\N
521	A15S	46	2025-08-26 18:36:21.816	2025-08-26 18:36:21.815	\N
522	A16	46	2025-08-26 18:36:21.825	2025-08-26 18:36:21.825	\N
523	A16E	46	2025-08-26 18:36:21.834	2025-08-26 18:36:21.833	\N
524	A16K	46	2025-08-26 18:36:21.844	2025-08-26 18:36:21.843	\N
525	A16S	46	2025-08-26 18:36:21.852	2025-08-26 18:36:21.851	\N
526	A17	46	2025-08-26 18:36:21.86	2025-08-26 18:36:21.859	\N
527	A17K	46	2025-08-26 18:36:21.867	2025-08-26 18:36:21.866	\N
528	A2 5G	46	2025-08-26 18:36:21.874	2025-08-26 18:36:21.873	\N
529	A31	46	2025-08-26 18:36:21.879	2025-08-26 18:36:21.878	\N
530	A31 2020	46	2025-08-26 18:36:21.884	2025-08-26 18:36:21.883	\N
531	A32	46	2025-08-26 18:36:21.892	2025-08-26 18:36:21.891	\N
532	A33	46	2025-08-26 18:36:21.901	2025-08-26 18:36:21.9	\N
533	A35	46	2025-08-26 18:36:21.911	2025-08-26 18:36:21.91	\N
534	A38	46	2025-08-26 18:36:21.916	2025-08-26 18:36:21.916	\N
535	A5 2020	46	2025-08-26 18:36:21.924	2025-08-26 18:36:21.924	\N
536	A52	46	2025-08-26 18:36:21.933	2025-08-26 18:36:21.932	\N
537	A52 4G	46	2025-08-26 18:36:21.946	2025-08-26 18:36:21.944	\N
538	A53	46	2025-08-26 18:36:21.951	2025-08-26 18:36:21.95	\N
539	A53 2020	46	2025-08-26 18:36:21.959	2025-08-26 18:36:21.959	\N
540	A53 4G	46	2025-08-26 18:36:21.965	2025-08-26 18:36:21.964	\N
541	A53S	46	2025-08-26 18:36:21.976	2025-08-26 18:36:21.975	\N
542	A54	46	2025-08-26 18:36:21.986	2025-08-26 18:36:21.985	\N
543	A54 4G	46	2025-08-26 18:36:21.994	2025-08-26 18:36:21.992	\N
544	A54S	46	2025-08-26 18:36:22.002	2025-08-26 18:36:22.001	\N
545	A55 4G	46	2025-08-26 18:36:22.008	2025-08-26 18:36:22.007	\N
546	A56	46	2025-08-26 18:36:22.017	2025-08-26 18:36:22.016	\N
547	A57	46	2025-08-26 18:36:22.024	2025-08-26 18:36:22.023	\N
548	A57E	46	2025-08-26 18:36:22.029	2025-08-26 18:36:22.029	\N
549	A57S	46	2025-08-26 18:36:22.034	2025-08-26 18:36:22.033	\N
550	A58 4G	46	2025-08-26 18:36:22.043	2025-08-26 18:36:22.042	\N
551	A58X 5G	46	2025-08-26 18:36:22.048	2025-08-26 18:36:22.047	\N
552	A5S	46	2025-08-26 18:36:22.06	2025-08-26 18:36:22.058	\N
553	A7	46	2025-08-26 18:36:22.066	2025-08-26 18:36:22.065	\N
554	A72	46	2025-08-26 18:36:22.073	2025-08-26 18:36:22.072	\N
555	A72 4G	46	2025-08-26 18:36:22.082	2025-08-26 18:36:22.081	\N
556	A73 5G	46	2025-08-26 18:36:22.087	2025-08-26 18:36:22.086	\N
557	A74 4G	46	2025-08-26 18:36:22.092	2025-08-26 18:36:22.091	\N
558	A77	46	2025-08-26 18:36:22.099	2025-08-26 18:36:22.098	\N
559	A78 4G	46	2025-08-26 18:36:22.111	2025-08-26 18:36:22.109	\N
560	A79 5G	46	2025-08-26 18:36:22.118	2025-08-26 18:36:22.117	\N
561	A7n	46	2025-08-26 18:36:22.127	2025-08-26 18:36:22.126	\N
562	A8	46	2025-08-26 18:36:22.132	2025-08-26 18:36:22.131	\N
563	A9	46	2025-08-26 18:36:22.143	2025-08-26 18:36:22.142	\N
564	A9 2020	46	2025-08-26 18:36:22.157	2025-08-26 18:36:22.156	\N
565	A92	46	2025-08-26 18:36:22.162	2025-08-26 18:36:22.161	\N
566	A92 4G	46	2025-08-26 18:36:22.168	2025-08-26 18:36:22.167	\N
567	A93 4G	46	2025-08-26 18:36:22.174	2025-08-26 18:36:22.173	\N
568	A93 5G	46	2025-08-26 18:36:22.185	2025-08-26 18:36:22.184	\N
569	A94 4G	46	2025-08-26 18:36:22.194	2025-08-26 18:36:22.192	\N
570	A95 4G	46	2025-08-26 18:36:22.2	2025-08-26 18:36:22.199	\N
571	Ax5S	46	2025-08-26 18:36:22.209	2025-08-26 18:36:22.208	\N
572	AX7	46	2025-08-26 18:36:22.219	2025-08-26 18:36:22.218	\N
573	C11	46	2025-08-26 18:36:22.227	2025-08-26 18:36:22.226	\N
574	C11 2021	46	2025-08-26 18:36:22.234	2025-08-26 18:36:22.233	\N
575	C15 CONFIGRACION BAJA	46	2025-08-26 18:36:22.242	2025-08-26 18:36:22.241	\N
576	C20	46	2025-08-26 18:36:22.247	2025-08-26 18:36:22.246	\N
577	C21	46	2025-08-26 18:36:22.253	2025-08-26 18:36:22.252	\N
578	C21Y	46	2025-08-26 18:36:22.261	2025-08-26 18:36:22.26	\N
579	C25	46	2025-08-26 18:36:22.266	2025-08-26 18:36:22.265	\N
580	C25S	46	2025-08-26 18:36:22.275	2025-08-26 18:36:22.275	\N
581	C25Y	46	2025-08-26 18:36:22.281	2025-08-26 18:36:22.28	\N
582	C30	46	2025-08-26 18:36:22.287	2025-08-26 18:36:22.286	\N
583	C30i	46	2025-08-26 18:36:22.297	2025-08-26 18:36:22.295	\N
584	C30S	46	2025-08-26 18:36:22.311	2025-08-26 18:36:22.31	\N
585	C33	46	2025-08-26 18:36:22.318	2025-08-26 18:36:22.317	\N
586	C35	46	2025-08-26 18:36:22.323	2025-08-26 18:36:22.322	\N
587	C36	46	2025-08-26 18:36:22.329	2025-08-26 18:36:22.328	\N
588	C3i	46	2025-08-26 18:36:22.336	2025-08-26 18:36:22.336	\N
589	C50i	46	2025-08-26 18:36:22.345	2025-08-26 18:36:22.344	\N
590	C51	46	2025-08-26 18:36:22.352	2025-08-26 18:36:22.351	\N
591	C51S	46	2025-08-26 18:36:22.359	2025-08-26 18:36:22.358	\N
592	C53	46	2025-08-26 18:36:22.368	2025-08-26 18:36:22.367	\N
593	C60	46	2025-08-26 18:36:22.372	2025-08-26 18:36:22.372	\N
594	C67	46	2025-08-26 18:36:22.379	2025-08-26 18:36:22.379	\N
595	F19 4G	46	2025-08-26 18:36:22.385	2025-08-26 18:36:22.385	\N
596	F19S 4G	46	2025-08-26 18:36:22.393	2025-08-26 18:36:22.392	\N
597	F21PRO 4G	46	2025-08-26 18:36:22.401	2025-08-26 18:36:22.398	\N
598	F21PRO 5G	46	2025-08-26 18:36:22.406	2025-08-26 18:36:22.405	\N
599	F21S PRO 4G	46	2025-08-26 18:36:22.415	2025-08-26 18:36:22.412	\N
600	F21S PRO4G	46	2025-08-26 18:36:22.422	2025-08-26 18:36:22.421	\N
601	F23	46	2025-08-26 18:36:22.435	2025-08-26 18:36:22.434	\N
602	FIND X3 LITE	46	2025-08-26 18:36:22.442	2025-08-26 18:36:22.441	\N
603	FIND X5 LI	46	2025-08-26 18:36:22.451	2025-08-26 18:36:22.45	\N
604	FIND X5 LITE 5G	46	2025-08-26 18:36:22.459	2025-08-26 18:36:22.458	\N
605	K10 5G	46	2025-08-26 18:36:22.467	2025-08-26 18:36:22.466	\N
606	K11X 5G	46	2025-08-26 18:36:22.478	2025-08-26 18:36:22.476	\N
607	K7X	46	2025-08-26 18:36:22.486	2025-08-26 18:36:22.486	\N
608	K9 5G	46	2025-08-26 18:36:22.492	2025-08-26 18:36:22.492	\N
609	K9PRO 5G	46	2025-08-26 18:36:22.508	2025-08-26 18:36:22.506	\N
610	N20SE	46	2025-08-26 18:36:22.514	2025-08-26 18:36:22.513	\N
611	N55	46	2025-08-26 18:36:22.52	2025-08-26 18:36:22.52	\N
612	Narzo N53	46	2025-08-26 18:36:22.524	2025-08-26 18:36:22.524	\N
613	Narzo10A	46	2025-08-26 18:36:22.532	2025-08-26 18:36:22.53	\N
614	NARZO20 PRO	46	2025-08-26 18:36:22.538	2025-08-26 18:36:22.537	\N
615	NARZO30 4G	46	2025-08-26 18:36:22.545	2025-08-26 18:36:22.544	\N
616	NARZO30 PRO	46	2025-08-26 18:36:22.552	2025-08-26 18:36:22.552	\N
617	NARZO50A	46	2025-08-26 18:36:22.558	2025-08-26 18:36:22.557	\N
618	Note50	46	2025-08-26 18:36:22.566	2025-08-26 18:36:22.565	\N
619	prime C3	46	2025-08-26 18:36:22.577	2025-08-26 18:36:22.576	\N
620	prime C5	46	2025-08-26 18:36:22.587	2025-08-26 18:36:22.585	\N
621	REALME	46	2025-08-26 18:36:22.596	2025-08-26 18:36:22.595	\N
622	realme 5s	46	2025-08-26 18:36:22.601	2025-08-26 18:36:22.6	\N
623	REALME C11 2020	46	2025-08-26 18:36:22.609	2025-08-26 18:36:22.608	\N
624	REALME C12	46	2025-08-26 18:36:22.617	2025-08-26 18:36:22.616	\N
625	REALME C17	46	2025-08-26 18:36:22.628	2025-08-26 18:36:22.627	\N
626	realme C3	46	2025-08-26 18:36:22.635	2025-08-26 18:36:22.634	\N
627	REALME C55	46	2025-08-26 18:36:22.64	2025-08-26 18:36:22.639	\N
628	REALME Q2	46	2025-08-26 18:36:22.645	2025-08-26 18:36:22.644	\N
629	REALME V5	46	2025-08-26 18:36:22.653	2025-08-26 18:36:22.652	\N
630	REALME11 5G	46	2025-08-26 18:36:22.659	2025-08-26 18:36:22.658	\N
631	Realme3	46	2025-08-26 18:36:22.668	2025-08-26 18:36:22.668	\N
632	Realme3i	46	2025-08-26 18:36:22.673	2025-08-26 18:36:22.673	\N
633	realme5	46	2025-08-26 18:36:22.68	2025-08-26 18:36:22.679	\N
634	realme5i	46	2025-08-26 18:36:22.685	2025-08-26 18:36:22.684	\N
635	realme5s	46	2025-08-26 18:36:22.696	2025-08-26 18:36:22.695	\N
636	REALME6	46	2025-08-26 18:36:22.705	2025-08-26 18:36:22.704	\N
637	realme6i	46	2025-08-26 18:36:22.712	2025-08-26 18:36:22.711	\N
638	REALME6I IZQUIERDO	46	2025-08-26 18:36:22.717	2025-08-26 18:36:22.716	\N
639	REALME6S	46	2025-08-26 18:36:22.722	2025-08-26 18:36:22.721	\N
640	REALME7	46	2025-08-26 18:36:22.731	2025-08-26 18:36:22.729	\N
641	REALME7 5G	46	2025-08-26 18:36:22.742	2025-08-26 18:36:22.742	\N
642	REALME7 PRO 04	46	2025-08-26 18:36:22.748	2025-08-26 18:36:22.746	\N
643	REALME7I	46	2025-08-26 18:36:22.756	2025-08-26 18:36:22.755	\N
644	realmeC3	46	2025-08-26 18:36:22.764	2025-08-26 18:36:22.763	\N
645	RENO 4SE	46	2025-08-26 18:36:22.772	2025-08-26 18:36:22.77	\N
646	RENO 5F	46	2025-08-26 18:36:22.778	2025-08-26 18:36:22.777	\N
647	RENO 5Z	46	2025-08-26 18:36:22.79	2025-08-26 18:36:22.789	\N
648	RENO 6Z	46	2025-08-26 18:36:22.795	2025-08-26 18:36:22.794	\N
649	RENO10 5G	46	2025-08-26 18:36:22.802	2025-08-26 18:36:22.801	\N
650	RENO11 5G	46	2025-08-26 18:36:22.806	2025-08-26 18:36:22.805	\N
651	Reno4se	46	2025-08-26 18:36:22.819	2025-08-26 18:36:22.818	\N
652	RENO5	46	2025-08-26 18:36:22.829	2025-08-26 18:36:22.828	\N
653	RENO5 4G(5G)	46	2025-08-26 18:36:22.839	2025-08-26 18:36:22.837	\N
654	RENO5 LITE	46	2025-08-26 18:36:22.851	2025-08-26 18:36:22.85	\N
655	Reno5F	46	2025-08-26 18:36:22.857	2025-08-26 18:36:22.857	\N
656	RENO5K	46	2025-08-26 18:36:22.873	2025-08-26 18:36:22.87	\N
657	Reno5Z	46	2025-08-26 18:36:22.881	2025-08-26 18:36:22.88	\N
658	RENO6 4G(5G)	46	2025-08-26 18:36:22.892	2025-08-26 18:36:22.89	\N
659	RENO6 LITE	46	2025-08-26 18:36:22.906	2025-08-26 18:36:22.903	\N
660	Reno6Z	46	2025-08-26 18:36:22.918	2025-08-26 18:36:22.916	\N
661	RENO7 4G	46	2025-08-26 18:36:22.926	2025-08-26 18:36:22.926	\N
662	RENO7 4G(5G)	46	2025-08-26 18:36:22.936	2025-08-26 18:36:22.933	\N
663	RENO7 5G	46	2025-08-26 18:36:22.947	2025-08-26 18:36:22.945	\N
664	RENO7 LITE	46	2025-08-26 18:36:22.961	2025-08-26 18:36:22.96	\N
665	RENO7 LITE 5G	46	2025-08-26 18:36:22.974	2025-08-26 18:36:22.973	\N
666	RENO7SE 5G	46	2025-08-26 18:36:22.996	2025-08-26 18:36:22.995	\N
667	RENO7Z	46	2025-08-26 18:36:23.011	2025-08-26 18:36:23.009	\N
668	RENO8 4G(5G)	46	2025-08-26 18:36:23.033	2025-08-26 18:36:23.032	\N
669	RENO8 LITE	46	2025-08-26 18:36:23.047	2025-08-26 18:36:23.046	\N
670	RENO8T	46	2025-08-26 18:36:23.059	2025-08-26 18:36:23.057	\N
671	RENO8T 5G	46	2025-08-26 18:36:23.068	2025-08-26 18:36:23.068	\N
672	RENO9	46	2025-08-26 18:36:23.074	2025-08-26 18:36:23.074	\N
673	V50	46	2025-08-26 18:36:23.08	2025-08-26 18:36:23.08	\N
674	V50S A98 4G	46	2025-08-26 18:36:23.089	2025-08-26 18:36:23.086	\N
675	T10	55	2025-08-26 18:37:00.13	2025-08-26 18:37:00.129	\N
676	T50	55	2025-08-26 18:37:04.164	2025-08-26 18:37:04.163	\N
677	20XE	53	2025-08-26 18:49:16.571	2025-08-26 18:49:16.57	\N
678	30PLUS	53	2025-08-26 18:49:16.583	2025-08-26 18:49:16.58	\N
679	10SE	53	2025-08-26 18:49:16.589	2025-08-26 18:49:16.588	\N
680	20SE	53	2025-08-26 18:49:16.603	2025-08-26 18:49:16.601	\N
681	20E	53	2025-08-26 18:49:16.612	2025-08-26 18:49:16.61	\N
682	30SE	53	2025-08-26 18:49:16.621	2025-08-26 18:49:16.62	\N
683	408	53	2025-08-26 18:49:16.627	2025-08-26 18:49:16.626	\N
684	V29E	53	2025-08-26 18:49:16.635	2025-08-26 18:49:16.634	\N
685	Y200	53	2025-08-26 18:49:16.647	2025-08-26 18:49:16.644	\N
686	A01 M	38	2025-08-26 18:52:30.162	2025-08-26 18:52:30.16	\N
687	A02	38	2025-08-26 18:52:30.173	2025-08-26 18:52:30.172	\N
688	A02S	38	2025-08-26 18:52:30.181	2025-08-26 18:52:30.18	\N
689	A03	38	2025-08-26 18:52:30.197	2025-08-26 18:52:30.194	\N
690	A03 CORE	38	2025-08-26 18:52:30.209	2025-08-26 18:52:30.206	\N
691	A037U	38	2025-08-26 18:52:30.222	2025-08-26 18:52:30.22	\N
692	A03S	38	2025-08-26 18:52:30.234	2025-08-26 18:52:30.233	\N
693	A04	38	2025-08-26 18:52:30.243	2025-08-26 18:52:30.242	\N
694	A045	38	2025-08-26 18:52:30.256	2025-08-26 18:52:30.253	\N
695	A04CORE	38	2025-08-26 18:52:30.262	2025-08-26 18:52:30.261	\N
696	A04E	38	2025-08-26 18:52:30.269	2025-08-26 18:52:30.268	\N
697	A04S	38	2025-08-26 18:52:30.279	2025-08-26 18:52:30.279	\N
698	A05	38	2025-08-26 18:52:30.287	2025-08-26 18:52:30.287	\N
699	A05S	38	2025-08-26 18:52:30.296	2025-08-26 18:52:30.295	\N
700	A06	38	2025-08-26 18:52:30.303	2025-08-26 18:52:30.303	\N
701	A065	38	2025-08-26 18:52:30.314	2025-08-26 18:52:30.311	\N
702	A10	38	2025-08-26 18:52:30.322	2025-08-26 18:52:30.321	\N
703	A107	38	2025-08-26 18:52:30.331	2025-08-26 18:52:30.33	\N
704	A10E	38	2025-08-26 18:52:30.34	2025-08-26 18:52:30.338	\N
705	A10S	38	2025-08-26 18:52:30.348	2025-08-26 18:52:30.345	\N
706	A11	38	2025-08-26 18:52:30.358	2025-08-26 18:52:30.357	\N
707	A11 INCELL300+ C/M	38	2025-08-26 18:52:30.367	2025-08-26 18:52:30.366	\N
708	A115	38	2025-08-26 18:52:30.374	2025-08-26 18:52:30.373	\N
709	A12	38	2025-08-26 18:52:30.386	2025-08-26 18:52:30.384	\N
710	A13	38	2025-08-26 18:52:30.397	2025-08-26 18:52:30.396	\N
711	A13 4G	38	2025-08-26 18:52:30.402	2025-08-26 18:52:30.402	\N
712	A13 5G	38	2025-08-26 18:52:30.41	2025-08-26 18:52:30.409	\N
713	A13 LITE	38	2025-08-26 18:52:30.421	2025-08-26 18:52:30.42	\N
714	A136B	38	2025-08-26 18:52:30.431	2025-08-26 18:52:30.43	\N
715	A14 4G	38	2025-08-26 18:52:30.438	2025-08-26 18:52:30.438	\N
716	A14 5G	38	2025-08-26 18:52:30.443	2025-08-26 18:52:30.442	\N
717	A145P	38	2025-08-26 18:52:30.45	2025-08-26 18:52:30.449	\N
718	A146B	38	2025-08-26 18:52:30.455	2025-08-26 18:52:30.455	\N
719	A15 4G(5G)	38	2025-08-26 18:52:30.464	2025-08-26 18:52:30.461	\N
720	A20	38	2025-08-26 18:52:30.472	2025-08-26 18:52:30.472	\N
721	A207	38	2025-08-26 18:52:30.478	2025-08-26 18:52:30.477	\N
722	A20S	38	2025-08-26 18:52:30.486	2025-08-26 18:52:30.485	\N
723	A217	38	2025-08-26 18:52:30.492	2025-08-26 18:52:30.491	\N
724	A21S	38	2025-08-26 18:52:30.499	2025-08-26 18:52:30.497	\N
725	A22 4G	38	2025-08-26 18:52:30.504	2025-08-26 18:52:30.503	\N
726	A23 4G	38	2025-08-26 18:52:30.514	2025-08-26 18:52:30.513	\N
727	A23 lite	38	2025-08-26 18:52:30.525	2025-08-26 18:52:30.524	\N
728	A24	38	2025-08-26 18:52:30.536	2025-08-26 18:52:30.535	\N
729	A24 4G	38	2025-08-26 18:52:30.543	2025-08-26 18:52:30.542	\N
730	A25	38	2025-08-26 18:52:30.552	2025-08-26 18:52:30.55	\N
731	A25 5G	38	2025-08-26 18:52:30.56	2025-08-26 18:52:30.559	\N
732	A30	38	2025-08-26 18:52:30.564	2025-08-26 18:52:30.564	\N
733	A30S	38	2025-08-26 18:52:30.574	2025-08-26 18:52:30.573	\N
734	A31	38	2025-08-26 18:52:30.582	2025-08-26 18:52:30.579	\N
735	A315	38	2025-08-26 18:52:30.589	2025-08-26 18:52:30.588	\N
736	A32 4G	38	2025-08-26 18:52:30.602	2025-08-26 18:52:30.599	\N
737	A32 5G	38	2025-08-26 18:52:30.609	2025-08-26 18:52:30.608	\N
738	A325	38	2025-08-26 18:52:30.616	2025-08-26 18:52:30.615	\N
739	A325 4G	38	2025-08-26 18:52:30.636	2025-08-26 18:52:30.633	\N
740	A33	38	2025-08-26 18:52:30.65	2025-08-26 18:52:30.647	\N
741	A336	38	2025-08-26 18:52:30.664	2025-08-26 18:52:30.663	\N
742	A34 5G	38	2025-08-26 18:52:30.679	2025-08-26 18:52:30.678	\N
743	A35	38	2025-08-26 18:52:30.692	2025-08-26 18:52:30.69	\N
744	A50	38	2025-08-26 18:52:30.708	2025-08-26 18:52:30.704	\N
745	A50S	38	2025-08-26 18:52:30.735	2025-08-26 18:52:30.725	\N
746	A51	38	2025-08-26 18:52:30.756	2025-08-26 18:52:30.755	\N
747	A515	38	2025-08-26 18:52:30.772	2025-08-26 18:52:30.769	\N
748	A52	38	2025-08-26 18:52:30.781	2025-08-26 18:52:30.78	\N
749	A525	38	2025-08-26 18:52:30.799	2025-08-26 18:52:30.798	\N
750	A525 4G	38	2025-08-26 18:52:30.818	2025-08-26 18:52:30.817	\N
751	A52S	38	2025-08-26 18:52:30.828	2025-08-26 18:52:30.828	\N
752	A53	38	2025-08-26 18:52:30.841	2025-08-26 18:52:30.84	\N
753	A536	38	2025-08-26 18:52:30.849	2025-08-26 18:52:30.848	\N
754	A54	38	2025-08-26 18:52:30.859	2025-08-26 18:52:30.855	\N
755	A546	38	2025-08-26 18:52:30.866	2025-08-26 18:52:30.865	\N
756	A55	38	2025-08-26 18:52:30.873	2025-08-26 18:52:30.872	\N
757	A70	38	2025-08-26 18:52:30.88	2025-08-26 18:52:30.879	\N
758	A70S	38	2025-08-26 18:52:30.887	2025-08-26 18:52:30.886	\N
759	A71	38	2025-08-26 18:52:30.895	2025-08-26 18:52:30.893	\N
760	A715	38	2025-08-26 18:52:30.904	2025-08-26 18:52:30.903	\N
761	A72	38	2025-08-26 18:52:30.913	2025-08-26 18:52:30.912	\N
762	A725	38	2025-08-26 18:52:30.922	2025-08-26 18:52:30.921	\N
763	A73 5G	38	2025-08-26 18:52:30.93	2025-08-26 18:52:30.929	\N
764	A730	38	2025-08-26 18:52:30.936	2025-08-26 18:52:30.936	\N
765	A8PLUS	38	2025-08-26 18:52:30.948	2025-08-26 18:52:30.947	\N
766	F12	38	2025-08-26 18:52:30.955	2025-08-26 18:52:30.954	\N
767	G530	38	2025-08-26 18:52:30.961	2025-08-26 18:52:30.96	\N
768	G530 LCD INCELL S/M	38	2025-08-26 18:52:30.966	2025-08-26 18:52:30.965	\N
769	G532	38	2025-08-26 18:52:30.973	2025-08-26 18:52:30.972	\N
770	HG NOTE10 PLUS	38	2025-08-26 18:52:30.981	2025-08-26 18:52:30.98	\N
771	HG NOTE20 ULTRA	38	2025-08-26 18:52:30.988	2025-08-26 18:52:30.988	\N
772	HG S20 PLUS	38	2025-08-26 18:52:30.996	2025-08-26 18:52:30.995	\N
773	HG S20 ULTRA	38	2025-08-26 18:52:31.005	2025-08-26 18:52:31.004	\N
774	HG S21 PLUS	38	2025-08-26 18:52:31.01	2025-08-26 18:52:31.01	\N
775	HG S21 ULTRA	38	2025-08-26 18:52:31.02	2025-08-26 18:52:31.018	\N
776	HG S22 PLUS	38	2025-08-26 18:52:31.037	2025-08-26 18:52:31.034	\N
777	HG S22 ULTRA	38	2025-08-26 18:52:31.044	2025-08-26 18:52:31.043	\N
778	HG S23 ULTRA	38	2025-08-26 18:52:31.052	2025-08-26 18:52:31.051	\N
779	J4	38	2025-08-26 18:52:31.059	2025-08-26 18:52:31.057	\N
780	J4CORE	38	2025-08-26 18:52:31.066	2025-08-26 18:52:31.065	\N
781	J4PLUS	38	2025-08-26 18:52:31.076	2025-08-26 18:52:31.075	\N
782	J5	38	2025-08-26 18:52:31.081	2025-08-26 18:52:31.08	\N
783	J5 PRIME	38	2025-08-26 18:52:31.092	2025-08-26 18:52:31.089	\N
784	J5 PRO	38	2025-08-26 18:52:31.097	2025-08-26 18:52:31.097	\N
785	J530	38	2025-08-26 18:52:31.109	2025-08-26 18:52:31.108	\N
786	J6	38	2025-08-26 18:52:31.115	2025-08-26 18:52:31.114	\N
787	J6 PLUS	38	2025-08-26 18:52:31.121	2025-08-26 18:52:31.12	\N
788	J610	38	2025-08-26 18:52:31.13	2025-08-26 18:52:31.128	\N
789	J6PLUS	38	2025-08-26 18:52:31.138	2025-08-26 18:52:31.137	\N
790	J7	38	2025-08-26 18:52:31.147	2025-08-26 18:52:31.146	\N
791	J7 NEO	38	2025-08-26 18:52:31.156	2025-08-26 18:52:31.155	\N
792	J7 PRIME	38	2025-08-26 18:52:31.162	2025-08-26 18:52:31.161	\N
793	J701	38	2025-08-26 18:52:31.17	2025-08-26 18:52:31.169	\N
794	J730	38	2025-08-26 18:52:31.178	2025-08-26 18:52:31.177	\N
795	J7NEO	38	2025-08-26 18:52:31.188	2025-08-26 18:52:31.185	\N
796	J7PRO	38	2025-08-26 18:52:31.2	2025-08-26 18:52:31.199	\N
797	J8	38	2025-08-26 18:52:31.205	2025-08-26 18:52:31.204	\N
798	M02	38	2025-08-26 18:52:31.212	2025-08-26 18:52:31.211	\N
799	M10	38	2025-08-26 18:52:31.218	2025-08-26 18:52:31.217	\N
800	M11	38	2025-08-26 18:52:31.225	2025-08-26 18:52:31.224	\N
801	M127	38	2025-08-26 18:52:31.23	2025-08-26 18:52:31.229	\N
802	M14 5G	38	2025-08-26 18:52:31.238	2025-08-26 18:52:31.237	\N
803	M146B	38	2025-08-26 18:52:31.247	2025-08-26 18:52:31.246	\N
804	M20	38	2025-08-26 18:52:31.254	2025-08-26 18:52:31.252	\N
805	M21	38	2025-08-26 18:52:31.26	2025-08-26 18:52:31.259	\N
806	M23	38	2025-08-26 18:52:31.276	2025-08-26 18:52:31.275	\N
807	M23 4G	38	2025-08-26 18:52:31.283	2025-08-26 18:52:31.282	\N
808	M23 5G	38	2025-08-26 18:52:31.288	2025-08-26 18:52:31.287	\N
809	M30	38	2025-08-26 18:52:31.3	2025-08-26 18:52:31.299	\N
810	M30 INCELL300+ C/M	38	2025-08-26 18:52:31.307	2025-08-26 18:52:31.306	\N
811	M30S	38	2025-08-26 18:52:31.314	2025-08-26 18:52:31.313	\N
812	M31	38	2025-08-26 18:52:31.321	2025-08-26 18:52:31.32	\N
813	M33	38	2025-08-26 18:52:31.329	2025-08-26 18:52:31.328	\N
814	M33 5G	38	2025-08-26 18:52:31.335	2025-08-26 18:52:31.334	\N
815	M336B	38	2025-08-26 18:52:31.346	2025-08-26 18:52:31.344	\N
816	M34 5G	38	2025-08-26 18:52:31.353	2025-08-26 18:52:31.352	\N
817	M53 5G	38	2025-08-26 18:52:31.359	2025-08-26 18:52:31.358	\N
818	NOTE10 LITE	38	2025-08-26 18:52:31.368	2025-08-26 18:52:31.367	\N
819	NOTE10 PLUS	38	2025-08-26 18:52:31.376	2025-08-26 18:52:31.374	\N
820	NOTE20	38	2025-08-26 18:52:31.381	2025-08-26 18:52:31.381	\N
821	NOTE20 ULTRA	38	2025-08-26 18:52:31.395	2025-08-26 18:52:31.394	\N
822	S10	38	2025-08-26 18:52:31.404	2025-08-26 18:52:31.403	\N
823	S10 PLUS	38	2025-08-26 18:52:31.413	2025-08-26 18:52:31.412	\N
824	S20 FE	38	2025-08-26 18:52:31.42	2025-08-26 18:52:31.417	\N
825	S20 PLUS	38	2025-08-26 18:52:31.427	2025-08-26 18:52:31.426	\N
826	S20 ULTRA	38	2025-08-26 18:52:31.438	2025-08-26 18:52:31.436	\N
827	S21 PLUS	38	2025-08-26 18:52:31.445	2025-08-26 18:52:31.444	\N
828	S21 ULTRA	38	2025-08-26 18:52:31.452	2025-08-26 18:52:31.451	\N
829	S22	38	2025-08-26 18:52:31.46	2025-08-26 18:52:31.458	\N
830	S22 PLUS	38	2025-08-26 18:52:31.472	2025-08-26 18:52:31.468	\N
831	S22 ULTRA	38	2025-08-26 18:52:31.479	2025-08-26 18:52:31.478	\N
832	S22 ULTRA SOFT OLED C/M(BOUTIQUE)	38	2025-08-26 18:52:31.487	2025-08-26 18:52:31.486	\N
833	S23	38	2025-08-26 18:52:31.497	2025-08-26 18:52:31.497	\N
834	S23 ULTRA	38	2025-08-26 18:52:31.506	2025-08-26 18:52:31.505	\N
835	S24 ULTRA	38	2025-08-26 18:52:31.516	2025-08-26 18:52:31.514	\N
836	S8	38	2025-08-26 18:52:31.524	2025-08-26 18:52:31.523	\N
837	S8PLUS	38	2025-08-26 18:52:31.53	2025-08-26 18:52:31.529	\N
838	S9	38	2025-08-26 18:52:31.536	2025-08-26 18:52:31.536	\N
839	S9 PLUS	38	2025-08-26 18:52:31.548	2025-08-26 18:52:31.545	\N
840	SAMA10	38	2025-08-26 18:52:31.562	2025-08-26 18:52:31.561	\N
841	10 INDIA	44	2025-08-26 18:56:12.033	2025-08-26 18:56:12.031	\N
842	11PRIME	44	2025-08-26 18:56:12.045	2025-08-26 18:56:12.044	\N
843	9 PRIME	44	2025-08-26 18:56:12.059	2025-08-26 18:56:12.057	\N
844	A1	44	2025-08-26 18:56:12.068	2025-08-26 18:56:12.066	\N
845	A1 PLUS	44	2025-08-26 18:56:12.074	2025-08-26 18:56:12.073	\N
846	A2	44	2025-08-26 18:56:12.082	2025-08-26 18:56:12.081	\N
847	A2+	44	2025-08-26 18:56:12.091	2025-08-26 18:56:12.089	\N
848	A2PLUS	44	2025-08-26 18:56:12.101	2025-08-26 18:56:12.1	\N
849	CC9PRO	44	2025-08-26 18:56:12.113	2025-08-26 18:56:12.108	\N
850	CMI 10T LITE	44	2025-08-26 18:56:12.126	2025-08-26 18:56:12.124	\N
851	K20	44	2025-08-26 18:56:12.133	2025-08-26 18:56:12.132	\N
852	K30S	44	2025-08-26 18:56:12.14	2025-08-26 18:56:12.139	\N
853	M6 PRO	44	2025-08-26 18:56:12.152	2025-08-26 18:56:12.149	\N
854	MI 10	44	2025-08-26 18:56:12.159	2025-08-26 18:56:12.158	\N
855	MI 10 LITE	44	2025-08-26 18:56:12.169	2025-08-26 18:56:12.168	\N
856	MI 10T	44	2025-08-26 18:56:12.176	2025-08-26 18:56:12.175	\N
857	MI 10T PRO	44	2025-08-26 18:56:12.183	2025-08-26 18:56:12.182	\N
858	MI 11 i	44	2025-08-26 18:56:12.192	2025-08-26 18:56:12.191	\N
859	MI 11 LITE 4G/5G	44	2025-08-26 18:56:12.199	2025-08-26 18:56:12.198	\N
860	MI 11 X	44	2025-08-26 18:56:12.207	2025-08-26 18:56:12.206	\N
861	MI 11T	44	2025-08-26 18:56:12.215	2025-08-26 18:56:12.214	\N
862	MI 11T PRO	44	2025-08-26 18:56:12.231	2025-08-26 18:56:12.228	\N
863	MI 12T	44	2025-08-26 18:56:12.242	2025-08-26 18:56:12.241	\N
864	MI 12T PRO	44	2025-08-26 18:56:12.25	2025-08-26 18:56:12.248	\N
865	MI 9	44	2025-08-26 18:56:12.256	2025-08-26 18:56:12.255	\N
866	MI 9T	44	2025-08-26 18:56:12.266	2025-08-26 18:56:12.265	\N
867	MI 9T PRO	44	2025-08-26 18:56:12.273	2025-08-26 18:56:12.272	\N
868	MI A1/5X	44	2025-08-26 18:56:12.278	2025-08-26 18:56:12.278	\N
869	MI A2/6X	44	2025-08-26 18:56:12.283	2025-08-26 18:56:12.282	\N
870	MI A3	44	2025-08-26 18:56:12.29	2025-08-26 18:56:12.289	\N
871	MI A3/CC9E	44	2025-08-26 18:56:12.304	2025-08-26 18:56:12.301	\N
872	MI NOTE10	44	2025-08-26 18:56:12.312	2025-08-26 18:56:12.311	\N
873	MI10 LITE	44	2025-08-26 18:56:12.32	2025-08-26 18:56:12.319	\N
874	MI10T	44	2025-08-26 18:56:12.331	2025-08-26 18:56:12.33	\N
875	MI10T PRO	44	2025-08-26 18:56:12.339	2025-08-26 18:56:12.338	\N
876	MI11 i	44	2025-08-26 18:56:12.347	2025-08-26 18:56:12.346	\N
877	MI11 LITE 4G/5G	44	2025-08-26 18:56:12.356	2025-08-26 18:56:12.355	\N
878	MI11 X	44	2025-08-26 18:56:12.365	2025-08-26 18:56:12.364	\N
879	MI11T	44	2025-08-26 18:56:12.378	2025-08-26 18:56:12.375	\N
880	MI11T PRO	44	2025-08-26 18:56:12.386	2025-08-26 18:56:12.385	\N
881	MI13T	44	2025-08-26 18:56:12.397	2025-08-26 18:56:12.395	\N
882	MI13T PRO	44	2025-08-26 18:56:12.404	2025-08-26 18:56:12.403	\N
883	MI9	44	2025-08-26 18:56:12.411	2025-08-26 18:56:12.411	\N
884	MI9 POWER	44	2025-08-26 18:56:12.42	2025-08-26 18:56:12.419	\N
885	MI9T PRO	44	2025-08-26 18:56:12.43	2025-08-26 18:56:12.429	\N
886	NOTE 13 4G	44	2025-08-26 18:56:12.442	2025-08-26 18:56:12.441	\N
887	NOTE10LITE	44	2025-08-26 18:56:12.453	2025-08-26 18:56:12.452	\N
888	NOTE10PRO	44	2025-08-26 18:56:12.46	2025-08-26 18:56:12.459	\N
889	NOTE10PRO MAX	44	2025-08-26 18:56:12.472	2025-08-26 18:56:12.471	\N
890	NOTE10S 5G	44	2025-08-26 18:56:12.481	2025-08-26 18:56:12.48	\N
891	NOTE10T	44	2025-08-26 18:56:12.488	2025-08-26 18:56:12.487	\N
892	NOTE10X	44	2025-08-26 18:56:12.493	2025-08-26 18:56:12.492	\N
893	NOTE11 E	44	2025-08-26 18:56:12.5	2025-08-26 18:56:12.499	\N
894	NOTE11 R	44	2025-08-26 18:56:12.507	2025-08-26 18:56:12.506	\N
895	NOTE11 SE	44	2025-08-26 18:56:12.517	2025-08-26 18:56:12.516	\N
896	NOTE11PRO	44	2025-08-26 18:56:12.527	2025-08-26 18:56:12.525	\N
897	NOTE11PRO LIUS	44	2025-08-26 18:56:12.541	2025-08-26 18:56:12.539	\N
898	Note11S	44	2025-08-26 18:56:12.554	2025-08-26 18:56:12.552	\N
899	NOTE12PRO 4G	44	2025-08-26 18:56:12.576	2025-08-26 18:56:12.574	\N
900	NOTE12S	44	2025-08-26 18:56:12.599	2025-08-26 18:56:12.589	\N
901	NOTE9 4G	44	2025-08-26 18:56:12.613	2025-08-26 18:56:12.612	\N
902	NOTE9PRO 5G	44	2025-08-26 18:56:12.626	2025-08-26 18:56:12.623	\N
903	POCO C3	44	2025-08-26 18:56:12.64	2025-08-26 18:56:12.64	\N
904	POCO C31	44	2025-08-26 18:56:12.663	2025-08-26 18:56:12.661	\N
905	POCO C40	44	2025-08-26 18:56:12.684	2025-08-26 18:56:12.682	\N
906	POCO C50	44	2025-08-26 18:56:12.702	2025-08-26 18:56:12.701	\N
907	POCO C65	44	2025-08-26 18:56:12.71	2025-08-26 18:56:12.708	\N
908	POCO F3	44	2025-08-26 18:56:12.725	2025-08-26 18:56:12.724	\N
909	POCO F4	44	2025-08-26 18:56:12.745	2025-08-26 18:56:12.744	\N
910	POCO M3	44	2025-08-26 18:56:12.754	2025-08-26 18:56:12.753	\N
911	POCO M3 PRO	44	2025-08-26 18:56:12.763	2025-08-26 18:56:12.763	\N
912	POCO M4	44	2025-08-26 18:56:12.772	2025-08-26 18:56:12.771	\N
913	POCO M4 PRO 4G	44	2025-08-26 18:56:12.779	2025-08-26 18:56:12.778	\N
914	POCO M4 PRO 5G	44	2025-08-26 18:56:12.792	2025-08-26 18:56:12.791	\N
915	POCO M4/M5	44	2025-08-26 18:56:12.798	2025-08-26 18:56:12.797	\N
916	POCO M5	44	2025-08-26 18:56:12.806	2025-08-26 18:56:12.805	\N
917	POCO M5S	44	2025-08-26 18:56:12.811	2025-08-26 18:56:12.81	\N
918	POCO X3	44	2025-08-26 18:56:12.816	2025-08-26 18:56:12.815	\N
919	POCO X3 GT	44	2025-08-26 18:56:12.823	2025-08-26 18:56:12.822	\N
920	POCO X3 PRO	44	2025-08-26 18:56:12.829	2025-08-26 18:56:12.829	\N
921	POCO X3/X3 PRO	44	2025-08-26 18:56:12.838	2025-08-26 18:56:12.836	\N
922	POCO X4 GT	44	2025-08-26 18:56:12.845	2025-08-26 18:56:12.844	\N
923	POCO X4PRO	44	2025-08-26 18:56:12.85	2025-08-26 18:56:12.849	\N
924	POCO X5	44	2025-08-26 18:56:12.857	2025-08-26 18:56:12.856	\N
925	REDMI 10	44	2025-08-26 18:56:12.868	2025-08-26 18:56:12.866	\N
926	REDMI 10 4G	44	2025-08-26 18:56:12.875	2025-08-26 18:56:12.874	\N
927	REDMI 10 5G	44	2025-08-26 18:56:12.882	2025-08-26 18:56:12.881	\N
928	REDMI 10 POWER	44	2025-08-26 18:56:12.887	2025-08-26 18:56:12.887	\N
929	REDMI 10A	44	2025-08-26 18:56:12.895	2025-08-26 18:56:12.894	\N
930	REDMI 10C	44	2025-08-26 18:56:12.906	2025-08-26 18:56:12.905	\N
931	REDMI 10X	44	2025-08-26 18:56:12.915	2025-08-26 18:56:12.914	\N
932	REDMI 12	44	2025-08-26 18:56:12.925	2025-08-26 18:56:12.924	\N
933	REDMI 12C	44	2025-08-26 18:56:12.935	2025-08-26 18:56:12.934	\N
934	REDMI 13C	44	2025-08-26 18:56:12.944	2025-08-26 18:56:12.943	\N
935	REDMI 14C	44	2025-08-26 18:56:12.957	2025-08-26 18:56:12.956	\N
936	REDMI 8	44	2025-08-26 18:56:12.965	2025-08-26 18:56:12.964	\N
937	REDMI 8A	44	2025-08-26 18:56:12.975	2025-08-26 18:56:12.974	\N
938	REDMI 9	44	2025-08-26 18:56:12.985	2025-08-26 18:56:12.983	\N
939	REDMI 9 PRIME	44	2025-08-26 18:56:12.999	2025-08-26 18:56:12.997	\N
940	REDMI 9A	44	2025-08-26 18:56:13.006	2025-08-26 18:56:13.006	\N
941	REDMI 9AT	44	2025-08-26 18:56:13.012	2025-08-26 18:56:13.011	\N
942	REDMI 9C	44	2025-08-26 18:56:13.021	2025-08-26 18:56:13.021	\N
943	REDMI 9I	44	2025-08-26 18:56:13.034	2025-08-26 18:56:13.034	\N
944	REDMI 9T	44	2025-08-26 18:56:13.041	2025-08-26 18:56:13.04	\N
945	REDMI A1	44	2025-08-26 18:56:13.05	2025-08-26 18:56:13.049	\N
946	REDMI A1+	44	2025-08-26 18:56:13.06	2025-08-26 18:56:13.059	\N
947	REDMI A3	44	2025-08-26 18:56:13.065	2025-08-26 18:56:13.064	\N
948	REDMI NOTE 10 4G	44	2025-08-26 18:56:13.073	2025-08-26 18:56:13.07	\N
949	REDMI NOTE 10 LITE	44	2025-08-26 18:56:13.082	2025-08-26 18:56:13.082	\N
950	REDMI NOTE 10 PRO	44	2025-08-26 18:56:13.089	2025-08-26 18:56:13.088	\N
951	REDMI NOTE 10 PRO MAX	44	2025-08-26 18:56:13.095	2025-08-26 18:56:13.094	\N
952	REDMI NOTE 10S	44	2025-08-26 18:56:13.104	2025-08-26 18:56:13.104	\N
953	REDMI NOTE 11	44	2025-08-26 18:56:13.117	2025-08-26 18:56:13.116	\N
954	REDMI NOTE 11 4G	44	2025-08-26 18:56:13.126	2025-08-26 18:56:13.125	\N
955	REDMI NOTE 11 PLUS	44	2025-08-26 18:56:13.132	2025-08-26 18:56:13.131	\N
956	REDMI NOTE 11 PRO	44	2025-08-26 18:56:13.145	2025-08-26 18:56:13.141	\N
957	REDMI NOTE 11S	44	2025-08-26 18:56:13.153	2025-08-26 18:56:13.152	\N
958	REDMI NOTE 11T PRO	44	2025-08-26 18:56:13.159	2025-08-26 18:56:13.158	\N
959	REDMI NOTE 12 4G	44	2025-08-26 18:56:13.164	2025-08-26 18:56:13.163	\N
960	REDMI NOTE 12 5G	44	2025-08-26 18:56:13.17	2025-08-26 18:56:13.169	\N
961	REDMI NOTE 12s	44	2025-08-26 18:56:13.174	2025-08-26 18:56:13.173	\N
962	REDMI NOTE 13 PRO 4G	44	2025-08-26 18:56:13.184	2025-08-26 18:56:13.183	\N
963	REDMI NOTE 7	44	2025-08-26 18:56:13.195	2025-08-26 18:56:13.194	\N
964	REDMI NOTE 7 PRO	44	2025-08-26 18:56:13.204	2025-08-26 18:56:13.203	\N
965	REDMI NOTE 8	44	2025-08-26 18:56:13.212	2025-08-26 18:56:13.211	\N
966	REDMI NOTE 8 PRO	44	2025-08-26 18:56:13.224	2025-08-26 18:56:13.223	\N
967	REDMI NOTE 9	44	2025-08-26 18:56:13.233	2025-08-26 18:56:13.231	\N
968	REDMI NOTE 9 4G	44	2025-08-26 18:56:13.239	2025-08-26 18:56:13.238	\N
969	REDMI NOTE 9S	44	2025-08-26 18:56:13.244	2025-08-26 18:56:13.244	\N
970	REDMI NOTE 12 PRO 5G	44	2025-08-26 18:56:13.253	2025-08-26 18:56:13.252	\N
971	REDMI NOTE10 4G	44	2025-08-26 18:56:13.265	2025-08-26 18:56:13.263	\N
972	REDMI NOTE10 5G	44	2025-08-26 18:56:13.276	2025-08-26 18:56:13.275	\N
973	REDMI NOTE10 PRO	44	2025-08-26 18:56:13.283	2025-08-26 18:56:13.282	\N
974	REDMI NOTE10 PRO MAX	44	2025-08-26 18:56:13.291	2025-08-26 18:56:13.29	\N
975	REDMI NOTE10PRO	44	2025-08-26 18:56:13.299	2025-08-26 18:56:13.297	\N
976	REDMI NOTE10PRO 5G	44	2025-08-26 18:56:13.308	2025-08-26 18:56:13.307	\N
977	REDMI NOTE10S	44	2025-08-26 18:56:13.319	2025-08-26 18:56:13.318	\N
978	REDMI NOTE10X	44	2025-08-26 18:56:13.327	2025-08-26 18:56:13.327	\N
979	REDMI NOTE11 4G	44	2025-08-26 18:56:13.333	2025-08-26 18:56:13.332	\N
980	REDMI NOTE11 5G	44	2025-08-26 18:56:13.341	2025-08-26 18:56:13.34	\N
981	REDMI NOTE11 PLUS	44	2025-08-26 18:56:13.353	2025-08-26 18:56:13.35	\N
982	REDMI NOTE11 PRO	44	2025-08-26 18:56:13.36	2025-08-26 18:56:13.359	\N
983	REDMI NOTE11S	44	2025-08-26 18:56:13.372	2025-08-26 18:56:13.37	\N
984	REDMI NOTE11T PRO	44	2025-08-26 18:56:13.39	2025-08-26 18:56:13.389	\N
985	REDMI NOTE12 4G	44	2025-08-26 18:56:13.401	2025-08-26 18:56:13.399	\N
986	REDMI NOTE12 4G/5G	44	2025-08-26 18:56:13.41	2025-08-26 18:56:13.409	\N
987	REDMI NOTE12 5G	44	2025-08-26 18:56:13.422	2025-08-26 18:56:13.421	\N
988	REDMI NOTE12 PRO 5G	44	2025-08-26 18:56:13.435	2025-08-26 18:56:13.434	\N
989	REDMI NOTE12PRO 4G	44	2025-08-26 18:56:13.445	2025-08-26 18:56:13.444	\N
990	REDMI NOTE12S	44	2025-08-26 18:56:13.451	2025-08-26 18:56:13.45	\N
991	REDMI NOTE12T PRO	44	2025-08-26 18:56:13.46	2025-08-26 18:56:13.459	\N
992	REDMI NOTE13 5G	44	2025-08-26 18:56:13.469	2025-08-26 18:56:13.469	\N
993	REDMI NOTE7	44	2025-08-26 18:56:13.479	2025-08-26 18:56:13.478	\N
994	REDMI NOTE7 PRO	44	2025-08-26 18:56:13.487	2025-08-26 18:56:13.486	\N
995	REDMI NOTE8	44	2025-08-26 18:56:13.492	2025-08-26 18:56:13.492	\N
996	REDMI NOTE8 PRO	44	2025-08-26 18:56:13.501	2025-08-26 18:56:13.501	\N
997	REDMI NOTE9	44	2025-08-26 18:56:13.511	2025-08-26 18:56:13.51	\N
998	REDMI NOTE9 PRO	44	2025-08-26 18:56:13.521	2025-08-26 18:56:13.52	\N
999	REDMI NOTE9S	44	2025-08-26 18:56:13.527	2025-08-26 18:56:13.527	\N
1000	REDMI POCO X6PRO	44	2025-08-26 18:56:13.535	2025-08-26 18:56:13.535	\N
1001	REDMI10 5G	44	2025-08-26 18:56:13.544	2025-08-26 18:56:13.543	\N
1002	5030 1SE	48	2025-08-26 18:56:59.866	2025-08-26 18:56:59.865	\N
1003	5024	48	2025-08-26 18:57:10.845	2025-08-26 18:57:10.844	\N
1004	5028	48	2025-08-26 18:57:20.732	2025-08-26 18:57:20.729	\N
1005	A3 2020	56	2025-08-26 19:03:52.197	2025-08-26 19:03:52.196	\N
1006	A31	56	2025-08-26 19:03:52.206	2025-08-26 19:03:52.206	\N
1007	A34/A54	56	2025-08-26 19:03:52.218	2025-08-26 19:03:52.217	\N
1008	A5 2020	56	2025-08-26 19:03:52.229	2025-08-26 19:03:52.228	\N
1009	A51	56	2025-08-26 19:03:52.243	2025-08-26 19:03:52.241	\N
1010	A52	56	2025-08-26 19:03:52.251	2025-08-26 19:03:52.25	\N
1011	A52 LITE	56	2025-08-26 19:03:52.258	2025-08-26 19:03:52.257	\N
1012	A52/A72	56	2025-08-26 19:03:52.265	2025-08-26 19:03:52.264	\N
1013	A53	56	2025-08-26 19:03:52.272	2025-08-26 19:03:52.271	\N
1014	A53PLUS	56	2025-08-26 19:03:52.284	2025-08-26 19:03:52.277	\N
1015	A54	56	2025-08-26 19:03:52.292	2025-08-26 19:03:52.291	\N
1016	A7 2020	56	2025-08-26 19:03:52.297	2025-08-26 19:03:52.296	\N
1017	A71	56	2025-08-26 19:03:52.301	2025-08-26 19:03:52.301	\N
1018	A72 4G	56	2025-08-26 19:03:52.309	2025-08-26 19:03:52.308	\N
1019	A72S 5G	56	2025-08-26 19:03:52.323	2025-08-26 19:03:52.322	\N
1020	A7S 2020	56	2025-08-26 19:03:52.328	2025-08-26 19:03:52.328	\N
1021	AXON 11	56	2025-08-26 19:03:52.334	2025-08-26 19:03:52.333	\N
1022	AXON 20	56	2025-08-26 19:03:52.341	2025-08-26 19:03:52.34	\N
1023	AXON 30	56	2025-08-26 19:03:52.353	2025-08-26 19:03:52.352	\N
1024	AXON 30 PRO	56	2025-08-26 19:03:52.363	2025-08-26 19:03:52.362	\N
1025	AXON 40 LITE	56	2025-08-26 19:03:52.371	2025-08-26 19:03:52.37	\N
1026	AXON 40 PRO	56	2025-08-26 19:03:52.376	2025-08-26 19:03:52.376	\N
1027	AXON 40SE	56	2025-08-26 19:03:52.382	2025-08-26 19:03:52.381	\N
1028	AXON 50 LITE	56	2025-08-26 19:03:52.389	2025-08-26 19:03:52.388	\N
1029	AXON 60	56	2025-08-26 19:03:52.398	2025-08-26 19:03:52.397	\N
1030	AXON 60 LITE	56	2025-08-26 19:03:52.411	2025-08-26 19:03:52.41	\N
1031	L210	56	2025-08-26 19:03:52.417	2025-08-26 19:03:52.416	\N
1032	NOBIA N41	56	2025-08-26 19:03:52.426	2025-08-26 19:03:52.425	\N
1033	V SMART/2050	56	2025-08-26 19:03:52.431	2025-08-26 19:03:52.43	\N
1034	V10	56	2025-08-26 19:03:52.436	2025-08-26 19:03:52.436	\N
1035	V10 VITA	56	2025-08-26 19:03:52.443	2025-08-26 19:03:52.442	\N
1036	V20	56	2025-08-26 19:03:52.448	2025-08-26 19:03:52.447	\N
1037	V20 SMART 2050	56	2025-08-26 19:03:52.453	2025-08-26 19:03:52.452	\N
1038	V20 SMART 8010	56	2025-08-26 19:03:52.462	2025-08-26 19:03:52.46	\N
1039	V2020 5G	56	2025-08-26 19:03:52.482	2025-08-26 19:03:52.48	\N
1040	V2020 VITA	56	2025-08-26 19:03:52.492	2025-08-26 19:03:52.491	\N
1041	V30	56	2025-08-26 19:03:52.503	2025-08-26 19:03:52.502	\N
1042	V30 VITA	56	2025-08-26 19:03:52.511	2025-08-26 19:03:52.51	\N
1043	V40	56	2025-08-26 19:03:52.52	2025-08-26 19:03:52.519	\N
1044	V40 PRO	56	2025-08-26 19:03:52.528	2025-08-26 19:03:52.527	\N
1045	V40 SMART	56	2025-08-26 19:03:52.535	2025-08-26 19:03:52.534	\N
1046	V40 VITA	56	2025-08-26 19:03:52.539	2025-08-26 19:03:52.539	\N
1047	V40S SMART	56	2025-08-26 19:03:52.547	2025-08-26 19:03:52.546	\N
1048	V41 SMART	56	2025-08-26 19:03:52.559	2025-08-26 19:03:52.557	\N
1049	V41S SMART	56	2025-08-26 19:03:52.572	2025-08-26 19:03:52.571	\N
1050	V50 SMART	56	2025-08-26 19:03:52.579	2025-08-26 19:03:52.578	\N
1051	V9	56	2025-08-26 19:03:52.585	2025-08-26 19:03:52.584	\N
1052	V9 LITE	56	2025-08-26 19:03:52.595	2025-08-26 19:03:52.594	\N
1065	iPhone 13	37	2025-08-27 11:42:21.893	2025-08-27 11:42:21.891	\N
1066	iPhone 6G	37	2025-08-27 11:42:32.342	2025-08-27 11:42:32.341	\N
1067	iPhone 6 Plus	37	2025-08-27 11:44:31.157	2025-08-27 11:44:31.156	\N
1068	iPhone 7	37	2025-08-27 11:44:36.273	2025-08-27 11:44:36.272	\N
1069	iPhone 7 Plus	37	2025-08-27 11:44:42.819	2025-08-27 11:44:42.818	\N
1070	iPhone 8	37	2025-08-27 11:44:52.058	2025-08-27 11:44:52.057	\N
1071	iPhone 8 Plus	37	2025-08-27 11:44:57.74	2025-08-27 11:44:57.738	\N
1072	iPhone 11	37	2025-08-27 11:45:08.926	2025-08-27 11:45:08.925	\N
1073	iPhone 11 Pro	37	2025-08-27 11:45:18.341	2025-08-27 11:45:18.339	\N
1074	iPhone 11 Pro Max	37	2025-08-27 11:45:26.228	2025-08-27 11:45:26.227	\N
1075	iPhone 12 Mini	37	2025-08-27 11:45:42.815	2025-08-27 11:45:42.814	\N
1076	iPhone 12 Pro	37	2025-08-27 11:45:51.743	2025-08-27 11:45:51.742	\N
1077	iPhone 12 Pro Max	37	2025-08-27 11:46:00.588	2025-08-27 11:46:00.587	\N
1078	iPhone 13	37	2025-08-27 11:46:24.54	2025-08-27 11:46:24.539	\N
1079	iPhone 13 Mini	37	2025-08-27 11:46:35.251	2025-08-27 11:46:35.25	\N
1080	iPhone 13 Pro	37	2025-08-27 11:46:43.64	2025-08-27 11:46:43.639	\N
1081	iPhone 13 Pro Max	37	2025-08-27 11:46:51.657	2025-08-27 11:46:51.656	\N
1082	iPhone 14 Pro Max	37	2025-08-27 11:47:21.564	2025-08-27 11:47:21.563	\N
1083	iPhone 14 Plus	37	2025-08-27 11:47:33.246	2025-08-27 11:47:33.245	\N
1084	iPhone 15 Pro Max	37	2025-08-27 11:47:56.548	2025-08-27 11:47:56.547	\N
1085	iPhone 15 Ultra	37	2025-08-27 11:48:15.511	2025-08-27 11:48:15.51	\N
1086	iPhone X	37	2025-08-27 11:48:31.699	2025-08-27 11:48:31.698	\N
1087	iPhone XR	37	2025-08-27 11:48:42.773	2025-08-27 11:48:42.772	\N
1088	iPhone XS	37	2025-08-27 11:48:51.854	2025-08-27 11:48:51.853	\N
1089	iPhone XS Max	37	2025-08-27 11:49:11.995	2025-08-27 11:49:11.994	\N
1090	iPhone SE 2000	37	2025-08-27 11:49:22.084	2025-08-27 11:49:22.083	\N
1091	Bocinas inalambricas 	59	2025-09-03 19:51:11.043	2025-09-03 19:51:11.042	\N
1093	Cargadores 	59	2025-09-03 19:51:34.594	2025-09-03 19:51:34.593	\N
1094	Cargadores turbo 	59	2025-09-03 19:51:49.661	2025-09-03 19:51:49.66	\N
1095	Audífonos bluetooth	59	2025-09-03 19:52:21.801	2025-09-03 19:52:21.799	\N
1096	Audífonos alambricos	59	2025-09-03 19:52:40.389	2025-09-03 19:52:40.388	\N
1097	Soportes para celular 	59	2025-09-03 19:53:17.644	2025-09-03 19:53:17.643	\N
1098	Cables para carga 	59	2025-09-03 19:53:32.707	2025-09-03 19:53:32.706	\N
1099	Varios	60	2025-09-05 18:15:20.07	2025-09-05 18:15:20.069	Android
1100	Varios 	60	2025-09-05 18:15:42.488	2025-09-05 18:15:42.487	Todos los modelos Apple
1101	HERRAMIENTA	63	2025-09-09 22:48:21.613	2025-09-09 22:48:21.612	\N
1102	HERRAMIENTA	64	2025-09-09 22:48:38.278	2025-09-09 22:48:38.277	\N
1103	HERR	65	2025-09-09 22:48:49.431	2025-09-09 22:48:49.429	\N
1104	HERRAMIENTA	62	2025-09-09 22:49:02.418	2025-09-09 22:49:02.417	\N
1105	HERRAMIENTA	61	2025-09-09 22:50:21.476	2025-09-09 22:50:21.475	\N
1106	HERRAMIENTA	66	2025-09-09 22:59:26.801	2025-09-09 22:59:26.8	\N
1107	HERRAMIENTA	67	2025-09-09 23:11:23.36	2025-09-09 23:11:23.359	\N
1108	Sim	69	2025-09-20 18:02:24.661	2025-09-20 18:02:24.66	\N
1109	Sim	68	2025-09-20 18:02:43.011	2025-09-20 18:02:43.01	\N
1110	Sim	71	2025-09-20 18:02:59.302	2025-09-20 18:02:59.301	\N
1111	Sim	70	2025-09-20 18:03:18.352	2025-09-20 18:03:18.351	\N
1112	nubia music z2353	56	2025-09-28 21:05:03.309	2025-09-28 21:05:03.308	\N
1113	a56	38	2025-10-03 23:13:10.701	2025-10-03 23:13:10.7	\N
1114	prueba2	72	2025-10-09 15:18:27.507	2025-10-09 15:18:27.505	\N
1115	m15 5g	38	2025-10-19 19:47:46.708	2025-10-19 19:47:46.707	\N
1116	reno 13 5g	46	2025-10-20 16:04:52.486	2025-10-20 16:04:52.485	\N
1117	FLIP 5	73	2025-10-22 18:02:19.168	2025-10-22 18:02:19.167	\N
1118	HDA	74	2025-10-23 18:12:23.473	2025-10-23 18:12:23.472	\N
1119	Tab A9 plus	38	2025-11-19 17:30:59.979	2025-11-19 17:30:59.978	\N
\.
COPY public.pagos (id, ticket_id, monto, metodo, referencia, created_at, updated_at) FROM stdin;
101	78	625	TARJETA	\N	2025-10-09 18:18:54.037	2025-10-09 18:18:54.037
102	80	200	EFECTIVO	\N	2025-10-09 23:05:18.381	2025-10-09 23:05:18.381
30	19	200	EFECTIVO	\N	2025-09-01 17:50:21.927	2025-09-01 17:50:21.927
31	20	50	EFECTIVO	\N	2025-09-01 19:00:17.163	2025-09-01 19:00:17.163
32	21	300	EFECTIVO	\N	2025-09-01 21:16:45.993	2025-09-01 21:16:45.993
33	21	0	EFECTIVO	\N	2025-09-01 21:16:47.189	2025-09-01 21:16:47.189
34	22	350	TRANSFERENCIA	\N	2025-09-05 16:23:54.533	2025-09-05 16:23:54.533
36	22	600	TRANSFERENCIA	\N	2025-09-06 22:36:19.926	2025-09-06 23:15:44.876
35	22	0	TRANSFERENCIA	\N	2025-09-06 22:36:08.923	2025-09-06 23:15:52.394
37	24	100	EFECTIVO	\N	2025-09-08 19:53:02.936	2025-09-08 19:53:02.936
38	25	2289	TARJETA	\N	2025-09-10 00:00:46.51	2025-09-10 00:00:46.51
39	26	800	EFECTIVO	\N	2025-09-10 16:36:23.234	2025-09-10 16:36:23.234
40	23	550	EFECTIVO	\N	2025-09-10 18:41:57.307	2025-09-10 18:42:16.06
41	27	50	EFECTIVO	\N	2025-09-11 18:24:30.922	2025-09-11 18:24:30.922
42	28	150	EFECTIVO	\N	2025-09-11 23:42:47.826	2025-09-11 23:42:47.826
43	29	0	TARJETA	\N	2025-09-13 20:19:02.622	2025-09-13 20:19:02.622
44	29	300	TARJETA	\N	2025-09-13 20:19:07.485	2025-09-13 20:20:34.091
45	30	351.98	EFECTIVO	\N	2025-09-13 23:49:24.206	2025-09-13 23:49:24.206
46	28	100	EFECTIVO	\N	2025-09-13 23:51:04.651	2025-09-13 23:51:04.651
103	78	0	EFECTIVO	\N	2025-10-10 16:41:43.052	2025-10-10 16:43:30.309
48	32	348	EFECTIVO	\N	2025-09-21 00:04:24.38	2025-09-21 00:04:24.38
49	33	100	EFECTIVO	\N	2025-09-21 00:06:50.158	2025-09-21 00:06:50.158
50	35	200	EFECTIVO	\N	2025-09-21 20:58:27.294	2025-09-21 20:58:27.294
51	36	200	EFECTIVO	\N	2025-09-22 22:46:22.071	2025-09-22 22:46:22.071
53	37	60	EFECTIVO	\N	2025-09-22 23:48:25.639	2025-09-22 23:48:25.639
54	38	2000	EFECTIVO	\N	2025-09-23 16:34:55.632	2025-09-23 16:34:55.632
55	39	1000	EFECTIVO	\N	2025-09-23 16:40:53.074	2025-09-23 16:40:53.074
58	31	556	TRANSFERENCIA	\N	2025-09-23 21:15:21.849	2025-09-23 21:15:21.849
59	36	400	EFECTIVO	\N	2025-09-23 22:05:30.974	2025-09-23 22:05:30.974
60	34	1700	EFECTIVO	\N	2025-09-23 22:12:43.104	2025-09-23 22:12:43.104
61	42	600	TRANSFERENCIA	\N	2025-09-23 22:16:24.081	2025-09-23 22:16:24.081
62	41	350	EFECTIVO	\N	2025-09-26 20:16:04.355	2025-09-26 20:16:04.355
63	45	300	TARJETA	\N	2025-09-26 22:45:14.243	2025-09-26 22:45:14.243
64	47	480	EFECTIVO	\N	2025-09-26 23:07:28.659	2025-09-26 23:07:28.659
65	44	600	EFECTIVO	\N	2025-09-26 23:51:01.297	2025-09-26 23:51:01.297
66	49	80	EFECTIVO	\N	2025-09-27 20:10:49.479	2025-09-27 20:10:49.479
67	50	150	EFECTIVO	\N	2025-09-27 20:12:45.17	2025-09-27 20:12:45.17
68	51	250	TARJETA	\N	2025-09-27 20:16:40.93	2025-09-27 20:16:40.93
69	48	350	EFECTIVO	\N	2025-09-27 23:40:07.772	2025-09-27 23:40:07.772
70	53	200	EFECTIVO	\N	2025-09-28 19:35:00.586	2025-09-28 19:35:00.586
71	55	200	TARJETA	\N	2025-09-29 21:48:52.333	2025-09-29 21:48:52.333
72	55	0	EFECTIVO	\N	2025-09-29 21:48:53.829	2025-09-29 21:48:53.829
74	57	0	EFECTIVO	\N	2025-09-30 22:48:16.845	2025-09-30 22:48:16.845
75	57	200	EFECTIVO	\N	2025-09-30 22:48:21.459	2025-09-30 22:48:21.459
76	43	400	EFECTIVO	\N	2025-09-30 23:03:30.859	2025-09-30 23:03:30.859
77	58	300	EFECTIVO	\N	2025-09-30 23:34:12.014	2025-09-30 23:34:12.014
78	59	500	EFECTIVO	\N	2025-10-01 17:51:00.095	2025-10-01 17:51:00.095
80	58	300	EFECTIVO	\N	2025-10-01 23:20:36.417	2025-10-01 23:20:36.417
81	59	100	EFECTIVO	\N	2025-10-01 23:57:55.728	2025-10-01 23:57:55.728
82	62	600	EFECTIVO	\N	2025-10-02 19:26:18.811	2025-10-02 19:26:18.811
83	63	500	TARJETA	\N	2025-10-03 23:16:19.933	2025-10-03 23:16:19.933
84	62	200	EFECTIVO	\N	2025-10-04 16:49:18.225	2025-10-04 16:49:18.225
87	67	200	EFECTIVO	\N	2025-10-06 21:41:59.222	2025-10-06 21:41:59.222
88	68	200	TRANSFERENCIA	\N	2025-10-07 16:05:11.295	2025-10-07 16:05:11.295
89	69	800	EFECTIVO	\N	2025-10-07 17:35:55.958	2025-10-07 17:35:55.958
91	66	300	EFECTIVO	\N	2025-10-08 20:09:01.989	2025-10-08 20:09:01.989
90	70	0	EFECTIVO	\N	2025-10-08 20:07:21.133	2025-10-08 20:11:57.051
92	70	200	TARJETA	\N	2025-10-08 22:24:53.332	2025-10-08 22:24:53.332
104	78	0	EFECTIVO	\N	2025-10-10 16:45:02.211	2025-10-10 16:45:02.211
105	81	700	EFECTIVO	\N	2025-10-10 17:43:24.458	2025-10-10 17:43:24.458
106	79	600	EFECTIVO	\N	2025-10-10 22:20:50.347	2025-10-10 22:20:50.347
107	64	675	EFECTIVO	\N	2025-10-10 22:29:32.939	2025-10-10 22:29:57.099
108	64	0	EFECTIVO	\N	2025-10-10 22:29:59.479	2025-10-10 22:29:59.479
109	54	400	EFECTIVO	\N	2025-10-11 15:06:27.626	2025-10-11 15:06:27.626
110	83	250	EFECTIVO	\N	2025-10-11 16:07:15.841	2025-10-11 16:07:15.841
111	83	0	EFECTIVO	\N	2025-10-11 16:07:18.242	2025-10-11 16:07:18.242
112	84	500	TARJETA	\N	2025-10-11 19:13:01.407	2025-10-11 19:13:22.804
113	83	250	TARJETA	\N	2025-10-11 23:23:56.112	2025-10-11 23:23:56.112
114	86	300	EFECTIVO	\N	2025-10-13 18:04:29.682	2025-10-13 18:04:29.682
115	85	500	EFECTIVO	\N	2025-10-13 20:31:42.111	2025-10-13 20:31:42.111
116	82	1500	TRANSFERENCIA	\N	2025-10-13 20:32:45.418	2025-10-13 20:34:29.073
117	86	300	EFECTIVO	\N	2025-10-13 23:29:57.662	2025-10-13 23:29:57.662
118	88	200	TARJETA	\N	2025-10-14 19:06:53.63	2025-10-14 19:06:53.63
119	88	0	EFECTIVO	\N	2025-10-14 19:06:54.517	2025-10-14 19:06:54.517
120	85	1500	EFECTIVO	\N	2025-10-14 21:32:33.403	2025-10-14 21:32:33.403
121	89	400	TARJETA	\N	2025-10-15 22:00:29.114	2025-10-15 22:00:29.114
122	89	275	EFECTIVO	\N	2025-10-16 21:12:39.591	2025-10-16 21:12:39.591
123	91	800	TARJETA	\N	2025-10-16 21:18:49.07	2025-10-16 21:18:49.07
124	90	350	TARJETA	\N	2025-10-16 21:22:51.157	2025-10-16 21:22:51.157
125	52	200	EFECTIVO	\N	2025-10-16 23:19:43.874	2025-10-16 23:19:43.874
126	92	1000	EFECTIVO	\N	2025-10-17 17:58:23.22	2025-10-17 17:58:23.22
127	87	1000	TRANSFERENCIA	\N	2025-10-17 20:59:44.505	2025-10-17 20:59:51.147
129	93	1500	TARJETA	\N	2025-10-18 19:52:39.148	2025-10-18 19:52:39.148
128	92	1000	TARJETA	\N	2025-10-18 19:50:49.146	2025-10-18 21:28:53.234
130	94	350	EFECTIVO	\N	2025-10-19 19:49:32.383	2025-10-19 19:49:32.383
131	95	300	EFECTIVO	\N	2025-10-20 16:07:52.813	2025-10-20 16:07:52.813
132	97	200	EFECTIVO	\N	2025-10-22 19:26:04.016	2025-10-22 19:26:04.016
133	99	650	EFECTIVO	\N	2025-10-23 15:35:40.191	2025-10-23 15:35:40.191
134	95	400	EFECTIVO	\N	2025-10-23 16:22:22.132	2025-10-23 16:22:22.132
135	98	200	TARJETA	\N	2025-10-24 21:31:00.67	2025-10-24 21:33:15.33
136	102	200	EFECTIVO	\N	2025-10-25 18:04:54.745	2025-10-25 18:04:54.745
137	103	200	EFECTIVO	\N	2025-10-27 19:58:52.406	2025-10-27 19:58:52.406
140	105	600	TARJETA	\N	2025-10-27 22:47:09.741	2025-10-27 22:47:09.741
139	104	0.1	EFECTIVO	\N	2025-10-27 22:36:55.307	2025-10-27 23:00:49.084
145	108	200	TARJETA	\N	2025-10-28 20:11:22.846	2025-10-28 20:11:22.846
138	104	0.1	EFECTIVO	\N	2025-10-27 22:33:19.951	2025-10-27 23:01:06.062
141	106	200	EFECTIVO	\N	2025-10-28 00:14:23.338	2025-10-28 00:14:23.338
142	106	0.01	EFECTIVO	\N	2025-10-28 00:30:26.464	2025-10-28 00:31:02.264
143	106	0	EFECTIVO	\N	2025-10-28 00:31:04.552	2025-10-28 00:31:04.552
144	107	200	EFECTIVO	\N	2025-10-28 00:33:04.897	2025-10-28 00:33:04.897
146	110	100	EFECTIVO	\N	2025-10-28 23:14:53.946	2025-10-28 23:14:53.946
147	111	200	EFECTIVO	\N	2025-10-28 23:41:43.626	2025-10-28 23:41:43.626
148	110	150	EFECTIVO	\N	2025-10-29 23:19:42.028	2025-10-29 23:19:42.028
149	113	150	EFECTIVO	\N	2025-10-30 18:52:01.545	2025-10-30 18:52:01.545
150	114	300	EFECTIVO	\N	2025-10-30 23:26:28.427	2025-10-30 23:26:28.427
151	116	200	EFECTIVO	\N	2025-10-31 16:38:47.787	2025-10-31 16:38:47.787
152	111	900	EFECTIVO	\N	2025-10-31 19:51:59.898	2025-10-31 19:51:59.898
153	116	200	EFECTIVO	\N	2025-10-31 20:54:58.978	2025-10-31 20:54:58.978
154	118	200	EFECTIVO	\N	2025-10-31 21:13:01.838	2025-10-31 21:13:01.838
155	115	600	TARJETA	\N	2025-10-31 21:41:33.941	2025-10-31 21:41:33.941
156	115	0	EFECTIVO	\N	2025-10-31 21:41:35.494	2025-10-31 21:41:35.494
157	119	0	TARJETA	\N	2025-11-01 18:13:27.657	2025-11-01 18:13:27.657
158	119	200	TARJETA	\N	2025-11-01 18:15:07.593	2025-11-01 18:15:07.593
159	109	600	TRANSFERENCIA	\N	2025-11-01 18:16:12.254	2025-11-01 18:16:12.254
160	122	200	EFECTIVO	\N	2025-11-01 20:55:14.184	2025-11-01 20:55:14.184
161	121	600	TARJETA	\N	2025-11-01 23:18:30.503	2025-11-01 23:18:30.503
162	120	600	TARJETA	\N	2025-11-01 23:19:08.034	2025-11-01 23:19:08.034
163	123	200	TARJETA	\N	2025-11-02 22:00:36.32	2025-11-02 22:01:21.9
164	124	250	EFECTIVO	\N	2025-11-03 19:06:20.589	2025-11-03 19:06:20.589
165	124	350	EFECTIVO	\N	2025-11-03 22:40:57.893	2025-11-03 22:40:57.893
166	126	130	EFECTIVO	\N	2025-11-04 23:17:57.942	2025-11-04 23:17:57.942
167	127	200	EFECTIVO	\N	2025-11-05 16:28:08.303	2025-11-05 16:28:08.303
168	128	600	EFECTIVO	\N	2025-11-05 23:27:25.35	2025-11-05 23:27:25.35
169	130	100	EFECTIVO	\N	2025-11-06 17:00:27.151	2025-11-06 17:00:27.151
170	131	350	TARJETA	603878	2025-11-06 17:53:27.435	2025-11-06 17:54:29.024
171	132	25	EFECTIVO	\N	2025-11-06 22:22:31.458	2025-11-06 22:22:31.458
172	133	800	EFECTIVO	\N	2025-11-06 23:55:25.89	2025-11-06 23:55:25.89
173	129	350	EFECTIVO	\N	2025-11-07 22:29:53.987	2025-11-07 22:29:53.987
174	136	100	EFECTIVO	\N	2025-11-08 20:27:42.981	2025-11-08 20:27:42.981
175	133	1400	EFECTIVO	\N	2025-11-08 21:53:12.422	2025-11-08 21:53:12.422
176	118	450	EFECTIVO	\N	2025-11-09 19:00:18.309	2025-11-09 19:00:18.309
177	136	100	EFECTIVO	\N	2025-11-09 19:26:58.674	2025-11-09 19:27:29.141
179	138	200	TARJETA	\N	2025-11-09 22:13:33.623	2025-11-09 22:17:20.156
180	137	200	EFECTIVO	\N	2025-11-09 22:19:02.415	2025-11-09 22:19:02.415
181	134	150	EFECTIVO	\N	2025-11-10 20:42:00.523	2025-11-10 20:42:00.523
182	139	200	TARJETA	\N	2025-11-10 21:14:36.451	2025-11-10 21:14:36.451
183	130	100	EFECTIVO	\N	2025-11-10 21:54:53.977	2025-11-10 21:54:53.977
184	140	200	EFECTIVO	\N	2025-11-10 22:02:30.136	2025-11-10 22:02:30.136
185	141	1200	TARJETA	\N	2025-11-12 00:09:14.019	2025-11-12 00:09:48.692
186	143	500	EFECTIVO	\N	2025-11-12 17:29:21.226	2025-11-12 17:29:21.226
187	145	300	EFECTIVO	\N	2025-11-12 18:02:02.141	2025-11-12 18:02:02.141
188	146	200	TARJETA	\N	2025-11-12 18:37:24.197	2025-11-12 18:37:24.197
189	146	0	EFECTIVO	\N	2025-11-12 18:37:24.825	2025-11-12 18:37:24.825
190	147	350	TARJETA	\N	2025-11-12 22:47:16.226	2025-11-12 22:47:16.226
191	145	750	EFECTIVO	\N	2025-11-12 23:24:11.157	2025-11-12 23:24:11.157
192	148	400	TARJETA	\N	2025-11-12 23:28:48.357	2025-11-12 23:28:48.357
193	149	200	TARJETA	\N	2025-11-12 23:38:38.919	2025-11-12 23:38:38.919
194	151	200	EFECTIVO	\N	2025-11-13 00:18:56.956	2025-11-13 00:18:56.956
195	140	150	EFECTIVO	\N	2025-11-13 15:54:18.665	2025-11-13 15:54:18.665
196	142	50	EFECTIVO	\N	2025-11-13 18:11:22.194	2025-11-13 18:11:22.194
197	142	0	EFECTIVO	\N	2025-11-13 18:11:23.835	2025-11-13 18:11:23.835
198	150	50	EFECTIVO	\N	2025-11-13 18:13:18.824	2025-11-13 18:13:18.824
200	153	600	TARJETA	\N	2025-11-14 15:28:57.102	2025-11-14 15:28:57.102
201	152	200	EFECTIVO	\N	2025-11-14 15:59:43.351	2025-11-14 15:59:43.351
202	143	400	TARJETA	\N	2025-11-14 18:59:08.162	2025-11-14 18:59:08.162
204	151	400	EFECTIVO	\N	2025-11-14 22:50:43.157	2025-11-14 22:50:43.157
203	130	0	EFECTIVO	\N	2025-11-14 22:04:49.016	2025-11-14 22:55:00.402
205	154	200	TARJETA	\N	2025-11-15 18:49:13.632	2025-11-15 18:49:13.632
206	154	0	EFECTIVO	\N	2025-11-15 18:49:15.038	2025-11-15 18:49:15.038
208	156	2920	TARJETA	\N	2025-11-15 19:13:52.839	2025-11-15 19:13:52.839
209	136	600	EFECTIVO	\N	2025-11-15 23:44:25.501	2025-11-15 23:44:25.501
210	114	300	EFECTIVO	\N	2025-11-17 16:30:06.688	2025-11-17 16:30:06.688
211	114	0	EFECTIVO	\N	2025-11-17 16:30:10.991	2025-11-17 16:30:10.991
212	157	250	EFECTIVO	\N	2025-11-17 20:45:36.95	2025-11-17 20:45:36.95
207	155	0	EFECTIVO	\N	2025-11-15 18:58:46.413	2025-11-17 22:14:27.344
213	158	200	EFECTIVO	\N	2025-11-18 20:23:33.026	2025-11-18 20:23:33.026
214	152	300	TARJETA	\N	2025-11-18 21:39:08.899	2025-11-18 21:39:08.899
215	159	1000	TRANSFERENCIA	\N	2025-11-18 21:49:50.982	2025-11-18 21:49:50.982
216	161	200	EFECTIVO	\N	2025-11-19 17:35:12.157	2025-11-19 17:35:12.157
217	160	150	TARJETA	\N	2025-11-19 18:36:55.423	2025-11-19 18:36:55.423
218	162	200	EFECTIVO	\N	2025-11-19 20:19:37.318	2025-11-19 20:19:37.318
219	161	500	EFECTIVO	\N	2025-11-20 19:21:52.382	2025-11-20 19:21:52.382
220	165	150	TARJETA	\N	2025-11-21 18:29:08.181	2025-11-21 18:29:08.181
221	164	200	TARJETA	\N	2025-11-21 18:29:34.973	2025-11-21 18:29:34.973
222	163	350	TRANSFERENCIA	\N	2025-11-21 18:34:19.703	2025-11-21 18:34:19.703
223	168	300	EFECTIVO	\N	2025-11-22 19:13:48.864	2025-11-22 19:13:48.864
224	167	300	EFECTIVO	\N	2025-11-22 19:14:03.269	2025-11-22 19:14:03.269
225	169	200	EFECTIVO	\N	2025-11-22 19:52:34.959	2025-11-22 19:52:34.959
226	125	750	EFECTIVO	\N	2025-11-22 22:34:00.752	2025-11-22 22:34:00.752
227	167	250	EFECTIVO	\N	2025-11-22 23:32:54.343	2025-11-22 23:32:54.343
228	168	250	EFECTIVO	\N	2025-11-22 23:41:46.855	2025-11-22 23:41:46.855
229	170	188	EFECTIVO	\N	2025-11-23 19:21:15.34	2025-11-23 19:21:15.34
199	135	1200	TARJETA	\N	2025-11-13 22:04:56.796	2025-11-23 19:49:00.469
230	173	150	TARJETA	\N	2025-11-23 21:32:41.04	2025-11-23 21:32:41.04
231	174	600	EFECTIVO	\N	2025-11-24 15:53:54.714	2025-11-24 15:54:12.515
232	176	89	EFECTIVO	\N	2025-11-24 18:25:24.151	2025-11-24 18:25:24.151
233	174	50	EFECTIVO	\N	2025-11-24 23:00:54.386	2025-11-24 23:00:54.386
234	177	200	EFECTIVO	\N	2025-11-24 23:38:06.654	2025-11-24 23:38:06.654
235	157	350	EFECTIVO	\N	2025-11-24 23:56:13.021	2025-11-24 23:56:13.021
\.
COPY public.pasos_reparacion_frecuente (id, reparacion_frecuente_id, descripcion, orden, created_at, updated_at) FROM stdin;
3	1	Asegurarse de sellar bien antes de cerrar	0	2025-06-18 00:08:07.746	2025-06-18 00:08:07.746
4	2	Asegurarse de que esté cargando adecuadamente antes de cerrar	0	2025-06-18 00:08:23.812	2025-06-18 00:08:23.812
5	3	realizar limpieza de centro de carga con alcohol isopropílico y cepillo  	0	2025-08-18 20:12:41.658	2025-08-18 20:12:41.658
6	4	se realiza diagnostico para dar presupuesto final	0	2025-08-19 15:35:10.977	2025-08-19 15:35:10.977
\.
COPY public.permisos (id, codigo, nombre, descripcion, categoria, created_at, updated_at) FROM stdin;
185	DASHBOARD_VIEW	Ver Dashboard	Permite ver el dashboard principal	DASHBOARD	2025-06-17 21:30:43.088	2025-06-17 21:30:43.088
186	COSTS_VIEW	Ver Costos	Permite ver la sección de costos	COSTS	2025-06-17 21:30:43.107	2025-06-17 21:30:43.107
187	COSTS_EDIT	Editar Costos	Permite editar información de costos	COSTS	2025-06-17 21:30:43.107	2025-06-17 21:30:43.107
188	CATALOG_VIEW	Ver Catálogo	Permite ver el catálogo	CATALOG	2025-06-17 21:30:43.108	2025-06-17 21:30:43.108
189	CATALOG_CREATE	Crear Catálogo	Permite crear elementos en el catálogo	CATALOG	2025-06-17 21:30:43.109	2025-06-17 21:30:43.109
190	CATALOG_EDIT	Editar Catálogo	Permite editar elementos del catálogo	CATALOG	2025-06-17 21:30:43.11	2025-06-17 21:30:43.11
191	CATALOG_DELETE	Eliminar Catálogo	Permite eliminar elementos del catálogo	CATALOG	2025-06-17 21:30:43.111	2025-06-17 21:30:43.111
192	INVENTORY_VIEW	Ver Inventario	Permite ver el inventario	INVENTORY	2025-06-17 21:30:43.112	2025-06-17 21:30:43.112
193	INVENTORY_CREATE	Crear Inventario	Permite crear elementos en el inventario	INVENTORY	2025-06-17 21:30:43.114	2025-06-17 21:30:43.114
194	INVENTORY_EDIT	Editar Inventario	Permite editar elementos del inventario	INVENTORY	2025-06-17 21:30:43.114	2025-06-17 21:30:43.114
195	INVENTORY_DELETE	Eliminar Inventario	Permite eliminar elementos del inventario	INVENTORY	2025-06-17 21:30:43.115	2025-06-17 21:30:43.115
196	CLIENTS_VIEW	Ver Clientes	Permite ver la lista de clientes	CLIENTS	2025-06-17 21:30:43.116	2025-06-17 21:30:43.116
197	CLIENTS_CREATE	Crear Cliente	Permite crear nuevos clientes	CLIENTS	2025-06-17 21:30:43.116	2025-06-17 21:30:43.116
198	CLIENTS_EDIT	Editar Cliente	Permite editar clientes existentes	CLIENTS	2025-06-17 21:30:43.117	2025-06-17 21:30:43.117
199	CLIENTS_DELETE	Eliminar Cliente	Permite eliminar clientes	CLIENTS	2025-06-17 21:30:43.117	2025-06-17 21:30:43.117
200	TICKETS_VIEW	Ver Tickets	Permite ver la lista de tickets	TICKETS	2025-06-17 21:30:43.118	2025-06-17 21:30:43.118
201	TICKETS_VIEW_DETAIL	Ver Detalle de Ticket	Permite ver el detalle de un ticket	TICKETS	2025-06-17 21:30:43.119	2025-06-17 21:30:43.119
202	TICKETS_CREATE	Crear Ticket	Permite crear nuevos tickets	TICKETS	2025-06-17 21:30:43.119	2025-06-17 21:30:43.119
203	TICKETS_EDIT	Editar Ticket	Permite editar tickets existentes	TICKETS	2025-06-17 21:30:43.12	2025-06-17 21:30:43.12
204	TICKETS_DELETE	Eliminar Ticket	Permite eliminar tickets	TICKETS	2025-06-17 21:30:43.121	2025-06-17 21:30:43.121
205	TICKETS_ASSIGN	Asignar Ticket	Permite asignar tickets a técnicos	TICKETS	2025-06-17 21:30:43.121	2025-06-17 21:30:43.121
206	REPAIRS_VIEW	Ver Reparaciones	Permite ver las reparaciones	REPAIRS	2025-06-17 21:30:43.122	2025-06-17 21:30:43.122
207	REPAIRS_CREATE	Crear Reparación	Permite crear nuevas reparaciones	REPAIRS	2025-06-17 21:30:43.122	2025-06-17 21:30:43.122
208	REPAIRS_EDIT	Editar Reparación	Permite editar reparaciones existentes	REPAIRS	2025-06-17 21:30:43.123	2025-06-17 21:30:43.123
209	REPAIRS_DELETE	Eliminar Reparación	Permite eliminar reparaciones	REPAIRS	2025-06-17 21:30:43.123	2025-06-17 21:30:43.123
210	USERS_VIEW	Ver Usuarios	Permite ver la lista de usuarios	USERS	2025-06-17 21:30:43.124	2025-06-17 21:30:43.124
211	USERS_CREATE	Crear Usuario	Permite crear nuevos usuarios	USERS	2025-06-17 21:30:43.124	2025-06-17 21:30:43.124
212	USERS_EDIT	Editar Usuario	Permite editar usuarios existentes	USERS	2025-06-17 21:30:43.125	2025-06-17 21:30:43.125
213	USERS_DELETE	Eliminar Usuario	Permite eliminar usuarios	USERS	2025-06-17 21:30:43.125	2025-06-17 21:30:43.125
214	ROLES_VIEW	Ver Roles	Permite ver la lista de roles	ROLES	2025-06-17 21:30:43.126	2025-06-17 21:30:43.126
215	ROLES_CREATE	Crear Rol	Permite crear nuevos roles	ROLES	2025-06-17 21:30:43.127	2025-06-17 21:30:43.127
216	ROLES_EDIT	Editar Rol	Permite editar roles existentes	ROLES	2025-06-17 21:30:43.128	2025-06-17 21:30:43.128
217	ROLES_DELETE	Eliminar Rol	Permite eliminar roles	ROLES	2025-06-17 21:30:43.129	2025-06-17 21:30:43.129
218	PERMISSIONS_VIEW	Ver Permisos	Permite ver la lista de permisos	PERMISSIONS	2025-06-17 21:30:43.13	2025-06-17 21:30:43.13
219	COLLECTION_POINTS_VIEW	Ver Puntos de Recolección	Permite ver los puntos de recolección	COLLECTION_POINTS	2025-06-17 21:30:43.131	2025-06-17 21:30:43.131
220	COLLECTION_POINTS_CREATE	Crear Punto de Recolección	Permite crear nuevos puntos de recolección	COLLECTION_POINTS	2025-06-17 21:30:43.132	2025-06-17 21:30:43.132
221	COLLECTION_POINTS_EDIT	Editar Punto de Recolección	Permite editar puntos de recolección existentes	COLLECTION_POINTS	2025-06-17 21:30:43.133	2025-06-17 21:30:43.133
222	COLLECTION_POINTS_DELETE	Eliminar Punto de Recolección	Permite eliminar puntos de recolección	COLLECTION_POINTS	2025-06-17 21:30:43.133	2025-06-17 21:30:43.133
223	PUNTO_USERS_VIEW	Ver Usuarios del Punto	Permite ver los usuarios asociados al punto de reparación	Punto de Reparación	2025-06-17 21:30:43.501	2025-06-17 21:30:43.501
224	PUNTO_USERS_CREATE	Crear Usuarios del Punto	Permite crear nuevos usuarios en el punto de reparación	Punto de Reparación	2025-06-17 21:30:43.502	2025-06-17 21:30:43.502
225	PUNTO_USERS_EDIT	Editar Usuarios del Punto	Permite editar usuarios del punto de reparación	Punto de Reparación	2025-06-17 21:30:43.502	2025-06-17 21:30:43.502
226	PUNTO_USERS_DELETE	Eliminar Usuarios del Punto	Permite eliminar usuarios del punto de reparación	Punto de Reparación	2025-06-17 21:30:43.503	2025-06-17 21:30:43.503
227	PUNTO_TICKETS_VIEW	Ver Tickets del Punto	Permite ver los tickets del punto de reparación	Punto de Reparación	2025-06-17 21:30:43.503	2025-06-17 21:30:43.503
228	PUNTO_TICKETS_CREATE	Crear Tickets del Punto	Permite crear tickets en el punto de reparación	Punto de Reparación	2025-06-17 21:30:43.503	2025-06-17 21:30:43.503
229	PUNTO_TICKETS_EDIT	Editar Tickets del Punto	Permite editar tickets del punto de reparación	Punto de Reparación	2025-06-17 21:30:43.504	2025-06-17 21:30:43.504
230	PUNTO_TICKETS_DELETE	Eliminar Tickets del Punto	Permite eliminar tickets del punto de reparación	Punto de Reparación	2025-06-17 21:30:43.504	2025-06-17 21:30:43.504
231	SALES_VIEW	Venta de Productos	Permite Gestionar y Vender productos	Ventas	2025-08-07 17:38:48.38	2025-08-07 17:38:48.38
232	REPORTS_VIEW	Ver Reportes	Ver una variedad de reportes del sistema	Reportes	2025-08-07 23:15:07.24	2025-08-07 23:15:07.24
\.
COPY public.piezas (id, nombre, marca_id, modelo_id, stock, precio, created_at, updated_at) FROM stdin;
\.
COPY public.piezas_reparacion (id, reparacion_id, pieza_id, cantidad, precio, total, created_at, updated_at) FROM stdin;
\.
COPY public.piezas_reparacion_productos (id, reparacion_id, producto_id, cantidad, precio, total, created_at, updated_at) FROM stdin;
84	136	303	2	625	1250	2025-10-09 23:08:42.256	2025-10-11 19:21:07.032
91	143	20	1	500	500	2025-10-11 22:40:53.758	2025-10-11 22:40:53.758
93	140	270	1	1500	1500	2025-10-13 20:32:54.094	2025-10-13 20:32:54.094
97	151	432	1	2000	2000	2025-10-14 21:32:42.51	2025-10-14 21:32:42.51
99	153	360	1	675	675	2025-10-16 21:12:42.143	2025-10-16 21:12:42.143
101	148	360	1	1000	1000	2025-10-17 20:59:59.733	2025-10-17 20:59:59.733
103	158	1111	1	800	800	2025-10-17 21:53:01.271	2025-10-17 21:53:01.271
106	161	1103	1	1500	1500	2025-10-18 20:37:04.677	2025-10-18 20:37:04.677
20	57	958	1	950	950	2025-09-06 22:37:30.092	2025-09-06 22:37:30.092
110	171	958	1	1057	1057	2025-10-27 22:36:32.484	2025-10-27 22:36:32.484
24	59	1056	1	550	550	2025-09-10 18:43:21.385	2025-09-10 18:43:21.385
27	67	1043	1	300	300	2025-09-13 20:20:44.655	2025-09-13 20:20:44.655
29	71	1070	1	125	125	2025-09-13 23:49:46.737	2025-09-13 23:49:46.737
30	71	1071	1	125	125	2025-09-13 23:49:46.748	2025-09-13 23:49:46.748
31	71	1072	1	25	25	2025-09-13 23:49:46.756	2025-09-13 23:49:46.756
32	71	1067	1	50	50	2025-09-13 23:49:46.764	2025-09-13 23:49:46.764
34	74	1076	1	25	25	2025-09-17 20:02:44.742	2025-09-17 20:02:44.742
35	74	1060	1	89	89	2025-09-17 20:02:44.747	2025-09-17 20:02:44.747
36	74	1074	1	39	39	2025-09-17 20:02:44.754	2025-09-17 20:02:44.754
37	74	1078	1	49	49	2025-09-17 20:02:44.76	2025-09-17 20:02:44.76
38	74	1079	1	49	49	2025-09-17 20:02:44.766	2025-09-17 20:02:44.766
39	74	1064	2	10	20	2025-09-17 20:02:44.77	2025-09-17 20:02:44.77
40	74	1075	1	100	100	2025-09-17 20:02:44.775	2025-09-17 20:02:44.775
41	74	1077	1	85	85	2025-09-17 20:02:44.784	2025-09-17 20:02:44.784
42	74	1069	1	79	79	2025-09-17 20:02:44.789	2025-09-17 20:02:44.789
43	74	1080	1	22	22	2025-09-17 20:02:44.795	2025-09-17 20:02:44.795
45	76	1096	2	99	198	2025-09-21 00:04:47.455	2025-09-21 00:04:47.455
46	76	1075	1	100	100	2025-09-21 00:04:47.462	2025-09-21 00:04:47.462
47	76	1095	1	50	50	2025-09-21 00:04:47.469	2025-09-21 00:04:47.469
116	180	1108	1	250	250	2025-10-29 23:11:18.621	2025-10-29 23:11:18.621
119	179	654	1	1100	1100	2025-10-31 19:52:02.456	2025-10-31 19:52:02.456
52	82	1021	1	700	700	2025-09-23 16:41:08.953	2025-09-23 16:41:08.953
53	82	1098	1	300	300	2025-09-23 16:41:08.96	2025-09-23 16:41:08.96
120	183	24	1	400	400	2025-10-31 20:55:03.291	2025-10-31 20:55:03.291
121	184	810	1	600	600	2025-10-31 21:41:36.7	2025-10-31 21:41:36.7
56	85	972	1	1700	1700	2025-09-23 22:12:55.922	2025-09-23 22:12:55.922
58	87	194	1	600	600	2025-09-23 22:16:51.912	2025-09-23 22:16:51.912
60	89	467	1	600	600	2025-09-26 23:51:09.275	2025-09-26 23:51:09.275
125	190	1044	1	200	200	2025-11-01 20:55:34.466	2025-11-01 20:55:34.466
63	95	1043	1	150	150	2025-09-27 20:13:12.929	2025-09-27 20:13:12.929
67	107	521	1	600	600	2025-10-01 23:20:49.64	2025-10-01 23:20:49.64
130	199	467	1	600	600	2025-11-05 23:28:21.499	2025-11-05 23:28:21.499
70	110	933	1	800	800	2025-10-04 16:49:31.323	2025-10-04 16:49:31.323
71	116	684	1	600	600	2025-10-07 23:21:43.219	2025-10-07 23:21:43.219
72	116	1027	1	200	200	2025-10-07 23:21:43.231	2025-10-07 23:21:43.231
136	203	1108	1	350	350	2025-11-07 22:29:58.437	2025-11-07 22:29:58.437
137	201	1116	1	350	350	2025-11-08 21:05:07.671	2025-11-08 21:05:07.671
139	209	6	1	1300	1300	2025-11-08 21:53:18.613	2025-11-08 21:53:18.613
140	204	420	1	650	650	2025-11-09 19:16:34.123	2025-11-09 19:16:34.123
86	138	903	1	675	675	2025-10-10 22:30:25.709	2025-10-10 22:30:25.709
88	139	1103	1	700	700	2025-10-10 22:31:41.478	2025-10-10 22:31:41.478
146	234	1120	1	750	750	2025-11-13 17:15:17.198	2025-11-13 17:15:17.198
147	224	961	1	800	800	2025-11-13 18:12:11.221	2025-11-13 18:12:11.221
148	224	937	1	250	250	2025-11-13 18:12:11.229	2025-11-13 18:12:11.229
149	222	1043	1	150	150	2025-11-13 18:12:33.462	2025-11-13 18:12:33.462
153	245	423	1	600	600	2025-11-14 22:05:12.069	2025-11-14 22:05:12.069
157	248	1120	1	500	500	2025-11-18 21:36:35.978	2025-11-18 21:36:35.978
159	254	415	1	600	600	2025-11-19 15:03:10.723	2025-11-19 15:03:10.723
161	257	1116	1	700	700	2025-11-20 19:21:54.92	2025-11-20 19:21:54.92
162	260	1108	1	150	150	2025-11-21 18:29:10.109	2025-11-21 18:29:10.109
163	261	1108	1	200	200	2025-11-21 18:29:38.175	2025-11-21 18:29:38.175
COPY public.precios_venta (id, tipo, nombre, marca, modelo, precio_compra_promedio, precio_venta, producto_id, servicio_id, created_by, updated_by, created_at, updated_at) FROM stdin;
10	SERVICIO	Diagnóstico	-	-	0	100	\N	1	system	system	2025-06-17 21:45:04.721	2025-06-17 21:45:04.721
12	SERVICIO	Mano de Obra	-	-	0	500	\N	1	system	system	2025-06-17 21:46:49.513	2025-06-17 21:46:49.513
14	SERVICIO	servicio a teléfonos mojados 	-	-	0	200	\N	1	system	system	2025-08-08 16:26:59.69	2025-08-08 16:26:59.689
11	SERVICIO	Diagnóstico	-	-	0	200	\N	1	system	system	2025-06-17 21:45:17.116	2025-08-20 15:43:31.502
16	SERVICIO	diagnostico	-	-	0	200	\N	1	system	system	2025-08-20 15:43:42.581	2025-08-20 15:43:42.579
17	SERVICIO	servicio Jack de audio 3.5 	-	-	0	200	\N	1	system	system	2025-08-20 15:43:52.864	2025-08-20 15:43:52.863
18	SERVICIO	servicio a botones	-	-	0	200	\N	1	system	system	2025-08-20 15:44:01.692	2025-08-20 15:44:01.691
19	SERVICIO	servicio altavoz 	-	-	0	200	\N	1	system	system	2025-08-20 15:44:10.214	2025-08-20 15:44:10.213
20	SERVICIO	servicio de auricular	-	-	0	200	\N	1	system	system	2025-08-20 15:44:18.522	2025-08-20 15:44:18.521
28	SERVICIO	servicio a centro de carga 	-	-	0	200	\N	1	system	system	2025-08-20 16:50:25.982	2025-08-20 16:50:25.981
37	PRODUCTO	servicio Jack de audio 3.5 			0	0	17	\N	SISTEMA	SISTEMA	2025-08-27 00:11:13.246	2025-08-27 12:28:12.208
21	PRODUCTO	Altavoz Android	Android	VARIOS	150	350	19	\N	system	system	2025-08-20 16:48:56.142	2025-10-11 20:35:44.817
25	PRODUCTO	centro de carga v8	Android	VARIOS	0	0	\N	\N	system	SISTEMA	2025-08-20 16:49:53.902	2025-08-27 12:28:12.25
15	PRODUCTO	Auricular Android 	Android	VARIOS	150	250	14	\N	system	system	2025-08-19 15:43:48.223	2025-10-11 20:35:20.779
22	PRODUCTO	batería Android	Android	VARIOS	0	0	24	\N	system	SISTEMA	2025-08-20 16:49:14.216	2025-08-27 12:28:12.258
24	PRODUCTO	centro de carga tipo C	Android	VARIOS	0	0	\N	\N	system	SISTEMA	2025-08-20 16:49:43.698	2025-08-27 12:28:12.244
40	PRODUCTO	Batería Hisense H40 LITE	Hisense		487	487	29	\N	SISTEMA	system	2025-08-27 00:11:13.374	2025-08-27 12:37:24.815
39	PRODUCTO	Batería Hisense E50 LITE	Hisense		487	487	28	\N	SISTEMA	system	2025-08-27 00:11:13.363	2025-08-27 12:37:24.804
29	PRODUCTO	Flex iPhone 12	Apple	iPhone 12	0	0	26	\N	system	SISTEMA	2025-08-26 16:26:03.13	2025-08-27 12:28:11.857
41	PRODUCTO	Batería Honor HONOR 10X	Honor		431	431	30	\N	SISTEMA	system	2025-08-27 00:11:13.386	2025-08-27 12:37:24.83
42	PRODUCTO	Batería Honor MediaPad T5	Honor		508	508	32	\N	SISTEMA	system	2025-08-27 00:11:13.393	2025-08-27 12:37:24.866
43	PRODUCTO	Batería Honor MatePad Pro	Honor		649	649	33	\N	SISTEMA	system	2025-08-27 00:11:13.399	2025-08-27 12:37:24.88
44	PRODUCTO	Batería Honor P10	Honor		371	371	34	\N	SISTEMA	system	2025-08-27 00:11:13.409	2025-08-27 12:37:24.892
45	PRODUCTO	Batería Honor MATE20 PRO	Honor		453	453	35	\N	SISTEMA	system	2025-08-27 00:11:13.417	2025-08-27 12:37:24.906
46	PRODUCTO	Batería Honor MATE 9	Honor		347	347	36	\N	SISTEMA	system	2025-08-27 00:11:13.423	2025-08-27 12:37:24.917
47	PRODUCTO	Batería Honor P40 LITE 4G	Honor		431	431	37	\N	SISTEMA	system	2025-08-27 00:11:13.428	2025-08-27 12:37:24.929
48	PRODUCTO	Batería Honor P30 LITE	Honor		403	403	38	\N	SISTEMA	system	2025-08-27 00:11:13.434	2025-08-27 12:37:24.936
49	PRODUCTO	Batería Honor P30	Honor		385	385	39	\N	SISTEMA	system	2025-08-27 00:11:13.45	2025-08-27 12:37:24.948
50	PRODUCTO	Batería Honor P20 PRO	Honor		420	420	40	\N	SISTEMA	system	2025-08-27 00:11:13.458	2025-08-27 12:37:24.958
51	PRODUCTO	Batería Honor Y9A	Honor		490	490	41	\N	SISTEMA	system	2025-08-27 00:11:13.466	2025-08-27 12:37:24.971
52	PRODUCTO	Batería Honor Y9S	Honor		403	403	42	\N	SISTEMA	system	2025-08-27 00:11:13.472	2025-08-27 12:37:24.983
53	PRODUCTO	Batería Honor HN-HONOR20 LITE	Honor		431	431	43	\N	SISTEMA	system	2025-08-27 00:11:13.488	2025-08-27 12:37:24.994
54	PRODUCTO	Batería Honor Y8P	Honor		431	431	44	\N	SISTEMA	system	2025-08-27 00:11:13.495	2025-08-27 12:37:25.008
55	PRODUCTO	Batería Honor Y7Prime	Honor		403	403	45	\N	SISTEMA	system	2025-08-27 00:11:13.501	2025-08-27 12:37:25.016
56	PRODUCTO	Batería Honor Y7A	Honor		385	385	46	\N	SISTEMA	system	2025-08-27 00:11:13.508	2025-08-27 12:37:25.025
57	PRODUCTO	Batería Honor Y6 2019	Honor		392	392	47	\N	SISTEMA	system	2025-08-27 00:11:13.514	2025-08-27 12:37:25.036
58	PRODUCTO	Batería Honor Y6 2018	Honor		368	368	48	\N	SISTEMA	system	2025-08-27 00:11:13.529	2025-08-27 12:37:25.044
59	PRODUCTO	Batería Honor NOVA Y70	Honor		431	431	49	\N	SISTEMA	system	2025-08-27 00:11:13.537	2025-08-27 12:37:25.052
60	PRODUCTO	Batería Honor NOVA Y60	Honor		431	431	50	\N	SISTEMA	system	2025-08-27 00:11:13.544	2025-08-27 12:37:25.058
61	PRODUCTO	Batería Honor HONOR 10 LITE	Honor		385	385	51	\N	SISTEMA	system	2025-08-27 00:11:13.551	2025-08-27 12:37:25.067
62	PRODUCTO	Batería Honor HONOR 10	Honor		347	347	52	\N	SISTEMA	system	2025-08-27 00:11:13.56	2025-08-27 12:37:25.077
63	PRODUCTO	Batería Honor HONOR X8	Honor		490	490	53	\N	SISTEMA	system	2025-08-27 00:11:13.571	2025-08-27 12:37:25.089
64	PRODUCTO	Batería Honor HONOR X7A	Honor		473	473	54	\N	SISTEMA	system	2025-08-27 00:11:13.583	2025-08-27 12:37:25.099
65	PRODUCTO	Batería Honor HONOR X6	Honor		462	462	55	\N	SISTEMA	system	2025-08-27 00:11:13.591	2025-08-27 12:37:25.106
66	PRODUCTO	Batería Honor HONOR 8X	Honor		403	403	56	\N	SISTEMA	system	2025-08-27 00:11:13.598	2025-08-27 12:37:25.114
67	PRODUCTO	Batería Huawei HUAWEI P20 / Honor 10	Huawei		570	570	57	\N	SISTEMA	system	2025-08-27 00:11:13.607	2025-08-27 12:37:25.121
118	PRODUCTO	Batería Motorola ONE ZOOM / XT2010	Motorola		413	413	110	\N	SISTEMA	system	2025-08-27 00:11:14.003	2025-08-27 12:37:25.748
30	PRODUCTO	Diagnóstico			0	0	7	\N	SISTEMA	SISTEMA	2025-08-27 00:11:13.126	2025-08-27 12:28:12.139
31	PRODUCTO	Mano de Obra			0	0	8	\N	SISTEMA	SISTEMA	2025-08-27 00:11:13.144	2025-08-27 12:28:12.16
32	PRODUCTO	servicio a teléfonos mojados 			0	0	9	\N	SISTEMA	SISTEMA	2025-08-27 00:11:13.148	2025-08-27 12:28:12.166
33	PRODUCTO	servicio a centro de carga 			0	0	12	\N	SISTEMA	SISTEMA	2025-08-27 00:11:13.16	2025-08-27 12:28:12.173
34	PRODUCTO	diagnostico			0	0	13	\N	SISTEMA	SISTEMA	2025-08-27 00:11:13.174	2025-08-27 12:28:12.181
13	PRODUCTO	bateria oppo a15	oppo	a15	100	0	11	\N	system	SISTEMA	2025-08-08 16:26:45.882	2025-08-27 12:28:12.193
36	PRODUCTO	servicio de auricular			0	0	16	\N	SISTEMA	SISTEMA	2025-08-27 00:11:13.231	2025-08-27 12:28:12.2
38	PRODUCTO	servicio a botones			0	0	18	\N	SISTEMA	SISTEMA	2025-08-27 00:11:13.255	2025-08-27 12:28:12.219
27	PRODUCTO	micrófono Android	Android	VARIOS	0	0	20	\N	system	SISTEMA	2025-08-20 16:50:15.699	2025-08-27 12:28:12.231
23	PRODUCTO	botones Android	Android	VARIOS	0	0	21	\N	system	SISTEMA	2025-08-20 16:49:32.577	2025-08-27 12:28:12.237
35	PRODUCTO	servicio altavoz 			0	0	15	\N	SISTEMA	SISTEMA	2025-08-27 00:11:13.221	2025-08-27 12:28:11.825
72	PRODUCTO	Batería Huawei HUAWEI P30 lite / HONOR 20S / HONOR 20 Lite	Huawei		508	508	64	\N	SISTEMA	system	2025-08-27 00:11:13.64	2025-08-27 12:37:25.205
73	PRODUCTO	Batería Huawei HUAWEI-P30 lite / HUAWEI nova 2 Plus / HUAWEI P10 Selfie / HUAWEI nova 3i / HUAWEI P smart+ / HUAW	Huawei		462	462	65	\N	SISTEMA	system	2025-08-27 00:11:13.649	2025-08-27 12:37:25.221
74	PRODUCTO	Batería Huawei HUAWEI P smart 2021 / HUAWEI Y7a / HONOR 10X Lite	Huawei		455	455	66	\N	SISTEMA	system	2025-08-27 00:11:13.658	2025-08-27 12:37:25.227
75	PRODUCTO	Batería Huawei HUAWEI MatePad Pro / HUAWEI MatePad Pro 5G	Huawei		490	490	67	\N	SISTEMA	system	2025-08-27 00:11:13.664	2025-08-27 12:37:25.238
76	PRODUCTO	Batería Huawei HUAWEI MediaPad M5 Pro / HUAWEI MediaPad M5 / HUAWEI MediaPad M5 lite / HUAWEI MediaPad M6	Huawei		438	438	68	\N	SISTEMA	system	2025-08-27 00:11:13.671	2025-08-27 12:37:25.251
77	PRODUCTO	Batería Huawei HUAWEI Y5 2018 / Honor 7A / HUAWEI Y5p / HONOR 9S	Huawei		298	298	69	\N	SISTEMA	system	2025-08-27 00:11:13.677	2025-08-27 12:37:25.258
78	PRODUCTO	Batería Huawei HUAWEI WATCH GT 2 / HUAWEI WATCH GT 2e / HUAWEI WATCH GT 2 Pro / HUAWEI WATCH GT 3	Huawei		298	298	70	\N	SISTEMA	system	2025-08-27 00:11:13.684	2025-08-27 12:37:25.275
79	PRODUCTO	Batería Huawei HUAWEI Y7s / HUAWEI Y7 Prime 2018 / HUAWEI nova 2 lite / Honor 7C / Honor 7C Pro / HUAWEI Y7 2018	Huawei		263	263	71	\N	SISTEMA	system	2025-08-27 00:11:13.695	2025-08-27 12:37:25.289
80	PRODUCTO	Batería Huawei HUAWEI P10	Huawei		182	182	72	\N	SISTEMA	system	2025-08-27 00:11:13.703	2025-08-27 12:37:25.3
81	PRODUCTO	Batería Huawei HUAWEI P9 lite 2017 / Honor 6C Pro	Huawei		175	175	73	\N	SISTEMA	system	2025-08-27 00:11:13.709	2025-08-27 12:37:25.317
82	PRODUCTO	Batería Huawei HUAWEI P50 Pro	Huawei		725	725	74	\N	SISTEMA	system	2025-08-27 00:11:13.716	2025-08-27 12:37:25.327
83	PRODUCTO	Batería Huawei HUAWEI nova Y90	Huawei		725	725	75	\N	SISTEMA	system	2025-08-27 00:11:13.729	2025-08-27 12:37:25.338
84	PRODUCTO	Batería Huawei HUAWEI P50 / P50E	Huawei		600	600	76	\N	SISTEMA	system	2025-08-27 00:11:13.735	2025-08-27 12:37:25.35
85	PRODUCTO	Batería Huawei HUAWEI P30 Pro / MATE20 PRO	Huawei		385	385	77	\N	SISTEMA	system	2025-08-27 00:11:13.741	2025-08-27 12:37:25.361
86	PRODUCTO	Batería Huawei HUAWEI nova Y70 / HUAWEI nova Y70 Plus	Huawei		357	357	78	\N	SISTEMA	system	2025-08-27 00:11:13.749	2025-08-27 12:37:25.373
87	PRODUCTO	Batería Huawei HUAWEI P30	Huawei		495	495	79	\N	SISTEMA	system	2025-08-27 00:11:13.756	2025-08-27 12:37:25.386
88	PRODUCTO	Batería Huawei HUAWEI nova 9	Huawei		473	473	80	\N	SISTEMA	system	2025-08-27 00:11:13.766	2025-08-27 12:37:25.396
89	PRODUCTO	Batería Huawei HUAWEI-Y9 2019 / Y8s / P40 lite E / Y7P	Huawei		480	480	81	\N	SISTEMA	system	2025-08-27 00:11:13.774	2025-08-27 12:37:25.405
90	PRODUCTO	Batería Huawei HUAWEI-NOVA 5T / Mate20 lite / P10 Plus / NOVA3 / NOVA4 / HONOR 20	Huawei		420	420	82	\N	SISTEMA	system	2025-08-27 00:11:13.781	2025-08-27 12:37:25.413
91	PRODUCTO	Batería Huawei HUAWEI nova 8i / HUAWEI P50 lite	Huawei		525	525	83	\N	SISTEMA	system	2025-08-27 00:11:13.786	2025-08-27 12:37:25.424
92	PRODUCTO	Batería Huawei HUAWEI-Y7 2019 / Y9 2018 / Y9 2019 / Y7 Prime / Y8s	Huawei		534	534	84	\N	SISTEMA	system	2025-08-27 00:11:13.796	2025-08-27 12:37:25.436
93	PRODUCTO	Batería Huawei HUAWEI Mate 10 Pro / HUAWEI Mate 10	Huawei		490	490	85	\N	SISTEMA	system	2025-08-27 00:11:13.807	2025-08-27 12:37:25.446
94	PRODUCTO	Batería Huawei HUAWEI Mate 40 Pro / HUAWEI Mate 40 Pro+ / HUAWEI Mate 40E Pro	Huawei		350	350	86	\N	SISTEMA	system	2025-08-27 00:11:13.816	2025-08-27 12:37:25.457
95	PRODUCTO	Batería Huawei HUAWEI nova 3e / HUAWEI P20 lite	Huawei		245	245	87	\N	SISTEMA	system	2025-08-27 00:11:13.824	2025-08-27 12:37:25.473
96	PRODUCTO	Batería Huawei HUAWEI Mate 9	Huawei		252	252	88	\N	SISTEMA	system	2025-08-27 00:11:13.833	2025-08-27 12:37:25.483
98	PRODUCTO	Batería Huawei HUAWEI nova 8	Huawei		420	420	90	\N	SISTEMA	system	2025-08-27 00:11:13.851	2025-08-27 12:37:25.517
99	PRODUCTO	Batería Huawei HUAWEI P40 Pro	Huawei		333	333	91	\N	SISTEMA	system	2025-08-27 00:11:13.857	2025-08-27 12:37:25.527
100	PRODUCTO	Batería Huawei HUAWEI nova 9 SE	Huawei		420	420	92	\N	SISTEMA	system	2025-08-27 00:11:13.868	2025-08-27 12:37:25.54
102	PRODUCTO	Batería Huawei HUAWEI P10 Plus	Huawei		315	315	94	\N	SISTEMA	system	2025-08-27 00:11:13.888	2025-08-27 12:37:25.563
70	PRODUCTO	Batería Huawei HUAWEI WATCH D / HUAWEI WATCH GT Runner	Huawei		495	495	62	\N	SISTEMA	system	2025-08-27 00:11:13.626	2025-08-27 12:37:25.173
105	PRODUCTO	Batería Huawei HONOR 10X / HUAWEI Y9a	Huawei		210	210	97	\N	SISTEMA	system	2025-08-27 00:11:13.905	2025-08-27 12:37:25.598
68	PRODUCTO	Batería Huawei HUAWEI P smart S / HUAWEI Y8p / HONOR 30i	Huawei		486	486	60	\N	SISTEMA	system	2025-08-27 00:11:13.615	2025-08-27 12:37:25.148
106	PRODUCTO	Batería Motorola G54	Motorola		420	420	98	\N	SISTEMA	system	2025-08-27 00:11:13.912	2025-08-27 12:37:25.612
107	PRODUCTO	Batería Motorola G04 / G34	Motorola		438	438	99	\N	SISTEMA	system	2025-08-27 00:11:13.918	2025-08-27 12:37:25.63
108	PRODUCTO	Batería Motorola EDGE 40 / EDGE 2023	Motorola		662	662	100	\N	SISTEMA	system	2025-08-27 00:11:13.931	2025-08-27 12:37:25.641
109	PRODUCTO	Batería Motorola EDGE30 PRO	Motorola		413	413	101	\N	SISTEMA	system	2025-08-27 00:11:13.938	2025-08-27 12:37:25.65
110	PRODUCTO	Batería Motorola EDGE20 PRO	Motorola		413	413	102	\N	SISTEMA	system	2025-08-27 00:11:13.947	2025-08-27 12:37:25.665
111	PRODUCTO	Batería Motorola EDGE 20	Motorola		431	431	103	\N	SISTEMA	system	2025-08-27 00:11:13.952	2025-08-27 12:37:25.677
112	PRODUCTO	Batería Motorola EDGE 20 LITE	Motorola		385	385	104	\N	SISTEMA	system	2025-08-27 00:11:13.961	2025-08-27 12:37:25.684
113	PRODUCTO	Batería Motorola EDGE	Motorola		385	385	105	\N	SISTEMA	system	2025-08-27 00:11:13.969	2025-08-27 12:37:25.698
114	PRODUCTO	Batería Motorola Z3 PLAY	Motorola		371	371	106	\N	SISTEMA	system	2025-08-27 00:11:13.976	2025-08-27 12:37:25.708
115	PRODUCTO	Batería Motorola Z2 PLAY	Motorola		371	371	107	\N	SISTEMA	system	2025-08-27 00:11:13.982	2025-08-27 12:37:25.718
116	PRODUCTO	Batería Motorola Z PLAY	Motorola		403	403	108	\N	SISTEMA	system	2025-08-27 00:11:13.988	2025-08-27 12:37:25.725
117	PRODUCTO	Batería Motorola X4	Motorola		347	347	109	\N	SISTEMA	system	2025-08-27 00:11:13.994	2025-08-27 12:37:25.738
101	PRODUCTO	Batería Motorola E5 PLAY GO	Motorola		326	326	140	\N	SISTEMA	system	2025-08-27 00:11:13.878	2025-08-27 12:37:26.093
103	PRODUCTO	Batería Huawei HUAWEI nova 6 SE / P40 LITE	Huawei		263	263	95	\N	SISTEMA	system	2025-08-27 00:11:13.893	2025-08-27 12:37:25.572
104	PRODUCTO	Batería Huawei HUAWEI Y6p / HUAWEI nova Y60 / 	Huawei		210	210	96	\N	SISTEMA	system	2025-08-27 00:11:13.899	2025-08-27 12:37:25.587
71	PRODUCTO	Batería Huawei HUAWEI P20 lite / HUAWEI nova 3e / 	Huawei		525	525	63	\N	SISTEMA	system	2025-08-27 00:11:13.634	2025-08-27 12:37:25.186
122	PRODUCTO	Batería Motorola G100 / EDGE S / ONE	Motorola		385	385	114	\N	SISTEMA	system	2025-08-27 00:11:14.028	2025-08-27 12:37:25.793
123	PRODUCTO	Batería Motorola G60S	Motorola		392	392	115	\N	SISTEMA	system	2025-08-27 00:11:14.037	2025-08-27 12:37:25.804
124	PRODUCTO	Batería Motorola EDGE30	Motorola		371	371	116	\N	SISTEMA	system	2025-08-27 00:11:14.047	2025-08-27 12:37:25.821
125	PRODUCTO	Batería Motorola G52 / G82 / G72	Motorola		413	413	117	\N	SISTEMA	system	2025-08-27 00:11:14.054	2025-08-27 12:37:25.833
126	PRODUCTO	Batería Motorola G50 5G	Motorola		385	385	118	\N	SISTEMA	system	2025-08-27 00:11:14.059	2025-08-27 12:37:25.843
127	PRODUCTO	Batería Motorola G71 / G71S / G62	Motorola		385	385	119	\N	SISTEMA	system	2025-08-27 00:11:14.067	2025-08-27 12:37:25.854
128	PRODUCTO	Batería Motorola G32 / G41	Motorola		406	406	120	\N	SISTEMA	system	2025-08-27 00:11:14.073	2025-08-27 12:37:25.869
129	PRODUCTO	Batería Motorola G31 / G42	Motorola		403	403	121	\N	SISTEMA	system	2025-08-27 00:11:14.082	2025-08-27 12:37:25.879
130	PRODUCTO	Batería Motorola G9 PLUS	Motorola		347	347	122	\N	SISTEMA	system	2025-08-27 00:11:14.091	2025-08-27 12:37:25.888
131	PRODUCTO	Batería Motorola G8 POWER	Motorola		403	403	123	\N	SISTEMA	system	2025-08-27 00:11:14.097	2025-08-27 12:37:25.898
132	PRODUCTO	Batería Motorola G8 PLUS	Motorola		403	403	124	\N	SISTEMA	system	2025-08-27 00:11:14.104	2025-08-27 12:37:25.911
133	PRODUCTO	Batería Motorola G7 PLUS	Motorola		368	368	126	\N	SISTEMA	system	2025-08-27 00:11:14.112	2025-08-27 12:37:25.937
134	PRODUCTO	Batería Motorola G7 PLAY / G7	Motorola		347	347	127	\N	SISTEMA	system	2025-08-27 00:11:14.118	2025-08-27 12:37:25.949
135	PRODUCTO	Batería Motorola G6 PLUS	Motorola		371	371	128	\N	SISTEMA	system	2025-08-27 00:11:14.128	2025-08-27 12:37:25.959
136	PRODUCTO	Batería Motorola G6 PLAY / E5	Motorola		403	403	129	\N	SISTEMA	system	2025-08-27 00:11:14.135	2025-08-27 12:37:25.97
137	PRODUCTO	Batería Motorola G6	Motorola		357	357	130	\N	SISTEMA	system	2025-08-27 00:11:14.141	2025-08-27 12:37:25.987
138	PRODUCTO	Batería Motorola G STYLUS 2022	Motorola		347	347	131	\N	SISTEMA	system	2025-08-27 00:11:14.146	2025-08-27 12:37:25.995
139	PRODUCTO	Batería Motorola E20 / XT2155	Motorola		431	431	132	\N	SISTEMA	system	2025-08-27 00:11:14.152	2025-08-27 12:37:26.004
141	PRODUCTO	Batería Motorola G8 PLAY / ONE MACRO	Motorola		403	403	134	\N	SISTEMA	system	2025-08-27 00:11:14.168	2025-08-27 12:37:26.026
142	PRODUCTO	Batería Motorola G9 / G9POWER / G40FUSION / G60	Motorola		385	385	136	\N	SISTEMA	system	2025-08-27 00:11:14.174	2025-08-27 12:37:26.05
143	PRODUCTO	Batería Motorola E6 PLAY / E6I	Motorola		403	403	137	\N	SISTEMA	system	2025-08-27 00:11:14.181	2025-08-27 12:37:26.064
144	PRODUCTO	Batería Motorola E6S / E6 PLUS	Motorola		326	326	138	\N	SISTEMA	system	2025-08-27 00:11:14.19	2025-08-27 12:37:26.072
145	PRODUCTO	Batería Motorola E5 PLUS	Motorola		403	403	139	\N	SISTEMA	system	2025-08-27 00:11:14.197	2025-08-27 12:37:26.081
146	PRODUCTO	Batería Oppo RENO5	oppo		504	504	141	\N	SISTEMA	system	2025-08-27 00:11:14.207	2025-08-27 12:37:26.106
147	PRODUCTO	Batería Oppo A5 2020 / A11 / A11X / A9-2020 / realme5 / realme5i / realme5s / realmeC3	oppo		385	385	144	\N	SISTEMA	system	2025-08-27 00:11:14.213	2025-08-27 12:37:26.142
150	PRODUCTO	Batería Oppo C21 / C11	oppo		385	385	147	\N	SISTEMA	system	2025-08-27 00:11:14.239	2025-08-27 12:37:26.174
120	PRODUCTO	Batería Motorola ONE FUSION / ONE FUSION PLUS	Motorola		385	385	112	\N	SISTEMA	system	2025-08-27 00:11:14.018	2025-08-27 12:37:25.767
151	PRODUCTO	Batería Oppo A52 / A72 / A92	oppo		410	410	148	\N	SISTEMA	system	2025-08-27 00:11:14.247	2025-08-27 12:37:26.188
153	PRODUCTO	Batería Oppo A12 / A15	oppo		385	385	150	\N	SISTEMA	system	2025-08-27 00:11:14.257	2025-08-27 12:37:26.206
154	PRODUCTO	Batería Oppo RENO5 LITE	oppo		431	431	151	\N	SISTEMA	system	2025-08-27 00:11:14.264	2025-08-27 12:37:26.22
155	PRODUCTO	Batería Oppo A15 / A15S / A35 / A54	oppo		385	385	152	\N	SISTEMA	system	2025-08-27 00:11:14.27	2025-08-27 12:37:26.23
156	PRODUCTO	Batería Samsung S22 PLUS	Samsung		431	431	153	\N	SISTEMA	system	2025-08-27 00:11:14.279	2025-08-27 12:37:26.237
157	PRODUCTO	Batería Samsung S22 ULTRA	Samsung		431	431	154	\N	SISTEMA	system	2025-08-27 00:11:14.289	2025-08-27 12:37:26.244
158	PRODUCTO	Batería Samsung S22	Samsung		403	403	155	\N	SISTEMA	system	2025-08-27 00:11:14.296	2025-08-27 12:37:26.256
159	PRODUCTO	Batería Samsung S21 PLUS	Samsung		462	462	156	\N	SISTEMA	system	2025-08-27 00:11:14.302	2025-08-27 12:37:26.269
160	PRODUCTO	Batería Samsung S21 ULTRA	Samsung		385	385	157	\N	SISTEMA	system	2025-08-27 00:11:14.31	2025-08-27 12:37:26.277
161	PRODUCTO	Batería Samsung S20 PLUS	Samsung		406	406	158	\N	SISTEMA	system	2025-08-27 00:11:14.319	2025-08-27 12:37:26.284
162	PRODUCTO	Batería Samsung S20 ULTRA	Samsung		406	406	159	\N	SISTEMA	system	2025-08-27 00:11:14.331	2025-08-27 12:37:26.293
163	PRODUCTO	Batería Samsung S9 PLUS	Samsung		385	385	160	\N	SISTEMA	system	2025-08-27 00:11:14.337	2025-08-27 12:37:26.307
164	PRODUCTO	Batería Samsung S9	Samsung		403	403	161	\N	SISTEMA	system	2025-08-27 00:11:14.342	2025-08-27 12:37:26.316
165	PRODUCTO	Batería Samsung S8PLUS	Samsung		403	403	162	\N	SISTEMA	system	2025-08-27 00:11:14.35	2025-08-27 12:37:26.323
166	PRODUCTO	Batería Samsung S8	Samsung		403	403	163	\N	SISTEMA	system	2025-08-27 00:11:14.36	2025-08-27 12:37:26.336
167	PRODUCTO	Batería Samsung NOTE20 ULTRA	Samsung		431	431	164	\N	SISTEMA	system	2025-08-27 00:11:14.368	2025-08-27 12:37:26.348
168	PRODUCTO	Batería Samsung NOTE20	Samsung		403	403	165	\N	SISTEMA	system	2025-08-27 00:11:14.377	2025-08-27 12:37:26.356
169	PRODUCTO	Batería Samsung NOTE10 PLUS	Samsung		434	434	166	\N	SISTEMA	system	2025-08-27 00:11:14.386	2025-08-27 12:37:26.364
170	PRODUCTO	Batería Samsung NOTE10 LITE	Samsung		371	371	167	\N	SISTEMA	system	2025-08-27 00:11:14.393	2025-08-27 12:37:26.376
171	PRODUCTO	Batería Samsung J730 / J7PRO	Samsung		312	312	168	\N	SISTEMA	system	2025-08-27 00:11:14.401	2025-08-27 12:37:26.385
172	PRODUCTO	Batería Samsung J6	Samsung		312	312	169	\N	SISTEMA	system	2025-08-27 00:11:14.407	2025-08-27 12:37:26.394
173	PRODUCTO	Batería Samsung J530 / J5 PRO	Samsung		312	312	170	\N	SISTEMA	system	2025-08-27 00:11:14.414	2025-08-27 12:37:26.403
174	PRODUCTO	Batería Samsung J5 PRIME	Samsung		312	312	171	\N	SISTEMA	system	2025-08-27 00:11:14.419	2025-08-27 12:37:26.418
148	PRODUCTO	Batería Oppo RENO6 LITE	oppo		431	431	145	\N	SISTEMA	system	2025-08-27 00:11:14.219	2025-08-27 12:37:26.153
149	PRODUCTO	Batería Oppo RENO7 4G	oppo		462	462	146	\N	SISTEMA	system	2025-08-27 00:11:14.226	2025-08-27 12:37:26.161
121	PRODUCTO	Batería Motorola G200 5G	Motorola		413	413	113	\N	SISTEMA	system	2025-08-27 00:11:14.023	2025-08-27 12:37:25.777
178	PRODUCTO	Batería Samsung A71 / A715	Samsung		403	403	175	\N	SISTEMA	system	2025-08-27 00:11:14.452	2025-08-27 12:37:26.464
179	PRODUCTO	Batería Samsung A70 / A70S	Samsung		371	371	176	\N	SISTEMA	system	2025-08-27 00:11:14.46	2025-08-27 12:37:26.475
180	PRODUCTO	Batería Samsung A52 / A52S / A525 4G / A525 5G / S20FE	Samsung		403	403	177	\N	SISTEMA	system	2025-08-27 00:11:14.466	2025-08-27 12:37:26.482
181	PRODUCTO	Batería Samsung A51 / A515	Samsung		403	403	178	\N	SISTEMA	system	2025-08-27 00:11:14.476	2025-08-27 12:37:26.494
182	PRODUCTO	Batería Samsung A34 5G / A546 / A54	Samsung		347	347	179	\N	SISTEMA	system	2025-08-27 00:11:14.484	2025-08-27 12:37:26.508
183	PRODUCTO	Batería Samsung A33 / A336 / A53 / A536	Samsung		347	347	180	\N	SISTEMA	system	2025-08-27 00:11:14.49	2025-08-27 12:37:26.517
184	PRODUCTO	Batería Samsung A24	Samsung		403	403	181	\N	SISTEMA	system	2025-08-27 00:11:14.499	2025-08-27 12:37:26.524
185	PRODUCTO	Batería Samsung A22 5G	Samsung		371	371	182	\N	SISTEMA	system	2025-08-27 00:11:14.505	2025-08-27 12:37:26.533
186	PRODUCTO	Batería Samsung A22 4G / A31 / A315 / A325 / A32 4G / A325 4G	Samsung		347	347	183	\N	SISTEMA	system	2025-08-27 00:11:14.512	2025-08-27 12:37:26.546
187	PRODUCTO	Batería Samsung A20 / A30 / A50 / A50S / A30S / A505	Samsung		347	347	184	\N	SISTEMA	system	2025-08-27 00:11:14.527	2025-08-27 12:37:26.555
188	PRODUCTO	Batería Samsung M30	Samsung		347	347	185	\N	SISTEMA	system	2025-08-27 00:11:14.533	2025-08-27 12:37:26.563
189	PRODUCTO	Batería Samsung A14 5G / A146B	Samsung		403	403	186	\N	SISTEMA	system	2025-08-27 00:11:14.54	2025-08-27 12:37:26.573
190	PRODUCTO	Batería Samsung A13 / A13 4G / A13 lite / A21S / A217 / A04S / A02 / A12 / M02 / M127 / A04S	Samsung		347	347	187	\N	SISTEMA	system	2025-08-27 00:11:14.547	2025-08-27 12:37:26.586
191	PRODUCTO	Batería Samsung A11 / A115	Samsung		403	403	189	\N	SISTEMA	system	2025-08-27 00:11:14.557	2025-08-27 12:37:26.607
194	PRODUCTO	Batería Samsung SAMA10 / M10	Samsung		371	371	192	\N	SISTEMA	system	2025-08-27 00:11:14.578	2025-08-27 12:37:26.643
176	PRODUCTO	Batería Samsung J4 / J7 / J701 / J7NEO	Samsung		263	263	173	\N	SISTEMA	system	2025-08-27 00:11:14.436	2025-08-27 12:37:26.439
196	PRODUCTO	Batería Samsung A13 5G / A136B	Samsung		347	347	194	\N	SISTEMA	system	2025-08-27 00:11:14.595	2025-08-27 12:37:26.657
195	PRODUCTO	Batería Samsung A05	Samsung		403	0	193	\N	SISTEMA	SISTEMA	2025-08-27 00:11:14.585	2025-08-27 12:28:13.276
197	PRODUCTO	Batería Samsung A04 / A045 / A04E / A14 4G / A145P	Samsung		385	385	195	\N	SISTEMA	system	2025-08-27 00:11:14.608	2025-08-27 12:37:26.671
198	PRODUCTO	Batería Samsung A03 CORE	Samsung		371	371	196	\N	SISTEMA	system	2025-08-27 00:11:14.613	2025-08-27 12:37:26.681
199	PRODUCTO	Batería Samsung A03	Samsung		403	403	197	\N	SISTEMA	system	2025-08-27 00:11:14.621	2025-08-27 12:37:26.698
200	PRODUCTO	Batería Samsung A02S / A03S	Samsung		385	385	198	\N	SISTEMA	system	2025-08-27 00:11:14.629	2025-08-27 12:37:26.718
201	PRODUCTO	Batería Samsung A32 5G / A72 / A725	Samsung		347	347	199	\N	SISTEMA	system	2025-08-27 00:11:14.639	2025-08-27 12:37:26.728
202	PRODUCTO	Batería Samsung A01 M	Samsung		347	347	200	\N	SISTEMA	system	2025-08-27 00:11:14.648	2025-08-27 12:37:26.748
203	PRODUCTO	Batería Samsung G532 / G530 / J5	Samsung		238	238	201	\N	SISTEMA	system	2025-08-27 00:11:14.653	2025-08-27 12:37:26.76
204	PRODUCTO	Batería Xiaomi REDMI NOTE12 PRO 5G	Xiaomi		564	564	202	\N	SISTEMA	system	2025-08-27 00:11:14.663	2025-08-27 12:37:26.768
205	PRODUCTO	Batería Xiaomi REDMI NOTE12 4G	Xiaomi		501	501	203	\N	SISTEMA	system	2025-08-27 00:11:14.669	2025-08-27 12:37:26.782
206	PRODUCTO	Batería Xiaomi REDMI NOTE12 5G / POCO X5	Xiaomi		525	525	204	\N	SISTEMA	system	2025-08-27 00:11:14.674	2025-08-27 12:37:26.793
207	PRODUCTO	Batería Xiaomi REDMI NOTE11T PRO / POCO X4 GT	Xiaomi		564	564	205	\N	SISTEMA	system	2025-08-27 00:11:14.683	2025-08-27 12:37:26.803
209	PRODUCTO	Batería Xiaomi REDMI NOTE11 5G / POCO M4 PRO 5G	Xiaomi		480	480	207	\N	SISTEMA	system	2025-08-27 00:11:14.696	2025-08-27 12:37:26.827
210	PRODUCTO	Batería Xiaomi REDMI NOTE10PRO MAX	Xiaomi		410	410	208	\N	SISTEMA	system	2025-08-27 00:11:14.703	2025-08-27 12:37:26.84
211	PRODUCTO	Batería Xiaomi REDMI NOTE11PRO / NOTE11PLUS / POCO X4 PRO / REDMI NOTE12PRO 4G	Xiaomi		504	504	209	\N	SISTEMA	system	2025-08-27 00:11:14.709	2025-08-27 12:37:26.855
212	PRODUCTO	Batería Xiaomi POCO X3 GT	Xiaomi		504	504	210	\N	SISTEMA	system	2025-08-27 00:11:14.717	2025-08-27 12:37:26.871
213	PRODUCTO	Batería Xiaomi REDMI NOTE10 4G / 10S / POCO M5S	Xiaomi		511	511	211	\N	SISTEMA	system	2025-08-27 00:11:14.727	2025-08-27 12:37:26.883
214	PRODUCTO	Batería Xiaomi REDMI NOTE9S	Xiaomi		385	385	212	\N	SISTEMA	system	2025-08-27 00:11:14.733	2025-08-27 12:37:26.893
215	PRODUCTO	Batería Xiaomi REDMI NOTE8 PRO	Xiaomi		403	403	213	\N	SISTEMA	system	2025-08-27 00:11:14.741	2025-08-27 12:37:26.901
216	PRODUCTO	Batería Xiaomi REDMI NOTE8	Xiaomi		403	403	214	\N	SISTEMA	system	2025-08-27 00:11:14.749	2025-08-27 12:37:26.914
217	PRODUCTO	Batería Xiaomi REDMI NOTE7 / NOTE7 PRO	Xiaomi		385	385	215	\N	SISTEMA	system	2025-08-27 00:11:14.756	2025-08-27 12:37:26.924
218	PRODUCTO	Batería Xiaomi REDMI 12C	Xiaomi		438	438	216	\N	SISTEMA	system	2025-08-27 00:11:14.765	2025-08-27 12:37:26.934
219	PRODUCTO	Batería Xiaomi REDMI 10C	Xiaomi		473	473	217	\N	SISTEMA	system	2025-08-27 00:11:14.775	2025-08-27 12:37:26.95
220	PRODUCTO	Batería Xiaomi REDMI 10 5G	Xiaomi		431	431	218	\N	SISTEMA	system	2025-08-27 00:11:14.781	2025-08-27 12:37:26.961
221	PRODUCTO	Batería Xiaomi REDMI 10 4G / REDMI NOTE11 4G	Xiaomi		413	413	219	\N	SISTEMA	system	2025-08-27 00:11:14.787	2025-08-27 12:37:26.974
222	PRODUCTO	Batería Xiaomi POCO X3 PRO	Xiaomi		480	480	220	\N	SISTEMA	system	2025-08-27 00:11:14.794	2025-08-27 12:37:26.989
223	PRODUCTO	Batería Xiaomi POCO X3	Xiaomi		508	508	221	\N	SISTEMA	system	2025-08-27 00:11:14.803	2025-08-27 12:37:27.002
224	PRODUCTO	Batería Xiaomi REDMI 9T / NOTE9 4G / POCO M3	Xiaomi		473	473	222	\N	SISTEMA	system	2025-08-27 00:11:14.814	2025-08-27 12:37:27.01
225	PRODUCTO	Batería Xiaomi REDMI 9 / REDMI NOTE9 / REDMI 10X	Xiaomi		403	403	224	\N	SISTEMA	system	2025-08-27 00:11:14.82	2025-08-27 12:37:27.031
226	PRODUCTO	Batería Xiaomi REDMI 8 / 8A	Xiaomi		385	385	225	\N	SISTEMA	system	2025-08-27 00:11:14.827	2025-08-27 12:37:27.044
227	PRODUCTO	Batería Xiaomi MI 12T / MI 12T PRO	Xiaomi		671	671	226	\N	SISTEMA	system	2025-08-27 00:11:14.834	2025-08-27 12:37:27.056
228	PRODUCTO	Batería Xiaomi MI11T PRO	Xiaomi		801	801	227	\N	SISTEMA	system	2025-08-27 00:11:14.843	2025-08-27 12:37:27.069
192	PRODUCTO	Batería Samsung A10E	Samsung		347	347	190	\N	SISTEMA	system	2025-08-27 00:11:14.567	2025-08-27 12:37:26.625
193	PRODUCTO	Batería Samsung A10S / A107 / A20S / A207	Samsung		403	403	191	\N	SISTEMA	system	2025-08-27 00:11:14.573	2025-08-27 12:37:26.635
177	PRODUCTO	Batería Samsung A730 / A8PLUS	Samsung		326	326	174	\N	SISTEMA	system	2025-08-27 00:11:14.446	2025-08-27 12:37:26.449
232	PRODUCTO	Batería Xiaomi MI 10 LITE	Xiaomi		490	490	231	\N	SISTEMA	system	2025-08-27 00:11:14.879	2025-08-27 12:37:27.114
233	PRODUCTO	Batería Xiaomi MI 10T / 10T PRO / K30S	Xiaomi		480	480	232	\N	SISTEMA	system	2025-08-27 00:11:14.892	2025-08-27 12:37:27.122
234	PRODUCTO	Batería Xiaomi MI9T PRO	Xiaomi		403	403	233	\N	SISTEMA	system	2025-08-27 00:11:14.898	2025-08-27 12:37:27.131
235	PRODUCTO	Batería Xiaomi MI 9T	Xiaomi		403	403	234	\N	SISTEMA	system	2025-08-27 00:11:14.905	2025-08-27 12:37:27.143
238	PRODUCTO	Batería Xiaomi POCO F4	Xiaomi		525	525	238	\N	SISTEMA	system	2025-08-27 00:11:14.935	2025-08-27 12:37:27.185
271	PRODUCTO	Display Honor 90 ORIG C/M(BOUTIQUE)	Honor	-	0	2050	272	\N	SISTEMA	system	2025-08-27 00:11:15.189	2025-08-29 18:53:41.123
240	PRODUCTO	Batería ZTE V40 SMART	ZTE		455	455	240	\N	SISTEMA	system	2025-08-27 00:11:14.947	2025-08-27 12:37:27.199
241	PRODUCTO	Batería ZTE V2020 5G	ZTE		371	371	241	\N	SISTEMA	system	2025-08-27 00:11:14.952	2025-08-27 12:37:27.207
242	PRODUCTO	Batería ZTE A53	ZTE		347	347	242	\N	SISTEMA	system	2025-08-27 00:11:14.96	2025-08-27 12:37:27.224
243	PRODUCTO	Batería ZTE A52 / A72 / V20 SMART 2050 / V20 SMART 8010	ZTE		459	459	243	\N	SISTEMA	system	2025-08-27 00:11:14.971	2025-08-27 12:37:27.231
244	PRODUCTO	Batería ZTE A71	ZTE		431	431	244	\N	SISTEMA	system	2025-08-27 00:11:14.979	2025-08-27 12:37:27.236
245	PRODUCTO	Batería ZTE A7 2020	ZTE		413	413	245	\N	SISTEMA	system	2025-08-27 00:11:14.985	2025-08-27 12:37:27.244
246	PRODUCTO	Batería ZTE A5 2020 / A51 / V9 / V9 LITE / V10 / V10 VITA	ZTE		371	371	246	\N	SISTEMA	system	2025-08-27 00:11:14.994	2025-08-27 12:37:27.253
247	PRODUCTO	Batería ZTE A3 2020 / L210	ZTE		277	277	247	\N	SISTEMA	system	2025-08-27 00:11:15.001	2025-08-27 12:37:27.261
262	PRODUCTO	Display Hisense E30 ORIGS/M NEGRO	Hisense	-	0	600	262	\N	SISTEMA	system	2025-08-27 00:11:15.121	2025-08-29 17:35:20.658
250	PRODUCTO	Display Alcatel 5028 ORIG S/M	Alcatel	-	0	650	250	\N	SISTEMA	system	2025-08-27 00:11:15.023	2025-08-28 23:28:22.147
248	PRODUCTO	Display Alcatel 5030 1SE ORIG	Alcatel	-	0	650	248	\N	SISTEMA	system	2025-08-27 00:11:15.009	2025-08-28 23:28:52.852
256	PRODUCTO	Display Hisense E60 LITE ORIG	Hisense	-	0	600	256	\N	SISTEMA	system	2025-08-27 00:11:15.068	2025-08-29 17:37:10.946
252	PRODUCTO	Display Hisense E50i ORIG S/M	Hisense		681	681	252	\N	SISTEMA	system	2025-08-27 00:11:15.038	2025-08-27 12:46:12.601
253	PRODUCTO	Display Hisense F23 ORIG S/M	Hisense		601	601	253	\N	SISTEMA	system	2025-08-27 00:11:15.046	2025-08-27 12:46:12.611
268	PRODUCTO	Display Hisense H30 LITE ORIG	Hisense	-	0	600	268	\N	SISTEMA	system	2025-08-27 00:11:15.17	2025-08-29 17:40:00.224
255	PRODUCTO	Display Hisense H40 ORIG S/M	Hisense		650	650	255	\N	SISTEMA	system	2025-08-27 00:11:15.058	2025-08-27 12:46:12.637
261	PRODUCTO	Display Hisense E60 ORIG S/M	Hisense	-	0	950	261	\N	SISTEMA	system	2025-08-27 00:11:15.11	2025-08-29 17:37:59.248
259	PRODUCTO	Display Hisense V60/E60 ORIG S/M	Hisense	-	0	800	259	\N	SISTEMA	system	2025-08-27 00:11:15.095	2025-08-29 17:44:59.068
263	PRODUCTO	Display Hisense H60 LITE ORIG	Hisense	-	0	800	263	\N	SISTEMA	system	2025-08-27 00:11:15.132	2025-08-29 17:42:54.999
270	PRODUCTO	Display Honor 70 ORIG OLED	Honor	-	0	1998	270	\N	SISTEMA	system	2025-08-27 00:11:15.183	2025-08-29 18:52:01.226
260	PRODUCTO	Display Hisense V50 ORIG S/M	Hisense		644	644	260	\N	SISTEMA	system	2025-08-27 00:11:15.103	2025-08-27 12:46:12.687
254	PRODUCTO	Display Hisense F20 ORIG S/M	Hisense	-	0	687	254	\N	SISTEMA	system	2025-08-27 00:11:15.053	2025-08-29 17:39:18.583
251	PRODUCTO	Display Hisense E50S ORIG S/M	Hisense	-	0	700	251	\N	SISTEMA	system	2025-08-27 00:11:15.029	2025-08-29 17:36:17.277
264	PRODUCTO	Display Hisense U50 4G ORIG	Hisense	-	0	775	264	\N	SISTEMA	system	2025-08-27 00:11:15.138	2025-08-29 17:43:18.165
257	PRODUCTO	Display Hisense V40S ORIG S/M	Hisense	-	0	687	257	\N	SISTEMA	system	2025-08-27 00:11:15.079	2025-08-29 17:43:38.577
265	PRODUCTO	Display Hisense E50 LITE ORIG	Hisense		607	607	265	\N	SISTEMA	system	2025-08-27 00:11:15.146	2025-08-27 12:46:12.763
266	PRODUCTO	Display Hisense H50 LITE/E50 ORIG	Hisense		687	687	266	\N	SISTEMA	system	2025-08-27 00:11:15.155	2025-08-27 12:46:12.788
267	PRODUCTO	Display Hisense H40 LITE/E40/V40 ORIG	Hisense		601	601	267	\N	SISTEMA	system	2025-08-27 00:11:15.162	2025-08-27 12:46:12.816
258	PRODUCTO	Display Hisense H50 ORIG S/M	Hisense	-	0	800	258	\N	SISTEMA	system	2025-08-27 00:11:15.089	2025-08-29 17:42:33.919
284	PRODUCTO	Display Honor X8A ORIG C/M(BOUTIQUE)	Honor	-	0	625	286	\N	SISTEMA	system	2025-08-27 00:11:15.285	2025-08-29 19:00:21.479
285	PRODUCTO	Display Honor 8X/9X LITE ORIG	Honor	-	0	775	287	\N	SISTEMA	system	2025-08-27 00:11:15.293	2025-08-29 18:52:59.004
273	PRODUCTO	Display Honor 90 ORIG S/M	Honor	-	0	2050	274	\N	SISTEMA	system	2025-08-27 00:11:15.208	2025-08-29 18:54:09.877
276	PRODUCTO	Display Honor X6A/X50 PRO/X5 PLUS	Honor	-	0	600	277	\N	SISTEMA	system	2025-08-27 00:11:15.226	2025-08-29 18:56:58.144
282	PRODUCTO	Display Honor X5 ORIG C/M(BOUTIQUE)	Honor	-	0	688	283	\N	SISTEMA	system	2025-08-27 00:11:15.27	2025-08-29 18:54:38.791
278	PRODUCTO	Display Honor X7B ORIG C/M(BOUTIQUE)	Honor	-	0	850	279	\N	SISTEMA	system	2025-08-27 00:11:15.244	2025-08-29 18:58:18.539
275	PRODUCTO	Display Honor 10 LITE ORIG	Honor		855	855	276	\N	SISTEMA	system	2025-08-27 00:11:15.218	2025-08-27 12:46:12.997
274	PRODUCTO	Display Honor X7A ORIG C/M(BOUTIQUE)	Honor	-	0	600	275	\N	SISTEMA	system	2025-08-27 00:11:15.213	2025-08-29 18:57:45.46
280	PRODUCTO	Display Honor X7B ORIG S/M	Honor	-	0	850	281	\N	SISTEMA	system	2025-08-27 00:11:15.257	2025-08-29 18:58:28.444
269	PRODUCTO	Display Honor X8A 5G/X6 ORIG	Honor	-	0	600	269	\N	SISTEMA	system	2025-08-27 00:11:15.176	2025-08-29 18:59:57.901
272	PRODUCTO	Display Honor X6A ORIG C/M(BOUTIQUE)	Honor	-	0	600	273	\N	SISTEMA	system	2025-08-27 00:11:15.197	2025-08-29 18:56:43.001
281	PRODUCTO	Display Honor X6 ORIG C/M(BOUTIQUE)	Honor	-	0	605	282	\N	SISTEMA	system	2025-08-27 00:11:15.263	2025-08-29 18:55:36.003
277	PRODUCTO	Display Honor X9 ORIG C/M(BOUTIQUE)	Honor	-	0	750	278	\N	SISTEMA	system	2025-08-27 00:11:15.235	2025-08-29 19:01:40.228
283	PRODUCTO	Display Honor X8B ORIG S/M	Honor	-	0	1525	284	\N	SISTEMA	system	2025-08-27 00:11:15.277	2025-08-29 19:01:05.775
236	PRODUCTO	Batería Xiaomi MI 9	Xiaomi		347	347	235	\N	SISTEMA	system	2025-08-27 00:11:14.913	2025-08-27 12:37:27.155
237	PRODUCTO	Batería Xiaomi MI A1 / 5X	Xiaomi		392	392	237	\N	SISTEMA	system	2025-08-27 00:11:14.926	2025-08-27 12:37:27.175
230	PRODUCTO	Batería Xiaomi MI 11 LITE 4G / 5G	Xiaomi		473	473	229	\N	SISTEMA	system	2025-08-27 00:11:14.86	2025-08-27 12:37:27.091
249	PRODUCTO	Display Alcatel 5024 ORIG S/M	Alcatel	-	0	625	249	\N	SISTEMA	system	2025-08-27 00:11:15.015	2025-08-28 23:27:23.607
231	PRODUCTO	Batería Xiaomi MI NOTE10 / NOTE10LITE / NOTE10PRO / CC9PRO	Xiaomi		543	543	230	\N	SISTEMA	system	2025-08-27 00:11:14.867	2025-08-27 12:37:27.103
300	PRODUCTO	Display Honor X6/X8A 5G ORIG	Honor	-	0	605	303	\N	SISTEMA	system	2025-08-27 00:11:15.421	2025-08-29 18:56:11.608
297	PRODUCTO	Display Honor X9 ORIG S/M	Honor	-	0	750	300	\N	SISTEMA	system	2025-08-27 00:11:15.394	2025-08-29 19:01:56.431
298	PRODUCTO	Display Honor X8 ORIG C/M(BOUTIQUE)	Honor	-	0	700	301	\N	SISTEMA	system	2025-08-27 00:11:15.403	2025-08-29 18:58:44.891
293	PRODUCTO	Display Honor 10 ORIG S/M	Honor		601	601	296	\N	SISTEMA	system	2025-08-27 00:11:15.364	2025-08-27 12:46:13.232
296	PRODUCTO	Display Honor 50 LITE/NOVA 8i	Honor	-	0	850	299	\N	SISTEMA	system	2025-08-27 00:11:15.387	2025-08-29 18:50:47.477
294	PRODUCTO	Display Honor 10 LITE ORIG	Honor	-	0	825	276	\N	SISTEMA	system	2025-08-27 00:11:15.371	2025-08-29 18:49:27.809
303	PRODUCTO	Display Honor 8X/9X LITE COF	Honor	-	0	775	306	\N	SISTEMA	system	2025-08-27 00:11:15.44	2025-08-29 18:52:33.814
307	PRODUCTO	Display Huawei MATE 10 ORIG	Huawei	-	0	1250	310	\N	SISTEMA	system	2025-08-27 00:11:15.463	2025-08-29 19:06:45.791
301	PRODUCTO	Display Honor X8 ORIG S/M	Honor	-	0	700	304	\N	SISTEMA	system	2025-08-27 00:11:15.426	2025-08-29 18:58:59.913
302	PRODUCTO	Display Honor X7 ORIG S/M	Honor	-	0	600	305	\N	SISTEMA	system	2025-08-27 00:11:15.43	2025-08-29 18:57:29.166
299	PRODUCTO	Display Honor X7 ORIG C/M(BOUTIGUE)	Honor	-	0	600	302	\N	SISTEMA	system	2025-08-27 00:11:15.414	2025-08-29 18:57:17.873
291	PRODUCTO	Display Honor X8A 4G/X50i/90 LITE	Honor	-	0	625	294	\N	SISTEMA	system	2025-08-27 00:11:15.342	2025-08-29 18:59:27.158
292	PRODUCTO	Display Honor X7A ORIG S/M	Honor	-	0	600	295	\N	SISTEMA	system	2025-08-27 00:11:15.349	2025-08-29 18:57:57.299
289	PRODUCTO	Display Honor 8X/9X LITE COG	Honor	-	0	775	292	\N	SISTEMA	system	2025-08-27 00:11:15.327	2025-08-29 18:52:45.783
304	PRODUCTO	Display Huawei MATE 9 ORIG	Huawei		875	875	307	\N	SISTEMA	system	2025-08-27 00:11:15.446	2025-08-27 12:46:13.361
305	PRODUCTO	Display Huawei MATE20 PRO INCELL	Huawei		1213	1213	308	\N	SISTEMA	system	2025-08-27 00:11:15.452	2025-08-27 12:46:13.37
324	PRODUCTO	Display Huawei NOVA 10 ORIG	Huawei	-	0	1800	327	\N	SISTEMA	system	2025-08-27 00:11:15.592	2025-08-29 19:17:41.416
308	PRODUCTO	Display Huawei MATE 9 ORIG	Huawei	-	0	800	307	\N	SISTEMA	system	2025-08-27 00:11:15.467	2025-08-29 19:07:28.591
313	PRODUCTO	Display Huawei MATE10 LITE ORIG	Huawei	-	0	600	316	\N	SISTEMA	system	2025-08-27 00:11:15.508	2025-08-29 19:09:27.451
306	PRODUCTO	Display Huawei MATE20 INCELL S/M	Huawei	-	0	0.01	309	\N	SISTEMA	system	2025-08-27 00:11:15.458	2025-08-29 19:14:06.06
314	PRODUCTO	Display Huawei MATE20 LITE ORIG	Huawei	-	0	675	315	\N	SISTEMA	system	2025-08-27 00:11:15.515	2025-08-29 19:16:56.69
311	PRODUCTO	Display Huawei MATE10 LITE ORIG	Huawei		715	715	314	\N	SISTEMA	system	2025-08-27 00:11:15.492	2025-08-27 12:46:13.444
312	PRODUCTO	Display Huawei MATE20 LITE ORIG	Huawei		1013	1013	315	\N	SISTEMA	system	2025-08-27 00:11:15.5	2025-08-27 12:46:13.455
309	PRODUCTO	Display Huawei MATE10 PRO INCELL	Huawei	-	0	0.01	312	\N	SISTEMA	system	2025-08-27 00:11:15.474	2025-08-29 19:13:53.988
310	PRODUCTO	Display Huawei MATE20 PRO INCELL	Huawei	-	0	0.01	313	\N	SISTEMA	system	2025-08-27 00:11:15.481	2025-08-29 19:16:39.511
325	PRODUCTO	Display Huawei NOVA Y90 ORIG	Huawei	-	0	700	325	\N	SISTEMA	system	2025-08-27 00:11:15.603	2025-08-29 19:20:38.03
316	PRODUCTO	Display Huawei NOVA 5T ORIG	Huawei		963	963	319	\N	SISTEMA	system	2025-08-27 00:11:15.532	2025-08-27 12:46:13.502
318	PRODUCTO	Display Huawei NOVA9 SE COG	Huawei		1040	1040	321	\N	SISTEMA	system	2025-08-27 00:11:15.544	2025-08-27 12:46:13.529
321	PRODUCTO	Display Huawei NOVA3 ORIG C/M(BOUTIQUE)	Huawei	-	0	1	324	\N	SISTEMA	system	2025-08-27 00:11:15.57	2025-08-29 17:03:50.102
320	PRODUCTO	Display Huawei NOVA 8 AMOLED	Huawei		1975	1975	323	\N	SISTEMA	system	2025-08-27 00:11:15.561	2025-08-27 12:46:13.555
340	PRODUCTO	Display Huawei P40 LITE COG	Huawei	-	0	740	346	\N	SISTEMA	system	2025-08-27 00:11:15.73	2025-08-29 17:21:34.437
322	PRODUCTO	Display Huawei NOVA Y90 ORIG	Huawei		1030	1030	325	\N	SISTEMA	system	2025-08-27 00:11:15.575	2025-08-27 12:46:13.577
323	PRODUCTO	Display Huawei NOVA9/HONOR 50 ORIG	Huawei		1620	1620	326	\N	SISTEMA	system	2025-08-27 00:11:15.583	2025-08-27 12:46:13.591
315	PRODUCTO	Display Huawei NOVA Y70/Y71 INCELL300+	Huawei	-	0	600	318	\N	SISTEMA	system	2025-08-27 00:11:15.526	2025-08-29 19:20:16.931
317	PRODUCTO	Display Huawei NOVA10 SE ORIG	Huawei	-	0	2150	320	\N	SISTEMA	system	2025-08-27 00:11:15.537	2025-08-29 19:21:05.59
326	PRODUCTO	Display Huawei NOVA5T/HONOR20 ORIG COF	Huawei		695	695	330	\N	SISTEMA	system	2025-08-27 00:11:15.611	2025-08-27 12:46:13.633
328	PRODUCTO	Display Huawei NOVA9/HONOR50 AMOLED S/M(CURVO)	Huawei	-	0	2500	332	\N	SISTEMA	system	2025-08-27 00:11:15.624	2025-08-29 17:15:11.286
329	PRODUCTO	Display Huawei NOVA8 AMOLED S/M(CURVO)	Huawei		1750	1750	333	\N	SISTEMA	system	2025-08-27 00:11:15.631	2025-08-27 12:46:13.664
330	PRODUCTO	Display Huawei NOVA Y60 ORIG	Huawei		663	663	334	\N	SISTEMA	system	2025-08-27 00:11:15.64	2025-08-27 12:46:13.673
331	PRODUCTO	Display Huawei NOVA Y70 ORIG	Huawei		663	663	335	\N	SISTEMA	system	2025-08-27 00:11:15.648	2025-08-27 12:46:13.681
332	PRODUCTO	Display Huawei NOVA3 INCELL S/M	Huawei	-	0	625	336	\N	SISTEMA	system	2025-08-27 00:11:15.653	2025-08-29 17:00:21.985
333	PRODUCTO	Display Huawei P SMART 2018	Huawei		720	720	339	\N	SISTEMA	system	2025-08-27 00:11:15.659	2025-08-27 12:46:13.727
336	PRODUCTO	Display Huawei P30 PRO OLED	Huawei		2670	2670	342	\N	SISTEMA	system	2025-08-27 00:11:15.687	2025-08-27 12:46:13.753
287	PRODUCTO	Display Honor X9A ORIG C/M(BOUTIQUE)	Honor		2288	2288	290	\N	SISTEMA	system	2025-08-27 00:11:15.309	2025-08-27 12:46:13.163
337	PRODUCTO	Display Huawei P20 PRO OLED	Huawei		2700	2700	343	\N	SISTEMA	system	2025-08-27 00:11:15.693	2025-08-27 12:46:13.762
338	PRODUCTO	Display Huawei P SMART 2019	Huawei		638	638	344	\N	SISTEMA	system	2025-08-27 00:11:15.706	2025-08-27 12:46:13.772
339	PRODUCTO	Display Huawei P SMART 2018	Huawei	-	0	600	339	\N	SISTEMA	system	2025-08-27 00:11:15.72	2025-08-29 17:10:16.208
295	PRODUCTO	Display Honor 10 LITE COG	Honor	-	0	825	298	\N	SISTEMA	system	2025-08-27 00:11:15.38	2025-08-29 18:49:09.196
341	PRODUCTO	Display Huawei P20 PRO COG	Huawei		870	870	347	\N	SISTEMA	system	2025-08-27 00:11:15.736	2025-08-27 12:46:13.804
342	PRODUCTO	Display Huawei P SMART 2019	Huawei		558	558	348	\N	SISTEMA	system	2025-08-27 00:11:15.741	2025-08-27 12:46:13.816
319	PRODUCTO	Display Huawei NOVA10 SE/NOVA11 SE/NOVA12	Huawei	-	0	2150	322	\N	SISTEMA	system	2025-08-27 00:11:15.549	2025-08-29 16:59:49.982
334	PRODUCTO	Display Huawei P smart 2019	Huawei		850	850	340	\N	SISTEMA	system	2025-08-27 00:11:15.67	2025-08-27 12:46:13.735
335	PRODUCTO	Display Huawei P30 LITE(128G) ORIG	Huawei		1025	1025	341	\N	SISTEMA	system	2025-08-27 00:11:15.678	2025-08-27 12:46:13.746
288	PRODUCTO	Display Honor X9A ORIG C/M(BOUTIQUE)	Honor		2300	2300	291	\N	SISTEMA	system	2025-08-27 00:11:15.318	2025-08-27 12:46:13.176
346	PRODUCTO	Display Huawei P40 LITE ORIG	Huawei		913	913	352	\N	SISTEMA	system	2025-08-27 00:11:15.776	2025-08-27 12:46:13.867
347	PRODUCTO	Display Huawei P30 LITE ORIG	Huawei		875	875	353	\N	SISTEMA	system	2025-08-27 00:11:15.783	2025-08-27 12:46:13.878
348	PRODUCTO	Display Huawei P30 INCELL S/M	Huawei	-	0	725	354	\N	SISTEMA	system	2025-08-27 00:11:15.79	2025-08-29 17:18:24.448
349	PRODUCTO	Display Huawei P40 LITE ORIG	Huawei		683	683	355	\N	SISTEMA	system	2025-08-27 00:11:15.8	2025-08-27 12:46:13.894
350	PRODUCTO	Display Huawei P SMART 2019	Huawei		710	710	356	\N	SISTEMA	system	2025-08-27 00:11:15.811	2025-08-27 12:46:13.908
375	PRODUCTO	Display Huawei Y6 2018 ORIG	Huawei	-	0	525	363	\N	SISTEMA	system	2025-08-27 00:11:16.015	2025-08-29 17:24:42.657
352	PRODUCTO	Display Huawei P20 LITE/ANE LX3	Huawei		567	567	358	\N	SISTEMA	system	2025-08-27 00:11:15.826	2025-08-27 12:46:13.927
369	PRODUCTO	Display Huawei Y9A ORIG C/M(BOUTIQUE)	Huawei	-	0	775	376	\N	SISTEMA	system	2025-08-27 00:11:15.962	2025-08-29 17:33:48.778
354	PRODUCTO	Display Huawei Y9S ORIG C/M(BOUTIQUE)	Huawei		980	980	360	\N	SISTEMA	system	2025-08-27 00:11:15.847	2025-08-27 12:46:13.949
360	PRODUCTO	Display Huawei Y9S/HONOR 9X ORIG	Huawei	-	0	775	366	\N	SISTEMA	system	2025-08-27 00:11:15.89	2025-08-29 19:13:19.08
356	PRODUCTO	Display Huawei Y7 2019 ORIG	Huawei		701	701	362	\N	SISTEMA	system	2025-08-27 00:11:15.86	2025-08-27 12:46:13.974
357	PRODUCTO	Display Huawei Y6 2018 ORIG	Huawei		673	673	363	\N	SISTEMA	system	2025-08-27 00:11:15.867	2025-08-27 12:46:13.982
358	PRODUCTO	Display Huawei Y7 2018 ORIG	Huawei		653	653	364	\N	SISTEMA	system	2025-08-27 00:11:15.874	2025-08-27 12:46:13.99
359	PRODUCTO	Display Huawei Y9S COG C/M(BOUTIQUE)	Huawei		675	675	365	\N	SISTEMA	system	2025-08-27 00:11:15.883	2025-08-27 12:46:14.003
355	PRODUCTO	Display Huawei Y9S/HONOR 9X INCELL300+	Huawei	-	0	0.01	361	\N	SISTEMA	system	2025-08-27 00:11:15.853	2025-08-29 19:13:37.739
361	PRODUCTO	Display Huawei Y9A COG S/M	Huawei		664	664	367	\N	SISTEMA	system	2025-08-27 00:11:15.896	2025-08-27 12:46:14.026
362	PRODUCTO	Display Huawei Y9 2019/Y8S COG	Huawei		510	510	368	\N	SISTEMA	system	2025-08-27 00:11:15.903	2025-08-27 12:46:14.036
363	PRODUCTO	Display Huawei Y9 2019/Y8S ORIG	Huawei		925	925	369	\N	SISTEMA	system	2025-08-27 00:11:15.908	2025-08-27 12:46:14.045
364	PRODUCTO	Display Huawei Y9S/HONOR 9X COG	Huawei	-	0	775	370	\N	SISTEMA	system	2025-08-27 00:11:15.914	2025-08-29 17:42:09.959
365	PRODUCTO	Display Huawei Y9S ORIG C/M(BOUTIQUE)	Huawei		963	963	372	\N	SISTEMA	system	2025-08-27 00:11:15.924	2025-08-27 12:46:14.079
366	PRODUCTO	Display Huawei Y7P ORIG C/M(BOUTIQUE)	Huawei		688	688	373	\N	SISTEMA	system	2025-08-27 00:11:15.932	2025-08-27 12:46:14.09
367	PRODUCTO	Display Huawei Y6 2019 ORIG	Huawei		678	678	374	\N	SISTEMA	system	2025-08-27 00:11:15.942	2025-08-27 12:46:14.105
368	PRODUCTO	Display Huawei Y7A ORIG C/M(BOUTIQUE)	Huawei		763	763	375	\N	SISTEMA	system	2025-08-27 00:11:15.949	2025-08-27 12:46:14.117
397	PRODUCTO	Display LG K51 ORIG S/M	LG	-	0	599	406	\N	SISTEMA	system	2025-08-27 00:11:16.186	2025-08-29 19:27:09.637
370	PRODUCTO	Display Huawei Y9 PRIME ORIG	Huawei		950	950	377	\N	SISTEMA	system	2025-08-27 00:11:15.971	2025-08-27 12:46:14.135
372	PRODUCTO	Display Huawei Y9 PRIME COG	Huawei	-	0	549	379	\N	SISTEMA	system	2025-08-27 00:11:15.988	2025-08-29 17:41:06.583
373	PRODUCTO	Display Huawei Y9A ORIG COF	Huawei		695	695	380	\N	SISTEMA	system	2025-08-27 00:11:15.997	2025-08-27 12:46:14.167
374	PRODUCTO	Display Huawei Y7 2018 ORIG	Huawei	-	0	550	381	\N	SISTEMA	system	2025-08-27 00:11:16.007	2025-08-29 17:26:21.717
382	PRODUCTO	Display Huawei Y6 2019/Y6S/HONOR 8A	Huawei	-	0	580	390	\N	SISTEMA	system	2025-08-27 00:11:16.067	2025-08-29 17:26:40.64
376	PRODUCTO	Display Huawei Y7P/P40 LITE E	Huawei	-	0	750	383	\N	SISTEMA	system	2025-08-27 00:11:16.021	2025-08-29 17:44:35.35
377	PRODUCTO	Display Huawei Y7A/P SMART 2021/HONOR	Huawei		544	544	384	\N	SISTEMA	system	2025-08-27 00:11:16.027	2025-08-27 12:46:14.209
378	PRODUCTO	Display Huawei Y8P/Honor 20 lite	Huawei		584	584	385	\N	SISTEMA	system	2025-08-27 00:11:16.036	2025-08-27 12:46:14.224
353	PRODUCTO	Display Huawei Y6P/HONOR9A/10E/HONOR9S PRIME COF	Huawei	-	0	599	359	\N	SISTEMA	system	2025-08-27 00:11:15.836	2025-08-29 17:27:59.016
380	PRODUCTO	Display Huawei Y9 2019/Y8S ORIG	Huawei		675	675	387	\N	SISTEMA	system	2025-08-27 00:11:16.053	2025-08-27 12:46:14.246
381	PRODUCTO	Display Huawei Y9 PRIME ORIG	Huawei		675	675	388	\N	SISTEMA	system	2025-08-27 00:11:16.06	2025-08-27 12:46:14.258
379	PRODUCTO	Display Huawei Y6P/HONOR9A/10E/HONOR9S PRIME COG	Huawei	-	0	600	386	\N	SISTEMA	system	2025-08-27 00:11:16.043	2025-08-29 17:27:41.585
385	PRODUCTO	Display Infinix X6831/HOT30 ORIG C/M(BOUTIQUE)	Infinix		800	800	394	\N	SISTEMA	system	2025-08-27 00:11:16.098	2025-08-27 12:46:14.322
383	PRODUCTO	Display Infinix X688/HOT10 PLAY ORIG	Infinix		601	601	391	\N	SISTEMA	system	2025-08-27 00:11:16.079	2025-08-27 12:46:14.287
386	PRODUCTO	Display Infinix X6515/Smart 7 ORIG	Infinix		658	658	395	\N	SISTEMA	system	2025-08-27 00:11:16.105	2025-08-27 12:46:14.329
387	PRODUCTO	Display Infinix X6833/Note30 ORIG C/M(BOUTIQUE)	Infinix		725	725	396	\N	SISTEMA	system	2025-08-27 00:11:16.111	2025-08-27 12:46:14.34
388	PRODUCTO	Display Infinix X669 ORIG C/M(BOUTIQUE)	Infinix		701	701	397	\N	SISTEMA	system	2025-08-27 00:11:16.121	2025-08-27 12:46:14.353
389	PRODUCTO	Display Infinix X6515/SMART 7 ORIG	Infinix	-	0	600	398	\N	SISTEMA	system	2025-08-27 00:11:16.129	2025-08-29 19:21:49.039
390	PRODUCTO	Display Infinix X669/HOT 30i ORIG	Infinix		504	504	399	\N	SISTEMA	system	2025-08-27 00:11:16.135	2025-08-27 12:46:14.37
391	PRODUCTO	Display Infinix X6833/Note30 4G ORIG	Infinix		693	693	400	\N	SISTEMA	system	2025-08-27 00:11:16.141	2025-08-27 12:46:14.38
392	PRODUCTO	Display Infinix X6831/HOT 30 ORIG	Infinix		653	653	401	\N	SISTEMA	system	2025-08-27 00:11:16.147	2025-08-27 12:46:14.391
393	PRODUCTO	Display LG K42/K52/K62 ORIG S/M	LG	-	0	578	402	\N	SISTEMA	system	2025-08-27 00:11:16.155	2025-08-29 19:21:03.039
394	PRODUCTO	Display LG K41S ORIG S/M	LG	-	0	599	403	\N	SISTEMA	system	2025-08-27 00:11:16.168	2025-08-29 19:25:15.784
395	PRODUCTO	Display LG K50 ORIG S/M	LG		527	527	404	\N	SISTEMA	system	2025-08-27 00:11:16.175	2025-08-27 12:46:14.42
396	PRODUCTO	Display LG K22 ORIG S/M	LG		492	492	405	\N	SISTEMA	system	2025-08-27 00:11:16.18	2025-08-27 12:46:14.431
398	PRODUCTO	Display LG K51S ORIG S/M	LG	-	0	600	407	\N	SISTEMA	system	2025-08-27 00:11:16.191	2025-08-29 19:25:59.181
351	PRODUCTO	Display Huawei P30 LITE ORIG	Huawei	-	0	1325	353	\N	SISTEMA	system	2025-08-27 00:11:15.821	2025-08-29 17:20:35.683
384	PRODUCTO	Display Infinix X678B/NOTE30 PRO ORIG	Infinix		795	795	393	\N	SISTEMA	system	2025-08-27 00:11:16.087	2025-08-27 12:46:14.313
344	PRODUCTO	Display Huawei P30 OLED S/M	Huawei		1575	1575	350	\N	SISTEMA	system	2025-08-27 00:11:15.756	2025-08-27 12:46:13.839
345	PRODUCTO	Display Huawei P20 LITE ORIG	Huawei		800	800	351	\N	SISTEMA	system	2025-08-27 00:11:15.77	2025-08-27 12:46:13.849
421	PRODUCTO	Display Motorola E7PLUS/G9/G9PLAY ORIG S/M	Motorola	-	0	600	430	\N	SISTEMA	system	2025-08-27 00:11:16.35	2025-08-29 17:16:05.206
414	PRODUCTO	Display Motorola E22/E22i ORIG S/M	Motorola	-	0	599	423	\N	SISTEMA	system	2025-08-27 00:11:16.301	2025-08-29 19:30:10.56
404	PRODUCTO	Display Motorola E30/E40 ORIG C/M(BOUTIQUE)	Motorola		638	638	413	\N	SISTEMA	system	2025-08-27 00:11:16.228	2025-08-27 12:46:14.517
427	PRODUCTO	Display Motorola EDGE 40/EDGE 40	Motorola	-	0	2375	436	\N	SISTEMA	system	2025-08-27 00:11:16.417	2025-08-29 17:19:44.034
406	PRODUCTO	Display Motorola E7 ORIG C/M(BOUTIQUE)	Motorola		687	687	415	\N	SISTEMA	system	2025-08-27 00:11:16.246	2025-08-27 12:46:14.536
407	PRODUCTO	Display Motorola E6S ORIG C/M(BOUTIQUE)	Motorola		638	638	416	\N	SISTEMA	system	2025-08-27 00:11:16.251	2025-08-27 12:46:14.553
408	PRODUCTO	Display Motorola E20 ORIG C/M	Motorola		687	687	417	\N	SISTEMA	system	2025-08-27 00:11:16.259	2025-08-27 12:46:14.567
409	PRODUCTO	Display Motorola E6PLUS ORIG C/M(BOUTIQUE)	Motorola		630	630	418	\N	SISTEMA	system	2025-08-27 00:11:16.264	2025-08-27 12:46:14.586
410	PRODUCTO	Display Motorola E40 ORIG C/M(BOUTIQUE)	Motorola		675	675	419	\N	SISTEMA	system	2025-08-27 00:11:16.27	2025-08-27 12:46:14.605
411	PRODUCTO	Display Motorola E22 ORIG C/M(BOUTIQUE)	Motorola		715	715	420	\N	SISTEMA	system	2025-08-27 00:11:16.277	2025-08-27 12:46:14.62
412	PRODUCTO	Display Motorola E5PLUS ORIG S/M	Motorola		458	458	421	\N	SISTEMA	system	2025-08-27 00:11:16.287	2025-08-27 12:46:14.637
413	PRODUCTO	Display Motorola E5PLUS ORIG S/M	Motorola	-	0	600	422	\N	SISTEMA	system	2025-08-27 00:11:16.295	2025-08-29 19:33:29.918
420	PRODUCTO	Display Motorola E6PLAY ORIG S/M	Motorola	-	0	600	429	\N	SISTEMA	system	2025-08-27 00:11:16.345	2025-08-29 19:33:58.838
415	PRODUCTO	Display Motorola E20/XT2155 ORIG S/M	Motorola	-	0	600	424	\N	SISTEMA	system	2025-08-27 00:11:16.308	2025-08-29 19:29:26.54
401	PRODUCTO	Display Motorola E7 INCELL300+ C/M	Motorola	-	0	601	410	\N	SISTEMA	system	2025-08-27 00:11:16.211	2025-08-29 19:35:53.233
417	PRODUCTO	Display Motorola E5 PLAY GO	Motorola	-	0	600	426	\N	SISTEMA	system	2025-08-27 00:11:16.326	2025-08-29 19:32:09.977
418	PRODUCTO	Display Motorola E7/E7POWER/E7I/ E7IPOWER ORIG	Motorola	-	0	600	427	\N	SISTEMA	system	2025-08-27 00:11:16.334	2025-08-29 19:32:47.158
419	PRODUCTO	Display Motorola E6PLUS ORIG S/M	Motorola	-	0	599	428	\N	SISTEMA	system	2025-08-27 00:11:16.339	2025-08-29 19:28:28.916
416	PRODUCTO	Display Motorola E6S/E6i ORIG S/M	Motorola	-	0	600	425	\N	SISTEMA	system	2025-08-27 00:11:16.314	2025-08-29 19:35:24.396
405	PRODUCTO	Display Motorola E7POWER ORIG C/M(BOUTIQUE)	Motorola	-	0	600	414	\N	SISTEMA	system	2025-08-27 00:11:16.235	2025-08-29 17:18:09.234
422	PRODUCTO	Display Motorola EDGE50 PRO AMOLED	Motorola	-	0	2350	431	\N	SISTEMA	system	2025-08-27 00:11:16.357	2025-08-29 17:23:32.484
438	PRODUCTO	Display Motorola G8POWER LITE INCELL300+	Motorola	-	0	600	449	\N	SISTEMA	system	2025-08-27 00:11:16.501	2025-08-29 21:20:17.781
424	PRODUCTO	Display Motorola EDGE 40 NEO	Motorola		3250	3250	433	\N	SISTEMA	system	2025-08-27 00:11:16.376	2025-08-27 12:49:59.564
425	PRODUCTO	Display Motorola EDGE 40 NEO	Motorola		3250	3250	434	\N	SISTEMA	system	2025-08-27 00:11:16.398	2025-08-27 12:49:59.576
426	PRODUCTO	Display Motorola EDGE 40 NEO	Motorola	-	0	2375	435	\N	SISTEMA	system	2025-08-27 00:11:16.41	2025-08-29 17:18:43.851
429	PRODUCTO	Display Motorola EDGE ORIG S/M	Motorola	-	0	3400	438	\N	SISTEMA	system	2025-08-27 00:11:16.432	2025-08-29 17:20:25.905
432	PRODUCTO	Display Motorola EDGE20/EDGE20 PRO/EDGE30 PRO	Motorola	-	0	2075	443	\N	SISTEMA	system	2025-08-27 00:11:16.456	2025-08-29 17:21:42.944
430	PRODUCTO	Display Motorola EDGE20 LITE AMOLED	Motorola		1995	1995	440	\N	SISTEMA	system	2025-08-27 00:11:16.44	2025-08-27 12:49:59.652
433	PRODUCTO	Display Motorola G5G 2023 ORIG	Motorola		865	865	444	\N	SISTEMA	system	2025-08-27 00:11:16.463	2025-08-27 12:49:59.712
400	PRODUCTO	Display Motorola E32/E22/E32S/G22 INCELL300+ S/M	Motorola	-	0	0.01	409	\N	SISTEMA	system	2025-08-27 00:11:16.205	2025-08-29 19:31:25.587
437	PRODUCTO	Display Motorola G10/G20/G30 INCELL300+ C/M	Motorola	-	0	600	448	\N	SISTEMA	system	2025-08-27 00:11:16.494	2025-08-29 17:42:53.211
431	PRODUCTO	Display Motorola G72/G52/G71S/G82/EDGE30 AMOLED S/M	Motorola	-	0	2150	441	\N	SISTEMA	system	2025-08-27 00:11:16.45	2025-08-29 19:54:52.307
436	PRODUCTO	Display Motorola G9 PLAY INCELL300+	Motorola		530	530	447	\N	SISTEMA	system	2025-08-27 00:11:16.482	2025-08-27 12:49:59.751
403	PRODUCTO	Display Motorola E13 ORIG S/M	Motorola	-	0	619	412	\N	SISTEMA	system	2025-08-27 00:11:16.224	2025-08-29 19:27:47.118
439	PRODUCTO	Display Motorola G31/G41/G71 INCELL300+ S/M	Motorola	-	0	1475	450	\N	SISTEMA	system	2025-08-27 00:11:16.506	2025-08-29 19:17:32.538
440	PRODUCTO	Display Motorola G STYLUS 2021	Motorola		1450	1450	451	\N	SISTEMA	system	2025-08-27 00:11:16.512	2025-08-27 12:49:59.804
441	PRODUCTO	Display Motorola G PURE 4G	Motorola		680	680	452	\N	SISTEMA	system	2025-08-27 00:11:16.524	2025-08-27 12:49:59.816
442	PRODUCTO	Display Motorola G POWER 2022	Motorola		687	687	453	\N	SISTEMA	system	2025-08-27 00:11:16.531	2025-08-27 12:49:59.827
443	PRODUCTO	Display Motorola G STYLUS 2022	Motorola		1425	1425	454	\N	SISTEMA	system	2025-08-27 00:11:16.536	2025-08-27 12:49:59.84
444	PRODUCTO	Display Motorola G5G 2022 4G	Motorola		673	673	455	\N	SISTEMA	system	2025-08-27 00:11:16.541	2025-08-27 12:49:59.852
450	PRODUCTO	Display Motorola G5G/ONE 5G ACE	Motorola	-	0	625	461	\N	SISTEMA	system	2025-08-27 00:11:16.586	2025-08-29 19:47:00.579
449	PRODUCTO	Display Motorola G STYLUS 2021	Motorola	-	0	775	451	\N	SISTEMA	system	2025-08-27 00:11:16.581	2025-08-29 17:30:46.042
451	PRODUCTO	Display Motorola G POWER 2022	Motorola	-	0	850	462	\N	SISTEMA	system	2025-08-27 00:11:16.595	2025-08-29 17:28:47.71
434	PRODUCTO	Display Motorola G STYLUS 5G	Motorola	-	0	950	445	\N	SISTEMA	system	2025-08-27 00:11:16.47	2025-08-29 17:31:47.383
448	PRODUCTO	Display Motorola G STYLUS 2022	Motorola	-	0	925	459	\N	SISTEMA	system	2025-08-27 00:11:16.574	2025-08-29 17:31:33.355
445	PRODUCTO	Display Motorola G5G ORIG C/M(BOUTIQUE)	Motorola	-	0	625	456	\N	SISTEMA	system	2025-08-27 00:11:16.546	2025-08-29 19:47:23.098
446	PRODUCTO	Display Motorola G PURE 4G	Motorola	-	0	600	457	\N	SISTEMA	system	2025-08-27 00:11:16.553	2025-08-29 17:30:16.256
452	PRODUCTO	Display Motorola G5G 2022 4G	Motorola	-	0	600	455	\N	SISTEMA	system	2025-08-27 00:11:16.603	2025-08-29 19:43:55.273
402	PRODUCTO	Display Motorola E7/E7i/E7power/E7ipower INCELL300+ S/M	Motorola	-	0	600	411	\N	SISTEMA	system	2025-08-27 00:11:16.217	2025-08-29 17:14:54.909
423	PRODUCTO	Display Motorola G85/S50 NEO/EDGE 50	Motorola	-	0	2350	432	\N	SISTEMA	system	2025-08-27 00:11:16.369	2025-08-29 21:12:19.758
447	PRODUCTO	Display Motorola G PLAY 2021	Motorola	-	0	600	458	\N	SISTEMA	system	2025-08-27 00:11:16.563	2025-08-29 17:26:56.527
435	PRODUCTO	Display Motorola G5G 2023 ORIG	Motorola	-	0	600	444	\N	SISTEMA	system	2025-08-27 00:11:16.476	2025-08-29 19:44:45.405
457	PRODUCTO	Display Motorola G31/G41/G71 INCELL S/M	Motorola	-	0	1475	468	\N	SISTEMA	system	2025-08-27 00:11:16.642	2025-08-29 19:12:15.121
505	PRODUCTO	Display Motorola G50 5G ORIG	Motorola	-	0	600	518	\N	SISTEMA	system	2025-08-27 00:11:17.062	2025-08-29 19:31:01.988
491	PRODUCTO	Display Motorola G31 OLED C/M(BOUTIQUE)	Motorola	-	0	1475	503	\N	SISTEMA	system	2025-08-27 00:11:16.944	2025-08-29 19:12:41.876
501	PRODUCTO	Display Motorola G8 ORIG S/M	Motorola	-	0	600	513	\N	SISTEMA	system	2025-08-27 00:11:17.021	2025-08-29 21:10:07.338
461	PRODUCTO	Display Motorola G41 INCELL C/M(BOUTIQUE)	Motorola	-	0	1475	472	\N	SISTEMA	system	2025-08-27 00:11:16.682	2025-08-29 19:22:48.07
465	PRODUCTO	Display Motorola G54/G55/G64 ORIG C/M(BOUTIQUE)	Motorola	-	0	650	476	\N	SISTEMA	system	2025-08-27 00:11:16.708	2025-08-29 19:42:13.341
463	PRODUCTO	Display Motorola G8 PLAY/ONE MACRO	Motorola		650	650	474	\N	SISTEMA	system	2025-08-27 00:11:16.695	2025-08-27 12:50:00.069
466	PRODUCTO	Display Motorola G84 AMOLED ORIG	Motorola	-	0	1900	477	\N	SISTEMA	system	2025-08-27 00:11:16.714	2025-08-29 21:11:20.138
470	PRODUCTO	Display Motorola G6 ORIG S/M	Motorola	-	0	600	481	\N	SISTEMA	system	2025-08-27 00:11:16.749	2025-08-29 19:48:08.535
500	PRODUCTO	Display Motorola G8PLUS ORIG S/M	Motorola	-	0	625	512	\N	SISTEMA	system	2025-08-27 00:11:17.016	2025-08-29 21:19:29.939
460	PRODUCTO	Display Motorola G71 INCELL BOUTIQUE	Motorola	-	0	1475	471	\N	SISTEMA	system	2025-08-27 00:11:16.671	2025-08-29 21:07:27.093
468	PRODUCTO	Display Motorola G14/G54/G55/G64 ORIG S/M	Motorola	-	0	650	479	\N	SISTEMA	system	2025-08-27 00:11:16.736	2025-08-29 17:41:48.635
503	PRODUCTO	Display Motorola G200 5G/EDGE 2021	Motorola	-	0	1025	515	\N	SISTEMA	system	2025-08-27 00:11:17.043	2025-08-29 17:44:18.562
482	PRODUCTO	Display Motorola G60S ORIG C/M(BOUTIQUE)	Motorola	-	0	700	494	\N	SISTEMA	system	2025-08-27 00:11:16.853	2025-08-29 19:49:54.248
473	PRODUCTO	Display Motorola G53 ORIG C/M(BOUTIQUE)	Motorola	-	0	600	484	\N	SISTEMA	system	2025-08-27 00:11:16.776	2025-08-29 19:41:00.635
472	PRODUCTO	Display Motorola G10 PLAY/G POWER	Motorola		650	650	483	\N	SISTEMA	system	2025-08-27 00:11:16.768	2025-08-27 12:50:00.174
462	PRODUCTO	Display Motorola G53 ORIG S/M	Motorola	-	0	600	473	\N	SISTEMA	system	2025-08-27 00:11:16.688	2025-08-29 19:41:16.561
474	PRODUCTO	Display Motorola G7PLAY ORIG C/M(BOUTIQUE)	Motorola	-	0	675	485	\N	SISTEMA	system	2025-08-27 00:11:16.781	2025-08-29 21:06:18.571
475	PRODUCTO	Display Motorola G8POWER LITE ORIG	Motorola		673	673	486	\N	SISTEMA	system	2025-08-27 00:11:16.788	2025-08-27 12:50:00.21
476	PRODUCTO	Display Motorola G6PLAY/E5 ORIG S/M	Motorola		478	478	487	\N	SISTEMA	system	2025-08-27 00:11:16.794	2025-08-27 12:50:00.227
477	PRODUCTO	Display Motorola G50 4G ORIG	Motorola		650	650	488	\N	SISTEMA	system	2025-08-27 00:11:16.804	2025-08-27 12:50:00.237
479	PRODUCTO	Display Motorola G9PLAY/E7PLUS ORIG C/M(BOUTIQUE)	Motorola	-	0	600	491	\N	SISTEMA	system	2025-08-27 00:11:16.819	2025-08-29 21:21:46.626
481	PRODUCTO	Display Motorola G8PLAY/ONE MACRO ORIG	Motorola		458	458	493	\N	SISTEMA	system	2025-08-27 00:11:16.84	2025-08-27 12:50:00.311
484	PRODUCTO	Display Motorola G10/G20/G30 ORIG C/M(BOUTIQUE)	Motorola	-	0	600	496	\N	SISTEMA	system	2025-08-27 00:11:16.872	2025-08-29 17:37:33.431
497	PRODUCTO	Display Motorola G62 ORIG S/M	Motorola	-	0	675	509	\N	SISTEMA	system	2025-08-27 00:11:16.99	2025-08-29 19:50:42.042
469	PRODUCTO	Display Motorola G14 ORIG C/M(BOUTIQUE)	Motorola	-	0	650	480	\N	SISTEMA	system	2025-08-27 00:11:16.742	2025-08-29 17:41:16.679
504	PRODUCTO	Display Motorola G100/EDGE S ORIG	Motorola	-	0	925	516	\N	SISTEMA	system	2025-08-27 00:11:17.054	2025-08-29 17:39:12.01
485	PRODUCTO	Display Motorola G9PLUS ORIG C/M(BOUTIQUE)	Motorola	-	0	675	497	\N	SISTEMA	system	2025-08-27 00:11:16.885	2025-08-29 21:23:03.381
467	PRODUCTO	Display Motorola G73 5G ORIG	Motorola	-	0	675	478	\N	SISTEMA	system	2025-08-27 00:11:16.727	2025-08-29 21:50:31.718
483	PRODUCTO	Display Motorola G13/G23 ORIG C/M(BOUTIQUE)	Motorola	-	0	600	495	\N	SISTEMA	system	2025-08-27 00:11:16.862	2025-08-29 17:40:38.664
488	PRODUCTO	Display Motorola G50 5G ORIG	Motorola		701	701	500	\N	SISTEMA	system	2025-08-27 00:11:16.918	2025-08-27 12:50:00.406
486	PRODUCTO	Display Motorola G72 AMOLED C/M	Motorola	-	0	2150	498	\N	SISTEMA	system	2025-08-27 00:11:16.892	2025-08-29 19:54:28.84
490	PRODUCTO	Display Motorola G41 OLED C/M(BOUTIGUE)	Motorola	-	0	1475	502	\N	SISTEMA	system	2025-08-27 00:11:16.936	2025-08-29 19:23:24.565
480	PRODUCTO	Display Motorola G22 ORIG C/M(BOUTIQUE)	Motorola	-	0	600	492	\N	SISTEMA	system	2025-08-27 00:11:16.826	2025-08-29 19:13:46.234
471	PRODUCTO	Display Motorola G52/G71S/G82 INCELL C/M(BOUTIGUE)	Motorola	-	0	2150	482	\N	SISTEMA	system	2025-08-27 00:11:16.758	2025-08-29 19:37:33.532
458	PRODUCTO	Display Motorola G42 INCELL C/M(BOUTIQUE)	Motorola	-	0	1525	469	\N	SISTEMA	system	2025-08-27 00:11:16.656	2025-08-29 19:29:50.317
495	PRODUCTO	Display Motorola G60 ORIG C/M(BOUTIQUE)	Motorola	-	0	700	507	\N	SISTEMA	system	2025-08-27 00:11:16.978	2025-08-29 19:49:13.831
496	PRODUCTO	Display Motorola G42 OLED S/M	Motorola	-	0	1525	508	\N	SISTEMA	system	2025-08-27 00:11:16.985	2025-08-29 19:28:42.947
502	PRODUCTO	Display Motorola G6PLUS ORIG S/M	Motorola	-	0	600	514	\N	SISTEMA	system	2025-08-27 00:11:17.03	2025-08-29 19:52:26.971
498	PRODUCTO	Display Motorola G32/G73 ORIG S/M	Motorola	-	0	675	510	\N	SISTEMA	system	2025-08-27 00:11:17.001	2025-08-29 19:25:53.097
499	PRODUCTO	Display Motorola G31/G41/G71 OLED S/M	Motorola	-	0	1475	511	\N	SISTEMA	system	2025-08-27 00:11:17.01	2025-08-29 19:18:20.928
478	PRODUCTO	Display Motorola G8PLUS ORIG C/M(BOUTIQUE)	Motorola	-	0	625	490	\N	SISTEMA	system	2025-08-27 00:11:16.811	2025-08-29 21:19:56.471
464	PRODUCTO	Display Motorola G8 PLAY/ONE MACRO	Motorola	-	0	600	474	\N	SISTEMA	system	2025-08-27 00:11:16.7	2025-08-29 21:10:26.306
489	PRODUCTO	Display Motorola G71 OLED C/M（BOUTIQUE）	Motorola	-	0	1475	501	\N	SISTEMA	system	2025-08-27 00:11:16.927	2025-08-29 19:53:39.329
455	PRODUCTO	Display Motorola G24/G24 POWER ORIG	Motorola	-	0	600	466	\N	SISTEMA	system	2025-08-27 00:11:16.627	2025-08-29 17:47:38.363
487	PRODUCTO	Display Motorola G13/G23 ORIG S/M	Motorola	-	0	600	499	\N	SISTEMA	system	2025-08-27 00:11:16.903	2025-08-29 17:39:50.935
492	PRODUCTO	Display Motorola G52 AMOLED C/M	Motorola	-	0	2150	504	\N	SISTEMA	system	2025-08-27 00:11:16.95	2025-08-29 19:32:34.092
893	PRODUCTO	Display ZTE V41 SMART ORIG	ZTE	-	0	651	916	\N	SISTEMA	system	2025-08-27 00:11:19.751	2025-08-29 21:35:07.926
493	PRODUCTO	Display Motorola G42 OLED C/M(BOUTIQUE)	Motorola	-	0	1525	505	\N	SISTEMA	system	2025-08-27 00:11:16.962	2025-08-29 19:27:50.206
459	PRODUCTO	Display Motorola G31 INCELL C/M(BOUTIQUE)	Motorola	-	0	1475	470	\N	SISTEMA	system	2025-08-27 00:11:16.661	2025-08-29 19:11:04.774
456	PRODUCTO	Display Motorola E14/G04/G04S/G24/G24 POWER ORIG	Motorola	-	0	599	467	\N	SISTEMA	system	2025-08-27 00:11:16.634	2025-08-29 19:29:00.113
510	PRODUCTO	Display Motorola G9POWER ORIG S/M	Motorola	-	0	625	523	\N	SISTEMA	system	2025-08-27 00:11:17.094	2025-08-29 21:22:37.32
509	PRODUCTO	Display Motorola G8POWER ORIG S/M	Motorola	-	0	675	522	\N	SISTEMA	system	2025-08-27 00:11:17.089	2025-08-29 21:21:18.801
514	PRODUCTO	Display Motorola G7PLAY ORIG S/M	Motorola	-	0	600	527	\N	SISTEMA	system	2025-08-27 00:11:17.125	2025-08-29 21:09:39.55
512	PRODUCTO	Display Motorola G7/G7PLUS ORIG S/M	Motorola	-	0	675	525	\N	SISTEMA	system	2025-08-27 00:11:17.108	2025-08-29 19:52:51.997
515	PRODUCTO	Display Motorola G7POWER ORIG S/M	Motorola	-	0	600	528	\N	SISTEMA	system	2025-08-27 00:11:17.133	2025-08-29 21:09:53.653
511	PRODUCTO	Display Motorola G8POWER LITE ORIG	Motorola	-	0	600	486	\N	SISTEMA	system	2025-08-27 00:11:17.101	2025-08-29 21:20:35.859
523	PRODUCTO	Display Motorola ONE ORIG S/M	Motorola	-	0	600	536	\N	SISTEMA	system	2025-08-27 00:11:17.185	2025-08-29 19:23:06.07
526	PRODUCTO	Display Motorola Z2 PLAY OLED	Motorola	-	0	1038	540	\N	SISTEMA	system	2025-08-27 00:11:17.216	2025-08-29 19:25:33.585
522	PRODUCTO	Display Motorola ONE FUSION PLUS	Motorola	-	0	600	529	\N	SISTEMA	system	2025-08-27 00:11:17.181	2025-08-29 19:22:21.12
517	PRODUCTO	Display Motorola ONE ORIG C/M(BOUTIQUE)	Motorola	-	0	600	530	\N	SISTEMA	system	2025-08-27 00:11:17.146	2025-08-29 19:22:59.692
518	PRODUCTO	Display Motorola ONE ZOOM/XT2010 OLED	Motorola	-	0	1425	531	\N	SISTEMA	system	2025-08-27 00:11:17.152	2025-08-29 19:23:53.474
520	PRODUCTO	Display Motorola ONE HYPER/XT2027 ORIG	Motorola	-	0	600	533	\N	SISTEMA	system	2025-08-27 00:11:17.17	2025-08-29 19:22:40.357
521	PRODUCTO	Display Motorola ONE VISION/ONE ATION	Motorola	-	0	1875	534	\N	SISTEMA	system	2025-08-27 00:11:17.175	2025-08-29 19:23:26.872
524	PRODUCTO	Display Motorola X4 ORIG S/M	Motorola		687	687	537	\N	SISTEMA	system	2025-08-27 00:11:17.194	2025-08-27 12:50:00.857
525	PRODUCTO	Display Motorola Z2 PLAY OLED	Motorola		938	938	538	\N	SISTEMA	system	2025-08-27 00:11:17.207	2025-08-27 12:50:00.871
528	PRODUCTO	Display Nokia G10/G20 ORIG S/M	Nokia	-	0	600	542	\N	SISTEMA	system	2025-08-27 00:11:17.228	2025-08-29 19:26:08.371
529	PRODUCTO	Display OnePlus 1+N10 ORIG S/M	OnePlus		740	740	543	\N	SISTEMA	system	2025-08-27 00:11:17.237	2025-08-27 12:50:00.936
519	PRODUCTO	Display Motorola ONE FUSION ORIG	Motorola	-	0	600	532	\N	SISTEMA	system	2025-08-27 00:11:17.162	2025-08-29 19:22:08.468
531	PRODUCTO	Display OnePlus 1+N10 ORIG S/M	OnePlus	-	0	850	543	\N	SISTEMA	system	2025-08-27 00:11:17.255	2025-08-29 19:26:49.403
539	PRODUCTO	Display Oppo "A5 2020//A8/A11/A11X/A31/A9 2020	oppo	-	0	600	554	\N	SISTEMA	system	2025-08-27 00:11:17.315	2025-08-29 19:28:10.037
543	PRODUCTO	Display Oppo A17/A17K ORIG C/M(BOUTIQUE)	oppo	-	0	600	558	\N	SISTEMA	system	2025-08-27 00:11:17.346	2025-08-29 19:36:10.114
558	PRODUCTO	Display Oppo A12/A7/A7n/A5S/Ax5S/A11K/A12s/Realme3/Realme3i ORIG S/M	oppo	-	0	600	573	\N	SISTEMA	system	2025-08-27 00:11:17.458	2025-08-29 19:34:24.819
534	PRODUCTO	Display Oppo "A17/A17K//A38/A57/A57S/A57E/A58 5G/A58X 5G/	oppo		415	415	549	\N	SISTEMA	system	2025-08-27 00:11:17.281	2025-08-27 12:50:01.018
550	PRODUCTO	Display Oppo A54 4G ORIG	oppo	-	0	600	565	\N	SISTEMA	system	2025-08-27 00:11:17.4	2025-08-29 19:37:58.568
560	PRODUCTO	Display Oppo C21Y/C25Y ORIG S/M	oppo	-	0	600	575	\N	SISTEMA	system	2025-08-27 00:11:17.469	2025-08-29 19:41:50.001
559	PRODUCTO	Display Oppo c30/C30i/C33/C50i ORIG S/M	oppo	-	0	600	574	\N	SISTEMA	system	2025-08-27 00:11:17.465	2025-08-29 19:48:20.291
538	PRODUCTO	Display Oppo A53 4G/1+N100/A32/A33/A53S/A11S/ REALME7I/REALME	oppo		429	429	553	\N	SISTEMA	system	2025-08-27 00:11:17.308	2025-08-27 12:50:01.058
533	PRODUCTO	Display Oppo "RENO7 4G(5G)/A78 4G/RENO7SE	oppo	-	0	2025	547	\N	SISTEMA	system	2025-08-27 00:11:17.272	2025-08-29 19:32:36.819
540	PRODUCTO	Display Oppo A93 4G INCELL	oppo	-	0	725	555	\N	SISTEMA	system	2025-08-27 00:11:17.327	2025-08-29 19:39:50.898
549	PRODUCTO	Display Oppo A16 ORIG C/M(BOUTIQUE)	oppo	-	0	600	564	\N	SISTEMA	system	2025-08-27 00:11:17.394	2025-08-29 19:35:32.722
542	PRODUCTO	Display Oppo C11 2021/C20/C21 ORIG	oppo		664	664	557	\N	SISTEMA	system	2025-08-27 00:11:17.34	2025-08-27 12:50:01.1
548	PRODUCTO	Display Oppo A32/A33/A53 4G ORIG	oppo	-	0	600	563	\N	SISTEMA	system	2025-08-27 00:11:17.387	2025-08-29 19:36:46.395
557	PRODUCTO	Display Oppo C30S ORIG S/M	oppo	-	0	600	572	\N	SISTEMA	system	2025-08-27 00:11:17.451	2025-08-29 19:42:20.43
545	PRODUCTO	Display Oppo A52/A72/A92 4G ORIG	oppo		638	638	560	\N	SISTEMA	system	2025-08-27 00:11:17.362	2025-08-27 12:50:01.132
546	PRODUCTO	Display Oppo A93 5G ORIG	oppo		700	700	561	\N	SISTEMA	system	2025-08-27 00:11:17.373	2025-08-27 12:50:01.148
513	PRODUCTO	Display Motorola G6PLAY/E5 ORIG S/M	Motorola	-	0	600	526	\N	SISTEMA	system	2025-08-27 00:11:17.118	2025-08-29 19:52:03.848
535	PRODUCTO	Display Oppo A52/A72/A92 INCELL300+ S/M	oppo	-	0	638	550	\N	SISTEMA	system	2025-08-27 00:11:17.289	2025-08-29 19:37:17.805
532	PRODUCTO	Display Oppo A16/A16S/A54S/Realme C25/RealmeC25S/NARZO50A INCELL300+S/M	oppo	-	0	600	546	\N	SISTEMA	system	2025-08-27 00:11:17.262	2025-08-29 19:35:53.897
551	PRODUCTO	Display Oppo A58 4G ORIG	oppo	-	0	675	566	\N	SISTEMA	system	2025-08-27 00:11:17.409	2025-08-29 19:38:46.361
553	PRODUCTO	Display Oppo C21Y ORIG C/M(BOUTIQUE)	oppo	-	0	600	568	\N	SISTEMA	system	2025-08-27 00:11:17.419	2025-08-29 19:41:29.945
556	PRODUCTO	Display Oppo C51/C51S/C53/Narzo N53/C36/C60/Note50 ORIG	oppo	-	0	600	571	\N	SISTEMA	system	2025-08-27 00:11:17.443	2025-08-29 19:42:49.894
536	PRODUCTO	Display Oppo C21Y/C25Y INCELL S/M	oppo	-	0	600	551	\N	SISTEMA	system	2025-08-27 00:11:17.296	2025-08-29 19:41:40.405
555	PRODUCTO	Display Oppo 8I/9i ORIG S/M	oppo		630	630	570	\N	SISTEMA	system	2025-08-27 00:11:17.433	2025-08-27 12:50:01.275
537	PRODUCTO	Display Oppo C53/Narzo N53/C51/C36/C60/NOTE50 INCELL	oppo	-	0	600	552	\N	SISTEMA	system	2025-08-27 00:11:17.303	2025-08-29 19:43:00.333
552	PRODUCTO	Display Oppo C35 ORIG C/M(BOUTIQUE)	oppo	-	0	600	567	\N	SISTEMA	system	2025-08-27 00:11:17.414	2025-08-29 19:42:32.186
541	PRODUCTO	Display Oppo A15/A15S/A16K ORIG C/M(BOUTIQUE)	oppo	-	0	600	556	\N	SISTEMA	system	2025-08-27 00:11:17.333	2025-08-29 19:35:16.478
547	PRODUCTO	Display Oppo c30/C33 ORIG C/M(BOUTIQUE)	oppo	-	0	600	562	\N	SISTEMA	system	2025-08-27 00:11:17.378	2025-08-29 19:48:29.161
544	PRODUCTO	Display Oppo C30S ORIG C/M_NEGRO	oppo	-	0	600	559	\N	SISTEMA	system	2025-08-27 00:11:17.351	2025-08-29 19:42:06.667
508	PRODUCTO	Display Motorola G20/G10/G30 ORIG S/M	Motorola	-	0	600	521	\N	SISTEMA	system	2025-08-27 00:11:17.083	2025-08-29 17:42:26.115
527	PRODUCTO	Display Motorola Z PLAY OLED	Motorola		850	850	541	\N	SISTEMA	system	2025-08-27 00:11:17.222	2025-08-27 12:50:00.912
530	PRODUCTO	Display OnePlus 1+N10 ORIG C/M	OnePlus	-	0	850	544	\N	SISTEMA	system	2025-08-27 00:11:17.249	2025-08-29 19:26:40.036
507	PRODUCTO	Display Motorola G22/E22S/E32/E32S ORIG S/M	Motorola	-	0	600	520	\N	SISTEMA	system	2025-08-27 00:11:17.076	2025-08-29 17:45:46.209
562	PRODUCTO	Display Oppo C11 2021/C20/C21 ORIG	oppo	-	0	600	577	\N	SISTEMA	system	2025-08-27 00:11:17.491	2025-08-29 19:40:53.645
570	PRODUCTO	Display Oppo A53 4G/1+N100/A32/A33/A53S/A11S/ REALME7I/REALME	oppo	-	0	600	585	\N	SISTEMA	system	2025-08-27 00:11:17.54	2025-08-29 19:37:33.93
580	PRODUCTO	Display Oppo "RENO5 4G(5G)/ RENO5K/RENO6	oppo	-	0	2050	596	\N	SISTEMA	system	2025-08-27 00:11:17.617	2025-08-29 19:30:57.008
565	PRODUCTO	Display Oppo A93 5G ORIG	oppo	-	0	725	561	\N	SISTEMA	system	2025-08-27 00:11:17.507	2025-08-29 19:40:02.33
569	PRODUCTO	Display Oppo A54 4G/A55 4G/A94	oppo	-	0	600	584	\N	SISTEMA	system	2025-08-27 00:11:17.535	2025-08-29 19:38:08.096
568	PRODUCTO	Display Oppo "A17/A17K//A38/A57/A57S/A57E/A58 5G/A58X 5G/	oppo	-	0	600	583	\N	SISTEMA	system	2025-08-27 00:11:17.53	2025-08-29 19:27:44.599
592	PRODUCTO	Display Samsung A02 ORIG C/M	Samsung	-	0	600	608	\N	SISTEMA	system	2025-08-27 00:11:17.711	2025-08-29 19:49:40.316
601	PRODUCTO	Display Samsung A30/A50/A50S INCELL300+ S/M	Samsung	-	0	0.01	617	\N	SISTEMA	system	2025-08-27 00:11:17.787	2025-08-29 19:46:10.33
604	PRODUCTO	Display Samsung A21S INCELL300+ C/M	Samsung	-	0	0.06	620	\N	SISTEMA	system	2025-08-27 00:11:17.812	2025-08-29 19:43:34.944
588	PRODUCTO	Display Samsung A30 OLED S/M（BOUTIQUE)	Samsung	-	0	1273	604	\N	SISTEMA	system	2025-08-27 00:11:17.685	2025-08-29 19:45:52.964
566	PRODUCTO	Display Oppo A52 4G/A72 4G/A92	oppo	-	0	600	581	\N	SISTEMA	system	2025-08-27 00:11:17.513	2025-08-29 19:36:52.197
577	PRODUCTO	Display Oppo "RENO7 4G(5G)/RENO7SE 5G/RENO8	oppo	-	0	2025	593	\N	SISTEMA	system	2025-08-27 00:11:17.593	2025-08-29 19:32:53.412
572	PRODUCTO	Display Oppo RENO7 4G(5G)/RENO7SE/RENO8 4G(5G)/RENO8T/1+NORD	oppo	-	0	2025	588	\N	SISTEMA	system	2025-08-27 00:11:17.553	2025-08-29 19:45:19.128
573	PRODUCTO	Display Oppo "RENO5 LITE /RENO6	oppo	-	0	2050	589	\N	SISTEMA	system	2025-08-27 00:11:17.559	2025-08-29 19:31:50.062
579	PRODUCTO	Display Oppo RENO5 LITE/RENO 4SE/RENO	oppo	-	0	2050	595	\N	SISTEMA	system	2025-08-27 00:11:17.609	2025-08-29 19:44:46.803
582	PRODUCTO	Display Oppo RENO9/RENO10 5G/RENO8T 5G/A1	oppo		2600	2600	598	\N	SISTEMA	system	2025-08-27 00:11:17.63	2025-08-27 12:50:01.645
581	PRODUCTO	Display Oppo RENO11 5G AMOLED	oppo	-	0	2125	597	\N	SISTEMA	system	2025-08-27 00:11:17.624	2025-08-29 19:44:24.461
585	PRODUCTO	Display Samsung A06/A065 ORIG S/M	Samsung	-	0	600	601	\N	SISTEMA	system	2025-08-27 00:11:17.66	2025-08-29 19:54:16.038
597	PRODUCTO	Display Samsung A10/M10 INCELL300+ C/M	Samsung	-	0	600	613	\N	SISTEMA	system	2025-08-27 00:11:17.751	2025-08-29 19:54:31.329
586	PRODUCTO	Display Samsung A55 OLED C/M(BOUTIQUE)	Samsung		2393	2393	602	\N	SISTEMA	system	2025-08-27 00:11:17.668	2025-08-27 12:50:01.7
598	PRODUCTO	Display Samsung A03 INCELL300+ C/M	Samsung	-	0	600	614	\N	SISTEMA	system	2025-08-27 00:11:17.763	2025-08-29 19:50:37.511
575	PRODUCTO	Display Oppo Reno6 LITE OLED	oppo	-	0	2050	591	\N	SISTEMA	system	2025-08-27 00:11:17.577	2025-08-29 19:46:07.823
589	PRODUCTO	Display Samsung A15 4G(5G) INCELL300+S/M	Samsung	-	0	0.01	605	\N	SISTEMA	system	2025-08-27 00:11:17.691	2025-08-29 19:40:40.362
590	PRODUCTO	Display Samsung A24/A24 4G/A25 5G/M34	Samsung	-	0	600	606	\N	SISTEMA	system	2025-08-27 00:11:17.698	2025-08-29 19:45:18.953
593	PRODUCTO	Display Samsung A03S ORIG C/M(BOUTIQUE)	Samsung	-	0	600	609	\N	SISTEMA	system	2025-08-27 00:11:17.722	2025-08-29 19:51:32.528
599	PRODUCTO	Display Samsung A02S INCELL300+ C/M	Samsung	-	0	600	615	\N	SISTEMA	system	2025-08-27 00:11:17.774	2025-08-29 19:50:00.785
613	PRODUCTO	Display Samsung A51/A515 INCELL C/M	Samsung	-	0	0.01	630	\N	SISTEMA	system	2025-08-27 00:11:17.871	2025-08-29 19:53:03.969
594	PRODUCTO	Display Samsung A32 4G INCELL	Samsung		687	687	610	\N	SISTEMA	system	2025-08-27 00:11:17.731	2025-08-27 12:50:01.799
606	PRODUCTO	Display Samsung A71/A715 INCELL300+ S/M	Samsung	-	0	0.01	622	\N	SISTEMA	system	2025-08-27 00:11:17.827	2025-08-29 19:56:44.329
607	PRODUCTO	Display Samsung A30S INCELL300+ S/M	Samsung	-	0	1355	623	\N	SISTEMA	system	2025-08-27 00:11:17.833	2025-10-29 14:56:25.582
608	PRODUCTO	Display Samsung A10/M10 INCELL300+ S/M	Samsung	-	0	600	624	\N	SISTEMA	system	2025-08-27 00:11:17.843	2025-08-29 19:54:49.931
612	PRODUCTO	Display Samsung A03 ORIG C/M(BOUTIQUE)	Samsung	-	0	600	628	\N	SISTEMA	system	2025-08-27 00:11:17.867	2025-08-29 19:50:46.764
611	PRODUCTO	Display Samsung A02S ORIG C/M(BOUTIQUE)	Samsung	-	0	600	627	\N	SISTEMA	system	2025-08-27 00:11:17.861	2025-08-29 19:50:11.03
600	PRODUCTO	Display Samsung A11/M11/A115 INCELL 300+	Samsung	-	0	0.01	616	\N	SISTEMA	system	2025-08-27 00:11:17.78	2025-08-29 19:36:55.543
602	PRODUCTO	Display Samsung A32 4G INCELL	Samsung	-	0	0.1	610	\N	SISTEMA	system	2025-08-27 00:11:17.794	2025-08-29 19:48:52.49
603	PRODUCTO	Display Samsung A12 INCELL300+ C/M(BOUTIQUE)	Samsung	-	0	0.01	619	\N	SISTEMA	system	2025-08-27 00:11:17.807	2025-08-29 19:37:29.432
583	PRODUCTO	Display Oppo REALME7 PRO 04	oppo	-	0	2050	599	\N	SISTEMA	system	2025-08-27 00:11:17.642	2025-08-29 19:44:00.228
605	PRODUCTO	Display Samsung A72/A725 INCELL300+ S/M	Samsung	-	0	0.01	621	\N	SISTEMA	system	2025-08-27 00:11:17.818	2025-08-29 21:04:14.52
596	PRODUCTO	Display Samsung A30S INCELL300+ C/M	Samsung	-	0	1355	612	\N	SISTEMA	system	2025-08-27 00:11:17.745	2025-10-29 14:56:15.82
574	PRODUCTO	Display Oppo Reno7 4G OLED	oppo	-	0	2025	590	\N	SISTEMA	system	2025-08-27 00:11:17.57	2025-08-29 19:47:33.046
595	PRODUCTO	Display Samsung A11 INCELL300+ C/M	Samsung	-	0	600	611	\N	SISTEMA	system	2025-08-27 00:11:17.739	2025-08-29 19:55:57.863
609	PRODUCTO	Display Samsung A25 OLED C/M(BOUTIQUE)	Samsung		1700	1700	625	\N	SISTEMA	system	2025-08-27 00:11:17.85	2025-08-27 12:50:01.984
610	PRODUCTO	Display Samsung A15 4G/5G OLED	Samsung	-	0	1733	626	\N	SISTEMA	system	2025-08-27 00:11:17.855	2025-08-29 19:41:06.833
587	PRODUCTO	Display Samsung A35 OLED C/M(BOUTIQUE)	Samsung	-	0	2125	603	\N	SISTEMA	system	2025-08-27 00:11:17.673	2025-08-29 19:50:32.207
591	PRODUCTO	Display Samsung A037U ORIG C/M	Samsung	-	0	600	607	\N	SISTEMA	system	2025-08-27 00:11:17.706	2025-08-29 19:51:24.469
584	PRODUCTO	Display Samsung A06/A065 ORIG C/M(BOUTIQUE)	Samsung	-	0	600	600	\N	SISTEMA	system	2025-08-27 00:11:17.652	2025-08-29 19:53:57.837
614	PRODUCTO	Display Samsung A30 OLED C/M（BOUTIQUE)	Samsung		1270	1270	631	\N	SISTEMA	system	2025-08-27 00:11:17.88	2025-08-27 12:53:24.939
571	PRODUCTO	Display Oppo "A15/A15S/A16K/A16E/A35/REALME C11 2020/REALME	oppo	-	0	600	587	\N	SISTEMA	system	2025-08-27 00:11:17.547	2025-08-29 19:27:28.331
576	PRODUCTO	Display Oppo Reno5 LITE OLED	oppo	-	0	2050	592	\N	SISTEMA	system	2025-08-27 00:11:17.587	2025-08-29 19:45:46.282
578	PRODUCTO	Display Oppo "RENO6 LITE/RENO7 LITE	oppo	-	0	2050	594	\N	SISTEMA	system	2025-08-27 00:11:17.601	2025-08-29 19:32:09.602
563	PRODUCTO	Display Oppo "A1 5G/A2 5G/REALME	oppo		648	648	578	\N	SISTEMA	system	2025-08-27 00:11:17.497	2025-08-27 12:50:01.387
632	PRODUCTO	Display Samsung A10/M10 ORIG C/M(BOUTIQUE)	Samsung	-	0	600	650	\N	SISTEMA	system	2025-08-27 00:11:18.014	2025-08-29 19:55:04.814
618	PRODUCTO	Display Samsung A12 ORIG C/M(BOUTIQUE)	Samsung	-	0	600	636	\N	SISTEMA	system	2025-08-27 00:11:17.914	2025-08-29 19:39:14.461
621	PRODUCTO	Display Samsung A20S/A207 ORIG C/M(BOUTIGQUE)	Samsung		644	644	639	\N	SISTEMA	system	2025-08-27 00:11:17.933	2025-08-27 12:53:25.049
664	PRODUCTO	Display Samsung A01M ORIG S/M	Samsung	-	0	600	683	\N	SISTEMA	system	2025-08-27 00:11:18.272	2025-08-29 19:49:18.24
623	PRODUCTO	Display Samsung A730/A8PLUS OLED S/M	Samsung		1275	1275	641	\N	SISTEMA	system	2025-08-27 00:11:17.945	2025-08-27 12:53:25.074
651	PRODUCTO	Display Samsung A04E ORIG S/M	Samsung	-	0	600	669	\N	SISTEMA	system	2025-08-27 00:11:18.171	2025-08-29 19:52:17.965
663	PRODUCTO	Display Samsung A10S/A107 ORIG S/M	Samsung	-	0	600	682	\N	SISTEMA	system	2025-08-27 00:11:18.266	2025-08-29 19:55:47.679
626	PRODUCTO	Display Samsung A73 5G ORIG	Samsung		1675	1675	644	\N	SISTEMA	system	2025-08-27 00:11:17.969	2025-08-27 12:53:25.117
627	PRODUCTO	Display Samsung A30S OLED C/M(BOUTIQUE)	Samsung		1355	1355	645	\N	SISTEMA	system	2025-08-27 00:11:17.974	2025-08-27 12:53:25.129
628	PRODUCTO	Display Samsung A20 OLED C/M(BOUTIQUE)	Samsung		1355	1355	646	\N	SISTEMA	system	2025-08-27 00:11:17.981	2025-08-27 12:53:25.143
629	PRODUCTO	Display Samsung A50/A50S OLED C/M（BOUTIQUE)	Samsung		1350	1350	647	\N	SISTEMA	system	2025-08-27 00:11:17.987	2025-08-27 12:53:25.151
630	PRODUCTO	Display Samsung A21S ORIG C/M	Samsung		710	710	648	\N	SISTEMA	system	2025-08-27 00:11:17.996	2025-08-27 12:53:25.163
625	PRODUCTO	Display Samsung A10E ORIG S/M	Samsung	-	0	600	643	\N	SISTEMA	system	2025-08-27 00:11:17.959	2025-08-29 19:55:30.486
631	PRODUCTO	Display Samsung A10/M10 ORIG S/M	Samsung	-	0	600	649	\N	SISTEMA	system	2025-08-27 00:11:18.004	2025-08-29 19:55:17.618
633	PRODUCTO	Display Samsung A31/A315 OLED C/M(BOUTIQUE)	Samsung	-	0	1375	651	\N	SISTEMA	system	2025-08-27 00:11:18.021	2025-08-29 19:47:33.172
634	PRODUCTO	Display Samsung A22 4G OLED	Samsung		1320	1320	652	\N	SISTEMA	system	2025-08-27 00:11:18.026	2025-08-27 12:53:25.22
635	PRODUCTO	Display Samsung A54 OLED C/M(BOUTIQUE)	Samsung		1913	1913	653	\N	SISTEMA	system	2025-08-27 00:11:18.032	2025-08-27 12:53:25.233
637	PRODUCTO	Display Samsung A34 5G ORIG	Samsung		2150	2150	655	\N	SISTEMA	system	2025-08-27 00:11:18.045	2025-08-27 12:53:25.258
638	PRODUCTO	Display Samsung A22 5G ORIG	Samsung		738	738	656	\N	SISTEMA	system	2025-08-27 00:11:18.056	2025-08-27 12:53:25.268
639	PRODUCTO	Display Samsung A14 5G/A146B ORIG	Samsung		675	675	657	\N	SISTEMA	system	2025-08-27 00:11:18.061	2025-08-27 12:53:25.278
640	PRODUCTO	Display Samsung A71/A715 OLED C/M	Samsung		1725	1725	658	\N	SISTEMA	system	2025-08-27 00:11:18.068	2025-08-27 12:53:25.293
641	PRODUCTO	Display Samsung A03 CORE ORIG	Samsung		401	401	659	\N	SISTEMA	system	2025-08-27 00:11:18.075	2025-08-27 12:53:25.305
642	PRODUCTO	Display Samsung A13 4G ORIG	Samsung		670	670	660	\N	SISTEMA	system	2025-08-27 00:11:18.082	2025-08-27 12:53:25.314
652	PRODUCTO	Display Samsung A04/A045 ORIG S/M	Samsung	-	0	600	670	\N	SISTEMA	system	2025-08-27 00:11:18.18	2025-08-29 19:51:52.583
645	PRODUCTO	Display Samsung A23 4G ORIG	Samsung		713	713	663	\N	SISTEMA	system	2025-08-27 00:11:18.104	2025-08-27 12:53:25.358
646	PRODUCTO	Display Samsung A72/A725 OLED C/M	Samsung	-	0	2000	664	\N	SISTEMA	system	2025-08-27 00:11:18.111	2025-08-29 21:05:40.964
647	PRODUCTO	Display Samsung A53/A536 OLED ORIG	Samsung		2068	2068	665	\N	SISTEMA	system	2025-08-27 00:11:18.124	2025-08-27 12:53:25.38
648	PRODUCTO	Display Samsung A33 OLED C/M	Samsung		1730	1730	666	\N	SISTEMA	system	2025-08-27 00:11:18.136	2025-08-27 12:53:25.391
649	PRODUCTO	Display Samsung A14 5G/A146B ORIG	Samsung	-	0	632	657	\N	SISTEMA	system	2025-08-27 00:11:18.147	2025-08-29 19:39:52.255
650	PRODUCTO	Display Samsung "A13/A13 4G/A13 LITE/	Samsung		624	624	668	\N	SISTEMA	system	2025-08-27 00:11:18.155	2025-08-27 12:53:25.422
619	PRODUCTO	Display Samsung A05 ORIG S/M	Samsung	-	0	600	637	\N	SISTEMA	system	2025-08-27 00:11:17.921	2025-08-29 19:52:33.601
624	PRODUCTO	Display Samsung A04CORE/A04S/A13 5G/A136B ORIG	Samsung	-	0	600	642	\N	SISTEMA	system	2025-08-27 00:11:17.951	2025-08-29 19:52:00.754
643	PRODUCTO	Display Samsung A04 ORIG C/M	Samsung	-	0	600	661	\N	SISTEMA	system	2025-08-27 00:11:18.091	2025-08-29 19:51:45.205
654	PRODUCTO	Display Samsung A22 4G INCELL	Samsung	-	0	0.02	672	\N	SISTEMA	system	2025-08-27 00:11:18.199	2025-08-29 19:41:51.623
655	PRODUCTO	Display Samsung A51/A515 OLED ORIG	Samsung	-	0	1378	673	\N	SISTEMA	system	2025-08-27 00:11:18.206	2025-08-29 21:04:43.202
656	PRODUCTO	Display Samsung A70/A70S OLED C/M（BOUTIQUE)	Samsung		1820	1820	675	\N	SISTEMA	system	2025-08-27 00:11:18.216	2025-08-27 12:53:25.51
616	PRODUCTO	Display Samsung A52/A52S/A525 4G/A525 5G	Samsung	-	0	1843	633	\N	SISTEMA	system	2025-08-27 00:11:17.901	2025-08-29 21:05:13.818
658	PRODUCTO	Display Samsung A32 4G OLED	Samsung		1495	1495	677	\N	SISTEMA	system	2025-08-27 00:11:18.228	2025-08-27 12:53:25.527
659	PRODUCTO	Display Samsung A31/A315 INCELL C/M	Samsung	-	0	0.01	678	\N	SISTEMA	system	2025-08-27 00:11:18.238	2025-08-29 19:48:29.334
660	PRODUCTO	Display Samsung A20 INCELL C/M	Samsung	-	0	0.01	679	\N	SISTEMA	system	2025-08-27 00:11:18.245	2025-08-29 19:41:30.316
661	PRODUCTO	Display Samsung A22 5G ORIG	Samsung	-	0	643	680	\N	SISTEMA	system	2025-08-27 00:11:18.254	2025-08-29 19:44:27.944
662	PRODUCTO	Display Samsung A20S/A207 ORIG S/M	Samsung	-	0	613	681	\N	SISTEMA	system	2025-08-27 00:11:18.261	2025-08-29 19:43:11.816
636	PRODUCTO	Display Samsung A30S INCELL S/M	Samsung	-	0	1355	654	\N	SISTEMA	system	2025-08-27 00:11:18.039	2025-10-29 14:56:32.922
653	PRODUCTO	Display Samsung A03 CORE ORIG	Samsung	-	0	600	659	\N	SISTEMA	system	2025-08-27 00:11:18.189	2025-08-29 19:50:26.294
667	PRODUCTO	Display Samsung A21S/A217 ORIG S/M	Samsung		492	492	685	\N	SISTEMA	system	2025-08-27 00:11:18.294	2025-08-27 12:53:25.617
617	PRODUCTO	Display Samsung A14 4G/A145P ORIG	Samsung	-	0	600	635	\N	SISTEMA	system	2025-08-27 00:11:17.908	2025-08-29 19:39:31.169
620	PRODUCTO	Display Samsung A05S ORIG S/M	Samsung	-	0	700	638	\N	SISTEMA	system	2025-08-27 00:11:17.927	2025-08-29 19:53:28.061
666	PRODUCTO	Display Samsung WF HG NOTE20	Samsung		0	0	729	\N	SISTEMA	SISTEMA	2025-08-27 00:11:18.288	2025-08-27 12:28:16.729
665	PRODUCTO	Display Samsung WF HG NOTE10	Samsung		0	0	728	\N	SISTEMA	SISTEMA	2025-08-27 00:11:18.279	2025-08-27 12:28:16.721
657	PRODUCTO	Display Samsung A52/A52S/A525 OLED C/M（BOUTIQUE)	Samsung	-	0	1775	676	\N	SISTEMA	system	2025-08-27 00:11:18.223	2025-08-29 21:07:07.498
668	PRODUCTO	Display Samsung A11/M11/A115 ORIG S/M	Samsung	-	0	603	686	\N	SISTEMA	system	2025-08-27 00:11:18.306	2025-08-29 19:37:11.338
622	PRODUCTO	Display Samsung A24 OLED C/M(BOUTIQUE)	Samsung	-	0	1825	640	\N	SISTEMA	system	2025-08-27 00:11:17.939	2025-08-29 19:48:08.025
673	PRODUCTO	Display Samsung J5 PRIME INCELL300+	Samsung		286	286	691	\N	SISTEMA	system	2025-08-27 00:11:18.349	2025-08-27 12:53:25.693
686	PRODUCTO	Display Samsung J5 PRIME ORIG	Samsung	-	0	600	703	\N	SISTEMA	system	2025-08-27 00:11:18.45	2025-08-29 21:10:32.246
676	PRODUCTO	Display Samsung J7 PRIME INCELL	Samsung		478	478	694	\N	SISTEMA	system	2025-08-27 00:11:18.374	2025-08-27 12:53:25.727
677	PRODUCTO	Display Samsung J7 PRIME INCELL	Samsung	-	0	0.01	694	\N	SISTEMA	system	2025-08-27 00:11:18.379	2025-08-29 21:12:16.874
678	PRODUCTO	Display Samsung J8 INCELL S/M	Samsung	-	0	0.01	696	\N	SISTEMA	system	2025-08-27 00:11:18.384	2025-08-29 21:17:20.55
679	PRODUCTO	Display Samsung J730/J7PRO INCELL S/M	Samsung		510	510	697	\N	SISTEMA	system	2025-08-27 00:11:18.39	2025-08-27 12:53:25.765
680	PRODUCTO	Display Samsung J730/J7PRO INCELL S/M	Samsung		510	510	698	\N	SISTEMA	system	2025-08-27 00:11:18.399	2025-08-27 12:53:25.782
681	PRODUCTO	Display Samsung J530/J5PRO OLED S/M	Samsung		1045	1045	699	\N	SISTEMA	system	2025-08-27 00:11:18.41	2025-08-27 12:53:25.79
682	PRODUCTO	Display Samsung J8 OLED S/M	Samsung	-	0	1614	700	\N	SISTEMA	system	2025-08-27 00:11:18.418	2025-08-29 21:18:26.212
683	PRODUCTO	Display Samsung J6 OLED S/M	Samsung	-	0	1627	701	\N	SISTEMA	system	2025-08-27 00:11:18.423	2025-08-29 21:13:55.248
684	PRODUCTO	Display Samsung J5 OLED S/M	Samsung		900	900	702	\N	SISTEMA	system	2025-08-27 00:11:18.43	2025-08-27 12:53:25.828
685	PRODUCTO	Display Samsung J5 PRIME ORIG	Samsung		464	464	703	\N	SISTEMA	system	2025-08-27 00:11:18.442	2025-08-27 12:53:25.838
696	PRODUCTO	Display Samsung J701/J7 NEO INCELL	Samsung	-	0	0.01	709	\N	SISTEMA	system	2025-08-27 00:11:18.534	2025-08-29 21:14:40.213
687	PRODUCTO	Display Samsung J4 INCELL S/M	Samsung	-	0	0.01	706	\N	SISTEMA	system	2025-08-27 00:11:18.456	2025-08-29 21:08:40.055
688	PRODUCTO	Display Samsung J730/J7PRO INCELL S/M	Samsung		510	510	707	\N	SISTEMA	system	2025-08-27 00:11:18.462	2025-08-27 12:53:25.886
689	PRODUCTO	Display Samsung J730/J7PRO OLED S/M	Samsung		838	838	708	\N	SISTEMA	system	2025-08-27 00:11:18.468	2025-08-27 12:53:25.904
690	PRODUCTO	Display Samsung J701/J7 NEO INCELL	Samsung		444	444	709	\N	SISTEMA	system	2025-08-27 00:11:18.474	2025-08-27 12:53:25.914
691	PRODUCTO	Display Samsung J701/J7 NEO OLED	Samsung		850	850	710	\N	SISTEMA	system	2025-08-27 00:11:18.482	2025-08-27 12:53:25.924
692	PRODUCTO	Display Samsung J7 INCELL S/M	Samsung		407	407	711	\N	SISTEMA	system	2025-08-27 00:11:18.49	2025-08-27 12:53:25.939
693	PRODUCTO	Display Samsung J7 OLED S/M	Samsung		850	850	712	\N	SISTEMA	system	2025-08-27 00:11:18.5	2025-08-27 12:53:25.952
707	PRODUCTO	Display Samsung M21/M30/M30S/M31 INCELL S/M	Samsung	-	0	0.01	726	\N	SISTEMA	system	2025-08-27 00:11:18.646	2025-08-29 21:20:00.373
695	PRODUCTO	Display Samsung J730/J7PRO OLED S/M	Samsung		838	838	714	\N	SISTEMA	system	2025-08-27 00:11:18.523	2025-08-27 12:53:25.977
702	PRODUCTO	Display Samsung M21/M30/M30S/ M31 INCELL300+	Samsung	-	0	0.01	721	\N	SISTEMA	system	2025-08-27 00:11:18.6	2025-08-29 21:16:16.965
697	PRODUCTO	Display Samsung J701/J7 NEO OLED	Samsung		850	850	716	\N	SISTEMA	system	2025-08-27 00:11:18.544	2025-08-27 12:53:25.998
698	PRODUCTO	Display Samsung J7 INCELL S/M	Samsung	-	0	0.01	717	\N	SISTEMA	system	2025-08-27 00:11:18.552	2025-08-29 21:11:33.146
699	PRODUCTO	Display Samsung J7 OLED S/M	Samsung		968	968	718	\N	SISTEMA	system	2025-08-27 00:11:18.562	2025-08-27 12:53:26.018
700	PRODUCTO	Display Samsung M20 INCELL300+ S/M	Samsung	-	0	0.01	719	\N	SISTEMA	system	2025-08-27 00:11:18.577	2025-08-29 21:19:18.075
701	PRODUCTO	Display Samsung M30 INCELL300+ C/M	Samsung	-	0	0.01	720	\N	SISTEMA	system	2025-08-27 00:11:18.585	2025-08-29 21:21:27.198
694	PRODUCTO	Display Samsung J730/J7PRO INCELL S/M	Samsung	-	0	0.01	707	\N	SISTEMA	system	2025-08-27 00:11:18.513	2025-08-29 21:16:35.685
703	PRODUCTO	Display Samsung M14 5G/M146B ORIG	Samsung		730	730	722	\N	SISTEMA	system	2025-08-27 00:11:18.615	2025-08-27 12:53:26.064
704	PRODUCTO	Display Samsung M14 5G/M146B ORIG	Samsung		644	644	723	\N	SISTEMA	system	2025-08-27 00:11:18.622	2025-08-27 12:53:26.073
705	PRODUCTO	Display Samsung M53 5G OLED	Samsung		1965	1965	724	\N	SISTEMA	system	2025-08-27 00:11:18.631	2025-08-27 12:53:26.082
706	PRODUCTO	Display Samsung M30 OLED S/M	Samsung	-	0	1375	725	\N	SISTEMA	system	2025-08-27 00:11:18.637	2025-08-29 21:22:13.142
708	PRODUCTO	Display Samsung M23 4G/M33 ORIG	Samsung		705	705	727	\N	SISTEMA	system	2025-08-27 00:11:18.658	2025-08-27 12:53:26.119
709	PRODUCTO	Display Samsung NOTE20 ULTRA ORIG	Samsung		4800	4800	730	\N	SISTEMA	system	2025-08-27 00:11:18.669	2025-08-27 12:53:26.145
710	PRODUCTO	Display Samsung NOTE10 PLUS SOFT	Samsung		3550	3550	731	\N	SISTEMA	system	2025-08-27 00:11:18.675	2025-08-27 12:53:26.157
712	PRODUCTO	Display Samsung NOTE10 LITE AMOLED	Samsung		4875	4875	733	\N	SISTEMA	system	2025-08-27 00:11:18.687	2025-08-27 12:53:26.184
720	PRODUCTO	Display Samsung S23 ORIG C/M(BOUTIQUE)	Samsung		5875	5875	743	\N	SISTEMA	system	2025-08-27 00:11:18.749	2025-08-27 12:53:26.258
723	PRODUCTO	Display Samsung S10 ORIG C/M(BOUTIQUE)	Samsung		5875	5875	746	\N	SISTEMA	system	2025-08-27 00:11:18.778	2025-08-27 12:53:26.289
714	PRODUCTO	Display Samsung WF HG S20	Samsung		0	0	736	\N	SISTEMA	SISTEMA	2025-08-27 00:11:18.704	2025-08-27 12:28:16.919
724	PRODUCTO	Display Samsung S10 PLUS AMOLED	Samsung		8250	8250	747	\N	SISTEMA	system	2025-08-27 00:11:18.786	2025-08-27 12:53:26.323
725	PRODUCTO	Display Samsung S23 ULTRA SOFT	Samsung		5750	5750	748	\N	SISTEMA	system	2025-08-27 00:11:18.797	2025-08-27 12:53:26.338
674	PRODUCTO	Display Samsung J5 PRIME INCELL300+	Samsung	-	0	0.01	691	\N	SISTEMA	system	2025-08-27 00:11:18.359	2025-08-29 21:10:10.985
713	PRODUCTO	Display Samsung WF HG S22	Samsung		0	0	735	\N	SISTEMA	SISTEMA	2025-08-27 00:11:18.693	2025-08-27 12:28:16.912
722	PRODUCTO	Display Samsung S22 ORIG C/M(BOUTIQUE)	Samsung		6450	6450	745	\N	SISTEMA	system	2025-08-27 00:11:18.766	2025-08-27 12:53:26.279
715	PRODUCTO	Display Samsung WF HG S20	Samsung		0	0	737	\N	SISTEMA	SISTEMA	2025-08-27 00:11:18.71	2025-08-27 12:28:16.925
716	PRODUCTO	Display Samsung WF HG S23	Samsung		0	0	738	\N	SISTEMA	SISTEMA	2025-08-27 00:11:18.719	2025-08-27 12:28:16.928
717	PRODUCTO	Display Samsung WF HG S21	Samsung		0	0	739	\N	SISTEMA	SISTEMA	2025-08-27 00:11:18.725	2025-08-27 12:28:16.933
718	PRODUCTO	Display Samsung WF HG S21	Samsung		0	0	740	\N	SISTEMA	SISTEMA	2025-08-27 00:11:18.734	2025-08-27 12:28:16.936
719	PRODUCTO	Display Samsung WF HG S22	Samsung		0	0	741	\N	SISTEMA	SISTEMA	2025-08-27 00:11:18.741	2025-08-27 12:28:16.939
721	PRODUCTO	Display Samsung S23 ORIG C/M(BOUTIQUE)	Samsung		5875	5875	744	\N	SISTEMA	system	2025-08-27 00:11:18.755	2025-08-27 12:53:26.27
671	PRODUCTO	Display Samsung J7 PRIME INCELL300+	Samsung		321	321	689	\N	SISTEMA	system	2025-08-27 00:11:18.33	2025-08-27 12:53:25.668
672	PRODUCTO	Display Samsung J7 PRIME INCELL300+	Samsung	-	0	0.01	689	\N	SISTEMA	system	2025-08-27 00:11:18.341	2025-08-29 21:12:36.543
729	PRODUCTO	Display Samsung S22 PLUS ORIG	Samsung		5050	5050	752	\N	SISTEMA	system	2025-08-27 00:11:18.837	2025-08-27 12:53:26.4
730	PRODUCTO	Display Samsung S9 PLUS AMOLED	Samsung		4625	4625	753	\N	SISTEMA	system	2025-08-27 00:11:18.85	2025-08-27 12:53:26.42
731	PRODUCTO	Display Samsung S20 PLUS SOFT	Samsung		3575	3575	754	\N	SISTEMA	system	2025-08-27 00:11:18.861	2025-08-27 12:53:26.443
732	PRODUCTO	Display Samsung S8PLUS AMOLED C/M（BOUTIQUE)	Samsung		4375	4375	755	\N	SISTEMA	system	2025-08-27 00:11:18.871	2025-08-27 12:53:26.461
733	PRODUCTO	Display Samsung S9 AMOLED C/M（BOUTIQUE）	Samsung		4625	4625	756	\N	SISTEMA	system	2025-08-27 00:11:18.877	2025-08-27 12:53:26.483
734	PRODUCTO	Display Samsung S21 ULTRA "SOFT	Samsung		4625	4625	757	\N	SISTEMA	system	2025-08-27 00:11:18.887	2025-08-27 12:53:26.512
735	PRODUCTO	Display Samsung S20 ULTRA "SOFT	Samsung		4300	4300	758	\N	SISTEMA	system	2025-08-27 00:11:18.896	2025-08-27 12:53:26.529
736	PRODUCTO	Display Samsung S8 "AMOLED C/M(BOUTIQUE)CURVO"	Samsung		4200	4200	759	\N	SISTEMA	system	2025-08-27 00:11:18.902	2025-08-27 12:53:26.548
737	PRODUCTO	Display Samsung S20 FE OLED	Samsung		2113	2113	760	\N	SISTEMA	system	2025-08-27 00:11:18.909	2025-08-27 12:53:26.557
742	PRODUCTO	Display Vivo Y71/Y73 INCELL300+ S/M	Vivo	-	0	600	765	\N	SISTEMA	system	2025-08-27 00:11:18.95	2025-08-29 21:13:06.581
740	PRODUCTO	Display Vivo Y33/Y33S INCELL300+ S/M	Vivo	-	0	625	763	\N	SISTEMA	system	2025-08-27 00:11:18.935	2025-08-29 21:10:57.087
749	PRODUCTO	Display Vivo Y33S 5G ORIG	Vivo	-	0	625	773	\N	SISTEMA	system	2025-08-27 00:11:19.006	2025-08-29 21:11:12.062
741	PRODUCTO	Display Vivo Y71/Y73 INCELL300+ S/M	Vivo		315	315	765	\N	SISTEMA	system	2025-08-27 00:11:18.943	2025-08-27 12:53:26.666
763	PRODUCTO	Display Wiko T10 ORIG S/M	Wiko	-	0	781	789	\N	SISTEMA	system	2025-08-27 00:11:19.129	2025-08-29 21:13:28.773
743	PRODUCTO	Display Vivo V21/V25/T1 5G/T1PRO/S9E OLED	Vivo	-	0	1475	767	\N	SISTEMA	system	2025-08-27 00:11:18.959	2025-08-29 21:07:47.424
744	PRODUCTO	Display Vivo V27E ORIG C/M	Vivo		2365	2365	768	\N	SISTEMA	system	2025-08-27 00:11:18.969	2025-08-27 12:53:26.699
745	PRODUCTO	Display Vivo V30LITE 5G ORIG	Vivo		2550	2550	769	\N	SISTEMA	system	2025-08-27 00:11:18.98	2025-08-27 12:53:26.71
746	PRODUCTO	Display Vivo Y36 4G ORIG	Vivo		713	713	770	\N	SISTEMA	system	2025-08-27 00:11:18.985	2025-08-27 12:53:26.719
747	PRODUCTO	Display Vivo Y17S ORIG C/M(BOUTIQUE)	Vivo	-	0	600	771	\N	SISTEMA	system	2025-08-27 00:11:18.991	2025-08-29 21:08:28.146
748	PRODUCTO	Display Vivo Y3 ORIG C/M(BOUTIQUE)	Vivo	-	0	600	772	\N	SISTEMA	system	2025-08-27 00:11:18.998	2025-08-29 21:09:49.58
761	PRODUCTO	Display Vivo Y33S/Y74S 5G/Y76S 5G/Y33T/Y21T	Vivo	-	0	625	787	\N	SISTEMA	system	2025-08-27 00:11:19.109	2025-08-29 21:11:27.665
759	PRODUCTO	Display Vivo Y30/Y30I ORIG S/M	Vivo	-	0	625	783	\N	SISTEMA	system	2025-08-27 00:11:19.095	2025-08-29 21:10:23.031
738	PRODUCTO	Display Vivo Y50/1935 INCELL300+ S/M	Vivo	-	0	600	761	\N	SISTEMA	system	2025-08-27 00:11:18.916	2025-08-29 21:12:56.609
756	PRODUCTO	Display Vivo Y1S/Y90/Y91/Y91I/Y91C/Y93/Y93S/Y95/U1 ORIG S/M	Vivo	-	0	600	780	\N	SISTEMA	system	2025-08-27 00:11:19.069	2025-08-29 21:08:58.351
751	PRODUCTO	Display Vivo Y36 5G ORIG	Vivo	-	0	675	775	\N	SISTEMA	system	2025-08-27 00:11:19.022	2025-08-29 21:12:26.258
752	PRODUCTO	Display Vivo Y17S/Y22/Y22S ORIG S/M	Vivo	-	0	600	776	\N	SISTEMA	system	2025-08-27 00:11:19.035	2025-08-29 21:08:45.049
750	PRODUCTO	Display Vivo Y20/Y20 2021 ORIG	Vivo	-	0	600	774	\N	SISTEMA	system	2025-08-27 00:11:19.017	2025-08-29 21:09:24.243
758	PRODUCTO	Display Vivo "Y3S 2020/Y31 2020/Y31S/Y51	Vivo	-	0	650	782	\N	SISTEMA	system	2025-08-27 00:11:19.087	2025-08-29 21:07:01.986
754	PRODUCTO	Display Vivo V21/V25/T1 5G/T1 PRO	Vivo	-	0	1475	778	\N	SISTEMA	system	2025-08-27 00:11:19.055	2025-08-29 21:07:23.144
739	PRODUCTO	Display Vivo Y30/Y30i INCELL300+ S/M	Vivo	-	0	625	762	\N	SISTEMA	system	2025-08-27 00:11:18.929	2025-08-29 21:10:33.787
760	PRODUCTO	Display Vivo "Y20/Y20 2021/Y20i/Y20S/Y20sg/Y15A/Y15s/Y11s/Y12s/V12A/V12s 2021/Y3s	Vivo	-	0	600	786	\N	SISTEMA	system	2025-08-27 00:11:19.103	2025-08-29 21:06:04.931
770	PRODUCTO	Display Xiaomi MI A1/5X INCELL	Xiaomi	-	0	600	796	\N	SISTEMA	system	2025-08-27 00:11:19.18	2025-08-29 21:24:39.027
753	PRODUCTO	Display Vivo Y36 4G ORIG	Vivo	-	0	650	770	\N	SISTEMA	system	2025-08-27 00:11:19.048	2025-08-29 21:12:11.987
766	PRODUCTO	Display Xiaomi REDMI A1/A1 PLUS/A2/	Xiaomi	-	0	600	792	\N	SISTEMA	system	2025-08-27 00:11:19.148	2025-08-29 22:33:02.701
769	PRODUCTO	Display Xiaomi REDMI A3 ORIG	Xiaomi	-	0	600	795	\N	SISTEMA	system	2025-08-27 00:11:19.174	2025-08-29 22:35:19.445
765	PRODUCTO	Display Xiaomi REDMI A1/A1 PLUS/A2/A2PLUS/POCO	Xiaomi	-	0	650	791	\N	SISTEMA	system	2025-08-27 00:11:19.14	2025-08-29 22:34:56.132
777	PRODUCTO	Display Xiaomi REDMI 12 ORIG	Xiaomi	-	0	675	803	\N	SISTEMA	system	2025-08-27 00:11:19.217	2025-08-29 21:38:43.95
768	PRODUCTO	Display Xiaomi REDMI A3 ORIG	Xiaomi		638	638	794	\N	SISTEMA	system	2025-08-27 00:11:19.164	2025-08-27 12:53:26.996
767	PRODUCTO	Display Xiaomi MI A2/6X ORIG	Xiaomi	-	0	600	793	\N	SISTEMA	system	2025-08-27 00:11:19.155	2025-08-29 21:24:52.768
771	PRODUCTO	Display Xiaomi MI A3 INCELL	Xiaomi	-	0	1545	797	\N	SISTEMA	system	2025-08-27 00:11:19.185	2025-08-29 21:25:41.094
772	PRODUCTO	Display Xiaomi MI A3/CC9E OLED	Xiaomi		1545	1545	798	\N	SISTEMA	system	2025-08-27 00:11:19.189	2025-08-27 12:53:27.041
773	PRODUCTO	Display Xiaomi REDMI 14C ORIG	Xiaomi		705	705	799	\N	SISTEMA	system	2025-08-27 00:11:19.196	2025-08-27 12:53:27.058
764	PRODUCTO	Display Xiaomi REDMI A1+/A1/A2/A2+/POCC C50	Xiaomi	-	0	600	790	\N	SISTEMA	system	2025-08-27 00:11:19.136	2025-08-29 21:43:28.683
775	PRODUCTO	Display Xiaomi REDMI 13C/POCO C65	Xiaomi		344	344	801	\N	SISTEMA	system	2025-08-27 00:11:19.207	2025-08-27 12:53:27.077
776	PRODUCTO	Display Xiaomi REDMI 9/9 PRIME	Xiaomi		344	344	802	\N	SISTEMA	system	2025-08-27 00:11:19.214	2025-08-27 12:53:27.091
780	PRODUCTO	Display Xiaomi REDMI 12C ORIG	Xiaomi	-	0	600	806	\N	SISTEMA	system	2025-08-27 00:11:19.23	2025-08-29 21:39:06.898
778	PRODUCTO	Display Xiaomi REDMI 12C ORIG	Xiaomi		687	687	804	\N	SISTEMA	system	2025-08-27 00:11:19.223	2025-08-27 12:53:27.141
779	PRODUCTO	Display Xiaomi REDMI 13C/POCO C65	Xiaomi	-	0	600	801	\N	SISTEMA	system	2025-08-27 00:11:19.227	2025-08-29 21:39:29.085
774	PRODUCTO	Display Xiaomi REDMI 14C ORIG	Xiaomi	-	0	600	799	\N	SISTEMA	system	2025-08-27 00:11:19.202	2025-08-29 21:39:43.643
757	PRODUCTO	Display Vivo "Y01/Y02S/Y15S/Y15A/Y16/Y21/Y21A/Y21E/Y21G/Y21T/Y31S/Y32/Y33 E/Y33S" ORIG	Vivo	-	0	600	781	\N	SISTEMA	system	2025-08-27 00:11:19.076	2025-08-29 21:05:51.85
762	PRODUCTO	Display Wiko T50 ORIG S/M	Wiko		825	825	788	\N	SISTEMA	system	2025-08-27 00:11:19.117	2025-08-27 12:53:26.925
727	PRODUCTO	Display Samsung S22 ULTRA SOFT	Samsung		4800	4800	750	\N	SISTEMA	system	2025-08-27 00:11:18.819	2025-08-27 12:53:26.376
728	PRODUCTO	Display Samsung S22 ORIG C/M(BOUTIQUE)	Samsung		6450	6450	751	\N	SISTEMA	system	2025-08-27 00:11:18.826	2025-08-27 12:53:26.386
793	PRODUCTO	Display Xiaomi REDMI 9A/9AT/9i/9C/10A/POCO C3/POCO	Xiaomi	-	0	650	819	\N	SISTEMA	system	2025-08-27 00:11:19.294	2025-08-29 21:41:39.046
788	PRODUCTO	Display Xiaomi MI9 OLED S/M	Xiaomi	-	0	2000	814	\N	SISTEMA	system	2025-08-27 00:11:19.27	2025-08-29 21:29:08.173
786	PRODUCTO	Display Xiaomi MI13T/13T PRO ORIG	Xiaomi		2115	2115	812	\N	SISTEMA	system	2025-08-27 00:11:19.261	2025-08-27 12:57:53.788
787	PRODUCTO	Display Xiaomi MI10T/MI10T PRO/K30S ORIG	Xiaomi		805	805	813	\N	SISTEMA	system	2025-08-27 00:11:19.267	2025-08-27 12:57:53.801
789	PRODUCTO	Display Xiaomi MI11 LITE 4G/5G	Xiaomi	-	0	1875	815	\N	SISTEMA	system	2025-08-27 00:11:19.273	2025-08-29 21:29:50.44
799	PRODUCTO	Display Xiaomi POCO F3/POCO F4/MI11	Xiaomi	-	0	1750	824	\N	SISTEMA	system	2025-08-27 00:11:19.321	2025-08-29 21:31:43.289
790	PRODUCTO	Display Xiaomi MI 9T/9T PRO/K20	Xiaomi		1870	1870	816	\N	SISTEMA	system	2025-08-27 00:11:19.279	2025-08-27 12:57:53.85
783	PRODUCTO	Display Xiaomi REDMI 8/8A ORIG	Xiaomi	-	0	600	809	\N	SISTEMA	system	2025-08-27 00:11:19.249	2025-08-29 21:39:58.285
794	PRODUCTO	Display Xiaomi REDMI 9/9 PRIME	Xiaomi	-	0	600	820	\N	SISTEMA	system	2025-08-27 00:11:19.299	2025-08-29 21:38:32.083
827	PRODUCTO	Display Xiaomi REDMI 9T/NOTE9 4G/POCO	Xiaomi	-	0	600	852	\N	SISTEMA	system	2025-08-27 00:11:19.449	2025-08-29 21:42:30.08
791	PRODUCTO	Display Xiaomi REDMI 9A/9AT/9C/10A ORIG	Xiaomi	-	0	600	817	\N	SISTEMA	system	2025-08-27 00:11:19.285	2025-08-29 21:38:47.191
795	PRODUCTO	Display Xiaomi REDMI POCO X6PRO	Xiaomi		793	793	821	\N	SISTEMA	system	2025-08-27 00:11:19.303	2025-08-27 12:57:53.926
811	PRODUCTO	Display Xiaomi "REDMI NOTE10 5G/NOTE11	Xiaomi	-	0	1525	838	\N	SISTEMA	system	2025-08-27 00:11:19.369	2025-10-06 20:47:27.541
830	PRODUCTO	Display Xiaomi POCO X3/X3 PRO/NOTE9PRO	Xiaomi	-	0	775	858	\N	SISTEMA	system	2025-08-27 00:11:19.46	2025-08-29 21:33:27.158
798	PRODUCTO	Display Xiaomi POCO F3/POCO F4/MI11	Xiaomi		1700	1700	824	\N	SISTEMA	system	2025-08-27 00:11:19.314	2025-08-27 12:57:53.965
797	PRODUCTO	Display Xiaomi POCO M4/M5 ORIG	Xiaomi	-	0	675	823	\N	SISTEMA	system	2025-08-27 00:11:19.31	2025-08-29 21:32:46.774
828	PRODUCTO	Display Xiaomi REDMI NOTE11 4G/NOTE11S/POCO	Xiaomi	-	0	1750	856	\N	SISTEMA	system	2025-08-27 00:11:19.453	2025-08-30 19:43:21.751
826	PRODUCTO	Display Xiaomi REDMI NOTE12 4G/5G	Xiaomi	-	0	1725	854	\N	SISTEMA	system	2025-08-27 00:11:19.444	2025-08-30 19:46:34.887
820	PRODUCTO	Display Xiaomi REDMI NOTE8PRO COG	Xiaomi	-	0	675	848	\N	SISTEMA	system	2025-08-27 00:11:19.413	2025-08-30 19:49:24.789
834	PRODUCTO	Display Xiaomi REDMI NOTE7/NOTE7 PRO	Xiaomi	-	0	600	862	\N	SISTEMA	system	2025-08-27 00:11:19.481	2025-08-30 19:48:28.759
805	PRODUCTO	Display Xiaomi REDMI 9T/NOTE9 4G/POCO	Xiaomi		372	372	831	\N	SISTEMA	system	2025-08-27 00:11:19.339	2025-08-27 12:57:54.058
825	PRODUCTO	Display Xiaomi REDMI NOTE12 4G	Xiaomi	-	0	1725	853	\N	SISTEMA	system	2025-08-27 00:11:19.438	2025-08-30 19:45:38.046
807	PRODUCTO	Display Xiaomi NOTE 13 4G	Xiaomi		2700	2700	833	\N	SISTEMA	system	2025-08-27 00:11:19.351	2025-08-27 12:57:54.084
808	PRODUCTO	Display Xiaomi NOTE 13 4G	Xiaomi		2875	2875	834	\N	SISTEMA	system	2025-08-27 00:11:19.358	2025-08-27 12:57:54.096
809	PRODUCTO	Display Xiaomi NOTE 13 4G	Xiaomi		2800	2800	836	\N	SISTEMA	system	2025-08-27 00:11:19.362	2025-08-27 12:57:54.123
812	PRODUCTO	Display Xiaomi NOTE 13 4G	Xiaomi		1763	1763	839	\N	SISTEMA	system	2025-08-27 00:11:19.374	2025-08-27 12:57:54.166
782	PRODUCTO	Display Xiaomi MI 10 AMOLED	Xiaomi		2550	2550	808	\N	SISTEMA	system	2025-08-27 00:11:19.241	2025-08-27 12:53:27.187
804	PRODUCTO	Display Xiaomi REDMI NOTE13 5G	Xiaomi	-	0	1500	830	\N	SISTEMA	system	2025-08-27 00:11:19.336	2025-08-30 19:48:05.207
814	PRODUCTO	Display Xiaomi REDMI NOTE12 PRO	Xiaomi		1650	1650	842	\N	SISTEMA	system	2025-08-27 00:11:19.384	2025-08-27 12:57:54.208
815	PRODUCTO	Display Xiaomi "REDMI NOTE10PRO/NOTE10PRO MAX/NOTE11PRO/NOTE11PRO	Xiaomi		1720	1720	843	\N	SISTEMA	system	2025-08-27 00:11:19.39	2025-08-27 12:57:54.217
813	PRODUCTO	Display Xiaomi REDMI NOTE12 5G/	Xiaomi	-	0	1725	840	\N	SISTEMA	system	2025-08-27 00:11:19.379	2025-08-30 19:47:44
817	PRODUCTO	Display Xiaomi MI NOTE10/NOTE10LITE/NOTE10PRO/CC9PRO AMOLED	Xiaomi		2175	2175	845	\N	SISTEMA	system	2025-08-27 00:11:19.399	2025-08-27 12:57:54.239
818	PRODUCTO	Display Xiaomi REDMI NOTE10PRO INCELL	Xiaomi		830	830	846	\N	SISTEMA	system	2025-08-27 00:11:19.405	2025-08-27 12:57:54.25
819	PRODUCTO	Display Xiaomi REDMI NOTE9/NOTE10X ORIG	Xiaomi		700	700	847	\N	SISTEMA	system	2025-08-27 00:11:19.41	2025-08-27 12:57:54.271
796	PRODUCTO	Display Xiaomi REDMI POCO X6PRO	Xiaomi	-	0	2100	821	\N	SISTEMA	system	2025-08-27 00:11:19.308	2025-08-30 19:55:18.933
816	PRODUCTO	Display Xiaomi REDMI NOTE12 PRO	Xiaomi	-	0	1725	842	\N	SISTEMA	system	2025-08-27 00:11:19.393	2025-08-30 19:47:30.278
822	PRODUCTO	Display Xiaomi REDMI NOTE10 4G/10S/POCO	Xiaomi		630	630	850	\N	SISTEMA	system	2025-08-27 00:11:19.421	2025-08-27 12:57:54.311
823	PRODUCTO	Display Xiaomi REDMI NOTE10 4G/10S/POCO	Xiaomi		1490	1490	851	\N	SISTEMA	system	2025-08-27 00:11:19.425	2025-08-27 12:57:54.322
824	PRODUCTO	Display Xiaomi REDMI 9T/NOTE9 4G/POCO	Xiaomi		658	658	852	\N	SISTEMA	system	2025-08-27 00:11:19.431	2025-08-27 12:57:54.33
801	PRODUCTO	Display Xiaomi REDMI NOTE12 4G&5G	Xiaomi	-	0	1725	827	\N	SISTEMA	system	2025-08-27 00:11:19.328	2025-08-30 19:46:08.332
821	PRODUCTO	Display Xiaomi REDMI NOTE12 5G/POCO	Xiaomi	-	0	1725	849	\N	SISTEMA	system	2025-08-27 00:11:19.419	2025-08-30 19:47:06.97
800	PRODUCTO	Display Xiaomi REDMI NOTE 13	Xiaomi	-	0	1675	826	\N	SISTEMA	system	2025-08-27 00:11:19.325	2025-08-29 22:37:00.59
806	PRODUCTO	Display Xiaomi REDMI NOTE11S OLED	Xiaomi	-	0	1525	832	\N	SISTEMA	system	2025-08-27 00:11:19.345	2025-08-30 19:44:16.292
829	PRODUCTO	Display Xiaomi REDMI NOTE10PRO 5G/POCO	Xiaomi	-	0	1600	857	\N	SISTEMA	system	2025-08-27 00:11:19.456	2025-08-29 22:53:07.591
792	PRODUCTO	Display Xiaomi REDMI 10C/10 POWER/POCO	Xiaomi	-	0	600	818	\N	SISTEMA	system	2025-08-27 00:11:19.29	2025-08-29 21:38:23.577
831	PRODUCTO	Display Xiaomi REDMI NOTE12 4G&5G/POCO	Xiaomi		1725	1725	859	\N	SISTEMA	system	2025-08-27 00:11:19.465	2025-08-27 12:57:54.407
832	PRODUCTO	Display Xiaomi REDMI NOTE8 INCELL	Xiaomi		638	638	860	\N	SISTEMA	system	2025-08-27 00:11:19.468	2025-08-27 12:57:54.415
802	PRODUCTO	Display Xiaomi REDMI NOTE8 PRO	Xiaomi	-	0	675	828	\N	SISTEMA	system	2025-08-27 00:11:19.33	2025-08-30 19:49:00.271
833	PRODUCTO	Display Xiaomi REDMI NOTE8 INCELL	Xiaomi	-	0	600	861	\N	SISTEMA	system	2025-08-27 00:11:19.473	2025-08-30 19:48:44.651
835	PRODUCTO	Display Xiaomi REDMI NOTE11 4G/11S/12S/POCO	Xiaomi		673	673	863	\N	SISTEMA	system	2025-08-27 00:11:19.485	2025-08-27 12:57:54.449
810	PRODUCTO	Display Xiaomi NOTE 13 4G	Xiaomi		2575	2575	837	\N	SISTEMA	system	2025-08-27 00:11:19.366	2025-08-27 12:57:54.135
785	PRODUCTO	Display Xiaomi MI10 LITE OLED	Xiaomi	-	0	1895	811	\N	SISTEMA	system	2025-08-27 00:11:19.258	2025-08-29 21:27:12.123
784	PRODUCTO	Display Xiaomi REDMI 9 ORIG	Xiaomi	-	0	600	810	\N	SISTEMA	system	2025-08-27 00:11:19.253	2025-08-29 21:40:19.528
839	PRODUCTO	Display Xiaomi REDMI NOTE9/NOTE10X ORIG	Xiaomi	-	0	1450	867	\N	SISTEMA	system	2025-08-27 00:11:19.498	2025-08-30 19:54:12.869
843	PRODUCTO	Display Xiaomi REDMI NOTE9S/NOTE9 PRO	Xiaomi	-	0	600	871	\N	SISTEMA	system	2025-08-27 00:11:19.515	2025-08-30 19:54:36.932
840	PRODUCTO	Display Xiaomi REDMI NOTE11T PRO/NOTE12T	Xiaomi	-	0	2000	868	\N	SISTEMA	system	2025-08-27 00:11:19.503	2025-08-30 19:44:58.911
871	PRODUCTO	Display ZTE A3 2020 ORIG	ZTE	-	0	600	873	\N	SISTEMA	system	2025-08-27 00:11:19.654	2025-08-30 19:56:53.678
841	PRODUCTO	Display Xiaomi REDMI NOTE11 5G/POCO	Xiaomi	-	0	675	869	\N	SISTEMA	system	2025-08-27 00:11:19.507	2025-08-30 19:43:55.335
845	PRODUCTO	Display ZTE A3 2020 ORIG	ZTE		708	708	873	\N	SISTEMA	system	2025-08-27 00:11:19.527	2025-08-27 12:57:54.563
846	PRODUCTO	Display ZTE A5 2020 ORIG	ZTE		720	720	874	\N	SISTEMA	system	2025-08-27 00:11:19.529	2025-08-27 12:57:54.573
847	PRODUCTO	Display ZTE A72 4G ORIG	ZTE	-	0	600	875	\N	SISTEMA	system	2025-08-27 00:11:19.535	2025-08-30 20:07:33.536
869	PRODUCTO	Display ZTE A7 2020 ORIG	ZTE	-	0	625	892	\N	SISTEMA	system	2025-08-27 00:11:19.644	2025-08-30 20:04:54.25
864	PRODUCTO	Display ZTE A53PLUS ORIG S/M	ZTE	-	0	650	887	\N	SISTEMA	system	2025-08-27 00:11:19.619	2025-08-30 20:02:23.71
856	PRODUCTO	Display ZTE A72S 5G ORIG	ZTE	-	0	625	880	\N	SISTEMA	system	2025-08-27 00:11:19.581	2025-08-30 20:08:32.372
865	PRODUCTO	Display ZTE A53 ORIG S/M	ZTE	-	0	650	888	\N	SISTEMA	system	2025-08-27 00:11:19.623	2025-08-30 20:01:01.124
852	PRODUCTO	Display ZTE A72S 5G ORIG	ZTE		775	775	880	\N	SISTEMA	system	2025-08-27 00:11:19.564	2025-08-27 12:57:54.646
844	PRODUCTO	Display Xiaomi REDMI 10/NOTE11 4G	Xiaomi	-	0	1525	872	\N	SISTEMA	system	2025-08-27 00:11:19.523	2025-10-06 20:48:04.507
870	PRODUCTO	Display ZTE A5 2020 ORIG	ZTE	-	0	625	874	\N	SISTEMA	system	2025-08-27 00:11:19.649	2025-08-30 19:58:14.433
854	PRODUCTO	Display ZTE A7S 2020 ORIG	ZTE	-	0	625	883	\N	SISTEMA	system	2025-08-27 00:11:19.57	2025-08-30 20:09:18.541
848	PRODUCTO	Display ZTE A54 ORIG C/M(BOUTIQUE)	ZTE	-	0	625	876	\N	SISTEMA	system	2025-08-27 00:11:19.541	2025-08-30 20:02:45.525
866	PRODUCTO	Display ZTE A52 LITE ORIG	ZTE	-	0	625	889	\N	SISTEMA	system	2025-08-27 00:11:19.628	2025-08-30 19:59:57.282
860	PRODUCTO	Batería Huawei HUAWEI-Y9 PRIME 2019 / Y9s / P SMART Z / P20 LITE / NOVA 5i / HONOR 9X / HONOR 9X PRO / P SMART PRO	Huawei		403	403	59	\N	SISTEMA	system	2025-08-27 00:11:19.606	2025-08-27 12:37:25.139
867	PRODUCTO	Display ZTE A52/A72 ORIG S/M	ZTE	-	0	625	890	\N	SISTEMA	system	2025-08-27 00:11:19.635	2025-08-30 19:59:28.557
850	PRODUCTO	Display ZTE A71 ORIG C/M(BOUTIQUE)	ZTE	-	0	600	878	\N	SISTEMA	system	2025-08-27 00:11:19.55	2025-08-30 20:05:04.221
868	PRODUCTO	Display ZTE A51/A71/NOBIA N41 ORIG	ZTE	-	0	600	891	\N	SISTEMA	system	2025-08-27 00:11:19.639	2025-08-30 19:59:01.099
855	PRODUCTO	Display ZTE A31 ORIG S/M	ZTE	-	0	675	884	\N	SISTEMA	system	2025-08-27 00:11:19.577	2025-08-30 19:57:19.651
872	PRODUCTO	Display ZTE AXON 60 ORIG	ZTE		1300	1300	895	\N	SISTEMA	system	2025-08-27 00:11:19.659	2025-08-27 12:57:54.841
873	PRODUCTO	Display ZTE AXON 60 LITE	ZTE		704	704	896	\N	SISTEMA	system	2025-08-27 00:11:19.665	2025-08-27 12:57:54.851
874	PRODUCTO	Display ZTE AXON 40SE ORIG	ZTE		3125	3125	897	\N	SISTEMA	system	2025-08-27 00:11:19.67	2025-08-27 12:57:54.862
875	PRODUCTO	Display ZTE AXON 20 ORIG	ZTE		2450	2450	898	\N	SISTEMA	system	2025-08-27 00:11:19.673	2025-08-27 12:57:54.875
876	PRODUCTO	Display ZTE AXON 40 PRO	ZTE		2320	2320	899	\N	SISTEMA	system	2025-08-27 00:11:19.679	2025-08-27 12:57:54.885
877	PRODUCTO	Display ZTE AXON 11 ORIG	ZTE		1850	1850	900	\N	SISTEMA	system	2025-08-27 00:11:19.685	2025-08-27 12:57:54.898
878	PRODUCTO	Display ZTE AXON 30 ORIG	ZTE		3500	3500	901	\N	SISTEMA	system	2025-08-27 00:11:19.687	2025-08-27 12:57:54.918
879	PRODUCTO	Display ZTE AXON 30 PRO	ZTE		3450	3450	902	\N	SISTEMA	system	2025-08-27 00:11:19.692	2025-08-27 12:57:54.928
880	PRODUCTO	Display ZTE AXON 50 LITE	ZTE		715	715	903	\N	SISTEMA	system	2025-08-27 00:11:19.697	2025-08-27 12:57:54.939
881	PRODUCTO	Display ZTE AXON 40 LITE	ZTE		650	650	904	\N	SISTEMA	system	2025-08-27 00:11:19.7	2025-08-27 12:57:54.953
882	PRODUCTO	Display ZTE L220 ORIG S/M	ZTE		675	675	905	\N	SISTEMA	system	2025-08-27 00:11:19.702	2025-08-27 12:57:54.965
883	PRODUCTO	Display ZTE L210 ORIG S/M	ZTE		567	567	906	\N	SISTEMA	system	2025-08-27 00:11:19.705	2025-08-27 12:57:54.975
884	PRODUCTO	Display ZTE V30 VITA ORIG	ZTE		775	775	907	\N	SISTEMA	system	2025-08-27 00:11:19.709	2025-08-27 12:57:54.987
885	PRODUCTO	Display ZTE V40 SMART ORIG	ZTE		810	810	908	\N	SISTEMA	system	2025-08-27 00:11:19.712	2025-08-27 12:57:54.997
886	PRODUCTO	Display ZTE V40 VITA ORIG	ZTE		725	725	909	\N	SISTEMA	system	2025-08-27 00:11:19.718	2025-08-27 12:57:55.009
887	PRODUCTO	Display ZTE V30 ORIG C/M(BOUTIQUE)	ZTE		850	850	910	\N	SISTEMA	system	2025-08-27 00:11:19.725	2025-08-27 12:57:55.018
888	PRODUCTO	Display ZTE V40 PRO ORIG	ZTE		1345	1345	911	\N	SISTEMA	system	2025-08-27 00:11:19.729	2025-08-27 12:57:55.037
889	PRODUCTO	Display ZTE V50 SMART ORIG	ZTE		704	704	912	\N	SISTEMA	system	2025-08-27 00:11:19.732	2025-08-27 12:57:55.047
890	PRODUCTO	Display ZTE V2020 5G ORIG	ZTE	-	0	676	913	\N	SISTEMA	system	2025-08-27 00:11:19.736	2025-08-29 21:32:28.904
891	PRODUCTO	Display ZTE V2020 VITA ORIG	ZTE	-	0	650	914	\N	SISTEMA	system	2025-08-27 00:11:19.739	2025-08-29 21:33:15.162
892	PRODUCTO	Display ZTE V20 ORIG S/M	ZTE	-	0	657	915	\N	SISTEMA	system	2025-08-27 00:11:19.746	2025-08-29 21:31:17.264
842	PRODUCTO	Display Xiaomi "REDMI NOTE10 PRO/NOTE10	Xiaomi	-	0	1720	870	\N	SISTEMA	system	2025-08-27 00:11:19.511	2025-08-29 21:23:22.083
858	PRODUCTO	Batería Honor MediaPad M5 Pro	Honor		582	582	31	\N	SISTEMA	system	2025-08-27 00:11:19.591	2025-08-27 12:37:24.85
851	PRODUCTO	Display ZTE A52 ORIG C/M(BOUTIQUE)	ZTE	-	0	625	879	\N	SISTEMA	system	2025-08-27 00:11:19.556	2025-08-30 20:00:20.634
862	PRODUCTO	Batería Motorola G8 / ONE VISION / ONE ATION	Motorola		385	385	125	\N	SISTEMA	system	2025-08-27 00:11:19.613	2025-08-27 12:37:25.921
863	PRODUCTO	Batería Motorola E7 / E7i / E7 POWER / E7i POWER / E7PLUS / G9PLAY / E40 / G7 POWER / G8 POWER LITE / G9 PLAY / G10 / G20 / G30 / G50	Motorola		403	403	135	\N	SISTEMA	system	2025-08-27 00:11:19.616	2025-08-27 12:37:26.038
837	PRODUCTO	Display Xiaomi REDMI NOTE10 4G/10S/POCO	Xiaomi		527	527	865	\N	SISTEMA	system	2025-08-27 00:11:19.492	2025-08-27 12:57:54.472
849	PRODUCTO	Display ZTE A53PLUS ORIG C/M(BOUTIQUE)	ZTE	-	0	650	877	\N	SISTEMA	system	2025-08-27 00:11:19.544	2025-08-30 20:01:21.401
861	PRODUCTO	Batería Huawei HUAWEI Y9 2019 / HUAWEI P smart 2019 / HONOR 20 Lite / HONOR 20i / HUAWEI P smart 2020	Huawei		420	420	93	\N	SISTEMA	system	2025-08-27 00:11:19.609	2025-08-27 12:37:25.553
857	PRODUCTO	Batería Hisense F23	Hisense		347	347	27	\N	SISTEMA	system	2025-08-27 00:11:19.588	2025-08-27 12:37:24.793
838	PRODUCTO	Display Xiaomi REDMI NOTE10 4G/10S/POCO	Xiaomi	-	0	1450	850	\N	SISTEMA	system	2025-08-27 00:11:19.495	2025-08-29 22:37:35.357
897	PRODUCTO	Display ZTE V30/V40 ORIG S/M	ZTE		695	695	921	\N	SISTEMA	system	2025-08-27 00:11:19.774	2025-08-27 12:57:55.177
898	PRODUCTO	Display ZTE V40 VITA/V40S SMART/V41S	ZTE	-	0	730	922	\N	SISTEMA	system	2025-08-27 00:11:19.777	2025-08-29 21:41:40.13
899	PRODUCTO	Display ZTE V20 SMART 8010	ZTE		615	615	923	\N	SISTEMA	system	2025-08-27 00:11:19.78	2025-08-27 12:57:55.202
900	PRODUCTO	Display ZTE V20 SMART 2050	ZTE	-	0	675	924	\N	SISTEMA	system	2025-08-27 00:11:19.785	2025-08-29 21:31:51.511
901	PRODUCTO	Display ZTE V30 VITA ORIG	ZTE	-	0	750	907	\N	SISTEMA	system	2025-08-27 00:11:19.791	2025-08-29 21:34:30.791
902	PRODUCTO	Display ZTE V40 SMART ORIG	ZTE		615	615	926	\N	SISTEMA	system	2025-08-27 00:11:19.793	2025-08-27 12:57:55.237
903	PRODUCTO	Display ZTE V SMART/2050 ORIG	ZTE	-	0	663	927	\N	SISTEMA	system	2025-08-27 00:11:19.797	2025-08-29 21:28:38.414
918	PRODUCTO	Display Motorola EDGE20 LITE AMOLED	Motorola	-	0	1925	440	\N	SISTEMA	system	2025-08-27 00:11:19.88	2025-08-29 17:21:04.008
907	PRODUCTO	Batería Xiaomi REDMI 9A / 9AT / 9I / 9C / 10A / POCO C3 / POCO C31	Xiaomi		385	385	223	\N	SISTEMA	system	2025-08-27 00:11:19.815	2025-08-27 12:37:27.022
69	PRODUCTO	Batería Huawei HUAWEI MatePad SE / HUAWEI MediaPad T5 / HUAWEI MatePad C5e / HUAWEI MatePad C3	Huawei		465	465	61	\N	SISTEMA	system	2025-08-27 00:11:13.621	2025-08-27 12:37:25.155
908	PRODUCTO	Batería Xiaomi MI A3	Xiaomi		347	347	236	\N	SISTEMA	system	2025-08-27 00:11:19.82	2025-08-27 12:37:27.163
910	PRODUCTO	Display Honor X9B/Magic 6 ORIG	Honor	-	0	1975	285	\N	SISTEMA	system	2025-08-27 00:11:19.835	2025-08-29 19:05:04.553
914	PRODUCTO	Display Huawei NOVA Y60 ORIG	Huawei	-	0	600	334	\N	SISTEMA	system	2025-08-27 00:11:19.856	2025-08-29 19:19:23.142
911	PRODUCTO	Display Honor X9A ORIG C/M(BOUTIQUE)	Honor		2288	2288	289	\N	SISTEMA	system	2025-08-27 00:11:19.842	2025-08-27 12:46:13.155
912	PRODUCTO	Display Huawei NOVA9 SE/N0VA 11i	Huawei	-	0	835	329	\N	SISTEMA	system	2025-08-27 00:11:19.846	2025-08-29 17:08:07.616
920	PRODUCTO	Display Motorola G50 4G ORIG	Motorola	-	0	600	489	\N	SISTEMA	system	2025-08-27 00:11:19.887	2025-08-29 19:30:25.508
913	PRODUCTO	Display Huawei NOVA Y70 ORIG	Huawei	-	0	600	335	\N	SISTEMA	system	2025-08-27 00:11:19.85	2025-08-29 19:19:55.88
915	PRODUCTO	Display Huawei Y6P/HONOR9A/HONOR9S PRIME ORIG	Huawei		668	668	371	\N	SISTEMA	system	2025-08-27 00:11:19.863	2025-08-27 12:46:14.067
916	PRODUCTO	Display Huawei Y7 2019 ORIG	Huawei	-	0	599	389	\N	SISTEMA	system	2025-08-27 00:11:19.868	2025-08-29 17:27:10.786
917	PRODUCTO	Display Infinix X678B/NOTE30 PRO ORIG	Infinix		963	963	392	\N	SISTEMA	system	2025-08-27 00:11:19.875	2025-08-27 12:46:14.302
909	PRODUCTO	Display Honor X9B ORIG C/M(BOUTIQUE)	Honor	-	0	1975	271	\N	SISTEMA	system	2025-08-27 00:11:19.83	2025-08-29 19:04:43.311
921	PRODUCTO	Display Motorola G60/G60S/G51 5G/G40FUSION ORIG	Motorola	-	0	700	517	\N	SISTEMA	system	2025-08-27 00:11:19.89	2025-08-29 19:49:28.77
923	PRODUCTO	Display Oppo A12/A7/AX7/A5S/A12S/A7n/Ax5s/realme3/realme3i INCELL300+ S/M	oppo	-	0	600	548	\N	SISTEMA	system	2025-08-27 00:11:19.896	2025-08-29 19:34:41.579
928	PRODUCTO	Display Samsung A02S/A03/A03S/A04E ORIG S/M	Samsung	-	0	600	684	\N	SISTEMA	system	2025-08-27 00:11:19.913	2025-08-29 19:50:20.191
922	PRODUCTO	Display Motorola Z3 PLAY OLED	Motorola		1300	1300	539	\N	SISTEMA	system	2025-08-27 00:11:19.893	2025-08-27 12:50:00.881
924	PRODUCTO	Display Oppo A16/A16S/A54S/A56/4G/C25/C25S/NARZO50A ORIG S/M	oppo	-	0	600	586	\N	SISTEMA	system	2025-08-27 00:11:19.899	2025-08-29 19:35:43.095
919	PRODUCTO	Display Motorola G52/G71S/G82/EDGE30 AMOLED (BOUTIQUE)	Motorola	-	0	2150	442	\N	SISTEMA	system	2025-08-27 00:11:19.884	2025-08-29 19:37:51.618
925	PRODUCTO	Display Samsung A30/A50/A50S INCELL C/M	Samsung		644	644	629	\N	SISTEMA	system	2025-08-27 00:11:19.902	2025-08-27 12:53:24.907
926	PRODUCTO	Display Samsung A70/A70S INCELL C/M	Samsung	-	0	0.01	634	\N	SISTEMA	system	2025-08-27 00:11:19.905	2025-08-29 19:53:56.811
932	PRODUCTO	Display Vivo Y1S/Y90/Y91/Y91I/Y91C/Y93/Y93S/Y95/U1 INCELL300+ S/M	Vivo	-	0	600	764	\N	SISTEMA	system	2025-08-27 00:11:19.93	2025-08-29 21:08:52.74
927	PRODUCTO	Display Samsung A70/A70S INCELL C/M（BOUTIQUE)	Samsung	-	0	0.01	674	\N	SISTEMA	system	2025-08-27 00:11:19.909	2025-08-29 19:54:37.685
934	PRODUCTO	Display Vivo Y3/Y3S/Y11/Y12/Y15/Y17/U3X/U10 ORIG S/M	Vivo	-	0	600	785	\N	SISTEMA	system	2025-08-27 00:11:19.938	2025-08-29 21:09:56.231
930	PRODUCTO	Display Samsung G530 LCD INCELL	Samsung	-	0	0.01	734	\N	SISTEMA	system	2025-08-27 00:11:19.921	2025-08-29 21:07:30.902
931	PRODUCTO	Display Samsung S24 ULTRA AMOLED	Samsung		8750	8750	742	\N	SISTEMA	system	2025-08-27 00:11:19.925	2025-08-27 12:53:26.241
929	PRODUCTO	Display Samsung J4CORE/J4PLUS/J6PLUS/J610 ORIG C/PEGAMENTO	Samsung	-	0	612	705	\N	SISTEMA	system	2025-08-27 00:11:19.918	2025-08-29 21:09:09.601
935	PRODUCTO	Display Xiaomi NOTE 13 4G	Xiaomi	-	0	1675	833	\N	SISTEMA	system	2025-08-27 00:11:19.942	2025-08-29 21:30:41.869
933	PRODUCTO	Display Vivo Y71/Y73 ORIG S/M	Vivo	-	0	600	784	\N	SISTEMA	system	2025-08-27 00:11:19.934	2025-08-29 21:13:14.595
938	PRODUCTO	Display ZTE A34/A54 ORIG S/M	ZTE	-	0	625	886	\N	SISTEMA	system	2025-08-27 00:11:19.955	2025-08-30 19:57:46.731
936	PRODUCTO	Display Xiaomi POCO M4/M5/REDMI10 5G/NOTE11	Xiaomi	-	0	1525	841	\N	SISTEMA	system	2025-08-27 00:11:19.947	2025-10-06 20:47:41.474
937	PRODUCTO	Display ZTE A51 ORIG C/M(BOUTIQUE)	ZTE	-	0	600	882	\N	SISTEMA	system	2025-08-27 00:11:19.95	2025-08-30 19:58:35.994
939	PRODUCTO	Display ZTE V9 ORIG S/M	ZTE		687	687	918	\N	SISTEMA	system	2025-08-27 00:11:19.965	2025-08-27 12:57:55.138
895	PRODUCTO	Display ZTE V10 VITA ORIG	ZTE	-	0	625	919	\N	SISTEMA	system	2025-08-27 00:11:19.763	2025-08-29 21:30:58.925
906	PRODUCTO	Batería Samsung A23 4G / M23 / M23 5G / M33 / M33 5G / a23 lite / A73 5G	Samsung		347	347	188	\N	SISTEMA	system	2025-08-27 00:11:19.81	2025-08-27 12:37:26.599
7	PRODUCTO	Pantalla iPhone 16 Pro	Apple	iPhone 16 Pro	3000	0	5	\N	system	SISTEMA	2025-06-17 21:36:45.619	2025-08-27 12:28:11.839
5	PRODUCTO	Batería iPhone 16 Pro	-	-	2100	0	6	\N	system	SISTEMA	2025-06-17 21:36:29.511	2025-08-27 12:28:12.15
26	PRODUCTO	flexor de interconexión Android	Android	VARIOS	0	0	25	\N	system	SISTEMA	2025-08-20 16:50:05.191	2025-08-27 12:28:12.272
119	PRODUCTO	Batería Motorola ONE HYPER / XT2027	Motorola		347	347	111	\N	SISTEMA	system	2025-08-27 00:11:14.012	2025-08-27 12:37:25.759
140	PRODUCTO	Batería Motorola G53 / XT2335-3 / G22 / XT2231-2 / E13 / E22i / E22S / E32 / E32S	Motorola		413	413	133	\N	SISTEMA	system	2025-08-27 00:11:14.161	2025-08-27 12:37:26.013
904	PRODUCTO	Batería Oppo A93 4G	oppo		385	385	142	\N	SISTEMA	system	2025-08-27 00:11:19.802	2025-08-27 12:37:26.116
896	PRODUCTO	Display ZTE V9 LITE ORIG	ZTE		601	601	920	\N	SISTEMA	system	2025-08-27 00:11:19.767	2025-08-27 12:57:55.169
229	PRODUCTO	Batería Xiaomi MI 11T	Xiaomi		634	634	228	\N	SISTEMA	system	2025-08-27 00:11:14.855	2025-08-27 12:37:27.081
239	PRODUCTO	Batería Xiaomi POCO F3 / MI11 i / MI11 X	Xiaomi		567	567	239	\N	SISTEMA	system	2025-08-27 00:11:14.942	2025-08-27 12:37:27.193
290	PRODUCTO	Display Honor X9A/MAGIC5 LITE ORIG	Honor	-	0	2288	293	\N	SISTEMA	system	2025-08-27 00:11:15.334	2025-08-29 19:03:14.276
279	PRODUCTO	Display Honor X8B ORIG C/M(BOUTIQUE)	Honor	-	0	1525	280	\N	SISTEMA	system	2025-08-27 00:11:15.25	2025-08-29 19:00:48.988
561	PRODUCTO	Display Oppo C35/narzo50A/prime C3/prime C5	oppo	-	0	600	576	\N	SISTEMA	system	2025-08-27 00:11:17.479	2025-08-29 19:42:40.069
327	PRODUCTO	Display Huawei NOVA5T/HONOR20 COG S/M	Huawei	-	0	850	331	\N	SISTEMA	system	2025-08-27 00:11:15.618	2025-08-29 17:07:37.379
454	PRODUCTO	Display Motorola G04/G04S/E14 ORIG C/M(BOUTIQUE)	Motorola	-	0	600	465	\N	SISTEMA	system	2025-08-27 00:11:16.621	2025-08-29 17:33:27.129
286	PRODUCTO	Display Honor X5 ORIG S/M	Honor	-	0	688	288	\N	SISTEMA	system	2025-08-27 00:11:15.298	2025-08-29 18:54:52.367
399	PRODUCTO	Display Motorola E30/E40 ORIG S/M	Motorola	-	0	599	408	\N	SISTEMA	system	2025-08-27 00:11:16.199	2025-08-29 19:30:51.171
428	PRODUCTO	Display Motorola EDGE30 NEO OLED	Motorola		3000	3000	437	\N	SISTEMA	system	2025-08-27 00:11:16.426	2025-08-27 12:49:59.617
453	PRODUCTO	Display Motorola G34 ORIG S/M	Motorola	-	0	600	464	\N	SISTEMA	system	2025-08-27 00:11:16.61	2025-08-29 19:21:43.457
371	PRODUCTO	Display Huawei Y8P INCELL C/M(BOUTIQUE)	Huawei	-	0	775	378	\N	SISTEMA	system	2025-08-27 00:11:15.98	2025-08-29 17:40:01.295
781	PRODUCTO	Display Xiaomi MI11T/MI11T PRO AMOLED	Xiaomi	-	0	2000	807	\N	SISTEMA	system	2025-08-27 00:11:19.233	2025-08-29 21:29:28.666
506	PRODUCTO	Display Motorola G9PLUS ORIG S/M	Motorola	-	0	675	519	\N	SISTEMA	system	2025-08-27 00:11:17.069	2025-08-29 21:22:51.276
516	PRODUCTO	Display Motorola ONE FUSION PLUS	Motorola		567	567	529	\N	SISTEMA	system	2025-08-27 00:11:17.138	2025-08-27 12:50:00.768
554	PRODUCTO	Display Oppo "REALME7 5G/A72 5G/A73	oppo		630	630	569	\N	SISTEMA	system	2025-08-27 00:11:17.424	2025-08-27 12:50:01.26
644	PRODUCTO	Display Samsung A04E ORIG C/M（BOUTIQUE)	Samsung	-	0	600	662	\N	SISTEMA	system	2025-08-27 00:11:18.097	2025-08-29 19:52:09.628
615	PRODUCTO	Display Samsung A53/A536 OLED C/M	Samsung		1625	1625	632	\N	SISTEMA	system	2025-08-27 00:11:17.892	2025-08-27 12:53:24.954
755	PRODUCTO	Display Vivo Y33S/Y76S/Y76 5G/Y74S/Y33T/X2058(UNIVERSAL) ORIG	Vivo	-	0	625	779	\N	SISTEMA	system	2025-08-27 00:11:19.061	2025-08-29 21:11:37.604
670	PRODUCTO	Display Samsung J6 INCELL300+S/M NEGRO	Samsung	-	0	0.01	688	\N	SISTEMA	system	2025-08-27 00:11:18.324	2025-08-29 21:11:17.456
675	PRODUCTO	Display Samsung J8 INCELL300+ S/M	Samsung	-	0	0.01	693	\N	SISTEMA	system	2025-08-27 00:11:18.369	2025-08-29 21:17:41.806
711	PRODUCTO	Display Samsung SAMSUNG-NOTE20 OLED C/M(BOUTIQUE)	Samsung		4125	4125	732	\N	SISTEMA	system	2025-08-27 00:11:18.681	2025-08-27 12:53:26.169
726	PRODUCTO	Display Samsung S21 PLUS SOFT	Samsung		3550	3550	749	\N	SISTEMA	system	2025-08-27 00:11:18.806	2025-08-27 12:53:26.356
494	PRODUCTO	Display Motorola G8POWER ORIG C/M（BOUTIQUE）	Motorola	-	0	675	506	\N	SISTEMA	system	2025-08-27 00:11:16.969	2025-08-29 21:21:03.917
803	PRODUCTO	Display Xiaomi REDMI Note11 4G/Note11S/NOTE12S/POCO	Xiaomi	-	0	1750	829	\N	SISTEMA	system	2025-08-27 00:11:19.333	2025-08-30 19:54:58.801
853	PRODUCTO	Display ZTE A53 ORIG C/M(BOUTIQUE)	ZTE	-	0	650	881	\N	SISTEMA	system	2025-08-27 00:11:19.567	2025-08-30 20:00:43.111
836	PRODUCTO	Display Xiaomi REDMI NOTE11 4G/NOTE11S/NOTE12S/POCO	Xiaomi		1408	1408	864	\N	SISTEMA	system	2025-08-27 00:11:19.489	2025-08-27 12:57:54.461
894	PRODUCTO	Display ZTE V10 ORIG S/M	ZTE	-	0	978	917	\N	SISTEMA	system	2025-08-27 00:11:19.756	2025-08-29 21:29:37.314
940	PRODUCTO	Batería Apple iPhone 13	Apple		516	516	929	\N	SISTEMA	system	2025-08-27 12:24:39.183	2025-08-27 13:01:28.751
905	PRODUCTO	Batería Oppo A17 / A17K / A57 / A57S / A57E / A58 4G A78 5G / K10 5G / N20SE	oppo		518	518	143	\N	SISTEMA	system	2025-08-27 00:11:19.806	2025-08-27 12:37:26.131
152	PRODUCTO	Batería Oppo A16K / A16E / A16 / A16S / A54S / A56 / A53 2020 / A32 / A33 / A53S / A11S / A54 4G / A55 4G / A9	oppo		410	410	149	\N	SISTEMA	system	2025-08-27 00:11:14.252	2025-08-27 12:37:26.197
941	PRODUCTO	Batería Apple iPhone 13MINI	Apple		465	465	930	\N	SISTEMA	system	2025-08-27 12:24:39.188	2025-08-27 13:01:28.763
946	PRODUCTO	Batería Apple iPhone MAX 11PRO MAX	Apple		646	646	934	\N	SISTEMA	system	2025-08-27 12:24:39.207	2025-08-27 13:01:28.821
948	PRODUCTO	Batería Apple iPhone XR	Apple		487	487	937	\N	SISTEMA	system	2025-08-27 12:24:39.221	2025-08-27 13:01:28.848
949	PRODUCTO	Batería Apple iPhone MAX XS MAX	Apple		546	546	936	\N	SISTEMA	system	2025-08-27 12:24:39.225	2025-08-27 13:01:28.866
950	PRODUCTO	Batería Apple iPhone X	Apple		501	501	938	\N	SISTEMA	system	2025-08-27 12:24:39.232	2025-08-27 13:01:28.878
951	PRODUCTO	Batería Apple iPhone 8PLUS	Apple		459	459	939	\N	SISTEMA	system	2025-08-27 12:24:39.236	2025-08-27 13:01:28.893
952	PRODUCTO	Batería Apple iPhone 8G	Apple		389	389	941	\N	SISTEMA	system	2025-08-27 12:24:39.239	2025-08-27 13:01:28.912
953	PRODUCTO	Batería Apple iPhone 7PLUS	Apple		406	406	942	\N	SISTEMA	system	2025-08-27 12:24:39.245	2025-08-27 13:01:28.922
954	PRODUCTO	Batería Apple iPhone 7G	Apple		361	361	943	\N	SISTEMA	system	2025-08-27 12:24:39.251	2025-08-27 13:01:28.94
955	PRODUCTO	Batería Apple iPhone 6G	Apple		361	361	945	\N	SISTEMA	system	2025-08-27 12:24:39.257	2025-08-27 13:01:28.958
957	PRODUCTO	Display Apple 7G AAA BLANCO	Apple	-	0	600	947	\N	SISTEMA	system	2025-08-27 12:24:39.267	2025-08-28 23:43:09.836
958	PRODUCTO	Display Apple 7G AAA NEGRO	Apple	-	0	600	948	\N	SISTEMA	system	2025-08-27 12:24:39.271	2025-08-28 23:43:28.758
343	PRODUCTO	Display Huawei P30 LITE COG	Huawei	-	0	775	349	\N	SISTEMA	system	2025-08-27 00:11:15.747	2025-08-29 17:19:02.657
956	PRODUCTO	Display Apple 6S PLUS AAA	Apple	-	0	628	946	\N	SISTEMA	system	2025-08-27 12:24:39.262	2025-08-28 23:42:36.666
942	PRODUCTO	Batería Apple iPhone MINI 12 MINI	Apple		0	0	931	\N	SISTEMA	SISTEMA	2025-08-27 12:24:39.191	2025-08-27 12:28:17.896
943	PRODUCTO	Batería Apple iPhone MAX 12PRO MAX	Apple		0	0	932	\N	SISTEMA	SISTEMA	2025-08-27 12:24:39.193	2025-08-27 12:28:17.903
944	PRODUCTO	Batería Apple iPhone 2020 SE 2020	Apple		0	0	940	\N	SISTEMA	SISTEMA	2025-08-27 12:24:39.199	2025-08-27 12:28:17.909
945	PRODUCTO	Batería Apple iPhone PLUS 6S PLUS	Apple		0	0	944	\N	SISTEMA	SISTEMA	2025-08-27 12:24:39.205	2025-08-27 12:28:17.912
947	PRODUCTO	Batería Apple iPhone 11	Apple	-	0	537	935	\N	SISTEMA	system	2025-08-27 12:24:39.212	2025-08-29 21:49:57.251
208	PRODUCTO	Batería Xiaomi REDMI NOTE11S / POCO M4PRO 4G / note11 / 12s	Xiaomi		453	453	206	\N	SISTEMA	system	2025-08-27 00:11:14.69	2025-08-27 12:37:26.814
859	PRODUCTO	Batería Huawei HONOR 8X / HONOR 9X Lite	Huawei		555	555	58	\N	SISTEMA	system	2025-08-27 00:11:19.601	2025-08-27 12:37:25.131
962	PRODUCTO	Display Apple 6G AAA S/M	Apple	-	0	600	951	\N	SISTEMA	system	2025-08-27 12:24:39.286	2025-08-28 23:41:58.001
963	PRODUCTO	Display Apple 8PLUS AAA BLANCO	Apple	-	0	627	953	\N	SISTEMA	system	2025-08-27 12:24:39.292	2025-08-28 23:45:15.299
964	PRODUCTO	Display Apple 8PLUS AAA NEGRO	Apple	-	0	627	954	\N	SISTEMA	system	2025-08-27 12:24:39.3	2025-08-28 23:45:47.33
966	PRODUCTO	Display Apple 7PLUS AAA NEGRO	Apple	-	0	600	956	\N	SISTEMA	system	2025-08-27 12:24:39.305	2025-08-28 23:44:16.503
975	PRODUCTO	Display Apple HG X11PRO MAX(MOVIL	Apple	-	0	1925	966	\N	SISTEMA	system	2025-08-27 12:24:39.343	2025-08-28 23:53:10.661
968	PRODUCTO	Display Apple HG X11(MOVIL IC)	Apple	-	0	1057	958	\N	SISTEMA	system	2025-08-27 12:24:39.312	2025-08-28 23:52:11.937
967	PRODUCTO	Display Apple HG X FHD	Apple	-	0	775	957	\N	SISTEMA	system	2025-08-27 12:24:39.308	2025-08-28 23:49:01.688
979	PRODUCTO	Display Apple HG X14PRO(MOVIL IC)	Apple	-	0	7375	970	\N	SISTEMA	system	2025-08-27 12:24:39.359	2025-08-29 16:04:27.036
973	PRODUCTO	Display Apple HG XS FHD	Apple	-	0	1450	964	\N	SISTEMA	system	2025-08-27 12:24:39.333	2025-08-29 17:02:34.446
1007	PRODUCTO	Display Apple HG X14PLUS(MOVIL IC)	Apple	-	0	4375	959	\N	SISTEMA	system	2025-08-27 12:24:39.476	2025-08-29 16:03:15.067
969	PRODUCTO	Display Apple HG X13PRO(MOVIL IC)	Apple	-	0	3850	960	\N	SISTEMA	system	2025-08-27 12:24:39.314	2025-08-29 16:01:46.201
974	PRODUCTO	Display Apple HG XS MAX	Apple	-	0	1775	965	\N	SISTEMA	system	2025-08-27 12:24:39.338	2025-08-29 17:03:55.926
992	PRODUCTO	Display Apple INCELL 12 MINI	Apple	-	0	2500	996	\N	SISTEMA	system	2025-08-27 12:24:39.428	2025-08-29 17:04:16.033
981	PRODUCTO	Display Apple HG X11PRO(MOVIL IC)	Apple	-	0	1625	972	\N	SISTEMA	system	2025-08-27 12:24:39.367	2025-08-28 23:53:31.138
976	PRODUCTO	Display Apple HG X12/12PRO(MOVIL IC)	Apple	-	0	1998	967	\N	SISTEMA	system	2025-08-27 12:24:39.347	2025-08-29 15:58:19.618
980	PRODUCTO	Display Apple HG X13(MOVIL IC)	Apple	-	0	2375	971	\N	SISTEMA	system	2025-08-27 12:24:39.363	2025-08-29 15:59:47.36
970	PRODUCTO	Display Apple HG XR FHD	Apple	-	0	800	961	\N	SISTEMA	system	2025-08-27 12:24:39.319	2025-08-29 17:00:50.077
978	PRODUCTO	Display Apple HG X15PRO FHD	Apple	-	0	8575	969	\N	SISTEMA	system	2025-08-27 12:24:39.355	2025-08-29 16:07:45.274
972	PRODUCTO	Display Apple HG X13PRO MAX(MOVIL	Apple	-	0	4750	963	\N	SISTEMA	system	2025-08-27 12:24:39.326	2025-08-29 16:01:00.611
977	PRODUCTO	Display Apple HG X12PRO MAX(MOVIL	Apple	-	0	2275	968	\N	SISTEMA	system	2025-08-27 12:24:39.351	2025-08-29 15:59:14.074
983	PRODUCTO	Display Apple JK 13MINI(MOVIL IC)	Apple	-	0	2850	974	\N	SISTEMA	system	2025-08-27 12:24:39.385	2025-08-29 17:16:21.983
1013	PRODUCTO	Display Apple JK X FHD	Apple	-	0	1500	987	\N	SISTEMA	system	2025-08-27 12:24:39.497	2025-08-29 17:16:44.481
982	PRODUCTO	Display Apple JK 13 PRO	Apple	-	0	3850	973	\N	SISTEMA	system	2025-08-27 12:24:39.379	2025-08-29 17:15:56.683
1010	PRODUCTO	Display Apple JK XR FHD	Apple	-	0	800	984	\N	SISTEMA	system	2025-08-27 12:24:39.487	2025-08-29 17:21:20.775
990	PRODUCTO	Display Apple JK X13 FHD	Apple	-	0	2375	981	\N	SISTEMA	system	2025-08-27 12:24:39.419	2025-08-29 17:19:34.545
1008	PRODUCTO	Display Apple JK X12/X12PRO FHD	Apple	-	0	2000	982	\N	SISTEMA	system	2025-08-27 12:24:39.481	2025-08-29 17:18:53.768
988	PRODUCTO	Display Apple JK XS MAX	Apple		913	913	979	\N	SISTEMA	system	2025-08-27 12:24:39.406	2025-08-27 13:01:29.386
985	PRODUCTO	Display Apple JK X15(MOVIL IC)	Apple	-	0	5500	976	\N	SISTEMA	system	2025-08-27 12:24:39.393	2025-08-29 17:20:58.786
989	PRODUCTO	Display Apple JK X14 FHD	Apple	-	0	2950	980	\N	SISTEMA	system	2025-08-27 12:24:39.413	2025-08-29 17:20:10.861
986	PRODUCTO	Display Apple JK X12PRO MAX	Apple	-	0	2775	977	\N	SISTEMA	system	2025-08-27 12:24:39.399	2025-08-29 17:19:13.084
987	PRODUCTO	Display Apple JK X11PRO MAX	Apple	-	0	1925	978	\N	SISTEMA	system	2025-08-27 12:24:39.403	2025-08-29 17:17:59.043
1015	PRODUCTO	Display Apple MS X11PRO MAX(MOVIL	Apple	-	0	1925	989	\N	SISTEMA	system	2025-08-27 12:24:39.503	2025-08-29 17:29:15.909
1009	PRODUCTO	Display Apple JK X11(MOVIL IC)	Apple	-	0	925	983	\N	SISTEMA	system	2025-08-27 12:24:39.484	2025-08-29 17:17:11.933
1016	PRODUCTO	Display Apple MS XS MAX	Apple	-	0	1775	990	\N	SISTEMA	system	2025-08-27 12:24:39.507	2025-08-29 17:30:14.624
1004	PRODUCTO	Display Apple OLED 13 OLED	Apple	-	0	2375	1020	\N	SISTEMA	system	2025-08-27 12:24:39.467	2025-08-29 17:30:38.394
965	PRODUCTO	Display Apple 7PLUS AAA BLANCO	Apple	-	0	600	955	\N	SISTEMA	system	2025-08-27 12:24:39.302	2025-08-28 23:43:54.6
991	PRODUCTO	Display Apple MAX INCELL-IC X15PRO	Apple		0	0	995	\N	SISTEMA	SISTEMA	2025-08-27 12:24:39.424	2025-08-27 12:28:18.011
997	PRODUCTO	Display Apple INCELL 13 MINI	Apple	-	0	2850	1004	\N	SISTEMA	system	2025-08-27 12:24:39.444	2025-08-29 17:04:34.907
993	PRODUCTO	Display Apple INCELL XS INCELL	Apple		0	0	1000	\N	SISTEMA	SISTEMA	2025-08-27 12:24:39.431	2025-08-27 12:28:18.017
994	PRODUCTO	Display Apple INCELL-IC 11PRO(MOVIL IC)	Apple		0	0	1001	\N	SISTEMA	SISTEMA	2025-08-27 12:24:39.435	2025-08-27 12:28:18.021
995	PRODUCTO	Display Apple INCELL-IC 12/12PRO(MOVIL IC)	Apple		0	0	1002	\N	SISTEMA	SISTEMA	2025-08-27 12:24:39.438	2025-08-27 12:28:18.022
996	PRODUCTO	Display Apple INCELL-IC X11(MOVIL IC)	Apple		0	0	1003	\N	SISTEMA	SISTEMA	2025-08-27 12:24:39.441	2025-08-27 12:28:18.024
984	PRODUCTO	Display Apple JK 12MINI(MOVIL IC)	Apple	-	0	2500	975	\N	SISTEMA	system	2025-08-27 12:24:39.389	2025-08-29 17:15:29.601
998	PRODUCTO	Display Apple INCELL XR INCELL	Apple		0	0	1005	\N	SISTEMA	SISTEMA	2025-08-27 12:24:39.448	2025-08-27 12:28:18.035
999	PRODUCTO	Display Apple INCELL X(CARTAN) INCELL	Apple		0	0	1006	\N	SISTEMA	SISTEMA	2025-08-27 12:24:39.45	2025-08-27 12:28:18.039
1001	PRODUCTO	Display Apple MAX OLED-IC X13PRO	Apple		0	0	1012	\N	SISTEMA	SISTEMA	2025-08-27 12:24:39.458	2025-08-27 12:28:18.05
1003	PRODUCTO	Display Apple OLED-IC 14PRO(MOVIL IC)	Apple	-	0	6625	1019	\N	SISTEMA	system	2025-08-27 12:24:39.464	2025-08-29 17:31:47.668
1000	PRODUCTO	Display Apple OLED-IC X15(MOVIL IC)	Apple	-	0	5500	1011	\N	SISTEMA	system	2025-08-27 12:24:39.454	2025-08-29 17:32:08.648
1002	PRODUCTO	Display Apple OLED-IC 14(MOVIL IC)	Apple	-	0	2950	1018	\N	SISTEMA	system	2025-08-27 12:24:39.461	2025-08-29 17:31:00.637
1006	PRODUCTO	Batería Apple iPhone 12/12PRO	Apple		546	546	933	\N	SISTEMA	system	2025-08-27 12:24:39.473	2025-08-27 13:01:28.802
961	PRODUCTO	Display Apple 6G AAA S/M	Apple		372	372	951	\N	SISTEMA	system	2025-08-27 12:24:39.283	2025-08-27 13:01:29.035
971	PRODUCTO	Display Apple HG X14(MOVIL IC)	Apple	-	0	2950	962	\N	SISTEMA	system	2025-08-27 12:24:39.321	2025-08-29 16:02:26.694
1011	PRODUCTO	Display Apple JK X11PRO FHD	Apple	-	0	1625	985	\N	SISTEMA	system	2025-08-27 12:24:39.489	2025-08-29 17:17:36.812
1012	PRODUCTO	Display Apple JK XS FHD	Apple	-	0	1450	986	\N	SISTEMA	system	2025-08-27 12:24:39.493	2025-08-29 17:21:38.205
1005	PRODUCTO	Batería Apple iPhone 12MINI	Apple		516	516	928	\N	SISTEMA	system	2025-08-27 12:24:39.47	2025-08-27 13:01:28.738
1045	PRODUCTO	Cable C a C	YA!	Cables para carga 	0	70	\N	\N	system	system	2025-09-05 18:06:33.799	2025-09-05 18:06:33.797
1052	PRODUCTO	Cable C a	YA!	Cables para carga 	60	60	1055	\N	system	system	2025-09-05 18:24:40.15	2025-09-05 18:25:35.323
1019	PRODUCTO	Display Apple MS XS INCELL	Apple	-	0	0.01	993	\N	SISTEMA	system	2025-08-27 12:24:39.517	2025-08-29 17:29:56.906
1021	PRODUCTO	Display Apple X HD INCELL	Apple	-	0	0.01	997	\N	SISTEMA	system	2025-08-27 12:24:39.524	2025-08-29 17:32:20.633
1022	PRODUCTO	Display Apple XR HD INCELL	Apple	-	0	0.01	998	\N	SISTEMA	system	2025-08-27 12:24:39.527	2025-08-29 17:32:34.581
1023	PRODUCTO	Display Apple XS HD INCELL	Apple	-	0	0.01	999	\N	SISTEMA	system	2025-08-27 12:24:39.534	2025-08-29 17:33:46.17
564	PRODUCTO	Display Oppo "A5 2020/A8/A11/A11X/A9 2020/realme5/realme5i/realme5s/A31	oppo	-	0	600	579	\N	SISTEMA	system	2025-08-27 00:11:17.503	2025-08-29 19:28:19.622
669	PRODUCTO	Display Samsung A02/A12/A32 5G/M02/M127/F12 ORIG	Samsung	-	0	600	687	\N	SISTEMA	system	2025-08-27 00:11:18.312	2025-08-29 19:49:50.173
1034	PRODUCTO	Audifonos Motorola 	YA!	Audífonos bluetooth	0	160	1038	\N	system	system	2025-09-05 17:26:17.763	2025-09-05 17:26:17.762
1035	PRODUCTO	Audifonos Ximi	YA!	Audífonos alambricos	0	39	1036	\N	system	system	2025-09-05 17:26:24.085	2025-09-05 17:26:24.084
1036	PRODUCTO	Audífonos Bose	YA!	Audífonos bluetooth	0	160	1040	\N	system	system	2025-09-05 17:26:31.273	2025-09-05 17:26:31.271
1037	PRODUCTO	Audífonos Sony 	YA!	Audífonos bluetooth	0	160	1039	\N	system	system	2025-09-05 17:26:37.03	2025-09-05 17:26:37.028
1038	PRODUCTO	Audífonos unicornio lila	YA!	Audífonos alambricos	0	250	1035	\N	system	system	2025-09-05 17:27:00.348	2025-09-05 17:27:00.346
1039	PRODUCTO	Audífonos unicornio rosa	YA!	Audífonos alambricos	0	250	1034	\N	system	system	2025-09-05 17:27:07.179	2025-09-05 17:27:07.178
1040	PRODUCTO	Bocina doble YA!	YA!	Bocinas inalambricas 	0	550	1033	\N	system	system	2025-09-05 17:27:23.846	2025-09-05 17:27:23.844
97	PRODUCTO	Batería Huawei HUAWEI MediaPad M5 / HUAWEI MediaPad M5 Pro / HUAWEI MediaPad M5 lite / HUAWEI MediaPad M6 / HUAWEI Ma	Huawei		455	455	89	\N	SISTEMA	system	2025-08-27 00:11:13.842	2025-08-27 12:37:25.5
175	PRODUCTO	Batería Samsung J4CORE / J4PLUS / J6 PLUS / J610	Samsung		228	228	172	\N	SISTEMA	system	2025-08-27 00:11:14.429	2025-08-27 12:37:26.431
1053	PRODUCTO	Bateria moto E13	Motorola	E13	0	400	1056	\N	system	system	2025-09-08 19:47:04.997	2025-09-08 19:47:04.996
567	PRODUCTO	Display Oppo "REALME6/REALME7/REALME6S/REALME6I IZQUIERDO/NARZO20 PRO/NARZO30	oppo		615	615	582	\N	SISTEMA	system	2025-08-27 00:11:17.525	2025-08-27 12:50:01.437
959	PRODUCTO	Display Apple 8G/SE 2020 AAA	Apple		418	418	949	\N	SISTEMA	system	2025-08-27 12:24:39.274	2025-08-27 13:01:29.009
1042	PRODUCTO	Bocina pequeña YA 	YA!	Bocinas inalambricas 	0	150	1031	\N	system	system	2025-09-05 17:27:42.016	2025-09-05 17:27:42.015
1041	PRODUCTO	Bocina mediana YA!	YA!	Bocinas inalambricas 	0	450	\N	\N	system	system	2025-09-05 17:27:33.444	2025-09-05 17:27:33.443
1043	PRODUCTO	Bocina cuadrada YA!	YA!	Bocinas inalambricas 	0	450	1042	\N	system	system	2025-09-05 17:29:01.905	2025-09-05 17:29:01.903
1044	PRODUCTO	Cables Pulpo	YA!	Cables para carga 	25	60	1048	\N	system	system	2025-09-05 18:06:07.769	2025-09-05 18:06:07.767
1020	PRODUCTO	Display Apple MS X INCELL	Apple		630	630	994	\N	SISTEMA	system	2025-08-27 12:24:39.52	2025-08-27 13:01:29.553
1046	PRODUCTO	Cargador Motorola 	YA!	Cargadores turbo 	55	150	1043	\N	system	system	2025-09-05 18:06:44.323	2025-09-05 18:06:44.322
1047	PRODUCTO	Cargador tipo C YA! 	YA!	Cargadores 	26	80	1044	\N	system	system	2025-09-05 18:06:58.433	2025-09-05 18:06:58.432
1048	PRODUCTO	Cargador tipo IPhone YA! 	YA!	Cargadores 	26	80	1046	\N	system	system	2025-09-05 18:07:10.315	2025-09-05 18:07:10.314
1049	PRODUCTO	Cargador tipo V8 YA!	YA!	Cargadores 	26	80	1045	\N	system	system	2025-09-05 18:07:16.734	2025-09-05 18:07:16.733
1050	PRODUCTO	Cubo para cable	YA!	Cargadores 	21	50	1047	\N	system	system	2025-09-05 18:07:26.306	2025-09-05 18:07:26.305
1051	PRODUCTO	cargador 	YA!	Cargadores 	0	80	\N	\N	system	system	2025-09-05 18:07:34.992	2025-09-05 18:07:34.991
960	PRODUCTO	Display Apple 8G/SE 2020 AAA	Apple	-	0	617	950	\N	SISTEMA	system	2025-08-27 12:24:39.279	2025-08-28 23:44:46.771
1033	PRODUCTO	Display Apple  X  OLed	Apple	iPhone X	0	1512	1021	\N	system	system	2025-08-28 23:51:24.046	2025-08-28 23:51:24.045
1027	PRODUCTO	Display Apple HG X12PRO MAX	Apple	-	0	2775	1010	\N	SISTEMA	system	2025-08-27 12:24:39.549	2025-08-29 15:58:48.984
1026	PRODUCTO	Display Apple HG X13PRO MAX	Apple	-	0	4750	1009	\N	SISTEMA	system	2025-08-27 12:24:39.546	2025-08-29 16:00:12.815
1025	PRODUCTO	Display Apple HG X14PRO MAX	Apple	-	0	7375	1008	\N	SISTEMA	system	2025-08-27 12:24:39.543	2025-08-29 16:03:45.949
1024	PRODUCTO	Display Apple HG X15PRO MAX	Apple	-	0	7828	1007	\N	SISTEMA	system	2025-08-27 12:24:39.537	2025-08-29 16:08:32.002
1031	PRODUCTO	Display Apple JK X11PRO MAX(MOVIL	Apple	-	0	1925	1016	\N	SISTEMA	system	2025-08-27 12:24:39.565	2025-08-29 17:18:15.08
1028	PRODUCTO	Display Apple JK X12/12PRO(MOVIL IC)	Apple	-	0	2000	1013	\N	SISTEMA	system	2025-08-27 12:24:39.552	2025-08-29 17:18:37.616
1030	PRODUCTO	Display Apple JK X13(MOVIL IC)	Apple	-	0	2375	1015	\N	SISTEMA	system	2025-08-27 12:24:39.561	2025-08-29 17:19:51.136
1029	PRODUCTO	Display Apple JK X14(MOVIL IC)	Apple	-	0	2950	1014	\N	SISTEMA	system	2025-08-27 12:24:39.556	2025-08-29 17:20:30.067
1032	PRODUCTO	Display Apple JK XS MAX	Apple	-	0	1775	1017	\N	SISTEMA	system	2025-08-27 12:24:39.569	2025-08-29 17:27:23.508
1017	PRODUCTO	Display Apple MS X11(MOVIL IC)	Apple	-	0	925	991	\N	SISTEMA	system	2025-08-27 12:24:39.51	2025-08-29 17:28:11.527
1014	PRODUCTO	Display Apple MS X11PRO INCELL	Apple	-	0	0.01	988	\N	SISTEMA	system	2025-08-27 12:24:39.5	2025-08-29 17:28:50.081
1018	PRODUCTO	Display Apple MS XR INCELL	Apple	-	0	0.01	992	\N	SISTEMA	system	2025-08-27 12:24:39.514	2025-08-29 17:29:30.496
1054	SERVICIO	Desbloqueo básico	-	-	0	100	\N	1	system	system	2025-09-08 19:52:32.553	2025-09-08 19:52:32.552
1055	PRODUCTO	Alcoholera de vidrio	DKT	HERRAMIENTA	0	150	1058	\N	system	system	2025-09-09 22:54:08.588	2025-09-09 22:54:08.587
1056	PRODUCTO	Flux	KAISI	HERRAMIENTA	0	290	1059	\N	system	system	2025-09-09 22:54:20.846	2025-09-09 22:54:20.845
1057	PRODUCTO	Paquete oppener de metal	PR	HERR	0	90	1061	\N	system	system	2025-09-09 22:54:37.893	2025-09-09 22:54:37.891
1058	PRODUCTO	Pegamento negro para pantalla	ZHANLIDA	HERRAMIENTA	0	89	1060	\N	system	system	2025-09-09 22:54:52.406	2025-09-09 22:54:52.405
1059	PRODUCTO	Tester 	MECHANIC	HERRAMIENTA	0	600	1062	\N	system	system	2025-09-09 22:55:11.993	2025-09-09 22:55:11.992
1060	PRODUCTO	Toallitas limpiadoras	KAISI	HERRAMIENTA	0	200	1063	\N	system	system	2025-09-09 22:55:29.41	2025-09-09 22:55:29.409
1061	PRODUCTO	Oppener de plastico	KAISI	HERRAMIENTA	0	10	1064	\N	system	system	2025-09-09 22:56:32.665	2025-09-09 22:56:32.664
1062	PRODUCTO	Pegamento transparente para pantalla	ZHANLIDA	HERRAMIENTA	0	90	1065	\N	system	system	2025-09-09 22:59:00.42	2025-09-09 22:59:00.419
1063	PRODUCTO	Caja organizadora grande	SUNSHINE 	HERRAMIENTA	0	50	1067	\N	system	system	2025-09-09 23:02:02.721	2025-09-09 23:02:02.719
1064	PRODUCTO	Caja organizadora pequeña	SUNSHINE 	HERRAMIENTA	0	30	1066	\N	system	system	2025-09-09 23:02:07.79	2025-09-09 23:02:07.789
1065	PRODUCTO	Soportes para motocicleta  	YA!	Soportes para celular 	0	130	1037	\N	system	system	2025-09-09 23:02:31.427	2025-09-09 23:02:31.426
1066	SERVICIO	Centro de carga tipo V8	-	-	0	300	\N	1	system	system	2025-09-13 20:13:59.851	2025-09-13 20:13:59.849
1067	PRODUCTO	Alcohol isopropilico	KAISI	HERRAMIENTA	0	100	1075	\N	system	system	2025-09-17 18:40:08.048	2025-09-17 18:40:08.047
1068	PRODUCTO	Oppener de metal	KAISI	HERRAMIENTA	0	39	1074	\N	system	system	2025-09-17 18:42:47.364	2025-09-17 18:42:47.362
1069	PRODUCTO	Desarmador de cruz	KAISI	HERRAMIENTA	0	49	1078	\N	system	system	2025-09-17 18:46:10.262	2025-09-17 18:46:27.753
1070	PRODUCTO	Desarmador plano	KAISI	HERRAMIENTA	0	49	1079	\N	system	system	2025-09-17 18:46:16.795	2025-09-17 18:46:33.449
1071	PRODUCTO	Cinta Kapton 	KAISI	HERRAMIENTA	0	85	1077	\N	system	system	2025-09-17 19:09:25.22	2025-09-17 19:09:25.219
1072	PRODUCTO	Gotero	KAISI	HERRAMIENTA	0	25	1076	\N	system	system	2025-09-17 19:09:39.682	2025-09-17 19:09:39.681
1073	PRODUCTO	Cepillo de limpieza	KAISI	HERRAMIENTA	0	22	1080	\N	system	system	2025-09-17 19:54:55.972	2025-09-17 19:54:55.971
1074	PRODUCTO	Espatula para baterias	MECHANIC	HERRAMIENTA	0	75	1069	\N	system	system	2025-09-17 19:55:07.467	2025-09-17 19:55:07.466
1075	PRODUCTO	Chip BAIT	BAIT	Sim	0	50	1094	\N	system	system	2025-09-20 18:06:32.745	2025-09-20 18:06:32.742
1076	PRODUCTO	Chip MOVISTAR	MOVISTAR	Sim	0	50	1093	\N	system	system	2025-09-20 18:06:41.96	2025-09-20 18:06:41.959
1077	PRODUCTO	Chip TELCEL	TELCEL	Sim	0	50	1092	\N	system	system	2025-09-20 18:06:51.791	2025-09-20 18:06:51.789
1078	PRODUCTO	Chip AT&T	AT&T	Sim	0	50	1095	\N	system	system	2025-09-20 18:07:52.781	2025-09-20 18:07:52.779
1079	PRODUCTO	Pinzas rectas	KAISI	HERRAMIENTA	0	99	1096	\N	system	system	2025-09-20 23:50:24.953	2025-09-20 23:50:24.952
1081	SERVICIO	Cámaras iPhone 11 pro max	-	-	0	1700	\N	1	system	system	2025-09-23 16:34:15.68	2025-09-23 16:34:15.679
1082	PRODUCTO	prueba 3	prueba	prueba2	0.1	0.1	1106	\N	system	system	2025-10-09 15:19:46.329	2025-10-09 16:42:31.121
1080	PRODUCTO	Auricular iPhone	Apple	iPhone 11	0	500	1098	\N	system	system	2025-09-23 16:33:59.989	2025-10-11 20:35:29.188
1083	PRODUCTO	Centro de carga tipo C	Android	VARIOS	15	50	1116	\N	system	system	2025-11-14 22:49:23.62	2025-11-14 22:49:23.618
1084	PRODUCTO	Pinzas de corte 	KAISI	HERRAMIENTA	0.01	54	1087	\N	system	system	2025-11-16 17:42:42.288	2025-11-16 17:42:42.286
1085	PRODUCTO	Tapete Louwei	Varios	Varios	0	260	1122	\N	system	system	2025-11-16 17:43:21.61	2025-11-16 17:43:21.608
\.
COPY public.presupuestos (id, ticket_id, total, descuento, total_final, aprobado, fecha_aprobacion, created_at, updated_at, iva_incluido, saldo, pagado) FROM stdin;
34	40	350	0	150	f	\N	2025-09-23 17:36:27.43	2025-09-25 17:04:13.334	t	150	f
18	24	100	0	0	t	\N	2025-09-08 19:52:55.284	2025-09-08 19:53:02.942	t	0	t
19	25	2289	0	0	t	\N	2025-09-09 23:20:37.945	2025-09-10 00:00:46.513	t	0	t
20	26	800	0	0	t	\N	2025-09-10 16:36:11.37	2025-09-10 16:36:23.235	t	0	t
51	57	200	0	0	t	\N	2025-09-30 21:02:00.102	2025-09-30 22:48:21.46	t	0	t
17	23	550	0	0	t	\N	2025-09-08 19:47:33.37	2025-09-10 18:41:57.311	t	0	t
21	27	50	0	0	t	\N	2025-09-11 18:24:25.507	2025-09-11 18:24:30.925	t	0	t
50	56	0	0	0	f	\N	2025-09-30 17:29:47.884	2025-09-30 22:52:45.715	t	0	f
37	43	400	0	0	t	\N	2025-09-25 23:01:47.329	2025-09-30 23:03:30.862	t	0	t
23	29	300	0	0	t	\N	2025-09-13 20:17:46.227	2025-09-13 20:19:07.487	t	0	t
22	28	250	0	150	f	\N	2025-09-11 23:42:40.051	2025-09-13 23:51:04.655	t	150	f
35	41	350	0	0	t	\N	2025-09-23 19:39:02.003	2025-09-26 20:16:04.357	t	0	t
40	46	199.97	0	199.97	f	\N	2025-09-26 22:18:26.973	2025-09-26 22:18:29.288	t	0	f
39	45	300	0	0	t	\N	2025-09-26 20:56:50.461	2025-09-26 22:45:14.246	t	0	t
24	30	325	0	325	f	\N	2025-09-13 23:49:13.301	2025-09-20 23:53:29.103	t	0	t
26	32	348	0	0	t	\N	2025-09-21 00:04:10.451	2025-09-21 00:04:24.383	t	0	t
27	33	100	0	0	t	\N	2025-09-21 00:06:43.428	2025-09-21 00:06:50.16	t	0	t
41	47	480	0	0	t	\N	2025-09-26 22:58:16.55	2025-09-26 23:07:28.662	t	0	t
29	35	200	0	0	t	\N	2025-09-21 20:58:01.934	2025-09-21 20:58:27.297	t	0	t
13	19	200	0	0	t	\N	2025-09-01 17:29:39.018	2025-09-01 17:50:21.935	t	0	t
14	20	50	0	0	t	\N	2025-09-01 19:00:06.854	2025-09-01 19:00:17.169	t	0	t
38	44	600	0	0	t	\N	2025-09-26 15:56:08.917	2025-09-26 23:51:01.3	t	0	t
15	21	300	0	300	f	\N	2025-09-01 21:16:24.396	2025-09-01 21:16:47.191	t	300	f
16	22	950	0	350	f	\N	2025-09-05 16:21:20.948	2025-09-06 22:36:19.93	t	350	f
31	37	60	0	0	t	\N	2025-09-22 23:41:14.5	2025-09-22 23:48:25.642	t	0	t
32	38	2000	0	0	t	\N	2025-09-23 16:34:48.393	2025-09-23 16:34:55.635	t	0	t
33	39	1000	0	0	t	\N	2025-09-23 16:40:47.298	2025-09-23 16:40:53.078	t	0	t
43	49	80	0	0	t	\N	2025-09-27 20:10:43.695	2025-09-27 20:10:49.482	t	0	t
25	31	556	0	0	t	\N	2025-09-17 19:53:53.339	2025-09-23 21:15:21.852	t	0	t
30	36	600	0	200	f	\N	2025-09-22 22:46:17.016	2025-09-23 22:05:30.978	t	200	f
28	34	1700	0	0	t	\N	2025-09-21 20:55:58.786	2025-09-23 22:12:43.107	t	0	t
36	42	600	0	0	t	\N	2025-09-23 22:16:07.163	2025-09-23 22:16:24.083	t	0	t
44	50	150	0	0	t	\N	2025-09-27 20:12:40.234	2025-09-27 20:12:45.176	t	0	t
45	51	250	0	0	t	\N	2025-09-27 20:16:30.285	2025-09-27 20:16:40.932	t	0	t
42	48	350	0	0	t	\N	2025-09-27 19:49:14.177	2025-09-27 23:40:07.775	t	0	t
47	53	200	0	0	t	\N	2025-09-28 19:34:53.505	2025-09-28 19:35:00.588	t	0	t
64	70	200	0	0	t	\N	2025-10-08 20:07:10.556	2025-10-08 22:24:53.336	t	0	t
56	61	0	0	0	f	\N	2025-10-02 19:33:29.064	2025-10-02 22:09:57.655	t	0	f
49	55	200	0	200	f	\N	2025-09-29 21:48:45.028	2025-09-29 21:48:53.832	t	200	f
58	64	675	0	675	f	\N	2025-10-04 14:25:58.17	2025-10-10 22:29:59.481	t	675	f
52	58	600	0	300	f	\N	2025-09-30 23:33:59.769	2025-10-01 23:20:36.42	t	300	f
53	59	600	0	500	f	\N	2025-10-01 17:50:33.114	2025-10-01 23:57:55.732	t	500	f
63	69	800	0	0	t	\N	2025-10-07 17:35:17.269	2025-10-07 17:35:55.961	t	0	t
55	62	800	0	600	f	\N	2025-10-02 19:25:29.565	2025-10-04 16:49:18.227	t	600	f
60	66	300	0	0	t	\N	2025-10-06 19:38:56.195	2025-10-08 20:09:01.992	t	0	t
59	65	500	0	500	f	\N	2025-10-05 18:59:32.206	2025-10-13 20:35:38.629	t	500	f
73	80	200	0	0	t	\N	2025-10-09 23:05:11.814	2025-10-09 23:05:18.384	t	0	t
61	67	200	0	0	t	\N	2025-10-06 21:17:07.461	2025-10-06 21:41:59.227	t	0	t
62	68	200	0	0	t	\N	2025-10-07 16:05:02.534	2025-10-07 16:05:11.297	t	0	t
74	81	700	0	0	t	\N	2025-10-10 17:43:13.136	2025-10-10 17:43:24.462	t	0	t
57	63	700	0	700	f	\N	2025-10-03 23:16:09.947	2025-10-08 20:25:41.252	t	200	f
75	79	600	0	0	t	\N	2025-10-10 22:20:45.725	2025-10-10 22:20:50.35	t	0	t
72	78	625	0	625	f	\N	2025-10-09 18:17:22.059	2025-10-10 16:45:02.213	t	625	f
48	54	400	0	0	t	\N	2025-09-28 21:06:46.043	2025-10-11 15:06:27.636	t	0	t
77	83	500	0	250	f	\N	2025-10-11 16:06:45.495	2025-10-11 23:23:56.114	t	250	f
78	84	500	0	0	t	\N	2025-10-11 19:12:05.28	2025-10-11 19:13:01.413	t	0	t
76	82	1500	0	0.01999999999998181	f	\N	2025-10-10 22:41:41.188	2025-10-13 20:32:45.422	t	0.01999999999998181	f
54	60	350	0	350	f	\N	2025-10-01 21:18:58.045	2025-11-10 22:00:48.765	t	350	f
79	86	600	0	300	f	\N	2025-10-13 18:04:16.211	2025-10-13 23:29:57.665	t	300	f
80	85	2000	0	500	f	\N	2025-10-13 20:31:27.813	2025-10-14 21:32:33.406	t	500	f
82	88	200	0	200	f	\N	2025-10-14 19:04:57.304	2025-10-14 19:06:54.519	t	200	f
46	52	200	0	0	t	\N	2025-09-28 18:58:03.788	2025-10-16 23:19:43.878	t	0	t
83	89	675	0	400	f	\N	2025-10-15 21:59:09.304	2025-10-16 21:12:39.594	t	400	f
85	91	800	0	0	t	\N	2025-10-16 21:17:34.543	2025-10-16 21:18:49.072	t	0	t
84	90	350	0	0	t	\N	2025-10-16 18:29:15.045	2025-10-16 21:22:51.161	t	0	t
81	87	1000	0	0	t	\N	2025-10-13 20:39:23.859	2025-10-17 20:59:44.507	t	0	t
86	92	2000	0	1000	f	\N	2025-10-17 17:58:15.451	2025-10-18 19:50:49.149	t	1000	f
87	93	1500	0	0	t	\N	2025-10-18 14:57:33.068	2025-10-18 19:52:39.15	t	0	t
88	94	350	0	0	t	\N	2025-10-19 19:49:25.294	2025-10-19 19:49:32.385	t	0	t
90	96	300	0	300	f	\N	2025-10-20 19:58:40.049	2025-10-20 19:58:40.047	t	0	f
91	97	200	0	0	t	\N	2025-10-22 17:06:26.711	2025-10-22 19:26:04.02	t	0	t
92	99	650	0	0	t	\N	2025-10-22 20:55:32.399	2025-10-23 15:35:40.194	t	0	t
89	95	700	0	300	f	\N	2025-10-20 16:07:47.435	2025-10-23 16:22:22.135	t	300	f
109	118	650	0	200	f	\N	2025-10-31 21:12:56.653	2025-11-09 19:00:18.312	t	200	f
94	102	200	0	0	t	\N	2025-10-23 18:13:52.831	2025-10-25 18:04:54.748	t	0	t
95	103	200	0	0	t	\N	2025-10-27 19:37:52.91	2025-10-27 19:58:52.408	t	0	t
96	104	1057	0	100	f	\N	2025-10-27 22:32:47.882	2025-10-27 22:36:55.309	t	100	f
113	122	200	0	0	t	\N	2025-11-01 20:55:08.94	2025-11-01 20:55:14.186	t	0	t
111	121	600	0	0	t	\N	2025-11-01 18:29:59.247	2025-11-01 23:18:30.507	t	0	t
112	120	600	0	0	t	\N	2025-11-01 18:30:18.838	2025-11-01 23:19:08.037	t	0	t
93	98	200	0	200	f	\N	2025-10-23 16:24:08.435	2025-11-02 21:20:36.345	t	0.03999999999999204	f
97	105	600	0	0	t	\N	2025-10-27 22:45:57.075	2025-10-27 22:47:09.743	t	0	t
114	123	200	0	0	t	\N	2025-11-02 22:00:31.131	2025-11-02 22:00:36.322	t	0	t
98	106	200	0	200	f	\N	2025-10-28 00:10:35.501	2025-10-28 00:31:04.554	t	200	f
99	107	200	0	0	t	\N	2025-10-28 00:21:27.883	2025-10-28 00:33:04.9	t	0	t
100	108	200	0	0	t	\N	2025-10-28 20:10:59.598	2025-10-28 20:11:22.849	t	0	t
115	112	550	0	550	f	\N	2025-11-03 16:23:18.201	2025-11-03 16:23:18.2	t	0	f
102	110	250	0	100	f	\N	2025-10-28 23:14:40.106	2025-10-29 23:19:42.03	t	100	f
104	113	150	0	0	t	\N	2025-10-29 22:58:51.795	2025-10-30 18:52:01.549	t	0	t
105	114	600	0	600	f	\N	2025-10-30 23:26:19.828	2025-11-17 16:30:10.992	t	600	f
129	139	200	0	0	t	\N	2025-11-10 21:14:26.281	2025-11-10 21:14:36.454	t	0	t
108	117	150	0	150	f	\N	2025-10-31 16:55:26.114	2025-10-31 16:55:26.113	t	0	f
116	124	600	0	250	f	\N	2025-11-03 19:02:14.744	2025-11-03 22:40:57.896	t	250	f
103	111	1100	0	200	f	\N	2025-10-28 23:41:08.592	2025-10-31 19:51:59.901	t	200	f
107	116	400	0	200	f	\N	2025-10-31 16:38:28.973	2025-10-31 20:54:58.981	t	200	f
106	115	600	0	600	f	\N	2025-10-31 14:55:53.481	2025-10-31 21:41:35.496	t	600	f
117	126	130	0	0	t	\N	2025-11-04 23:15:49.215	2025-11-04 23:17:57.948	t	0	t
110	119	200	0	0	t	\N	2025-11-01 17:50:05.916	2025-11-01 18:15:07.594	t	0	t
101	109	600	0	0	t	\N	2025-10-28 21:36:24.145	2025-11-01 18:16:12.256	t	0	t
118	127	200	0	0	t	\N	2025-11-05 16:27:47.177	2025-11-05 16:28:08.306	t	0	t
119	128	600	0	0	t	\N	2025-11-05 17:36:57.531	2025-11-05 23:27:25.353	t	0	t
122	131	350	0	0	t	\N	2025-11-06 17:53:17.415	2025-11-06 17:53:27.437	t	0	t
123	132	25	0	0	t	\N	2025-11-06 22:22:25.134	2025-11-06 22:22:31.462	t	0	t
120	129	350	0	0	t	\N	2025-11-05 23:16:57.149	2025-11-07 22:29:53.99	t	0	t
132	141	3000	0	0	t	\N	2025-11-12 00:09:04.013	2025-11-12 00:09:14.021	t	0	t
124	133	2200	0	800	f	\N	2025-11-06 23:55:21.094	2025-11-08 21:53:12.425	t	800	f
131	142	50	0	50	f	\N	2025-11-11 22:16:46.987	2025-11-13 18:11:23.837	t	50	f
139	150	50	0	0	t	\N	2025-11-12 23:57:49.575	2025-11-13 18:13:18.825	t	0	t
136	147	350	0	0	t	\N	2025-11-12 22:38:32.099	2025-11-12 22:47:16.229	t	0	t
128	138	200	0	200	f	\N	2025-11-09 22:13:27.156	2025-11-09 22:17:11.973	t	200	f
127	137	200	0	0	t	\N	2025-11-09 21:35:28.44	2025-11-09 22:19:02.418	t	0	t
125	134	150	0	0	t	\N	2025-11-07 16:01:01.563	2025-11-10 20:42:00.526	t	0	t
135	146	200	0	200	f	\N	2025-11-12 18:37:19.157	2025-11-12 18:37:24.826	t	200	f
145	154	200	0	200	f	\N	2025-11-15 18:48:57.706	2025-11-15 18:49:15.041	t	200	f
130	140	350	0	200	f	\N	2025-11-10 22:02:23.489	2025-11-13 15:54:18.67	t	200	f
134	145	1050	0	300	f	\N	2025-11-12 18:01:40.907	2025-11-12 23:24:11.16	t	300	f
137	148	400	0	0	t	\N	2025-11-12 23:05:11.174	2025-11-12 23:28:48.36	t	0	t
138	149	600	0	400	f	\N	2025-11-12 23:38:12.313	2025-11-12 23:38:38.921	t	400	f
133	143	900	0	500	f	\N	2025-11-12 17:29:16.508	2025-11-14 18:59:08.164	t	500	f
148	157	600	0	250	f	\N	2025-11-17 20:45:27.278	2025-11-24 23:56:13.024	t	250	f
142	135	0	0	0	f	\N	2025-11-13 22:04:01.794	2025-11-17 18:10:21.193	t	0	t
143	153	600	0	0	t	\N	2025-11-14 15:27:45.276	2025-11-14 15:28:57.105	t	0	t
150	159	2500	0	1500	f	\N	2025-11-18 20:31:58.732	2025-11-18 21:49:50.985	t	1500	f
121	130	200	0	-200	t	\N	2025-11-06 17:00:01.946	2025-11-14 22:04:49.019	t	0	t
140	151	600	0	200	f	\N	2025-11-13 00:18:01.454	2025-11-14 22:50:43.159	t	200	f
146	155	150	0	0	t	\N	2025-11-15 18:57:59.68	2025-11-15 18:58:46.415	t	0	t
147	156	7300	0	4380	f	\N	2025-11-15 19:11:18.396	2025-11-15 19:13:52.841	t	4380	f
126	136	800	0	200	f	\N	2025-11-08 20:26:59.371	2025-11-15 23:44:25.503	t	200	f
149	158	600	0	400	f	\N	2025-11-18 20:23:28.206	2025-11-18 20:23:33.029	t	400	f
144	152	500	0	200	f	\N	2025-11-14 15:59:35.829	2025-11-18 21:39:08.902	t	200	f
141	125	750	0	0	t	\N	2025-11-13 17:15:09.12	2025-11-22 22:34:00.755	t	0	t
151	160	150	0	0	t	\N	2025-11-19 17:31:17.249	2025-11-19 18:36:55.425	t	0	t
152	161	700	0	200	f	\N	2025-11-19 17:33:10.366	2025-11-20 19:21:52.384	t	200	f
153	162	200	0	0	t	\N	2025-11-19 20:17:52.287	2025-11-19 20:19:37.321	t	0	t
154	144	2000	0	2000	f	\N	2025-11-20 19:55:38.897	2025-11-20 19:55:38.896	t	0	f
156	165	150	0	0	t	\N	2025-11-21 18:29:00.479	2025-11-21 18:29:08.184	t	0	t
157	164	200	0	0	t	\N	2025-11-21 18:29:27.379	2025-11-21 18:29:34.976	t	0	t
155	163	350	0	0	t	\N	2025-11-20 21:45:06.86	2025-11-21 18:34:19.705	t	0	t
158	166	1000	0	1000	f	\N	2025-11-21 21:19:03.989	2025-11-21 21:19:03.988	t	0	f
161	169	200	0	0	t	\N	2025-11-22 19:52:30.206	2025-11-22 19:52:34.962	t	0	t
159	167	550	0	300	f	\N	2025-11-22 19:00:35.144	2025-11-22 23:32:54.346	t	300	f
160	168	550	0	300	f	\N	2025-11-22 19:08:17.865	2025-11-22 23:41:46.857	t	300	f
162	170	188	0	0	t	\N	2025-11-23 19:21:06.599	2025-11-23 19:21:15.343	t	0	t
163	173	450	0	300	f	\N	2025-11-23 21:31:35.348	2025-11-23 21:32:41.043	t	300	f
165	172	600	0	600	f	\N	2025-11-24 16:47:52.56	2025-11-24 16:47:52.559	t	0	f
166	176	89	0	0	t	\N	2025-11-24 18:25:17.886	2025-11-24 18:25:24.153	t	0	t
164	174	650	0	600	f	\N	2025-11-24 15:53:33.716	2025-11-24 23:00:54.389	t	600	f
167	177	250	0	50	f	\N	2025-11-24 23:37:52.706	2025-11-24 23:38:06.656	t	50	f
\.
COPY public.presupuestos_independientes (id, nombre, descripcion, cliente_nombre, usuario_id, total, created_at, updated_at) FROM stdin;
11	HERRAMIENTA	Venta de herramienta	Publico General	24	139	2025-11-23 19:01:29.511	2025-11-23 19:01:29.511
\.
COPY public.problemas_frecuentes (id, nombre, descripcion, created_at, updated_at) FROM stdin;
\.
COPY public.productos (id, sku, nombre, descripcion, notas_internas, garantia_valor, garantia_unidad, categoria_id, marca_id, modelo_id, proveedor_id, precio_promedio, stock, tipo_servicio_id, stock_maximo, stock_minimo, tipo, created_at, updated_at) FROM stdin;
15	servicioaltavoz	servicio altavoz 	\N	\N	\N	\N	1	\N	\N	\N	0	0	1	0	0	SERVICIO	2025-08-20 15:37:51.087	2025-08-27 12:27:54.294
6	0002	Batería iPhone 16 Pro	\N	\N	\N	\N	1	37	136	\N	0	10	1	0	5	PRODUCTO	2025-06-17 21:35:20.915	2025-11-08 21:53:18.628
19	altavozandroid	Altavoz Android	\N	\N	\N	\N	1	47	141	\N	0	0	1	0	0	PRODUCTO	2025-08-20 15:52:54.698	2025-08-27 12:27:54.31
26	000000000000001	Flex iPhone 12	\N	\N	\N	\N	1	37	139	\N	0	0	1	0	0	PRODUCTO	2025-08-26 16:25:41.906	2025-08-27 12:27:54.314
29	LPN385400A	Batería Hisense H40 LITE	Batería compatible con: H40 LITE, E40, V40	\N	\N	\N	\N	49	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:33:40.978	2025-08-27 12:27:54.32
30	HB476586ECW	Batería Honor HONOR 10X	Batería compatible con: HONOR 10X	\N	\N	\N	\N	57	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:38:06.318	2025-08-27 12:27:54.329
32	HB2899C0ECW	Batería Honor MediaPad T5	Batería compatible con: MediaPad T5	\N	\N	\N	\N	57	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:38:06.343	2025-08-27 12:27:54.343
33	HB28D8C8ECW-12	Batería Honor MatePad Pro	Batería compatible con: MatePad Pro, HUAWEI MatePad Pro 5G	\N	\N	\N	\N	57	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:38:06.361	2025-08-27 12:27:54.351
34	HB386280ECW	Batería Honor P10	Batería compatible con: P10	\N	\N	\N	\N	57	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:38:06.369	2025-08-27 12:27:54.36
35	HB486486EEW	Batería Honor MATE20 PRO	Batería compatible con: MATE20 PRO, P30 PRO	\N	\N	\N	\N	57	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:38:06.377	2025-08-27 12:27:54.373
36	HB396689ECW	Batería Honor MATE 9	Batería compatible con: MATE 9	\N	\N	\N	\N	57	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:38:06.385	2025-08-27 12:27:54.382
37	HB486586ECW	Batería Honor P40 LITE 4G	Batería compatible con: P40 LITE 4G, NOVA6 SE	\N	\N	\N	\N	57	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:38:06.392	2025-08-27 12:27:54.392
38	HB356687ECW	Batería Honor P30 LITE	Batería compatible con: P30 LITE, NOVA4E, MATE10 LITE	\N	\N	\N	\N	57	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:38:06.402	2025-08-27 12:27:54.401
39	HB436380ECW	Batería Honor P30	Batería compatible con: P30	\N	\N	\N	\N	57	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:38:06.412	2025-08-27 12:27:54.415
40	HB436486ECW	Batería Honor P20 PRO	Batería compatible con: P20 PRO, MATE 10, MATE10 PRO, MATE20	\N	\N	\N	\N	57	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:38:06.42	2025-08-27 12:27:54.419
41	HB486686ECW	Batería Honor Y9A	Batería compatible con: Y9A	\N	\N	\N	\N	57	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:38:06.43	2025-08-27 12:27:54.424
42	HB446486ECW	Batería Honor Y9S	Batería compatible con: Y9S, HONOR 9X, HONOR 9X LITE, Y9 prime 2019	\N	\N	\N	\N	57	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:38:06.436	2025-08-27 12:27:54.43
43	HB426389EEW	Batería Honor HN-HONOR20 LITE	Batería compatible con: HN-HONOR20 LITE	\N	\N	\N	\N	57	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:38:06.443	2025-08-27 12:27:54.437
44	HB426489EEW	Batería Honor Y8P	Batería compatible con: Y8P, Y9P	\N	\N	\N	\N	57	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:38:06.451	2025-08-27 12:27:54.444
45	HB406689ECW	Batería Honor Y7Prime	Batería compatible con: Y7Prime, P40 LITE E, Y7 2019, Y9 2019, Y8S	\N	\N	\N	\N	57	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:38:06.46	2025-08-27 12:27:54.452
46	HB526488EEW	Batería Honor Y7A	Batería compatible con: Y7A, P SMART 2021, HONOR 10X LITE	\N	\N	\N	\N	57	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:38:06.469	2025-08-27 12:27:54.456
47	HB405979ECW	Batería Honor Y6 2019	Batería compatible con: Y6 2019, Y6S, HONOR 8A, Y6 2019, Y5 2018, Y5 2019	\N	\N	\N	\N	57	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:38:06.475	2025-08-27 12:27:54.46
48	HB366481ECW	Batería Honor Y6 2018	Batería compatible con: Y6 2018, Y7 2018, P SMART 2018, P20 LITE, ANE LX3	\N	\N	\N	\N	57	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:38:06.482	2025-08-27 12:27:54.465
49	HB536896EFW	Batería Honor NOVA Y70	Batería compatible con: NOVA Y70	\N	\N	\N	\N	57	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:38:06.494	2025-08-27 12:27:54.47
50	HB526489EEW	Batería Honor NOVA Y60	Batería compatible con: NOVA Y60, Y6P, HONOR9A, HONOR9S PRIME	\N	\N	\N	\N	57	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:38:06.504	2025-08-27 12:27:54.477
51	HB396286ECW	Batería Honor HONOR 10 LITE	Batería compatible con: HONOR 10 LITE, P SMART 2019	\N	\N	\N	\N	57	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:38:06.512	2025-08-27 12:27:54.484
52	HB396285ECW	Batería Honor HONOR 10	Batería compatible con: HONOR 10	\N	\N	\N	\N	57	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:38:06.519	2025-08-27 12:27:54.491
53	HB416492EFW	Batería Honor HONOR X8	Batería compatible con: HONOR X8	\N	\N	\N	\N	57	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:38:06.528	2025-08-27 12:27:54.496
54	HB5066A1EGW	Batería Honor HONOR X7A	Batería compatible con: HONOR X7A	\N	\N	\N	\N	57	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:38:06.536	2025-08-27 12:27:54.501
55	HB496590EFW-F	Batería Honor HONOR X6	Batería compatible con: HONOR X6, HONOR X7	\N	\N	\N	\N	57	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:38:06.542	2025-08-27 12:27:54.505
56	HB386589ECW	Batería Honor HONOR 8X	Batería compatible con: HONOR 8X, NOVA3, NOVA 5T, HONOR 20, MATE20 LITE	\N	\N	\N	\N	57	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:38:06.549	2025-08-27 12:27:54.514
57	24022756	Batería Huawei HUAWEI P20 / Honor 10	Batería compatible con: HUAWEI P20, Honor 10	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:43:16.291	2025-08-27 12:27:54.521
7	0003	Diagnóstico	\N	\N	\N	\N	1	\N	\N	\N	0	0	1	0	0	SERVICIO	2025-06-17 21:35:33.135	2025-08-27 12:27:54.53
8	0004	Mano de Obra	\N	\N	\N	\N	1	\N	\N	\N	0	0	1	0	0	SERVICIO	2025-06-17 21:35:44.652	2025-08-27 12:27:54.535
9	no hay	servicio a teléfonos mojados 	\N	\N	\N	\N	1	\N	\N	\N	0	0	1	0	0	SERVICIO	2025-08-08 16:22:01.572	2025-08-27 12:27:54.539
12	servcentrcarg	servicio a centro de carga 	\N	\N	\N	\N	1	\N	\N	\N	0	0	1	0	0	SERVICIO	2025-08-18 20:10:44.2	2025-08-27 12:27:54.548
13	diagnostico	diagnostico	\N	\N	\N	\N	1	\N	\N	\N	0	0	1	0	0	SERVICIO	2025-08-18 22:24:17.987	2025-08-27 12:27:54.562
11	234567	bateria oppo a15	\N	\N	\N	\N	1	46	140	\N	0	8	1	0	0	PRODUCTO	2025-08-08 16:25:49.074	2025-08-27 12:27:54.567
16	serviciodeauricular	servicio de auricular	\N	\N	\N	\N	1	\N	\N	\N	0	0	1	0	0	SERVICIO	2025-08-20 15:40:12.188	2025-08-27 12:27:54.575
17	audio3.5	servicio Jack de audio 3.5 	\N	\N	\N	\N	1	\N	\N	\N	0	0	1	0	0	SERVICIO	2025-08-20 15:41:45.601	2025-08-27 12:27:54.58
18	servibotones	servicio a botones	\N	\N	\N	\N	1	\N	\N	\N	0	0	1	0	0	SERVICIO	2025-08-20 15:42:48.265	2025-08-27 12:27:54.585
20	microfonoandroid	micrófono Android	\N	\N	\N	\N	1	47	141	\N	0	0	1	0	0	PRODUCTO	2025-08-20 15:54:27.118	2025-08-27 12:27:54.596
21	botonesandroid	botones Android	\N	\N	\N	\N	1	47	141	\N	0	0	1	0	0	PRODUCTO	2025-08-20 16:39:02.953	2025-08-27 12:27:54.605
14	AuricularAndroid	Auricular Android 	\N	\N	\N	\N	1	47	141	\N	200	0	1	0	0	PRODUCTO	2025-08-19 15:41:52.515	2025-10-11 23:19:34.958
24	bateriaandroid	batería Android	\N	\N	\N	\N	1	47	141	\N	0	0	1	0	0	PRODUCTO	2025-08-20 16:43:31.662	2025-08-27 12:27:54.621
25	flexorinterconexion	flexor de interconexión Android	\N	\N	\N	\N	1	47	141	\N	0	0	1	0	0	PRODUCTO	2025-08-20 16:46:38.689	2025-08-27 12:27:54.628
28	LPN440450	Batería Hisense E50 LITE	Batería compatible con: E50 LITE	\N	\N	\N	\N	49	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:33:40.963	2025-08-27 12:27:54.641
5	0001	Pantalla iPhone 16 Pro	\N	\N	\N	\N	1	37	136	\N	0	1	1	0	6	PRODUCTO	2025-06-17 21:35:04.214	2025-08-29 18:41:11.42
62	24023562	Batería Huawei HUAWEI WATCH D / HUAWEI WATCH GT Runner	Batería compatible con: HUAWEI WATCH D, HUAWEI WATCH GT Runner	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:43:16.424	2025-08-27 12:27:54.653
63	24022368	Batería Huawei HUAWEI P20 lite / HUAWEI nova 3e / 	Batería compatible con: HUAWEI P20 lite, HUAWEI nova 3e, 	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:43:16.448	2025-08-27 12:27:54.657
64	24022872	Batería Huawei HUAWEI P30 lite / HONOR 20S / HONOR 20 Lite	Batería compatible con: HUAWEI P30 lite, HONOR 20S, HONOR 20 Lite	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:43:16.465	2025-08-27 12:27:54.662
65	24022698(HB356687ECW)	Batería Huawei HUAWEI-P30 lite / HUAWEI nova 2 Plus / HUAWEI P10 Selfie / HUAWEI nova 3i / HUAWEI P smart+ / HUAW	Batería compatible con: HUAWEI-P30 lite, HUAWEI nova 2 Plus, HUAWEI P10 Selfie, HUAWEI nova 3i, HUAWEI P smart+, HUAW	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:43:16.481	2025-08-27 12:27:54.668
66	24023342	Batería Huawei HUAWEI P smart 2021 / HUAWEI Y7a / HONOR 10X Lite	Batería compatible con: HUAWEI P smart 2021, HUAWEI Y7a, HONOR 10X Lite	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:43:16.499	2025-08-27 12:27:54.675
67	24023020	Batería Huawei HUAWEI MatePad Pro / HUAWEI MatePad Pro 5G	Batería compatible con: HUAWEI MatePad Pro, HUAWEI MatePad Pro 5G	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:43:16.517	2025-08-27 12:27:54.681
68	24022688	Batería Huawei HUAWEI MediaPad M5 Pro / HUAWEI MediaPad M5 / HUAWEI MediaPad M5 lite / HUAWEI MediaPad M6	Batería compatible con: HUAWEI MediaPad M5 Pro, HUAWEI MediaPad M5, HUAWEI MediaPad M5 lite, HUAWEI MediaPad M6	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:43:16.532	2025-08-27 12:27:54.688
69	24022610	Batería Huawei HUAWEI Y5 2018 / Honor 7A / HUAWEI Y5p / HONOR 9S	Batería compatible con: HUAWEI Y5 2018, Honor 7A, HUAWEI Y5p, HONOR 9S	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:43:16.541	2025-08-27 12:27:54.693
70	24023514	Batería Huawei HUAWEI WATCH GT 2 / HUAWEI WATCH GT 2e / HUAWEI WATCH GT 2 Pro / HUAWEI WATCH GT 3	Batería compatible con: HUAWEI WATCH GT 2, HUAWEI WATCH GT 2e, HUAWEI WATCH GT 2 Pro, HUAWEI WATCH GT 3	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:43:16.552	2025-08-27 12:27:54.701
71	24022376	Batería Huawei HUAWEI Y7s / HUAWEI Y7 Prime 2018 / HUAWEI nova 2 lite / Honor 7C / Honor 7C Pro / HUAWEI Y7 2018	Batería compatible con: HUAWEI Y7s, HUAWEI Y7 Prime 2018, HUAWEI nova 2 lite, Honor 7C, Honor 7C Pro, HUAWEI Y7 2018	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:43:16.569	2025-08-27 12:27:54.71
72	24022182	Batería Huawei HUAWEI P10	Batería compatible con: HUAWEI P10	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:43:16.582	2025-08-27 12:27:54.718
73	24022215	Batería Huawei HUAWEI P9 lite 2017 / Honor 6C Pro	Batería compatible con: HUAWEI P9 lite 2017, Honor 6C Pro	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:43:16.596	2025-08-27 12:27:54.723
74	02354HFN	Batería Huawei HUAWEI P50 Pro	Batería compatible con: HUAWEI P50 Pro	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:43:16.614	2025-08-27 12:27:54.729
75	02355AVL	Batería Huawei HUAWEI nova Y90	Batería compatible con: HUAWEI nova Y90	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:43:16.626	2025-08-27 12:27:54.736
76	02354MQA	Batería Huawei HUAWEI P50 / P50E	Batería compatible con: HUAWEI P50, P50E	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:43:16.639	2025-08-27 12:27:54.741
77	24022946	Batería Huawei HUAWEI P30 Pro / MATE20 PRO	Batería compatible con: HUAWEI P30 Pro, MATE20 PRO	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:43:16.652	2025-08-27 12:27:54.745
78	24023690	Batería Huawei HUAWEI nova Y70 / HUAWEI nova Y70 Plus	Batería compatible con: HUAWEI nova Y70, HUAWEI nova Y70 Plus	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:43:16.666	2025-08-27 12:27:54.752
79	24022804	Batería Huawei HUAWEI P30	Batería compatible con: HUAWEI P30	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:43:16.696	2025-08-27 12:27:54.76
80	02354NUU	Batería Huawei HUAWEI nova 9	Batería compatible con: HUAWEI nova 9	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:43:16.722	2025-08-27 12:27:54.767
81	24023024(HB406689ECW)	Batería Huawei HUAWEI-Y9 2019 / Y8s / P40 lite E / Y7P	Batería compatible con: HUAWEI-Y9 2019, Y8s, P40 lite E, Y7P	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:43:16.737	2025-08-27 12:27:54.771
82	24022732(HB386589ECW)	Batería Huawei HUAWEI-NOVA 5T / Mate20 lite / P10 Plus / NOVA3 / NOVA4 / HONOR 20	Batería compatible con: HUAWEI-NOVA 5T, Mate20 lite, P10 Plus, NOVA3, NOVA4, HONOR 20	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:43:16.748	2025-08-27 12:27:54.777
83	24023533	Batería Huawei HUAWEI nova 8i / HUAWEI P50 lite	Batería compatible con: HUAWEI nova 8i, HUAWEI P50 lite	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:43:16.756	2025-08-27 12:27:54.781
84	24022981(HB406689ECW)	Batería Huawei HUAWEI-Y7 2019 / Y9 2018 / Y9 2019 / Y7 Prime / Y8s	Batería compatible con: HUAWEI-Y7 2019, Y9 2018, Y9 2019, Y7 Prime, Y8s	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:43:16.774	2025-08-27 12:27:54.793
85	24022342	Batería Huawei HUAWEI Mate 10 Pro / HUAWEI Mate 10	Batería compatible con: HUAWEI Mate 10 Pro, HUAWEI Mate 10	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:43:16.783	2025-08-27 12:27:54.799
86	02353XXA	Batería Huawei HUAWEI Mate 40 Pro / HUAWEI Mate 40 Pro+ / HUAWEI Mate 40E Pro	Batería compatible con: HUAWEI Mate 40 Pro, HUAWEI Mate 40 Pro+, HUAWEI Mate 40E Pro	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:43:16.792	2025-08-27 12:27:54.809
87	24022157	Batería Huawei HUAWEI nova 3e / HUAWEI P20 lite	Batería compatible con: HUAWEI nova 3e, HUAWEI P20 lite	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:43:16.799	2025-08-27 12:27:54.818
88	24022102	Batería Huawei HUAWEI Mate 9	Batería compatible con: HUAWEI Mate 9	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:43:16.812	2025-08-27 12:27:54.824
89	24022844	Batería Huawei HUAWEI MediaPad M5 / HUAWEI MediaPad M5 Pro / HUAWEI MediaPad M5 lite / HUAWEI MediaPad M6 / HUAWEI Ma	Batería compatible con: HUAWEI MediaPad M5, HUAWEI MediaPad M5 Pro, HUAWEI MediaPad M5 lite, HUAWEI MediaPad M6, HUAWEI Ma	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:43:16.826	2025-08-27 12:27:54.831
90	02354KEL	Batería Huawei HUAWEI nova 8	Batería compatible con: HUAWEI nova 8	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:43:16.837	2025-08-27 12:27:54.842
91	02353MET	Batería Huawei HUAWEI P40 Pro	Batería compatible con: HUAWEI P40 Pro	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:43:16.844	2025-08-27 12:27:54.846
92	02354UVQ	Batería Huawei HUAWEI nova 9 SE	Batería compatible con: HUAWEI nova 9 SE	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:43:16.85	2025-08-27 12:27:54.852
140	JE30	Batería Motorola E5 PLAY GO	Batería compatible con: E5 PLAY GO	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:46:42.235	2025-08-27 12:27:54.858
60	24023214	Batería Huawei HUAWEI P smart S / HUAWEI Y8p / HONOR 30i	Batería compatible con: HUAWEI P smart S, HUAWEI Y8p, HONOR 30i	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:43:16.378	2025-08-27 12:27:54.864
61	24022744	Batería Huawei HUAWEI MatePad SE / HUAWEI MediaPad T5 / HUAWEI MatePad C5e / HUAWEI MatePad C3	Batería compatible con: HUAWEI MatePad SE, HUAWEI MediaPad T5, HUAWEI MatePad C5e, HUAWEI MatePad C3	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:43:16.406	2025-08-27 12:27:54.648
96	24023085	Batería Huawei HUAWEI Y6p / HUAWEI nova Y60 / 	Batería compatible con: HUAWEI Y6p, HUAWEI nova Y60, 	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:43:16.882	2025-08-27 12:27:54.887
97	24023184	Batería Huawei HONOR 10X / HUAWEI Y9a	Batería compatible con: HONOR 10X, HUAWEI Y9a	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:43:16.898	2025-08-27 12:27:54.896
98	PC50	Batería Motorola G54	Batería compatible con: G54	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:46:41.674	2025-08-27 12:27:54.9
99	QF50	Batería Motorola G04 / G34	Batería compatible con: G04, G34	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:46:41.693	2025-08-27 12:27:54.908
100	NP44	Batería Motorola EDGE 40 / EDGE 2023	Batería compatible con: EDGE 40, EDGE 2023	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:46:41.7	2025-08-27 12:27:54.916
101	NA50	Batería Motorola EDGE30 PRO	Batería compatible con: EDGE30 PRO	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:46:41.708	2025-08-27 12:27:54.923
102	MT45	Batería Motorola EDGE20 PRO	Batería compatible con: EDGE20 PRO	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:46:41.724	2025-08-27 12:27:54.929
103	MB40	Batería Motorola EDGE 20	Batería compatible con: EDGE 20	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:46:41.736	2025-08-27 12:27:54.933
104	NT50	Batería Motorola EDGE 20 LITE	Batería compatible con: EDGE 20 LITE	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:46:41.75	2025-08-27 12:27:54.939
105	NF50	Batería Motorola EDGE	Batería compatible con: EDGE	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:46:41.767	2025-08-27 12:27:54.945
106	JS40	Batería Motorola Z3 PLAY	Batería compatible con: Z3 PLAY	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:46:41.785	2025-08-27 12:27:54.952
107	HZ40	Batería Motorola Z2 PLAY	Batería compatible con: Z2 PLAY	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:46:41.806	2025-08-27 12:27:54.959
108	GL40	Batería Motorola Z PLAY	Batería compatible con: Z PLAY	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:46:41.82	2025-08-27 12:27:54.965
109	HX40	Batería Motorola X4	Batería compatible con: X4	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:46:41.838	2025-08-27 12:27:54.97
110	KP50	Batería Motorola ONE ZOOM / XT2010	Batería compatible con: ONE ZOOM, XT2010	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:46:41.854	2025-08-27 12:27:54.974
111	KG50	Batería Motorola ONE HYPER / XT2027	Batería compatible con: ONE HYPER, XT2027	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:46:41.867	2025-08-27 12:27:54.981
112	LG50	Batería Motorola ONE FUSION / ONE FUSION PLUS	Batería compatible con: ONE FUSION, ONE FUSION PLUS	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:46:41.883	2025-08-27 12:27:54.988
113	MB50	Batería Motorola G200 5G	Batería compatible con: G200 5G	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:46:41.904	2025-08-27 12:27:54.994
114	LZ50	Batería Motorola G100 / EDGE S / ONE	Batería compatible con: G100, EDGE S, ONE	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:46:41.921	2025-08-27 12:27:55
115	LK50	Batería Motorola G60S	Batería compatible con: G60S	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:46:41.944	2025-08-27 12:27:55.005
116	ND40	Batería Motorola EDGE30	Batería compatible con: EDGE30	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:46:41.958	2025-08-27 12:27:55.009
117	NE50	Batería Motorola G52 / G82 / G72	Batería compatible con: G52, G82, G72	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:46:41.979	2025-08-27 12:27:55.015
118	MS50	Batería Motorola G50 5G	Batería compatible con: G50 5G	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:46:41.99	2025-08-27 12:27:55.019
119	NG50	Batería Motorola G71 / G71S / G62	Batería compatible con: G71, G71S, G62	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:46:42.004	2025-08-27 12:27:55.023
120	NC50	Batería Motorola G32 / G41	Batería compatible con: G32, G41	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:46:42.012	2025-08-27 12:27:55.031
121	ND50	Batería Motorola G31 / G42	Batería compatible con: G31, G42	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:46:42.027	2025-08-27 12:27:55.036
122	MG50	Batería Motorola G9 PLUS	Batería compatible con: G9 PLUS	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:46:42.035	2025-08-27 12:27:55.043
123	KZ50	Batería Motorola G8 POWER	Batería compatible con: G8 POWER	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:46:42.042	2025-08-27 12:27:55.047
124	KD40	Batería Motorola G8 PLUS	Batería compatible con: G8 PLUS	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:46:42.051	2025-08-27 12:27:55.051
126	JG40	Batería Motorola G7 PLUS	Batería compatible con: G7 PLUS	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:46:42.082	2025-08-27 12:27:55.057
127	JE40	Batería Motorola G7 PLAY / G7	Batería compatible con: G7 PLAY, G7	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:46:42.092	2025-08-27 12:27:55.062
128	JT40	Batería Motorola G6 PLUS	Batería compatible con: G6 PLUS	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:46:42.103	2025-08-27 12:27:55.068
129	BL270	Batería Motorola G6 PLAY / E5	Batería compatible con: G6 PLAY, E5	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:46:42.115	2025-08-27 12:27:55.075
130	HG30	Batería Motorola G6	Batería compatible con: G6	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:46:42.122	2025-08-27 12:27:55.08
131	MD50	Batería Motorola G STYLUS 2022	Batería compatible con: G STYLUS 2022	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:46:42.132	2025-08-27 12:27:55.086
132	NT40	Batería Motorola E20 / XT2155	Batería compatible con: E20, XT2155	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:46:42.146	2025-08-27 12:27:55.093
133	NH50	Batería Motorola G53 / XT2335-3 / G22 / XT2231-2 / E13 / E22i / E22S / E32 / E32S	Batería compatible con: G53, XT2335-3, G22, XT2231-2, E13, E22i, E22S, E32, E32S	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:46:42.156	2025-08-27 12:27:55.096
134	KG40	Batería Motorola G8 PLAY / ONE MACRO	Batería compatible con: G8 PLAY, ONE MACRO	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:46:42.164	2025-08-27 12:27:55.1
136	MC50	Batería Motorola G9 / G9POWER / G40FUSION / G60	Batería compatible con: G9, G9POWER, G40FUSION, G60	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:46:42.188	2025-08-27 12:27:55.107
137	KS40	Batería Motorola E6 PLAY / E6I	Batería compatible con: E6 PLAY, E6I	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:46:42.2	2025-08-27 12:27:55.113
138	KC40	Batería Motorola E6S / E6 PLUS	Batería compatible con: E6S, E6 PLUS	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:46:42.208	2025-08-27 12:27:55.119
139	HE50	Batería Motorola E5 PLUS	Batería compatible con: E5 PLUS	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:46:42.223	2025-08-27 12:27:55.123
141	BLP819	Batería Oppo RENO5	Batería compatible con: RENO5	\N	\N	\N	\N	46	\N	\N	180	0	\N	10	1	PRODUCTO	2025-08-26 21:51:42.075	2025-10-28 22:10:02.496
94	24022209	Batería Huawei HUAWEI P10 Plus	Batería compatible con: HUAWEI P10 Plus	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:43:16.867	2025-08-27 12:27:55.136
95	24023099	Batería Huawei HUAWEI nova 6 SE / P40 LITE	Batería compatible con: HUAWEI nova 6 SE, P40 LITE	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:43:16.875	2025-08-27 12:27:54.876
146	BLP907	Batería Oppo RENO7 4G	Batería compatible con: RENO7 4G	\N	\N	\N	\N	46	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:51:42.137	2025-08-27 12:27:55.147
147	BLP729	Batería Oppo C21 / C11	Batería compatible con: C21, C11	\N	\N	\N	\N	46	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:51:42.146	2025-08-27 12:27:55.153
148	BLP781	Batería Oppo A52 / A72 / A92	Batería compatible con: A52, A72, A92	\N	\N	\N	\N	46	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:51:42.154	2025-08-27 12:27:55.158
150	BLP673	Batería Oppo A12 / A15	Batería compatible con: A12, A15	\N	\N	\N	\N	46	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:51:42.178	2025-08-27 12:27:55.163
151	BLP835	Batería Oppo RENO5 LITE	Batería compatible con: RENO5 LITE	\N	\N	\N	\N	46	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:51:42.19	2025-08-27 12:27:55.167
152	BLP817	Batería Oppo A15 / A15S / A35 / A54	Batería compatible con: A15, A15S, A35, A54	\N	\N	\N	\N	46	\N	\N	200	0	\N	10	1	PRODUCTO	2025-08-26 21:51:42.203	2025-10-31 22:21:14.685
153	EB-BS906ABY	Batería Samsung S22 PLUS	Batería compatible con: S22 PLUS	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:56:45.095	2025-08-27 12:27:55.176
154	EB-BS908ABY	Batería Samsung S22 ULTRA	Batería compatible con: S22 ULTRA	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:56:45.105	2025-08-27 12:27:55.181
155	EB-BS901ABY	Batería Samsung S22	Batería compatible con: S22	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:56:45.113	2025-08-27 12:27:55.185
156	EB-BG996ABY	Batería Samsung S21 PLUS	Batería compatible con: S21 PLUS	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:56:45.121	2025-08-27 12:27:55.19
157	EB-BG998ABY	Batería Samsung S21 ULTRA	Batería compatible con: S21 ULTRA	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:56:45.131	2025-08-27 12:27:55.2
158	EB-BG985ABY	Batería Samsung S20 PLUS	Batería compatible con: S20 PLUS	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:56:45.141	2025-08-27 12:27:55.208
159	EB-BG988ABY	Batería Samsung S20 ULTRA	Batería compatible con: S20 ULTRA	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:56:45.153	2025-08-27 12:27:55.215
160	EB-BG965ABE	Batería Samsung S9 PLUS	Batería compatible con: S9 PLUS	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:56:45.162	2025-08-27 12:27:55.225
161	EB-BG960ABE	Batería Samsung S9	Batería compatible con: S9	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:56:45.175	2025-08-27 12:27:55.235
162	EB-BG955ABA	Batería Samsung S8PLUS	Batería compatible con: S8PLUS	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:56:45.186	2025-08-27 12:27:55.244
163	EB-BG950ABE	Batería Samsung S8	Batería compatible con: S8	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:56:45.195	2025-08-27 12:27:55.248
164	EB-BN985ABY	Batería Samsung NOTE20 ULTRA	Batería compatible con: NOTE20 ULTRA	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:56:45.205	2025-08-27 12:27:55.254
165	EB-BN980ABY	Batería Samsung NOTE20	Batería compatible con: NOTE20	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:56:45.211	2025-08-27 12:27:55.261
166	EB-BN972ABU	Batería Samsung NOTE10 PLUS	Batería compatible con: NOTE10 PLUS	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:56:45.223	2025-08-27 12:27:55.268
167	EB-BN770ABY	Batería Samsung NOTE10 LITE	Batería compatible con: NOTE10 LITE	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:56:45.231	2025-08-27 12:27:55.279
168	EB-BJ730ABE	Batería Samsung J730 / J7PRO	Batería compatible con: J730, J7PRO	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:56:45.239	2025-08-27 12:27:55.285
169	EB-BJ800ABE	Batería Samsung J6	Batería compatible con: J6	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:56:45.248	2025-08-27 12:27:55.289
170	EB-BJ530ABE	Batería Samsung J530 / J5 PRO	Batería compatible con: J530, J5 PRO	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:56:45.258	2025-08-27 12:27:55.296
171	EB-BG570ABE	Batería Samsung J5 PRIME	Batería compatible con: J5 PRIME	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:56:45.268	2025-08-27 12:27:55.3
172	EB-BG610ABE	Batería Samsung J4CORE / J4PLUS / J6 PLUS / J610	Batería compatible con: J4CORE, J4PLUS, J6 PLUS, J610	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:56:45.278	2025-08-27 12:27:55.304
173	EB-BJ700BBC	Batería Samsung J4 / J7 / J701 / J7NEO	Batería compatible con: J4, J7, J701, J7NEO	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:56:45.289	2025-08-27 12:27:55.312
174	EB-BA730ABE	Batería Samsung A730 / A8PLUS	Batería compatible con: A730, A8PLUS	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:56:45.298	2025-08-27 12:27:55.318
175	EB-BA715ABY	Batería Samsung A71 / A715	Batería compatible con: A71, A715	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:56:45.308	2025-08-27 12:27:55.324
176	EB-BA705ABU	Batería Samsung A70 / A70S	Batería compatible con: A70, A70S	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:56:45.315	2025-08-27 12:27:55.329
177	EB-BG781ABY	Batería Samsung A52 / A52S / A525 4G / A525 5G / S20FE	Batería compatible con: A52, A52S, A525 4G, A525 5G, S20FE	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:56:45.324	2025-08-27 12:27:55.336
178	EB-BA515ABY	Batería Samsung A51 / A515	Batería compatible con: A51, A515	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:56:45.333	2025-08-27 12:27:55.34
179	EB-BA546ABY	Batería Samsung A34 5G / A546 / A54	Batería compatible con: A34 5G, A546, A54	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:56:45.347	2025-08-27 12:27:55.345
180	EB-BA336ABY	Batería Samsung A33 / A336 / A53 / A536	Batería compatible con: A33, A336, A53, A536	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:56:45.355	2025-08-27 12:27:55.358
181	EB-BA245ABY	Batería Samsung A24	Batería compatible con: A24	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:56:45.362	2025-08-27 12:27:55.363
182	SCUD-WT-W1	Batería Samsung A22 5G	Batería compatible con: A22 5G	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:56:45.374	2025-08-27 12:27:55.373
183	EB-BA315ABY	Batería Samsung A22 4G / A31 / A315 / A325 / A32 4G / A325 4G	Batería compatible con: A22 4G, A31, A315, A325, A32 4G, A325 4G	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:56:45.38	2025-08-27 12:27:55.379
184	EB-A505ABU	Batería Samsung A20 / A30 / A50 / A50S / A30S / A505	Batería compatible con: A20, A30, A50, A50S, A30S, A505	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:56:45.387	2025-08-27 12:27:55.393
185	EB-BG580ABU	Batería Samsung M30	Batería compatible con: M30	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:56:45.393	2025-08-27 12:27:55.399
186	EB-BA146ABY	Batería Samsung A14 5G / A146B	Batería compatible con: A14 5G, A146B	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:56:45.401	2025-08-27 12:27:55.405
187	EB-BA217ABY	Batería Samsung A13 / A13 4G / A13 lite / A21S / A217 / A04S / A02 / A12 / M02 / M127 / A04S	Batería compatible con: A13, A13 4G, A13 lite, A21S, A217, A04S, A02, A12, M02, M127, A04S	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:56:45.416	2025-08-27 12:27:55.408
144	BLP727	Batería Oppo A5 2020 / A11 / A11X / A9-2020 / realme5 / realme5i / realme5s / realmeC3	Batería compatible con: A5 2020, A11, A11X, A9-2020, realme5, realme5i, realme5s, realmeC3	\N	\N	\N	\N	46	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:51:42.115	2025-08-27 12:27:55.415
145	BLP851	Batería Oppo RENO6 LITE	Batería compatible con: RENO6 LITE	\N	\N	\N	\N	46	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:51:42.125	2025-08-27 12:27:55.142
191	SCUD-WT-N6	Batería Samsung A10S / A107 / A20S / A207	Batería compatible con: A10S, A107, A20S, A207	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:56:45.449	2025-08-27 12:27:55.426
192	EB-BA750ABU	Batería Samsung SAMA10 / M10	Batería compatible con: SAMA10, M10	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:56:45.457	2025-08-27 12:27:55.438
193	WT-S-N28	Batería Samsung A05	Batería compatible con: A05	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:56:45.465	2025-08-27 12:27:55.445
194	EB-BA136ABY	Batería Samsung A13 5G / A136B	Batería compatible con: A13 5G, A136B	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:56:45.473	2025-08-27 12:27:55.449
195	WT-S-W1	Batería Samsung A04 / A045 / A04E / A14 4G / A145P	Batería compatible con: A04, A045, A04E, A14 4G, A145P	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:56:45.486	2025-08-27 12:27:55.455
196	SLC-50	Batería Samsung A03 CORE	Batería compatible con: A03 CORE	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:56:45.494	2025-08-27 12:27:55.461
197	HQ-50SD	Batería Samsung A03	Batería compatible con: A03	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:56:45.505	2025-08-27 12:27:55.468
198	HQ-50S	Batería Samsung A02S / A03S	Batería compatible con: A02S, A03S	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:56:45.512	2025-08-27 12:27:55.476
199	EB-BA426ABY	Batería Samsung A32 5G / A72 / A725	Batería compatible con: A32 5G, A72, A725	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:56:45.52	2025-08-27 12:27:55.483
200	QL1695	Batería Samsung A01 M	Batería compatible con: A01 M	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:56:45.534	2025-08-27 12:27:55.491
201	EB-BG530BBE	Batería Samsung G532 / G530 / J5	Batería compatible con: G532, G530, J5	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:56:45.542	2025-08-27 12:27:55.498
202	BP4K	Batería Xiaomi REDMI NOTE12 PRO 5G	Batería compatible con: REDMI NOTE12 PRO 5G	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:59:53.945	2025-08-27 12:27:55.504
203	BN5M	Batería Xiaomi REDMI NOTE12 4G	Batería compatible con: REDMI NOTE12 4G	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:59:53.964	2025-08-27 12:27:55.516
204	BN5J	Batería Xiaomi REDMI NOTE12 5G / POCO X5	Batería compatible con: REDMI NOTE12 5G, POCO X5	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:59:53.971	2025-08-27 12:27:55.521
205	BM5G	Batería Xiaomi REDMI NOTE11T PRO / POCO X4 GT	Batería compatible con: REDMI NOTE11T PRO, POCO X4 GT	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:59:53.982	2025-08-27 12:27:55.529
206	BN5D	Batería Xiaomi REDMI NOTE11S / POCO M4PRO 4G / note11 / 12s	Batería compatible con: REDMI NOTE11S, POCO M4PRO 4G, note11, 12s	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:59:54.004	2025-08-27 12:27:55.534
207	BN5C	Batería Xiaomi REDMI NOTE11 5G / POCO M4 PRO 5G	Batería compatible con: REDMI NOTE11 5G, POCO M4 PRO 5G	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:59:54.015	2025-08-27 12:27:55.538
208	BN52	Batería Xiaomi REDMI NOTE10PRO MAX	Batería compatible con: REDMI NOTE10PRO MAX	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:59:54.026	2025-08-27 12:27:55.549
209	BN5E	Batería Xiaomi REDMI NOTE11PRO / NOTE11PLUS / POCO X4 PRO / REDMI NOTE12PRO 4G	Batería compatible con: REDMI NOTE11PRO, NOTE11PLUS, POCO X4 PRO, REDMI NOTE12PRO 4G	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:59:54.035	2025-08-27 12:27:55.557
210	BM57	Batería Xiaomi POCO X3 GT	Batería compatible con: POCO X3 GT	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:59:54.046	2025-08-27 12:27:55.563
211	BN59	Batería Xiaomi REDMI NOTE10 4G / 10S / POCO M5S	Batería compatible con: REDMI NOTE10 4G, 10S, POCO M5S	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:59:54.058	2025-08-27 12:27:55.571
212	BN55	Batería Xiaomi REDMI NOTE9S	Batería compatible con: REDMI NOTE9S	\N	\N	\N	\N	44	\N	\N	155	0	\N	10	1	PRODUCTO	2025-08-26 21:59:54.071	2025-10-28 21:47:07.106
213	BM4J	Batería Xiaomi REDMI NOTE8 PRO	Batería compatible con: REDMI NOTE8 PRO	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:59:54.08	2025-08-27 12:27:55.583
214	BN46	Batería Xiaomi REDMI NOTE8	Batería compatible con: REDMI NOTE8	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:59:54.086	2025-08-27 12:27:55.589
215	BN4A	Batería Xiaomi REDMI NOTE7 / NOTE7 PRO	Batería compatible con: REDMI NOTE7, NOTE7 PRO	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:59:54.098	2025-08-27 12:27:55.597
216	BN5K	Batería Xiaomi REDMI 12C	Batería compatible con: REDMI 12C	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:59:54.109	2025-08-27 12:27:55.601
217	BN5G	Batería Xiaomi REDMI 10C	Batería compatible con: REDMI 10C	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:59:54.119	2025-08-27 12:27:55.607
218	BN5H	Batería Xiaomi REDMI 10 5G	Batería compatible con: REDMI 10 5G	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:59:54.129	2025-08-27 12:27:55.611
219	BN5A	Batería Xiaomi REDMI 10 4G / REDMI NOTE11 4G	Batería compatible con: REDMI 10 4G, REDMI NOTE11 4G	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:59:54.143	2025-08-27 12:27:55.615
220	BN57	Batería Xiaomi POCO X3 PRO	Batería compatible con: POCO X3 PRO	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:59:54.154	2025-08-27 12:27:55.619
221	BN61	Batería Xiaomi POCO X3	Batería compatible con: POCO X3	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:59:54.161	2025-08-27 12:27:55.624
222	BN62	Batería Xiaomi REDMI 9T / NOTE9 4G / POCO M3	Batería compatible con: REDMI 9T, NOTE9 4G, POCO M3	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:59:54.175	2025-08-27 12:27:55.63
224	BN54	Batería Xiaomi REDMI 9 / REDMI NOTE9 / REDMI 10X	Batería compatible con: REDMI 9, REDMI NOTE9, REDMI 10X	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:59:54.198	2025-08-27 12:27:55.639
225	BN51	Batería Xiaomi REDMI 8 / 8A	Batería compatible con: REDMI 8, 8A	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:59:54.214	2025-08-27 12:27:55.643
226	BM5J	Batería Xiaomi MI 12T / MI 12T PRO	Batería compatible con: MI 12T, MI 12T PRO	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:59:54.224	2025-08-27 12:27:55.648
227	BM58	Batería Xiaomi MI11T PRO	Batería compatible con: MI11T PRO	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:59:54.233	2025-08-27 12:27:55.653
228	BM59	Batería Xiaomi MI 11T	Batería compatible con: MI 11T	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:59:54.24	2025-08-27 12:27:55.658
229	BP42	Batería Xiaomi MI 11 LITE 4G / 5G	Batería compatible con: MI 11 LITE 4G, 5G	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:59:54.252	2025-08-27 12:27:55.662
230	BM52	Batería Xiaomi MI NOTE10 / NOTE10LITE / NOTE10PRO / CC9PRO	Batería compatible con: MI NOTE10, NOTE10LITE, NOTE10PRO, CC9PRO	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:59:54.261	2025-08-27 12:27:55.669
231	BM4R	Batería Xiaomi MI 10 LITE	Batería compatible con: MI 10 LITE	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:59:54.272	2025-08-27 12:27:55.675
232	BM53	Batería Xiaomi MI 10T / 10T PRO / K30S	Batería compatible con: MI 10T, 10T PRO, K30S	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:59:54.282	2025-08-27 12:27:55.683
233	BP40	Batería Xiaomi MI9T PRO	Batería compatible con: MI9T PRO	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:59:54.29	2025-08-27 12:27:55.689
189	HQ-70N	Batería Samsung A11 / A115	Batería compatible con: A11, A115	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:56:45.431	2025-08-27 12:27:55.697
190	EB-BA202ABU	Batería Samsung A10E	Batería compatible con: A10E	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:56:45.439	2025-08-27 12:27:55.421
237	BN31	Batería Xiaomi MI A1 / 5X	Batería compatible con: MI A1, 5X	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:59:54.326	2025-08-27 12:27:55.707
238	BP49	Batería Xiaomi POCO F4	Batería compatible con: POCO F4	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:59:54.338	2025-08-27 12:27:55.712
239	BM4Y	Batería Xiaomi POCO F3 / MI11 i / MI11 X	Batería compatible con: POCO F3, MI11 i, MI11 X	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:59:54.351	2025-08-27 12:27:55.72
240	LI3951T44P8H956656	Batería ZTE V40 SMART	Batería compatible con: V40 SMART	\N	\N	\N	\N	56	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:02:57.585	2025-08-27 12:27:55.724
241	LI3939T44P8H756547	Batería ZTE V2020 5G	Batería compatible con: V2020 5G	\N	\N	\N	\N	56	\N	\N	270	0	\N	10	1	PRODUCTO	2025-08-26 22:02:57.603	2025-10-28 22:02:33.143
242	E6539ZTE-B	Batería ZTE A53	Batería compatible con: A53	\N	\N	\N	\N	56	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:02:57.609	2025-08-27 12:27:55.734
243	Li3949T44P8h906450	Batería ZTE A52 / A72 / V20 SMART 2050 / V20 SMART 8010	Batería compatible con: A52, A72, V20 SMART 2050, V20 SMART 8010	\N	\N	\N	\N	56	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:02:57.618	2025-08-27 12:27:55.739
244	LI3839T44P8H866445	Batería ZTE A71	Batería compatible con: A71	\N	\N	\N	\N	56	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:02:57.648	2025-08-27 12:27:55.744
245	LI3839T43P8H826348	Batería ZTE A7 2020	Batería compatible con: A7 2020	\N	\N	\N	\N	56	\N	\N	260	0	\N	10	1	PRODUCTO	2025-08-26 22:02:57.66	2025-10-28 22:06:31.908
246	LI3931T44P8H806139	Batería ZTE A5 2020 / A51 / V9 / V9 LITE / V10 / V10 VITA	Batería compatible con: A5 2020, A51, V9, V9 LITE, V10, V10 VITA	\N	\N	\N	\N	56	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:02:57.679	2025-08-27 12:27:55.76
247	LI3826T43P4H695950	Batería ZTE A3 2020 / L210	Batería compatible con: A3 2020, L210	\N	\N	\N	\N	56	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:02:57.69	2025-08-27 12:27:55.765
248	AL503	Display Alcatel 5030 1SE ORIG	Display compatible con: 5030	\N	\N	\N	\N	48	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:17:09.181	2025-08-27 12:27:55.771
249	AL524	Display Alcatel 5024 ORIG S/M	Display compatible con: 5024	\N	\N	\N	\N	48	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:17:09.196	2025-08-27 12:27:55.777
250	AL528	Display Alcatel 5028 ORIG S/M	Display compatible con: 5028	\N	\N	\N	\N	48	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:17:09.215	2025-08-27 12:27:55.78
251	A0550	Display Hisense E50S ORIG S/M	Display compatible con: E50S	\N	\N	\N	\N	49	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:20:43.543	2025-08-27 12:27:55.785
252	A0005	Display Hisense E50i ORIG S/M	Display compatible con: E50i	\N	\N	\N	\N	49	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:20:43.559	2025-08-27 12:27:55.793
253	A0230	Display Hisense F23 ORIG S/M	Display compatible con: F23	\N	\N	\N	\N	49	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:20:43.574	2025-08-27 12:27:55.801
254	A0220	Display Hisense F20 ORIG S/M	Display compatible con: F20	\N	\N	\N	\N	49	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:20:43.583	2025-08-27 12:27:55.805
255	A0444	Display Hisense H40 ORIG S/M	Display compatible con: H40	\N	\N	\N	\N	49	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:20:43.599	2025-08-27 12:27:55.813
256	A0060	Display Hisense E60 LITE ORIG	Display compatible con: E60	\N	\N	\N	\N	49	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:20:43.615	2025-08-27 12:27:55.817
257	A0411	Display Hisense V40S ORIG S/M	Display compatible con: V40S	\N	\N	\N	\N	49	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:20:43.627	2025-08-27 12:27:55.822
258	A0555	Display Hisense H50 ORIG S/M	Display compatible con: H50	\N	\N	\N	\N	49	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:20:43.635	2025-08-27 12:27:55.83
259	A0611	Display Hisense V60/E60 ORIG S/M	Display compatible con: V60/E60	\N	\N	\N	\N	49	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:20:43.648	2025-08-27 12:27:55.836
260	A0511	Display Hisense V50 ORIG S/M	Display compatible con: V50	\N	\N	\N	\N	49	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:20:43.656	2025-08-27 12:27:55.84
261	A0610	Display Hisense E60 ORIG S/M	Display compatible con: E60	\N	\N	\N	\N	49	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:20:43.668	2025-08-27 12:27:55.846
262	A0310	Display Hisense E30 ORIGS/M NEGRO	Display compatible con: E30	\N	\N	\N	\N	49	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:20:43.679	2025-08-27 12:27:55.85
263	A0066	Display Hisense H60 LITE ORIG	Display compatible con: H60	\N	\N	\N	\N	49	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:20:43.694	2025-08-27 12:27:55.856
264	H0505	Display Hisense U50 4G ORIG	Display compatible con: U50	\N	\N	\N	\N	49	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:20:43.708	2025-08-27 12:27:55.861
265	A0055	Display Hisense E50 LITE ORIG	Display compatible con: E50	\N	\N	\N	\N	49	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:20:43.717	2025-08-27 12:27:55.868
266	A0050	Display Hisense H50 LITE/E50 ORIG	Display compatible con: H50	\N	\N	\N	\N	49	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:20:43.724	2025-08-27 12:27:55.877
267	A0040	Display Hisense H40 LITE/E40/V40 ORIG	Display compatible con: H40	\N	\N	\N	\N	49	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:20:43.738	2025-08-27 12:27:55.886
268	A0030	Display Hisense H30 LITE ORIG	Display compatible con: H30	\N	\N	\N	\N	49	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:20:43.748	2025-08-27 12:27:55.891
269	W0805	Display Honor X8A 5G/X6 ORIG	Display compatible con: X8A	\N	\N	\N	\N	57	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:23:47.261	2025-08-27 12:27:55.896
272	W0090+F	Display Honor 90 ORIG C/M(BOUTIQUE)	Display compatible con: 90	\N	\N	\N	\N	57	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:23:47.286	2025-08-27 12:27:55.907
273	W0066+F	Display Honor X6A ORIG C/M(BOUTIQUE)	Display compatible con: X6A	\N	\N	\N	\N	57	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:23:47.306	2025-08-27 12:27:55.913
274	W0090	Display Honor 90 ORIG S/M	Display compatible con: 90	\N	\N	\N	\N	57	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:23:47.317	2025-08-27 12:27:55.922
275	W0077+F	Display Honor X7A ORIG C/M(BOUTIQUE)	Display compatible con: X7A	\N	\N	\N	\N	57	\N	\N	295	0	\N	10	1	PRODUCTO	2025-08-26 22:23:47.331	2025-10-14 21:48:46.201
276	W1100+F	Display Honor 10 LITE ORIG	Display compatible con: 10	\N	\N	\N	\N	57	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:23:47.339	2025-08-27 12:27:55.935
277	W0066	Display Honor X6A/X50 PRO/X5 PLUS	Display compatible con: X6A/X50	\N	\N	\N	\N	57	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:23:47.347	2025-08-27 12:27:55.942
278	W0909+F	Display Honor X9 ORIG C/M(BOUTIQUE)	Display compatible con: X9	\N	\N	\N	\N	57	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:23:47.363	2025-08-27 12:27:55.947
279	W1177+F	Display Honor X7B ORIG C/M(BOUTIQUE)	Display compatible con: X7B	\N	\N	\N	\N	57	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:23:47.369	2025-08-27 12:27:55.954
280	W1188+F	Display Honor X8B ORIG C/M(BOUTIQUE)	Display compatible con: X8B	\N	\N	\N	\N	57	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:23:47.374	2025-08-27 12:27:55.962
281	W1177	Display Honor X7B ORIG S/M	Display compatible con: X7B	\N	\N	\N	\N	57	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:23:47.38	2025-08-27 12:27:55.97
282	W0606+F	Display Honor X6 ORIG C/M(BOUTIQUE)	Display compatible con: X6	\N	\N	\N	\N	57	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:23:47.387	2025-08-27 12:27:55.976
283	W0505+F	Display Honor X5 ORIG C/M(BOUTIQUE)	Display compatible con: X5	\N	\N	\N	\N	57	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:23:47.396	2025-08-27 12:27:55.984
284	W1188	Display Honor X8B ORIG S/M	Display compatible con: X8B	\N	\N	\N	\N	57	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:23:47.406	2025-08-27 12:27:55.992
234	BP41	Batería Xiaomi MI 9T	Batería compatible con: MI 9T	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:59:54.301	2025-08-27 12:27:55.997
235	BM3L	Batería Xiaomi MI 9	Batería compatible con: MI 9	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:59:54.309	2025-08-27 12:27:55.702
1033	Bo345	Bocina doble YA!	\N	\N	\N	\N	1	59	1091	\N	350	3	31	0	0	PRODUCTO	2025-09-05 17:17:25.159	2025-09-05 17:35:20.047
288	W0505	Display Honor X5 ORIG S/M	Display compatible con: X5	\N	\N	\N	\N	57	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:23:47.438	2025-08-27 12:27:56.004
290	W9090+F/S	Display Honor X9A ORIG C/M(BOUTIQUE)	Display compatible con: X9A	\N	\N	\N	\N	57	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:23:47.451	2025-08-27 12:27:56.009
291	W9090+F	Display Honor X9A ORIG C/M(BOUTIQUE)	Display compatible con: X9A	\N	\N	\N	\N	57	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:23:47.46	2025-08-27 12:27:56.013
292	W0088-COG	Display Honor 8X/9X LITE COG	Display compatible con: 8X/9X	\N	\N	\N	\N	57	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:23:47.471	2025-08-27 12:27:56.018
293	W9090	Display Honor X9A/MAGIC5 LITE ORIG	Display compatible con: X9A/MAGIC5	\N	\N	\N	\N	57	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:23:47.479	2025-08-27 12:27:56.021
294	W1818	Display Honor X8A 4G/X50i/90 LITE	Display compatible con: X8A	\N	\N	\N	\N	57	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:23:47.488	2025-08-27 12:27:56.031
295	W0077	Display Honor X7A ORIG S/M	Display compatible con: X7A	\N	\N	\N	\N	57	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:23:47.496	2025-08-27 12:27:56.039
296	W1010	Display Honor 10 ORIG S/M	Display compatible con: 10	\N	\N	\N	\N	57	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:23:47.51	2025-08-27 12:27:56.047
297	W1100-COF	Display Honor 10 LITE ORIG	Display compatible con: 10	\N	\N	\N	\N	57	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:23:47.516	2025-08-27 12:27:56.051
298	W1100-COG	Display Honor 10 LITE COG	Display compatible con: 10	\N	\N	\N	\N	57	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:23:47.521	2025-08-27 12:27:56.06
299	W0550	Display Honor 50 LITE/NOVA 8i	Display compatible con: 50	\N	\N	\N	\N	57	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:23:47.526	2025-08-27 12:27:56.066
300	W0909	Display Honor X9 ORIG S/M	Display compatible con: X9	\N	\N	\N	\N	57	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:23:47.536	2025-08-27 12:27:56.078
301	W8000+F	Display Honor X8 ORIG C/M(BOUTIQUE)	Display compatible con: X8	\N	\N	\N	\N	57	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:23:47.548	2025-08-27 12:27:56.086
302	W0707+F	Display Honor X7 ORIG C/M(BOUTIGUE)	Display compatible con: X7	\N	\N	\N	\N	57	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:23:47.555	2025-08-27 12:27:56.095
304	W8000	Display Honor X8 ORIG S/M	Display compatible con: X8	\N	\N	\N	\N	57	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:23:47.569	2025-08-27 12:27:56.107
305	W0707	Display Honor X7 ORIG S/M	Display compatible con: X7	\N	\N	\N	\N	57	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:23:47.583	2025-08-27 12:27:56.113
306	W0088-COF	Display Honor 8X/9X LITE COF	Display compatible con: 8X/9X	\N	\N	\N	\N	57	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:23:47.592	2025-08-27 12:27:56.118
307	W0999+F	Display Huawei MATE 9 ORIG	Display compatible con: MATE	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:27:29.434	2025-08-27 12:27:56.125
308	W0099	Display Huawei MATE20 PRO INCELL	Display compatible con: MATE20	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:27:29.449	2025-08-27 12:27:56.131
309	W0222	Display Huawei MATE20 INCELL S/M	Display compatible con: MATE20	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:27:29.456	2025-08-27 12:27:56.135
310	W0010	Display Huawei MATE 10 ORIG	Display compatible con: MATE	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:27:29.467	2025-08-27 12:27:56.142
311	W0999	Display Huawei MATE 9 ORIG	Display compatible con: MATE	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:27:29.481	2025-08-27 12:27:56.145
312	W0101	Display Huawei MATE10 PRO INCELL	Display compatible con: MATE10	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:27:29.503	2025-08-27 12:27:56.149
313	W0200	Display Huawei MATE20 PRO INCELL	Display compatible con: MATE20	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:27:29.514	2025-08-27 12:27:56.156
314	W0002+F	Display Huawei MATE10 LITE ORIG	Display compatible con: MATE10	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:27:29.527	2025-08-27 12:27:56.165
315	W0012+F	Display Huawei MATE20 LITE ORIG	Display compatible con: MATE20	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:27:29.538	2025-08-27 12:27:56.169
316	W0002	Display Huawei MATE10 LITE ORIG	Display compatible con: MATE10	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:27:29.549	2025-08-27 12:27:56.174
317	W0012	Display Huawei MATE20 LITE ORIG	Display compatible con: MATE20	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:27:29.562	2025-08-27 12:27:56.179
318	KL-HD067-M11	Display Huawei NOVA Y70/Y71 INCELL300+	Display compatible con: NOVA	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:27:29.576	2025-08-27 12:27:56.184
319	W0121+F	Display Huawei NOVA 5T ORIG	Display compatible con: NOVA	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:27:29.589	2025-08-27 12:27:56.189
320	W0100+F	Display Huawei NOVA10 SE ORIG	Display compatible con: NOVA10	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:27:29.602	2025-08-27 12:27:56.194
321	W1212+F	Display Huawei NOVA9 SE COG	Display compatible con: NOVA9	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:27:29.615	2025-08-27 12:27:56.2
322	W0100	Display Huawei NOVA10 SE/NOVA11 SE/NOVA12	Display compatible con: NOVA10	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:27:29.625	2025-08-27 12:27:56.207
323	W0888+F	Display Huawei NOVA 8 AMOLED	Display compatible con: NOVA	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:27:29.636	2025-08-27 12:27:56.212
324	W0300+F	Display Huawei NOVA3 ORIG C/M(BOUTIQUE)	Display compatible con: NOVA3	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:27:29.646	2025-08-27 12:27:56.218
325	W1414+F	Display Huawei NOVA Y90 ORIG	Display compatible con: NOVA	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:27:29.66	2025-08-27 12:27:56.222
326	W0150	Display Huawei NOVA9/HONOR 50 ORIG	Display compatible con: NOVA9/HONOR	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:27:29.668	2025-08-27 12:27:56.228
327	W0011	Display Huawei NOVA 10 ORIG	Display compatible con: NOVA	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:27:29.676	2025-08-27 12:27:56.234
328	W1414	Display Huawei NOVA Y90 ORIG	Display compatible con: NOVA	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:27:29.686	2025-08-27 12:27:56.24
330	W0121-COF	Display Huawei NOVA5T/HONOR20 ORIG COF	Display compatible con: NOVA5T/HONOR20	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:27:29.705	2025-08-27 12:27:56.249
331	W0121-COG	Display Huawei NOVA5T/HONOR20 COG S/M	Display compatible con: NOVA5T/HONOR20	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:27:29.715	2025-08-27 12:27:56.257
332	W0911	Display Huawei NOVA9/HONOR50 AMOLED S/M(CURVO)	Display compatible con: NOVA9/HONOR50	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:27:29.726	2025-08-27 12:27:56.268
333	W0888	Display Huawei NOVA8 AMOLED S/M(CURVO)	Display compatible con: NOVA8	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:27:29.734	2025-08-27 12:27:56.279
334	W0004+F	Display Huawei NOVA Y60 ORIG	Display compatible con: NOVA	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:27:29.748	2025-08-27 12:27:56.285
335	W0020+F	Display Huawei NOVA Y70 ORIG	Display compatible con: NOVA	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:27:29.756	2025-08-27 12:27:56.297
336	W0300	Display Huawei NOVA3 INCELL S/M	Display compatible con: NOVA3	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:27:29.764	2025-08-27 12:27:56.303
286	W1818+F	Display Honor X8A ORIG C/M(BOUTIQUE)	Display compatible con: X8A	\N	\N	\N	\N	57	\N	\N	250	0	\N	10	1	PRODUCTO	2025-08-26 22:23:47.426	2025-10-11 23:12:57.8
287	W0088+F	Display Honor 8X/9X LITE ORIG	Display compatible con: 8X/9X	\N	\N	\N	\N	57	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:23:47.433	2025-08-27 12:27:56
303	W0606	Display Honor X6/X8A 5G ORIG	Display compatible con: X6/X8A	\N	\N	\N	\N	57	\N	\N	225	1	\N	10	1	PRODUCTO	2025-08-26 22:23:47.562	2025-10-28 22:00:22.336
341	02352PJP	Display Huawei P30 LITE(128G) ORIG	Display compatible con: P30	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:27:29.819	2025-08-27 12:27:56.319
342	W0030	Display Huawei P30 PRO OLED	Display compatible con: P30	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:27:29.829	2025-08-27 12:27:56.325
343	W0202+F	Display Huawei P20 PRO OLED	Display compatible con: P20	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:27:29.842	2025-08-27 12:27:56.335
344	W0029+F	Display Huawei P SMART 2019	Display compatible con: P	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:27:29.856	2025-08-27 12:27:56.34
345	W0666-COF	Display Huawei P SMART 2018	Display compatible con: P	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:27:29.864	2025-08-27 12:27:56.345
346	W0040-COG	Display Huawei P40 LITE COG	Display compatible con: P40	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:27:29.875	2025-08-27 12:27:56.352
347	W0202	Display Huawei P20 PRO COG	Display compatible con: P20	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:27:29.886	2025-08-27 12:27:56.361
348	W0029-COG	Display Huawei P SMART 2019	Display compatible con: P	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:27:29.9	2025-08-27 12:27:56.364
349	W0333-COG	Display Huawei P30 LITE COG	Display compatible con: P30	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:27:29.911	2025-08-27 12:27:56.37
350	W0035	Display Huawei P30 OLED S/M	Display compatible con: P30	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:27:29.919	2025-08-27 12:27:56.376
351	W0023+F	Display Huawei P20 LITE ORIG	Display compatible con: P20	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:27:29.926	2025-08-27 12:27:56.381
352	W0040+F	Display Huawei P40 LITE ORIG	Display compatible con: P40	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:27:29.942	2025-08-27 12:27:56.391
353	W0333+F	Display Huawei P30 LITE ORIG	Display compatible con: P30	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:27:29.953	2025-08-27 12:27:56.399
354	W0022	Display Huawei P30 INCELL S/M	Display compatible con: P30	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:27:29.963	2025-08-27 12:27:56.408
355	W0040-COF	Display Huawei P40 LITE ORIG	Display compatible con: P40	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:27:29.976	2025-08-27 12:27:56.414
356	W0029-COF	Display Huawei P SMART 2019	Display compatible con: P	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:27:29.989	2025-08-27 12:27:56.421
357	W0333-COF	Display Huawei P30 LITE ORIG	Display compatible con: P30	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:27:30	2025-08-27 12:27:56.428
358	W0023	Display Huawei P20 LITE/ANE LX3	Display compatible con: P20	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:27:30.013	2025-08-27 12:27:56.433
359	W6000-COF	Display Huawei Y6P/HONOR9A/10E/HONOR9S PRIME COF	Display compatible con: Y6P/HONOR9A/10E/HONOR9S	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:27:30.02	2025-08-27 12:27:56.44
360	W0006+F/A	Display Huawei Y9S ORIG C/M(BOUTIQUE)	Display compatible con: Y9S	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:27:30.029	2025-08-27 12:27:56.447
361	KL-HD065-9X	Display Huawei Y9S/HONOR 9X INCELL300+	Display compatible con: Y9S/HONOR	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:27:30.044	2025-08-27 12:27:56.455
362	W0777+F	Display Huawei Y7 2019 ORIG	Display compatible con: Y7	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:27:30.057	2025-08-27 12:27:56.46
363	W0600+F	Display Huawei Y6 2018 ORIG	Display compatible con: Y6	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:27:30.064	2025-08-27 12:27:56.465
364	W0178+F	Display Huawei Y7 2018 ORIG	Display compatible con: Y7	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:27:30.079	2025-08-27 12:27:56.471
365	W0006-COG+F	Display Huawei Y9S COG C/M(BOUTIQUE)	Display compatible con: Y9S	\N	\N	\N	\N	40	\N	\N	497	0	\N	10	1	PRODUCTO	2025-08-26 22:27:30.087	2025-10-14 21:45:25.997
366	W0006-COF	Display Huawei Y9S/HONOR 9X ORIG	Display compatible con: Y9S/HONOR	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:27:30.1	2025-08-27 12:27:56.483
367	W0009-COG	Display Huawei Y9A COG S/M	Display compatible con: Y9A	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:27:30.112	2025-08-27 12:27:56.491
368	W0019-COG	Display Huawei Y9 2019/Y8S COG	Display compatible con: Y9	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:27:30.125	2025-08-27 12:27:56.501
369	W0019+F	Display Huawei Y9 2019/Y8S ORIG	Display compatible con: Y9	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:27:30.134	2025-08-27 12:27:56.509
370	W0006-COG	Display Huawei Y9S/HONOR 9X COG	Display compatible con: Y9S/HONOR	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:27:30.143	2025-08-27 12:27:56.515
372	W0006+F	Display Huawei Y9S ORIG C/M(BOUTIQUE)	Display compatible con: Y9S	\N	\N	\N	\N	40	\N	\N	290	0	\N	10	1	PRODUCTO	2025-08-26 22:27:30.168	2025-10-16 20:25:31.536
373	W0027+F	Display Huawei Y7P ORIG C/M(BOUTIQUE)	Display compatible con: Y7P	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:27:30.178	2025-08-27 12:27:56.523
374	W0069+F	Display Huawei Y6 2019 ORIG	Display compatible con: Y6	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:27:30.186	2025-08-27 12:27:56.534
375	W0045+F	Display Huawei Y7A ORIG C/M(BOUTIQUE)	Display compatible con: Y7A	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:27:30.195	2025-08-27 12:27:56.54
376	W0009+F	Display Huawei Y9A ORIG C/M(BOUTIQUE)	Display compatible con: Y9A	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:27:30.207	2025-08-27 12:27:56.549
377	W0007+F	Display Huawei Y9 PRIME ORIG	Display compatible con: Y9	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:27:30.217	2025-08-27 12:27:56.553
378	W0808+F	Display Huawei Y8P INCELL C/M(BOUTIQUE)	Display compatible con: Y8P	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:27:30.229	2025-08-27 12:27:56.558
379	W0007-COG	Display Huawei Y9 PRIME COG	Display compatible con: Y9	\N	\N	\N	\N	40	\N	\N	245	0	\N	10	1	PRODUCTO	2025-08-26 22:27:30.247	2025-10-28 22:24:06.521
380	W0009-COF	Display Huawei Y9A ORIG COF	Display compatible con: Y9A	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:27:30.256	2025-08-27 12:27:56.569
381	W0718	Display Huawei Y7 2018 ORIG	Display compatible con: Y7	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:27:30.264	2025-08-27 12:27:56.575
382	W0600	Display Huawei Y6 2018 ORIG	Display compatible con: Y6	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:27:30.273	2025-08-27 12:27:56.582
383	W0027	Display Huawei Y7P/P40 LITE E	Display compatible con: Y7P/P40	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:27:30.285	2025-08-27 12:27:56.587
384	W0045	Display Huawei Y7A/P SMART 2021/HONOR	Display compatible con: Y7A/P	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:27:30.292	2025-08-27 12:27:56.593
385	W0808	Display Huawei Y8P/Honor 20 lite	Display compatible con: Y8P/Honor	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:27:30.299	2025-08-27 12:27:56.598
386	W6000-COG	Display Huawei Y6P/HONOR9A/10E/HONOR9S PRIME COG	Display compatible con: Y6P/HONOR9A/10E/HONOR9S	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:27:30.309	2025-08-27 12:27:56.605
387	W0019-COF	Display Huawei Y9 2019/Y8S ORIG	Display compatible con: Y9	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:27:30.326	2025-08-27 12:27:56.611
388	W0007-COF	Display Huawei Y9 PRIME ORIG	Display compatible con: Y9	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:27:30.339	2025-08-27 12:27:56.619
339	W0666+F	Display Huawei P SMART 2018	Display compatible con: P	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:27:29.793	2025-08-27 12:27:56.626
340	02352HTF	Display Huawei P smart 2019	Display compatible con: P	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:27:29.807	2025-08-27 12:27:56.314
393	X0678	Display Infinix X678B/NOTE30 PRO ORIG	Display compatible con: X678B/NOTE30	\N	\N	\N	\N	51	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:30:04.427	2025-08-27 12:27:56.639
394	X0031+F	Display Infinix X6831/HOT30 ORIG C/M(BOUTIQUE)	Display compatible con: X6831/HOT30	\N	\N	\N	\N	51	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:30:04.442	2025-08-27 12:27:56.646
395	X0065+F	Display Infinix X6515/Smart 7 ORIG	Display compatible con: X6515/Smart	\N	\N	\N	\N	51	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:30:04.457	2025-08-27 12:27:56.653
396	X0011+F	Display Infinix X6833/Note30 ORIG C/M(BOUTIQUE)	Display compatible con: X6833/Note30	\N	\N	\N	\N	51	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:30:04.47	2025-08-27 12:27:56.657
397	X0669+F	Display Infinix X669 ORIG C/M(BOUTIQUE)	Display compatible con: X669	\N	\N	\N	\N	51	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:30:04.486	2025-08-27 12:27:56.661
398	X0065	Display Infinix X6515/SMART 7 ORIG	Display compatible con: X6515/SMART	\N	\N	\N	\N	51	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:30:04.496	2025-08-27 12:27:56.667
399	X0669	Display Infinix X669/HOT 30i ORIG	Display compatible con: X669/HOT	\N	\N	\N	\N	51	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:30:04.506	2025-08-27 12:27:56.675
400	X0011-X2186	Display Infinix X6833/Note30 4G ORIG	Display compatible con: X6833/Note30	\N	\N	\N	\N	51	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:30:04.518	2025-08-27 12:27:56.68
401	X0031	Display Infinix X6831/HOT 30 ORIG	Display compatible con: X6831/HOT	\N	\N	\N	\N	51	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:30:04.533	2025-08-27 12:27:56.686
402	H0422	Display LG K42/K52/K62 ORIG S/M	Display compatible con: K42/K52/K62	\N	\N	\N	\N	42	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:32:31.684	2025-08-27 12:27:56.692
403	H0512	Display LG K41S ORIG S/M	Display compatible con: K41S	\N	\N	\N	\N	42	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:32:31.701	2025-08-27 12:27:56.703
404	H0909	Display LG K50 ORIG S/M	Display compatible con: K50	\N	\N	\N	\N	42	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:32:31.707	2025-08-27 12:27:56.708
405	H0777	Display LG K22 ORIG S/M	Display compatible con: K22	\N	\N	\N	\N	42	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:32:31.721	2025-08-27 12:27:56.713
406	H0551	Display LG K51 ORIG S/M	Display compatible con: K51	\N	\N	\N	\N	42	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:32:31.741	2025-08-27 12:27:56.718
407	H0998	Display LG K51S ORIG S/M	Display compatible con: K51S	\N	\N	\N	\N	42	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:32:31.758	2025-08-27 12:27:56.724
408	F1414	Display Motorola E30/E40 ORIG S/M	Display compatible con: E30/E40	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:06.832	2025-08-27 12:27:56.734
409	KL-HD065-E32	Display Motorola E32/E22/E32S/G22 INCELL300+ S/M	Display compatible con: E32/E22/E32S/G22	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:06.843	2025-08-27 12:27:56.74
410	KL-HD065-E7+F	Display Motorola E7 INCELL300+ C/M	Display compatible con: E7	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:06.859	2025-08-27 12:27:56.752
411	KL-HD065-E7	Display Motorola E7/E7i/E7power/E7ipower INCELL300+ S/M	Display compatible con: E7/E7i/E7power/E7ipower	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:06.874	2025-08-27 12:27:56.756
412	F1313	Display Motorola E13 ORIG S/M	Display compatible con: E13	\N	\N	\N	\N	41	\N	\N	190	0	\N	10	1	PRODUCTO	2025-08-26 22:36:06.888	2025-11-01 21:55:27.317
413	F1414+F	Display Motorola E30/E40 ORIG C/M(BOUTIQUE)	Display compatible con: E30/E40	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:06.903	2025-08-27 12:27:56.768
414	F0824+F	Display Motorola E7POWER ORIG C/M(BOUTIQUE)	Display compatible con: E7POWER	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:06.921	2025-08-27 12:27:56.777
415	F0296+F	Display Motorola E7 ORIG C/M(BOUTIQUE)	Display compatible con: E7	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:06.932	2025-08-27 12:27:56.787
416	F0125+F	Display Motorola E6S ORIG C/M(BOUTIQUE)	Display compatible con: E6S	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:06.944	2025-08-27 12:27:56.795
417	F0127+F	Display Motorola E20 ORIG C/M	Display compatible con: E20	\N	\N	\N	\N	41	\N	\N	190	0	\N	10	1	PRODUCTO	2025-08-26 22:36:06.95	2025-11-01 21:57:25.914
418	F0702+F	Display Motorola E6PLUS ORIG C/M(BOUTIQUE)	Display compatible con: E6PLUS	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:06.958	2025-08-27 12:27:56.809
419	A0044+F	Display Motorola E40 ORIG C/M(BOUTIQUE)	Display compatible con: E40	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:06.967	2025-08-27 12:27:56.814
420	F6011+F	Display Motorola E22 ORIG C/M(BOUTIQUE)	Display compatible con: E22	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:06.977	2025-08-27 12:27:56.822
421	F0855-O	Display Motorola E5PLUS ORIG S/M	Display compatible con: E5PLUS	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:06.99	2025-08-27 12:27:56.828
422	F0855-N	Display Motorola E5PLUS ORIG S/M	Display compatible con: E5PLUS	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:06.998	2025-08-27 12:27:56.835
423	F6011	Display Motorola E22/E22i ORIG S/M	Display compatible con: E22/E22i	\N	\N	\N	\N	41	\N	\N	170	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.004	2025-11-13 19:17:38.938
424	F0127	Display Motorola E20/XT2155 ORIG S/M	Display compatible con: E20/XT2155	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.013	2025-08-27 12:27:56.849
425	F0125	Display Motorola E6S/E6i ORIG S/M	Display compatible con: E6S/E6i	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.022	2025-08-27 12:27:56.859
426	F0055	Display Motorola E5 PLAY GO	Display compatible con: E5	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.03	2025-08-27 12:27:56.865
427	F0296	Display Motorola E7/E7POWER/E7I/ E7IPOWER ORIG	Display compatible con: E7/E7POWER/E7I/	\N	\N	\N	\N	41	\N	\N	170	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.038	2025-11-18 21:53:04.329
428	F0702	Display Motorola E6PLUS ORIG S/M	Display compatible con: E6PLUS	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.047	2025-08-27 12:27:56.877
429	F0037	Display Motorola E6PLAY ORIG S/M	Display compatible con: E6PLAY	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.056	2025-08-27 12:27:56.881
430	F0456	Display Motorola E7PLUS/G9/G9PLAY ORIG S/M	Display compatible con: E7PLUS/G9/G9PLAY	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.066	2025-08-27 12:27:56.885
431	F0500	Display Motorola EDGE50 PRO AMOLED	Display compatible con: EDGE50	\N	\N	\N	\N	41	\N	\N	970	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.076	2025-10-28 22:19:53.713
432	F5555	Display Motorola G85/S50 NEO/EDGE 50	Display compatible con: G85/S50	\N	\N	\N	\N	41	\N	\N	940	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.089	2025-10-17 20:50:01.846
433	F0400+F/g	Display Motorola EDGE 40 NEO	Display compatible con: EDGE	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.1	2025-08-27 12:27:56.908
434	F0400+F/L	Display Motorola EDGE 40 NEO	Display compatible con: EDGE	\N	\N	\N	\N	41	\N	\N	220	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.117	2025-10-28 22:17:10.297
435	F0400+F	Display Motorola EDGE 40 NEO	Display compatible con: EDGE	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.134	2025-08-27 12:27:56.921
436	F0105/F0400	Display Motorola EDGE 40/EDGE 40	Display compatible con: EDGE	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.146	2025-08-27 12:27:56.929
437	F1133	Display Motorola EDGE30 NEO OLED	Display compatible con: EDGE30	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.155	2025-08-27 12:27:56.936
438	F0776	Display Motorola EDGE ORIG S/M	Display compatible con: EDGE	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.168	2025-08-27 12:27:56.943
391	X0688	Display Infinix X688/HOT10 PLAY ORIG	Display compatible con: X688/HOT10	\N	\N	\N	\N	51	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:30:04.406	2025-08-27 12:27:56.633
443	F0814	Display Motorola EDGE20/EDGE20 PRO/EDGE30 PRO	Display compatible con: EDGE20/EDGE20	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.214	2025-08-27 12:27:56.953
444	F5223+F	Display Motorola G5G 2023 ORIG	Display compatible con: G5G	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.22	2025-08-27 12:27:56.96
445	F5023	Display Motorola G STYLUS 5G	Display compatible con: G	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.226	2025-08-27 12:27:56.965
446	F5223	Display Motorola G5G 2023 ORIG	Display compatible con: G5G	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.233	2025-08-27 12:27:56.97
448	KL-HD065-G10+F	Display Motorola G10/G20/G30 INCELL300+ C/M	Display compatible con: G10/G20/G30	\N	\N	\N	\N	41	\N	\N	300	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.247	2025-10-22 22:53:38.348
449	KL-HD065-G8M+F	Display Motorola G8POWER LITE INCELL300+	Display compatible con: G8POWER	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.257	2025-08-27 12:27:56.993
450	KL-HD065-G31	Display Motorola G31/G41/G71 INCELL300+ S/M	Display compatible con: G31/G41/G71	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.264	2025-08-27 12:27:56.997
451	F2215+F	Display Motorola G STYLUS 2021	Display compatible con: G	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.274	2025-08-27 12:27:57.003
452	F0040+F	Display Motorola G PURE 4G	Display compatible con: G	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.283	2025-08-27 12:27:57.011
453	F2224+F	Display Motorola G POWER 2022	Display compatible con: G	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.289	2025-08-27 12:27:57.019
454	F2225+F	Display Motorola G STYLUS 2022	Display compatible con: G	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.296	2025-08-27 12:27:57.024
455	F5222+F	Display Motorola G5G 2022 4G	Display compatible con: G5G	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.303	2025-08-27 12:27:57.028
456	F0009+F	Display Motorola G5G ORIG C/M(BOUTIQUE)	Display compatible con: G5G	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.309	2025-08-27 12:27:57.034
457	F0040	Display Motorola G PURE 4G	Display compatible con: G	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.315	2025-08-27 12:27:57.039
458	F0388	Display Motorola G PLAY 2021	Display compatible con: G	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.324	2025-08-27 12:27:57.043
459	F2225	Display Motorola G STYLUS 2022	Display compatible con: G	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.333	2025-08-27 12:27:57.054
460	F2215	Display Motorola G STYLUS 2021	Display compatible con: G	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.339	2025-08-27 12:27:57.061
461	F0009	Display Motorola G5G/ONE 5G ACE	Display compatible con: G5G/ONE	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.347	2025-08-27 12:27:57.067
462	F2224	Display Motorola G POWER 2022	Display compatible con: G	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.354	2025-08-27 12:27:57.072
463	F5222	Display Motorola G5G 2022 4G	Display compatible con: G5G	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.369	2025-08-27 12:27:57.077
464	F0034	Display Motorola G34 ORIG S/M	Display compatible con: G34	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.376	2025-08-27 12:27:57.081
465	F0444+F	Display Motorola G04/G04S/E14 ORIG C/M(BOUTIQUE)	Display compatible con: G04/G04S/E14	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.383	2025-08-27 12:27:57.085
466	F0024+F	Display Motorola G24/G24 POWER ORIG	Display compatible con: G24/G24	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.389	2025-08-27 12:27:57.094
467	F0024	Display Motorola E14/G04/G04S/G24/G24 POWER ORIG	Display compatible con: E14/G04/G04S/G24/G24	\N	\N	\N	\N	41	\N	\N	190	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.394	2025-11-05 22:23:26.837
468	F0733	Display Motorola G31/G41/G71 INCELL S/M	Display compatible con: G31/G41/G71	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.407	2025-08-27 12:27:57.111
469	F0042+F	Display Motorola G42 INCELL C/M(BOUTIQUE)	Display compatible con: G42	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.417	2025-08-27 12:27:57.114
470	F0733+F	Display Motorola G31 INCELL C/M(BOUTIQUE)	Display compatible con: G31	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.422	2025-08-27 12:27:57.118
471	F0177+F	Display Motorola G71 INCELL BOUTIQUE	Display compatible con: G71	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.43	2025-08-27 12:27:57.122
472	F1411+F	Display Motorola G41 INCELL C/M(BOUTIQUE)	Display compatible con: G41	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.439	2025-08-27 12:27:57.13
473	F0808	Display Motorola G53 ORIG S/M	Display compatible con: G53	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.447	2025-08-27 12:27:57.136
474	F4455+F/H	Display Motorola G8 PLAY/ONE MACRO	Display compatible con: G8	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.458	2025-08-27 12:27:57.145
475	F4455+F	Display Motorola G8 PLAY/ONE MACRO	Display compatible con: G8	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.463	2025-08-27 12:27:57.149
476	F5544+F	Display Motorola G54/G55/G64 ORIG C/M(BOUTIQUE)	Display compatible con: G54/G55/G64	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.472	2025-08-27 12:27:57.159
477	F8844	Display Motorola G84 AMOLED ORIG	Display compatible con: G84	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.486	2025-08-27 12:27:57.163
478	F7373+F	Display Motorola G73 5G ORIG	Display compatible con: G73	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.494	2025-08-27 12:27:57.172
479	F1144	Display Motorola G14/G54/G55/G64 ORIG S/M	Display compatible con: G14/G54/G55/G64	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.501	2025-08-27 12:27:57.178
480	F1144+F	Display Motorola G14 ORIG C/M(BOUTIQUE)	Display compatible con: G14	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.507	2025-08-27 12:27:57.184
481	F044	Display Motorola G6 ORIG S/M	Display compatible con: G6	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.513	2025-08-27 12:27:57.189
482	F0522+F	Display Motorola G52/G71S/G82 INCELL C/M(BOUTIGUE)	Display compatible con: G52/G71S/G82	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.527	2025-08-27 12:27:57.193
483	F0929	Display Motorola G10 PLAY/G POWER	Display compatible con: G10	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.535	2025-08-27 12:27:57.197
484	F0808+F	Display Motorola G53 ORIG C/M(BOUTIQUE)	Display compatible con: G53	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.542	2025-08-27 12:27:57.201
485	F0506+F	Display Motorola G7PLAY ORIG C/M(BOUTIQUE)	Display compatible con: G7PLAY	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.548	2025-08-27 12:27:57.208
486	F0233+F	Display Motorola G8POWER LITE ORIG	Display compatible con: G8POWER	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.555	2025-08-27 12:27:57.22
487	F0059-N	Display Motorola G6PLAY/E5 ORIG S/M	Display compatible con: G6PLAY/E5	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.567	2025-08-27 12:27:57.227
488	F5040+F	Display Motorola G50 4G ORIG	Display compatible con: G50	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.575	2025-08-27 12:27:57.236
440	F2002+F	Display Motorola EDGE20 LITE AMOLED	Display compatible con: EDGE20	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.189	2025-08-27 12:27:57.242
441	F6767	Display Motorola G72/G52/G71S/G82/EDGE30 AMOLED S/M	Display compatible con: G72/G52/G71S/G82/EDGE30	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.196	2025-08-27 12:27:56.947
447	KL-HD065-G9+F	Display Motorola G9 PLAY INCELL300+	Display compatible con: G9	\N	\N	\N	\N	41	\N	\N	170	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.239	2025-11-22 20:07:42.775
492	F0819+F	Display Motorola G22 ORIG C/M(BOUTIQUE)	Display compatible con: G22	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.604	2025-08-27 12:27:57.257
493	F4455	Display Motorola G8PLAY/ONE MACRO ORIG	Display compatible con: G8PLAY/ONE	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.614	2025-08-27 12:27:57.263
494	F0002+F	Display Motorola G60S ORIG C/M(BOUTIQUE)	Display compatible con: G60S	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.621	2025-08-27 12:27:57.268
495	F4027+F	Display Motorola G13/G23 ORIG C/M(BOUTIQUE)	Display compatible con: G13/G23	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.629	2025-08-27 12:27:57.272
497	F0949+F	Display Motorola G9PLUS ORIG C/M(BOUTIQUE)	Display compatible con: G9PLUS	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.654	2025-08-27 12:27:57.282
498	F6767+F	Display Motorola G72 AMOLED C/M	Display compatible con: G72	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.662	2025-08-27 12:27:57.287
499	F4027	Display Motorola G13/G23 ORIG S/M	Display compatible con: G13/G23	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.671	2025-08-27 12:27:57.292
500	F3785+F	Display Motorola G50 5G ORIG	Display compatible con: G50	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.68	2025-08-27 12:27:57.303
501	F2397+F	Display Motorola G71 OLED C/M（BOUTIQUE）	Display compatible con: G71	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.687	2025-08-27 12:27:57.309
502	F0470+F	Display Motorola G41 OLED C/M(BOUTIGUE)	Display compatible con: G41	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.693	2025-08-27 12:27:57.314
503	F0310+F	Display Motorola G31 OLED C/M(BOUTIQUE)	Display compatible con: G31	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.7	2025-08-27 12:27:57.317
504	F0279+F	Display Motorola G52 AMOLED C/M	Display compatible con: G52	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.704	2025-08-27 12:27:57.323
505	F3874+F	Display Motorola G42 OLED C/M(BOUTIQUE)	Display compatible con: G42	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.709	2025-08-27 12:27:57.326
506	F0840+F	Display Motorola G8POWER ORIG C/M（BOUTIQUE）	Display compatible con: G8POWER	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.721	2025-08-27 12:27:57.332
507	F1022+F	Display Motorola G60 ORIG C/M(BOUTIQUE)	Display compatible con: G60	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.731	2025-08-27 12:27:57.338
508	F3874	Display Motorola G42 OLED S/M	Display compatible con: G42	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.739	2025-08-27 12:27:57.345
509	F6062	Display Motorola G62 ORIG S/M	Display compatible con: G62	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.75	2025-08-27 12:27:57.35
510	F0532	Display Motorola G32/G73 ORIG S/M	Display compatible con: G32/G73	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.764	2025-08-27 12:27:57.356
511	F0310	Display Motorola G31/G41/G71 OLED S/M	Display compatible con: G31/G41/G71	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.773	2025-08-27 12:27:57.362
512	F0230	Display Motorola G8PLUS ORIG S/M	Display compatible con: G8PLUS	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.782	2025-08-27 12:27:57.366
513	F0013	Display Motorola G8 ORIG S/M	Display compatible con: G8	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.788	2025-08-27 12:27:57.371
514	F0025	Display Motorola G6PLUS ORIG S/M	Display compatible con: G6PLUS	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.8	2025-08-27 12:27:57.378
515	F0200	Display Motorola G200 5G/EDGE 2021	Display compatible con: G200	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.81	2025-08-27 12:27:57.383
516	F0725	Display Motorola G100/EDGE S ORIG	Display compatible con: G100/EDGE	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.817	2025-08-27 12:27:57.388
518	F3785	Display Motorola G50 5G ORIG	Display compatible con: G50	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.835	2025-08-27 12:27:57.393
519	F0949	Display Motorola G9PLUS ORIG S/M	Display compatible con: G9PLUS	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.846	2025-08-27 12:27:57.399
520	F0819	Display Motorola G22/E22S/E32/E32S ORIG S/M	Display compatible con: G22/E22S/E32/E32S	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.856	2025-08-27 12:27:57.405
521	F1010	Display Motorola G20/G10/G30 ORIG S/M	Display compatible con: G20/G10/G30	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.866	2025-08-27 12:27:57.41
522	F0840	Display Motorola G8POWER ORIG S/M	Display compatible con: G8POWER	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.877	2025-08-27 12:27:57.415
523	F7777	Display Motorola G9POWER ORIG S/M	Display compatible con: G9POWER	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.89	2025-08-27 12:27:57.423
524	F0233	Display Motorola G8POWER LITE ORIG	Display compatible con: G8POWER	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.898	2025-08-27 12:27:57.43
525	F0014	Display Motorola G7/G7PLUS ORIG S/M	Display compatible con: G7/G7PLUS	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.907	2025-08-27 12:27:57.435
526	F0059-O	Display Motorola G6PLAY/E5 ORIG S/M	Display compatible con: G6PLAY/E5	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.916	2025-08-27 12:27:57.44
527	F0506	Display Motorola G7PLAY ORIG S/M	Display compatible con: G7PLAY	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.933	2025-08-27 12:27:57.445
528	F0066	Display Motorola G7POWER ORIG S/M	Display compatible con: G7POWER	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.944	2025-08-27 12:27:57.453
529	F0001-N	Display Motorola ONE FUSION PLUS	Display compatible con: ONE	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.955	2025-08-27 12:27:57.461
530	F0410+F	Display Motorola ONE ORIG C/M(BOUTIQUE)	Display compatible con: ONE	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.963	2025-08-27 12:27:57.468
531	F0666	Display Motorola ONE ZOOM/XT2010 OLED	Display compatible con: ONE	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.973	2025-08-27 12:27:57.473
532	F0862	Display Motorola ONE FUSION ORIG	Display compatible con: ONE	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.981	2025-08-27 12:27:57.478
533	F0909	Display Motorola ONE HYPER/XT2027 ORIG	Display compatible con: ONE	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.99	2025-08-27 12:27:57.486
534	F0720	Display Motorola ONE VISION/ONE ATION	Display compatible con: ONE	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.997	2025-08-27 12:27:57.493
535	F0001-B	Display Motorola ONE FUSION PLUS	Display compatible con: ONE	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:08.007	2025-08-27 12:27:57.501
536	F0410	Display Motorola ONE ORIG S/M	Display compatible con: ONE	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:08.013	2025-08-27 12:27:57.509
537	F0404	Display Motorola X4 ORIG S/M	Display compatible con: X4	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:08.021	2025-08-27 12:27:57.516
538	F0750-B	Display Motorola Z2 PLAY OLED	Display compatible con: Z2	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:08.028	2025-08-27 12:27:57.521
490	F0230+F	Display Motorola G8PLUS ORIG C/M(BOUTIQUE)	Display compatible con: G8PLUS	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.587	2025-08-27 12:27:57.527
491	F0456+F	Display Motorola G9PLAY/E7PLUS ORIG C/M(BOUTIQUE)	Display compatible con: G9PLAY/E7PLUS	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.593	2025-08-27 12:27:57.248
1029	tapa_andorid_2	Tapa Android 2	\N	\N	\N	\N	1	47	141	\N	0	0	1	0	0	PRODUCTO	2025-09-01 17:50:36.166	2025-09-01 17:50:36.165
542	N0100	Display Nokia G10/G20 ORIG S/M	Display compatible con: G10/G20	\N	\N	\N	\N	52	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:38:37.062	2025-08-27 12:27:57.541
543	E0100	Display OnePlus 1+N10 ORIG S/M	Display compatible con: 1+N10	\N	\N	\N	\N	39	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:40:50.325	2025-08-27 12:27:57.549
545	TC100	Display OnePlus 1+N10 ORIG S/M	Display compatible con: 1+N10	\N	\N	\N	\N	39	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:40:50.351	2025-08-27 12:27:57.558
546	KL-HD065-A16	Display Oppo A16/A16S/A54S/Realme C25/RealmeC25S/NARZO50A INCELL300+S/M	Display compatible con: A16/A16S/A54S/Realme	\N	\N	\N	\N	46	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:43:52.597	2025-08-27 12:27:57.562
547	KL-HD064-R7	Display Oppo "RENO7 4G(5G)/A78 4G/RENO7SE	Display compatible con: "RENO7	\N	\N	\N	\N	46	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:43:52.61	2025-08-27 12:27:57.568
549	KL-HD065-A57	Display Oppo "A17/A17K//A38/A57/A57S/A57E/A58 5G/A58X 5G/	Display compatible con: "A17/A17K//A38/A57/A57S/A57E/A58	\N	\N	\N	\N	46	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:43:52.625	2025-08-27 12:27:57.577
550	KL-HD065-A92	Display Oppo A52/A72/A92 INCELL300+ S/M	Display compatible con: A52/A72/A92	\N	\N	\N	\N	46	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:43:52.64	2025-08-27 12:27:57.581
551	KL-HD065-C21	Display Oppo C21Y/C25Y INCELL S/M	Display compatible con: C21Y/C25Y	\N	\N	\N	\N	46	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:43:52.65	2025-08-27 12:27:57.588
552	KL-HD067-C53	Display Oppo C53/Narzo N53/C51/C36/C60/NOTE50 INCELL	Display compatible con: C53/Narzo	\N	\N	\N	\N	46	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:43:52.659	2025-08-27 12:27:57.595
553	KL-HD065-P32	Display Oppo A53 4G/1+N100/A32/A33/A53S/A11S/ REALME7I/REALME	Display compatible con: A53	\N	\N	\N	\N	46	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:43:52.668	2025-08-27 12:27:57.599
554	KL-HD065-A11	Display Oppo "A5 2020//A8/A11/A11X/A31/A9 2020	Display compatible con: "A5	\N	\N	\N	\N	46	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:43:52.678	2025-08-27 12:27:57.606
555	P0934	Display Oppo A93 4G INCELL	Display compatible con: A93	\N	\N	\N	\N	46	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:43:52.687	2025-08-27 12:27:57.62
556	P0015+F	Display Oppo A15/A15S/A16K ORIG C/M(BOUTIQUE)	Display compatible con: A15/A15S/A16K	\N	\N	\N	\N	46	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:43:52.697	2025-08-27 12:27:57.625
557	C0011+F	Display Oppo C11 2021/C20/C21 ORIG	Display compatible con: C11	\N	\N	\N	\N	46	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:43:52.709	2025-08-27 12:27:57.631
558	P0157+F	Display Oppo A17/A17K ORIG C/M(BOUTIQUE)	Display compatible con: A17/A17K	\N	\N	\N	\N	46	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:43:52.716	2025-08-27 12:27:57.635
559	C3003+F	Display Oppo C30S ORIG C/M_NEGRO	Display compatible con: C30S	\N	\N	\N	\N	46	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:43:52.723	2025-08-27 12:27:57.637
560	P0092+F	Display Oppo A52/A72/A92 4G ORIG	Display compatible con: A52/A72/A92	\N	\N	\N	\N	46	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:43:52.732	2025-08-27 12:27:57.642
561	P0935+F	Display Oppo A93 5G ORIG	Display compatible con: A93	\N	\N	\N	\N	46	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:43:52.739	2025-08-27 12:27:57.645
562	C0303+F	Display Oppo c30/C33 ORIG C/M(BOUTIQUE)	Display compatible con: c30/C33	\N	\N	\N	\N	46	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:43:52.749	2025-08-27 12:27:57.65
563	P0053+F	Display Oppo A32/A33/A53 4G ORIG	Display compatible con: A32/A33/A53	\N	\N	\N	\N	46	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:43:52.756	2025-08-27 12:27:57.659
564	P0016+F	Display Oppo A16 ORIG C/M(BOUTIQUE)	Display compatible con: A16	\N	\N	\N	\N	46	\N	\N	210	0	\N	10	1	PRODUCTO	2025-08-26 22:43:52.765	2025-10-27 23:03:42.35
565	P0054+F	Display Oppo A54 4G ORIG	Display compatible con: A54	\N	\N	\N	\N	46	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:43:52.772	2025-08-27 12:27:57.666
566	P0584+F	Display Oppo A58 4G ORIG	Display compatible con: A58	\N	\N	\N	\N	46	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:43:52.78	2025-08-27 12:27:57.669
567	C0035+F	Display Oppo C35 ORIG C/M(BOUTIQUE)	Display compatible con: C35	\N	\N	\N	\N	46	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:43:52.788	2025-08-27 12:27:57.672
568	C0021+F	Display Oppo C21Y ORIG C/M(BOUTIQUE)	Display compatible con: C21Y	\N	\N	\N	\N	46	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:43:52.794	2025-08-27 12:27:57.675
569	C0750	Display Oppo "REALME7 5G/A72 5G/A73	Display compatible con: "REALME7	\N	\N	\N	\N	46	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:43:52.805	2025-08-27 12:27:57.682
570	C0008	Display Oppo 8I/9i ORIG S/M	Display compatible con: 8I/9i	\N	\N	\N	\N	46	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:43:52.813	2025-08-27 12:27:57.685
571	C0053	Display Oppo C51/C51S/C53/Narzo N53/C36/C60/Note50 ORIG	Display compatible con: C51/C51S/C53/Narzo	\N	\N	\N	\N	46	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:43:52.82	2025-08-27 12:27:57.69
572	C3003	Display Oppo C30S ORIG S/M	Display compatible con: C30S	\N	\N	\N	\N	46	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:43:52.829	2025-08-27 12:27:57.696
573	P1212	Display Oppo A12/A7/A7n/A5S/Ax5S/A11K/A12s/Realme3/Realme3i ORIG S/M	Display compatible con: A12/A7/A7n/A5S/Ax5S/A11K/A12s/Realme3/Realme3i	\N	\N	\N	\N	46	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:43:52.839	2025-08-27 12:27:57.7
574	C3300/C0303	Display Oppo c30/C30i/C33/C50i ORIG S/M	Display compatible con: c30/C30i/C33/C50i	\N	\N	\N	\N	46	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:43:52.851	2025-08-27 12:27:57.703
575	C0021	Display Oppo C21Y/C25Y ORIG S/M	Display compatible con: C21Y/C25Y	\N	\N	\N	\N	46	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:43:52.86	2025-08-27 12:27:57.71
576	C0035	Display Oppo C35/narzo50A/prime C3/prime C5	Display compatible con: C35/narzo50A/prime	\N	\N	\N	\N	46	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:43:52.868	2025-08-27 12:27:57.713
577	C0011	Display Oppo C11 2021/C20/C21 ORIG	Display compatible con: C11	\N	\N	\N	\N	46	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:43:52.875	2025-08-27 12:27:57.717
578	C0055/P0584	Display Oppo "A1 5G/A2 5G/REALME	Display compatible con: "A1	\N	\N	\N	\N	46	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:43:52.883	2025-08-27 12:27:57.719
579	C0003	Display Oppo "A5 2020/A8/A11/A11X/A9 2020/realme5/realme5i/realme5s/A31	Display compatible con: "A5	\N	\N	\N	\N	46	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:43:52.891	2025-08-27 12:27:57.721
580	P0935	Display Oppo A93 5G ORIG	Display compatible con: A93	\N	\N	\N	\N	46	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:43:52.898	2025-08-27 12:27:57.724
581	P0092	Display Oppo A52 4G/A72 4G/A92	Display compatible con: A52	\N	\N	\N	\N	46	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:43:52.906	2025-08-27 12:27:57.729
582	C0077	Display Oppo "REALME6/REALME7/REALME6S/REALME6I IZQUIERDO/NARZO20 PRO/NARZO30	Display compatible con: "REALME6/REALME7/REALME6S/REALME6I	\N	\N	\N	\N	46	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:43:52.914	2025-08-27 12:27:57.737
583	P0157	Display Oppo "A17/A17K//A38/A57/A57S/A57E/A58 5G/A58X 5G/	Display compatible con: "A17/A17K//A38/A57/A57S/A57E/A58	\N	\N	\N	\N	46	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:43:52.922	2025-08-27 12:27:57.742
584	P0054	Display Oppo A54 4G/A55 4G/A94	Display compatible con: A54	\N	\N	\N	\N	46	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:43:52.93	2025-08-27 12:27:57.744
585	P0053	Display Oppo A53 4G/1+N100/A32/A33/A53S/A11S/ REALME7I/REALME	Display compatible con: A53	\N	\N	\N	\N	46	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:43:52.938	2025-08-27 12:27:57.746
540	F0750-N	Display Motorola Z2 PLAY OLED	Display compatible con: Z2	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:08.048	2025-08-27 12:27:57.749
541	F0097	Display Motorola Z PLAY OLED	Display compatible con: Z	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:08.054	2025-08-27 12:27:57.533
544	E0100+F	Display OnePlus 1+N10 ORIG C/M	Display compatible con: 1+N10	\N	\N	\N	\N	39	\N	\N	220	1	\N	10	1	PRODUCTO	2025-08-26 22:40:50.343	2025-10-28 21:52:40.596
589	P0055	Display Oppo "RENO5 LITE /RENO6	Display compatible con: "RENO5	\N	\N	\N	\N	46	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:43:52.975	2025-08-27 12:27:57.757
590	P0074+F	Display Oppo Reno7 4G OLED	Display compatible con: Reno7	\N	\N	\N	\N	46	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:43:52.984	2025-08-27 12:27:57.762
591	P0066+F	Display Oppo Reno6 LITE OLED	Display compatible con: Reno6	\N	\N	\N	\N	46	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:43:52.993	2025-08-27 12:27:57.764
592	P0095+F	Display Oppo Reno5 LITE OLED	Display compatible con: Reno5	\N	\N	\N	\N	46	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:43:52.999	2025-08-27 12:27:57.767
593	P0074	Display Oppo "RENO7 4G(5G)/RENO7SE 5G/RENO8	Display compatible con: "RENO7	\N	\N	\N	\N	46	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:43:53.009	2025-08-27 12:27:57.77
594	P0066	Display Oppo "RENO6 LITE/RENO7 LITE	Display compatible con: "RENO6	\N	\N	\N	\N	46	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:43:53.02	2025-08-27 12:27:57.774
595	P0095	Display Oppo RENO5 LITE/RENO 4SE/RENO	Display compatible con: RENO5	\N	\N	\N	\N	46	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:43:53.028	2025-08-27 12:27:57.778
596	P0075	Display Oppo "RENO5 4G(5G)/ RENO5K/RENO6	Display compatible con: "RENO5	\N	\N	\N	\N	46	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:43:53.037	2025-08-27 12:27:57.78
597	P0115	Display Oppo RENO11 5G AMOLED	Display compatible con: RENO11	\N	\N	\N	\N	46	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:43:53.045	2025-08-27 12:27:57.782
598	P0010	Display Oppo RENO9/RENO10 5G/RENO8T 5G/A1	Display compatible con: RENO9/RENO10	\N	\N	\N	\N	46	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:43:53.055	2025-08-27 12:27:57.783
599	C0088	Display Oppo REALME7 PRO 04	Display compatible con: REALME7	\N	\N	\N	\N	46	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:43:53.066	2025-08-27 12:27:57.785
600	T1166+F	Display Samsung A06/A065 ORIG C/M(BOUTIQUE)	Display compatible con: A06/A065	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:15.513	2025-08-27 12:27:57.787
601	T1166	Display Samsung A06/A065 ORIG S/M	Display compatible con: A06/A065	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:15.527	2025-08-27 12:27:57.789
602	T0555+F	Display Samsung A55 OLED C/M(BOUTIQUE)	Display compatible con: A55	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:15.537	2025-08-27 12:27:57.791
603	T0035+F	Display Samsung A35 OLED C/M(BOUTIQUE)	Display compatible con: A35	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:15.544	2025-08-27 12:27:57.795
604	T0055	Display Samsung A30 OLED S/M（BOUTIQUE)	Display compatible con: A30	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:15.556	2025-08-27 12:27:57.798
605	KL-HD064-A15	Display Samsung A15 4G(5G) INCELL300+S/M	Display compatible con: A15	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:15.576	2025-08-27 12:27:57.802
606	KL-HD064-A24	Display Samsung A24/A24 4G/A25 5G/M34	Display compatible con: A24/A24	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:15.59	2025-08-27 12:27:57.804
607	T3377+F	Display Samsung A037U ORIG C/M	Display compatible con: A037U	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:15.6	2025-08-27 12:27:57.806
608	T4444+F	Display Samsung A02 ORIG C/M	Display compatible con: A02	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:15.612	2025-08-27 12:27:57.81
609	T1012+F	Display Samsung A03S ORIG C/M(BOUTIQUE)	Display compatible con: A03S	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:15.622	2025-08-27 12:27:57.813
610	T0424	Display Samsung A32 4G INCELL	Display compatible con: A32	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:15.63	2025-08-27 12:27:57.819
611	KL-HD064-A11+F	Display Samsung A11 INCELL300+ C/M	Display compatible con: A11	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:15.638	2025-08-27 12:27:57.822
612	KL-HD062-A30S+F	Display Samsung A30S INCELL300+ C/M	Display compatible con: A30S	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:15.655	2025-08-27 12:27:57.824
613	KL-HD062-A10+F	Display Samsung A10/M10 INCELL300+ C/M	Display compatible con: A10/M10	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:15.667	2025-08-27 12:27:57.826
614	KL-HD065-A03+F	Display Samsung A03 INCELL300+ C/M	Display compatible con: A03	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:15.677	2025-08-27 12:27:57.83
615	KL-HD065-A02S+F	Display Samsung A02S INCELL300+ C/M	Display compatible con: A02S	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:15.687	2025-08-27 12:27:57.836
616	KL-HD064-A11	Display Samsung A11/M11/A115 INCELL 300+	Display compatible con: A11/M11/A115	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:15.705	2025-08-27 12:27:57.84
617	KL-HD062-A30	Display Samsung A30/A50/A50S INCELL300+ S/M	Display compatible con: A30/A50/A50S	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:15.713	2025-08-27 12:27:57.843
618	T0424+F	Display Samsung A32 4G INCELL	Display compatible con: A32	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:15.722	2025-08-27 12:27:57.847
619	KL-HD065-M12+F	Display Samsung A12 INCELL300+ C/M(BOUTIQUE)	Display compatible con: A12	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:15.731	2025-08-27 12:27:57.85
620	KL-HD066-A21	Display Samsung A21S INCELL300+ C/M	Display compatible con: A21S	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:15.743	2025-08-27 12:27:57.857
621	KL-HD066-A72	Display Samsung A72/A725 INCELL300+ S/M	Display compatible con: A72/A725	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:15.755	2025-08-27 12:27:57.862
622	KL-HD066-A71	Display Samsung A71/A715 INCELL300+ S/M	Display compatible con: A71/A715	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:15.765	2025-08-27 12:27:57.865
623	KL-HD062-A30S	Display Samsung A30S INCELL300+ S/M	Display compatible con: A30S	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:15.781	2025-08-27 12:27:57.868
624	KL-HD062-A10	Display Samsung A10/M10 INCELL300+ S/M	Display compatible con: A10/M10	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:15.791	2025-08-27 12:27:57.872
625	T2255+F	Display Samsung A25 OLED C/M(BOUTIQUE)	Display compatible con: A25	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:15.802	2025-08-27 12:27:57.874
627	T2222+F	Display Samsung A02S ORIG C/M(BOUTIQUE)	Display compatible con: A02S	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:15.823	2025-08-27 12:27:57.879
628	T3333+F	Display Samsung A03 ORIG C/M(BOUTIQUE)	Display compatible con: A03	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:15.832	2025-08-27 12:27:57.883
630	T0344+F	Display Samsung A51/A515 INCELL C/M	Display compatible con: A51/A515	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:15.848	2025-08-27 12:27:57.889
631	T0055+F	Display Samsung A30 OLED C/M（BOUTIQUE)	Display compatible con: A30	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:15.856	2025-08-27 12:27:57.894
632	T0335+F/	Display Samsung A53/A536 OLED C/M	Display compatible con: A53/A536	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:15.865	2025-08-27 12:27:57.898
633	T0901+F/	Display Samsung A52/A52S/A525 4G/A525 5G	Display compatible con: A52/A52S/A525	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:15.872	2025-08-27 12:27:57.903
587	P0015	Display Oppo "A15/A15S/A16K/A16E/A35/REALME C11 2020/REALME	Display compatible con: "A15/A15S/A16K/A16E/A35/REALME	\N	\N	\N	\N	46	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:43:52.958	2025-08-27 12:27:57.906
588	P0076	Display Oppo RENO7 4G(5G)/RENO7SE/RENO8 4G(5G)/RENO8T/1+NORD	Display compatible con: RENO7	\N	\N	\N	\N	46	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:43:52.968	2025-08-27 12:27:57.754
626	T1155+F	Display Samsung A15 4G/5G OLED	Display compatible con: A15	\N	\N	\N	\N	38	\N	\N	800	1	\N	10	1	PRODUCTO	2025-08-26 22:49:15.812	2025-11-23 19:53:29.169
637	T0550	Display Samsung A05 ORIG S/M	Display compatible con: A05	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:15.908	2025-08-27 12:27:57.914
638	T0606	Display Samsung A05S ORIG S/M	Display compatible con: A05S	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:15.915	2025-08-27 12:27:57.916
639	T0015+F	Display Samsung A20S/A207 ORIG C/M(BOUTIGQUE)	Display compatible con: A20S/A207	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:15.923	2025-08-27 12:27:57.918
640	T9181+F	Display Samsung A24 OLED C/M(BOUTIQUE)	Display compatible con: A24	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:15.935	2025-08-27 12:27:57.922
641	T0048	Display Samsung A730/A8PLUS OLED S/M	Display compatible con: A730/A8PLUS	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:15.944	2025-08-27 12:27:57.925
642	T1350	Display Samsung A04CORE/A04S/A13 5G/A136B ORIG	Display compatible con: A04CORE/A04S/A13	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:15.956	2025-08-27 12:27:57.927
643	T0190	Display Samsung A10E ORIG S/M	Display compatible con: A10E	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:15.97	2025-08-27 12:27:57.932
644	T7360+F	Display Samsung A73 5G ORIG	Display compatible con: A73	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:15.979	2025-08-27 12:27:57.934
645	T0977+F	Display Samsung A30S OLED C/M(BOUTIQUE)	Display compatible con: A30S	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:15.989	2025-08-27 12:27:57.936
646	T0023+F	Display Samsung A20 OLED C/M(BOUTIQUE)	Display compatible con: A20	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:15.998	2025-08-27 12:27:57.938
647	T0066+F	Display Samsung A50/A50S OLED C/M（BOUTIQUE)	Display compatible con: A50/A50S	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:16.006	2025-08-27 12:27:57.941
648	T0211+F	Display Samsung A21S ORIG C/M	Display compatible con: A21S	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:16.013	2025-08-27 12:27:57.944
649	T0069	Display Samsung A10/M10 ORIG S/M	Display compatible con: A10/M10	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:16.023	2025-08-27 12:27:57.948
650	T0069+F	Display Samsung A10/M10 ORIG C/M(BOUTIQUE)	Display compatible con: A10/M10	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:16.031	2025-08-27 12:27:57.952
651	T0756+F	Display Samsung A31/A315 OLED C/M(BOUTIQUE)	Display compatible con: A31/A315	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:16.04	2025-08-27 12:27:57.954
652	T1022+F	Display Samsung A22 4G OLED	Display compatible con: A22	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:16.048	2025-08-27 12:27:57.958
653	T4607+F	Display Samsung A54 OLED C/M(BOUTIQUE)	Display compatible con: A54	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:16.057	2025-08-27 12:27:57.961
654	T0102	Display Samsung A30S INCELL S/M	Display compatible con: A30S	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:16.068	2025-08-27 12:27:57.964
655	T9090+F	Display Samsung A34 5G ORIG	Display compatible con: A34	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:16.075	2025-08-27 12:27:57.971
656	T0115+F	Display Samsung A22 5G ORIG	Display compatible con: A22	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:16.082	2025-08-27 12:27:57.975
657	T1460+F	Display Samsung A14 5G/A146B ORIG	Display compatible con: A14	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:16.09	2025-08-27 12:27:57.978
658	T0334+F	Display Samsung A71/A715 OLED C/M	Display compatible con: A71/A715	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:16.098	2025-08-27 12:27:57.985
659	T6660+F	Display Samsung A03 CORE ORIG	Display compatible con: A03	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:16.105	2025-08-27 12:27:57.988
661	T5555+F	Display Samsung A04 ORIG C/M	Display compatible con: A04	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:16.117	2025-08-27 12:27:57.997
662	T3014+F	Display Samsung A04E ORIG C/M（BOUTIQUE)	Display compatible con: A04E	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:16.123	2025-08-27 12:27:57.999
663	T1305+F	Display Samsung A23 4G ORIG	Display compatible con: A23	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:16.131	2025-08-27 12:27:58.004
664	T0725+F	Display Samsung A72/A725 OLED C/M	Display compatible con: A72/A725	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:16.137	2025-08-27 12:27:58.007
665	T0335+F	Display Samsung A53/A536 OLED ORIG	Display compatible con: A53/A536	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:16.146	2025-08-27 12:27:58.015
666	T7799+F	Display Samsung A33 OLED C/M	Display compatible con: A33	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:16.158	2025-08-27 12:27:58.02
667	T1460	Display Samsung A14 5G/A146B ORIG	Display compatible con: A14	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:16.172	2025-08-27 12:27:58.025
668	T0006	Display Samsung "A13/A13 4G/A13 LITE/	Display compatible con: "A13/A13	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:16.179	2025-08-27 12:27:58.028
669	T3014	Display Samsung A04E ORIG S/M	Display compatible con: A04E	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:16.191	2025-08-27 12:27:58.03
670	T5555	Display Samsung A04/A045 ORIG S/M	Display compatible con: A04/A045	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:16.202	2025-08-27 12:27:58.035
671	T6660	Display Samsung A03 CORE ORIG	Display compatible con: A03	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:16.212	2025-08-27 12:27:58.038
672	T0002+F	Display Samsung A22 4G INCELL	Display compatible con: A22	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:16.227	2025-08-27 12:27:58.043
673	T0333+F	Display Samsung A51/A515 OLED ORIG	Display compatible con: A51/A515	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:16.234	2025-08-27 12:27:58.045
675	T0987+F	Display Samsung A70/A70S OLED C/M（BOUTIQUE)	Display compatible con: A70/A70S	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:16.261	2025-08-27 12:27:58.05
676	T0901+F	Display Samsung A52/A52S/A525 OLED C/M（BOUTIQUE)	Display compatible con: A52/A52S/A525	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:16.268	2025-08-27 12:27:58.056
677	T1032+F	Display Samsung A32 4G OLED	Display compatible con: A32	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:16.275	2025-08-27 12:27:58.06
678	T0005+F	Display Samsung A31/A315 INCELL C/M	Display compatible con: A31/A315	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:16.284	2025-08-27 12:27:58.062
679	T0234+F	Display Samsung A20 INCELL C/M	Display compatible con: A20	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:16.292	2025-08-27 12:27:58.064
680	T0115	Display Samsung A22 5G ORIG	Display compatible con: A22	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:16.299	2025-08-27 12:27:58.067
681	T0015	Display Samsung A20S/A207 ORIG S/M	Display compatible con: A20S/A207	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:16.305	2025-08-27 12:27:58.069
682	T0180	Display Samsung A10S/A107 ORIG S/M	Display compatible con: A10S/A107	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:16.315	2025-08-27 12:27:58.071
683	T0052	Display Samsung A01M ORIG S/M	Display compatible con: A01M	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:16.323	2025-08-27 12:27:58.077
635	T1440	Display Samsung A14 4G/A145P ORIG	Display compatible con: A14	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:15.891	2025-08-27 12:27:58.08
636	T1212+F	Display Samsung A12 ORIG C/M(BOUTIQUE)	Display compatible con: A12	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:15.899	2025-08-27 12:27:57.908
1034	Au123	Audífonos unicornio rosa	\N	\N	\N	\N	1	59	1096	\N	0	0	31	0	0	PRODUCTO	2025-09-05 17:20:23.92	2025-09-05 17:20:23.919
660	T0006+F	Display Samsung A13 4G ORIG	Display compatible con: A13	\N	\N	\N	\N	38	\N	\N	260	1	\N	10	1	PRODUCTO	2025-08-26 22:49:16.11	2025-10-28 22:24:52.885
687	T1212	Display Samsung A02/A12/A32 5G/M02/M127/F12 ORIG	Display compatible con: A02/A12/A32	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:16.375	2025-08-27 12:27:58.092
688	KL-HD057-SJ6	Display Samsung J6 INCELL300+S/M NEGRO	Display compatible con: J6	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:16.382	2025-08-27 12:27:58.097
689	KL-HD055-J7PA/N	Display Samsung J7 PRIME INCELL300+	Display compatible con: J7	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:16.395	2025-08-27 12:27:58.099
690	KL-HD055-J7PA/B	Display Samsung J7 PRIME INCELL300+	Display compatible con: J7	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:16.403	2025-08-27 12:27:58.103
691	KL-HD050-J5P-B	Display Samsung J5 PRIME INCELL300+	Display compatible con: J5	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:16.411	2025-08-27 12:27:58.105
692	KL-HD050-J5P-N	Display Samsung J5 PRIME INCELL300+	Display compatible con: J5	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:16.418	2025-08-27 12:27:58.11
693	KL-HD060-J8	Display Samsung J8 INCELL300+ S/M	Display compatible con: J8	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:16.427	2025-08-27 12:27:58.113
694	T0790-N	Display Samsung J7 PRIME INCELL	Display compatible con: J7	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:16.437	2025-08-27 12:27:58.116
695	T0790-B	Display Samsung J7 PRIME INCELL	Display compatible con: J7	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:16.448	2025-08-27 12:27:58.12
696	T0028	Display Samsung J8 INCELL S/M	Display compatible con: J8	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:16.457	2025-08-27 12:27:58.125
697	T0209-O	Display Samsung J730/J7PRO INCELL S/M	Display compatible con: J730/J7PRO	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:16.465	2025-08-27 12:27:58.133
698	T0209-N	Display Samsung J730/J7PRO INCELL S/M	Display compatible con: J730/J7PRO	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:16.474	2025-08-27 12:27:58.137
699	T0089	Display Samsung J530/J5PRO OLED S/M	Display compatible con: J530/J5PRO	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:16.481	2025-08-27 12:27:58.139
700	T0907	Display Samsung J8 OLED S/M	Display compatible con: J8	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:16.49	2025-08-27 12:27:58.141
701	T0092	Display Samsung J6 OLED S/M	Display compatible con: J6	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:16.498	2025-08-27 12:27:58.144
702	T0043	Display Samsung J5 OLED S/M	Display compatible con: J5	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:16.508	2025-08-27 12:27:58.146
703	T0540-B	Display Samsung J5 PRIME ORIG	Display compatible con: J5	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:16.515	2025-08-27 12:27:58.148
704	T0540-N	Display Samsung J5 PRIME ORIG	Display compatible con: J5	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:16.522	2025-08-27 12:27:58.154
706	T0262	Display Samsung J4 INCELL S/M	Display compatible con: J4	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:16.545	2025-08-27 12:27:58.156
707	T7373-O	Display Samsung J730/J7PRO INCELL S/M	Display compatible con: J730/J7PRO	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:16.557	2025-08-27 12:27:58.16
708	T0019-O	Display Samsung J730/J7PRO OLED S/M	Display compatible con: J730/J7PRO	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:16.566	2025-08-27 12:27:58.163
709	T7001-O	Display Samsung J701/J7 NEO INCELL	Display compatible con: J701/J7	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:16.577	2025-08-27 12:27:58.166
710	T0101-O	Display Samsung J701/J7 NEO OLED	Display compatible con: J701/J7	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:16.587	2025-08-27 12:27:58.172
711	T0001-O	Display Samsung J7 INCELL S/M	Display compatible con: J7	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:16.599	2025-08-27 12:27:58.176
712	T0380-O	Display Samsung J7 OLED S/M	Display compatible con: J7	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:16.606	2025-08-27 12:27:58.18
713	T7373-N	Display Samsung J730/J7PRO INCELL S/M	Display compatible con: J730/J7PRO	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:16.613	2025-08-27 12:27:58.183
714	T0019-N	Display Samsung J730/J7PRO OLED S/M	Display compatible con: J730/J7PRO	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:16.623	2025-08-27 12:27:58.188
715	T7001-N	Display Samsung J701/J7 NEO INCELL	Display compatible con: J701/J7	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:16.634	2025-08-27 12:27:58.192
716	T0101-N	Display Samsung J701/J7 NEO OLED	Display compatible con: J701/J7	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:16.652	2025-08-27 12:27:58.196
717	T0001-N	Display Samsung J7 INCELL S/M	Display compatible con: J7	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:16.661	2025-08-27 12:27:58.2
718	T0380-N	Display Samsung J7 OLED S/M	Display compatible con: J7	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:16.67	2025-08-27 12:27:58.203
719	KL-HD062-M2	Display Samsung M20 INCELL300+ S/M	Display compatible con: M20	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:16.681	2025-08-27 12:27:58.208
720	KL-HD062-M30+F	Display Samsung M30 INCELL300+ C/M	Display compatible con: M30	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:16.689	2025-08-27 12:27:58.213
721	KL-HD062-M30	Display Samsung M21/M30/M30S/ M31 INCELL300+	Display compatible con: M21/M30/M30S/	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:16.697	2025-08-27 12:27:58.217
722	T1199+F	Display Samsung M14 5G/M146B ORIG	Display compatible con: M14	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:16.703	2025-08-27 12:27:58.219
723	T1199	Display Samsung M14 5G/M146B ORIG	Display compatible con: M14	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:16.716	2025-08-27 12:27:58.223
724	T5699+F	Display Samsung M53 5G OLED	Display compatible con: M53	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:16.73	2025-08-27 12:27:58.225
725	T0988	Display Samsung M30 OLED S/M	Display compatible con: M30	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:16.752	2025-08-27 12:27:58.228
726	T0926	Display Samsung M21/M30/M30S/M31 INCELL S/M	Display compatible con: M21/M30/M30S/M31	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:16.769	2025-08-27 12:27:58.232
727	T0008+F	Display Samsung M23 4G/M33 ORIG	Display compatible con: M23	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:16.788	2025-08-27 12:27:58.235
730	T2344+F	Display Samsung NOTE20 ULTRA ORIG	Display compatible con: NOTE20	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:16.851	2025-08-27 12:27:58.239
731	T3230+F	Display Samsung NOTE10 PLUS SOFT	Display compatible con: NOTE10	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:16.867	2025-08-27 12:27:58.243
732	T2750+F	Display Samsung SAMSUNG-NOTE20 OLED C/M(BOUTIQUE)	Display compatible con: SAMSUNG-NOTE20	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:16.884	2025-08-27 12:27:58.249
733	T9898+F	Display Samsung NOTE10 LITE AMOLED	Display compatible con: NOTE10	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:16.899	2025-08-27 12:27:58.253
728	SA056	Display Samsung WF HG NOTE10	Display compatible con: WF	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:16.803	2025-08-27 12:27:58.256
686	T4111	Display Samsung A11/M11/A115 ORIG S/M	Display compatible con: A11/M11/A115	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:16.366	2025-08-27 12:27:58.082
729	SA130	Display Samsung WF HG NOTE20	Display compatible con: WF	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:16.836	2025-08-27 12:27:58.258
685	T0211	Display Samsung A21S/A217 ORIG S/M	Display compatible con: A21S/A217	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:16.354	2025-08-27 12:27:58.26
745	T0022/S	Display Samsung S22 ORIG C/M(BOUTIQUE)	Display compatible con: S22	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:17.041	2025-08-27 12:27:58.268
746	T1100	Display Samsung S10 ORIG C/M(BOUTIQUE)	Display compatible con: S10	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:17.05	2025-08-27 12:27:58.27
747	T1010	Display Samsung S10 PLUS AMOLED	Display compatible con: S10	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:17.064	2025-08-27 12:27:58.273
748	T2233+F	Display Samsung S23 ULTRA SOFT	Display compatible con: S23	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:17.077	2025-08-27 12:27:58.277
749	T4595+F	Display Samsung S21 PLUS SOFT	Display compatible con: S21	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:17.094	2025-08-27 12:27:58.281
750	T6600+F	Display Samsung S22 ULTRA SOFT	Display compatible con: S22	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:17.108	2025-08-27 12:27:58.288
751	T0022	Display Samsung S22 ORIG C/M(BOUTIQUE)	Display compatible con: S22	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:17.119	2025-08-27 12:27:58.294
752	T0828+F	Display Samsung S22 PLUS ORIG	Display compatible con: S22	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:17.135	2025-08-27 12:27:58.296
753	T9999	Display Samsung S9 PLUS AMOLED	Display compatible con: S9	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:17.148	2025-08-27 12:27:58.302
754	T2220+F	Display Samsung S20 PLUS SOFT	Display compatible con: S20	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:17.16	2025-08-27 12:27:58.304
755	T8888+F	Display Samsung S8PLUS AMOLED C/M（BOUTIQUE)	Display compatible con: S8PLUS	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:17.175	2025-08-27 12:27:58.308
756	T0999+F	Display Samsung S9 AMOLED C/M（BOUTIQUE）	Display compatible con: S9	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:17.194	2025-08-27 12:27:58.31
757	T7686+F	Display Samsung S21 ULTRA "SOFT	Display compatible con: S21	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:17.204	2025-08-27 12:27:58.313
758	T2211+F	Display Samsung S20 ULTRA "SOFT	Display compatible con: S20	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:17.211	2025-08-27 12:27:58.316
759	T0888	Display Samsung S8 "AMOLED C/M(BOUTIQUE)CURVO"	Display compatible con: S8	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:17.22	2025-08-27 12:27:58.318
760	T2110+F	Display Samsung S20 FE OLED	Display compatible con: S20	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:17.238	2025-08-27 12:27:58.322
761	KL-HD065-Y50	Display Vivo Y50/1935 INCELL300+ S/M	Display compatible con: Y50/1935	\N	\N	\N	\N	54	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:56:32.19	2025-08-27 12:27:58.327
762	KL-HD065-Y30	Display Vivo Y30/Y30i INCELL300+ S/M	Display compatible con: Y30/Y30i	\N	\N	\N	\N	54	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:56:32.206	2025-08-27 12:27:58.331
763	KL-HD065-Y33	Display Vivo Y33/Y33S INCELL300+ S/M	Display compatible con: Y33/Y33S	\N	\N	\N	\N	54	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:56:32.214	2025-08-27 12:27:58.336
765	KL-HD060-Y71-N	Display Vivo Y71/Y73 INCELL300+ S/M	Display compatible con: Y71/Y73	\N	\N	\N	\N	54	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:56:32.244	2025-08-27 12:27:58.339
766	KL-HD060-Y71-B	Display Vivo Y71/Y73 INCELL300+ S/M	Display compatible con: Y71/Y73	\N	\N	\N	\N	54	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:56:32.264	2025-08-27 12:27:58.343
767	ZT021	Display Vivo V21/V25/T1 5G/T1PRO/S9E OLED	Display compatible con: V21/V25/T1	\N	\N	\N	\N	54	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:56:32.283	2025-08-27 12:27:58.347
768	K0027+F	Display Vivo V27E ORIG C/M	Display compatible con: V27E	\N	\N	\N	\N	54	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:56:32.294	2025-08-27 12:27:58.35
769	K0305+F	Display Vivo V30LITE 5G ORIG	Display compatible con: V30LITE	\N	\N	\N	\N	54	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:56:32.309	2025-08-27 12:27:58.354
770	K0365+F	Display Vivo Y36 4G ORIG	Display compatible con: Y36	\N	\N	\N	\N	54	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:56:32.329	2025-08-27 12:27:58.358
771	K0017+F	Display Vivo Y17S ORIG C/M(BOUTIQUE)	Display compatible con: Y17S	\N	\N	\N	\N	54	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:56:32.344	2025-08-27 12:27:58.363
772	K0113+F	Display Vivo Y3 ORIG C/M(BOUTIQUE)	Display compatible con: Y3	\N	\N	\N	\N	54	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:56:32.357	2025-08-27 12:27:58.369
773	K0033+F	Display Vivo Y33S 5G ORIG	Display compatible con: Y33S	\N	\N	\N	\N	54	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:56:32.368	2025-08-27 12:27:58.374
774	K2020+F	Display Vivo Y20/Y20 2021 ORIG	Display compatible con: Y20/Y20	\N	\N	\N	\N	54	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:56:32.383	2025-08-27 12:27:58.378
775	K0364	Display Vivo Y36 5G ORIG	Display compatible con: Y36	\N	\N	\N	\N	54	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:56:32.399	2025-08-27 12:27:58.382
776	K0217	Display Vivo Y17S/Y22/Y22S ORIG S/M	Display compatible con: Y17S/Y22/Y22S	\N	\N	\N	\N	54	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:56:32.408	2025-08-27 12:27:58.385
777	K0365	Display Vivo Y36 4G ORIG	Display compatible con: Y36	\N	\N	\N	\N	54	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:56:32.416	2025-08-27 12:27:58.387
778	K0025	Display Vivo V21/V25/T1 5G/T1 PRO	Display compatible con: V21/V25/T1	\N	\N	\N	\N	54	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:56:32.428	2025-08-27 12:27:58.391
779	K033S	Display Vivo Y33S/Y76S/Y76 5G/Y74S/Y33T/X2058(UNIVERSAL) ORIG	Display compatible con: Y33S/Y76S/Y76	\N	\N	\N	\N	54	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:56:32.444	2025-08-27 12:27:58.394
780	K0093	Display Vivo Y1S/Y90/Y91/Y91I/Y91C/Y93/Y93S/Y95/U1 ORIG S/M	Display compatible con: Y1S/Y90/Y91/Y91I/Y91C/Y93/Y93S/Y95/U1	\N	\N	\N	\N	54	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:56:32.454	2025-08-27 12:27:58.397
781	K0015	Display Vivo "Y01/Y02S/Y15S/Y15A/Y16/Y21/Y21A/Y21E/Y21G/Y21T/Y31S/Y32/Y33 E/Y33S" ORIG	Display compatible con: "Y01/Y02S/Y15S/Y15A/Y16/Y21/Y21A/Y21E/Y21G/Y21T/Y31S/Y32/Y33	\N	\N	\N	\N	54	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:56:32.462	2025-08-27 12:27:58.406
782	K0053	Display Vivo "Y3S 2020/Y31 2020/Y31S/Y51	Display compatible con: "Y3S	\N	\N	\N	\N	54	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:56:32.47	2025-08-27 12:27:58.412
783	K0030	Display Vivo Y30/Y30I ORIG S/M	Display compatible con: Y30/Y30I	\N	\N	\N	\N	54	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:56:32.482	2025-08-27 12:27:58.419
735	SA128	Display Samsung WF HG S22	Display compatible con: WF	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:16.917	2025-08-27 12:27:58.423
744	T2323	Display Samsung S23 ORIG C/M(BOUTIQUE)	Display compatible con: S23	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:17.034	2025-08-27 12:27:58.264
736	E013	Display Samsung WF HG S20	Display compatible con: WF	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:16.926	2025-08-27 12:27:58.429
737	E011+	Display Samsung WF HG S20	Display compatible con: WF	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:16.936	2025-08-27 12:27:58.431
738	SA129	Display Samsung WF HG S23	Display compatible con: WF	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:16.948	2025-08-27 12:27:58.436
739	E014+	Display Samsung WF HG S21	Display compatible con: WF	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:16.964	2025-08-27 12:27:58.438
740	E015	Display Samsung WF HG S21	Display compatible con: WF	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:16.978	2025-08-27 12:27:58.443
741	SA131	Display Samsung WF HG S22	Display compatible con: WF	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:16.993	2025-08-27 12:27:58.447
743	T2323/S	Display Samsung S23 ORIG C/M(BOUTIQUE)	Display compatible con: S23	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:17.021	2025-08-27 12:27:58.452
788	M0050	Display Wiko T50 ORIG S/M	Display compatible con: T50	\N	\N	\N	\N	55	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:00:21.077	2025-08-27 12:27:58.456
789	M0010	Display Wiko T10 ORIG S/M	Display compatible con: T10	\N	\N	\N	\N	55	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:00:21.096	2025-08-27 12:27:58.46
790	KL-HD065-A1+	Display Xiaomi REDMI A1+/A1/A2/A2+/POCC C50	Display compatible con: REDMI	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:04:18.374	2025-08-27 12:27:58.464
791	Z6988+F	Display Xiaomi REDMI A1/A1 PLUS/A2/A2PLUS/POCO	Display compatible con: REDMI	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:04:18.395	2025-08-27 12:27:58.466
792	Z6988	Display Xiaomi REDMI A1/A1 PLUS/A2/	Display compatible con: REDMI	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:04:18.401	2025-08-27 12:27:58.468
793	Z0202	Display Xiaomi MI A2/6X ORIG	Display compatible con: MI	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:04:18.417	2025-08-27 12:27:58.472
794	Z0003+F	Display Xiaomi REDMI A3 ORIG	Display compatible con: REDMI	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:04:18.428	2025-08-27 12:27:58.476
795	Z0003	Display Xiaomi REDMI A3 ORIG	Display compatible con: REDMI	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:04:18.441	2025-08-27 12:27:58.478
796	Z0011	Display Xiaomi MI A1/5X INCELL	Display compatible con: MI	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:04:18.456	2025-08-27 12:27:58.485
797	Z0949	Display Xiaomi MI A3 INCELL	Display compatible con: MI	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:04:18.47	2025-08-27 12:27:58.489
798	Z0634	Display Xiaomi MI A3/CC9E OLED	Display compatible con: MI	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:04:18.482	2025-08-27 12:27:58.495
799	Z0014+F	Display Xiaomi REDMI 14C ORIG	Display compatible con: REDMI	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:04:18.491	2025-08-27 12:27:58.497
800	Z0014	Display Xiaomi REDMI 14C ORIG	Display compatible con: REDMI	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:04:18.501	2025-08-27 12:27:58.5
801	KL-HD067-13C	Display Xiaomi REDMI 13C/POCO C65	Display compatible con: REDMI	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:04:18.512	2025-08-27 12:27:58.504
802	KL-HD065-9B	Display Xiaomi REDMI 9/9 PRIME	Display compatible con: REDMI	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:04:18.525	2025-08-27 12:27:58.508
803	Z3232	Display Xiaomi REDMI 12 ORIG	Display compatible con: REDMI	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:04:18.537	2025-08-27 12:27:58.513
804	Z1202+F	Display Xiaomi REDMI 12C ORIG	Display compatible con: REDMI	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:04:18.545	2025-08-27 12:27:58.515
805	Z3311	Display Xiaomi REDMI 13C/POCO C65	Display compatible con: REDMI	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:04:18.589	2025-08-27 12:27:58.517
806	Z1202	Display Xiaomi REDMI 12C ORIG	Display compatible con: REDMI	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:04:18.596	2025-08-27 12:27:58.521
807	Z0303	Display Xiaomi MI11T/MI11T PRO AMOLED	Display compatible con: MI11T/MI11T	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:04:18.602	2025-08-27 12:27:58.528
808	Z2520	Display Xiaomi MI 10 AMOLED	Display compatible con: MI	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:04:18.616	2025-08-27 12:27:58.531
809	Z0404	Display Xiaomi REDMI 8/8A ORIG	Display compatible con: REDMI	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:04:18.626	2025-08-27 12:27:58.535
810	Z0717+F	Display Xiaomi REDMI 9 ORIG	Display compatible con: REDMI	\N	\N	\N	\N	44	\N	\N	200	0	\N	10	1	PRODUCTO	2025-08-26 23:04:18.64	2025-10-31 22:20:04.165
811	Z1012	Display Xiaomi MI10 LITE OLED	Display compatible con: MI10	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:04:18.65	2025-08-27 12:27:58.539
812	Z012T	Display Xiaomi MI13T/13T PRO ORIG	Display compatible con: MI13T/13T	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:04:18.657	2025-08-27 12:27:58.541
813	Z0789	Display Xiaomi MI10T/MI10T PRO/K30S ORIG	Display compatible con: MI10T/MI10T	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:04:18.665	2025-08-27 12:27:58.544
814	Z0670	Display Xiaomi MI9 OLED S/M	Display compatible con: MI9	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:04:18.674	2025-08-27 12:27:58.547
815	Z0234	Display Xiaomi MI11 LITE 4G/5G	Display compatible con: MI11	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:04:18.686	2025-08-27 12:27:58.551
816	Z0640	Display Xiaomi MI 9T/9T PRO/K20	Display compatible con: MI	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:04:18.696	2025-08-27 12:27:58.553
817	Z0999+F	Display Xiaomi REDMI 9A/9AT/9C/10A ORIG	Display compatible con: REDMI	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:04:18.706	2025-08-27 12:27:58.555
818	Z0444	Display Xiaomi REDMI 10C/10 POWER/POCO	Display compatible con: REDMI	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:04:18.72	2025-08-27 12:27:58.557
819	Z0999	Display Xiaomi REDMI 9A/9AT/9i/9C/10A/POCO C3/POCO	Display compatible con: REDMI	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:04:18.734	2025-08-27 12:27:58.562
820	Z0717	Display Xiaomi REDMI 9/9 PRIME	Display compatible con: REDMI	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:04:18.745	2025-08-27 12:27:58.566
821	Z0667	Display Xiaomi REDMI POCO X6PRO	Display compatible con: REDMI	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:04:18.757	2025-08-27 12:27:58.572
822	Z0128	Display Xiaomi REDMI POCO X6PRO	Display compatible con: REDMI	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:04:18.777	2025-08-27 12:27:58.575
823	Z0675+F	Display Xiaomi POCO M4/M5 ORIG	Display compatible con: POCO	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:04:18.794	2025-08-27 12:27:58.579
824	Z0666	Display Xiaomi POCO F3/POCO F4/MI11	Display compatible con: POCO	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:04:18.817	2025-08-27 12:27:58.582
825	Z0551	Display Xiaomi POCO F3/POCO F4/MI11	Display compatible con: POCO	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:04:18.843	2025-08-27 12:27:58.585
826	Z0334	Display Xiaomi REDMI NOTE 13	Display compatible con: REDMI	\N	\N	\N	\N	44	\N	\N	220	0	\N	10	1	PRODUCTO	2025-08-26 23:04:18.876	2025-10-28 22:27:08.492
827	Z0021	Display Xiaomi REDMI NOTE12 4G&5G	Display compatible con: REDMI	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:04:18.892	2025-08-27 12:27:58.589
828	KL-HD064-N8P	Display Xiaomi REDMI NOTE8 PRO	Display compatible con: REDMI	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:04:18.93	2025-08-27 12:27:58.591
829	KL-HD064-N11	Display Xiaomi REDMI Note11 4G/Note11S/NOTE12S/POCO	Display compatible con: REDMI	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:04:18.957	2025-08-27 12:27:58.593
830	Z3456	Display Xiaomi REDMI NOTE13 5G	Display compatible con: REDMI	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:04:18.987	2025-08-27 12:27:58.595
831	KL-HD065-N9	Display Xiaomi REDMI 9T/NOTE9 4G/POCO	Display compatible con: REDMI	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:04:18.997	2025-08-27 12:27:58.597
832	Z0417+F	Display Xiaomi REDMI NOTE11S OLED	Display compatible con: REDMI	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:04:19.011	2025-08-27 12:27:58.6
833	Z1133+F/O	Display Xiaomi NOTE 13 4G	Display compatible con: NOTE	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:04:19.026	2025-08-27 12:27:58.603
834	Z1133+F/0	Display Xiaomi NOTE 13 4G	Display compatible con: NOTE	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:04:19.042	2025-08-27 12:27:58.61
787	K0033	Display Vivo Y33S/Y74S 5G/Y76S 5G/Y33T/Y21T	Display compatible con: Y33S/Y74S	\N	\N	\N	\N	54	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:56:32.529	2025-08-27 12:27:58.454
838	Z0105	Display Xiaomi "REDMI NOTE10 5G/NOTE11	Display compatible con: "REDMI	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:04:19.104	2025-08-27 12:27:58.617
839	Z1133	Display Xiaomi NOTE 13 4G	Display compatible con: NOTE	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:04:19.118	2025-08-27 12:27:58.619
840	Z0021+F	Display Xiaomi REDMI NOTE12 5G/	Display compatible con: REDMI	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:04:19.132	2025-08-27 12:27:58.622
842	Z7878	Display Xiaomi REDMI NOTE12 PRO	Display compatible con: REDMI	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:04:19.154	2025-08-27 12:27:58.625
843	Z1279	Display Xiaomi "REDMI NOTE10PRO/NOTE10PRO MAX/NOTE11PRO/NOTE11PRO	Display compatible con: "REDMI	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:04:19.167	2025-08-27 12:27:58.627
844	Z1313	Display Xiaomi REDMI NOTE12 PRO	Display compatible con: REDMI	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:04:19.18	2025-08-27 12:27:58.629
845	Z0044	Display Xiaomi MI NOTE10/NOTE10LITE/NOTE10PRO/CC9PRO AMOLED	Display compatible con: MI	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:04:19.188	2025-08-27 12:27:58.632
846	Z0887+F	Display Xiaomi REDMI NOTE10PRO INCELL	Display compatible con: REDMI	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:04:19.196	2025-08-27 12:27:58.635
847	Z0022+F	Display Xiaomi REDMI NOTE9/NOTE10X ORIG	Display compatible con: REDMI	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:04:19.204	2025-08-27 12:27:58.639
848	Z0088	Display Xiaomi REDMI NOTE8PRO COG	Display compatible con: REDMI	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:04:19.215	2025-08-27 12:27:58.644
849	Z3690+F	Display Xiaomi REDMI NOTE12 5G/POCO	Display compatible con: REDMI	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:04:19.222	2025-08-27 12:27:58.647
850	Z0091+F	Display Xiaomi REDMI NOTE10 4G/10S/POCO	Display compatible con: REDMI	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:04:19.234	2025-08-27 12:27:58.651
851	Z0535+F	Display Xiaomi REDMI NOTE10 4G/10S/POCO	Display compatible con: REDMI	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:04:19.243	2025-08-27 12:27:58.656
852	Z1120+F	Display Xiaomi REDMI 9T/NOTE9 4G/POCO	Display compatible con: REDMI	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:04:19.253	2025-08-27 12:27:58.659
853	Z1212+F	Display Xiaomi REDMI NOTE12 4G	Display compatible con: REDMI	\N	\N	\N	\N	44	\N	\N	255	0	\N	10	1	PRODUCTO	2025-08-26 23:04:19.262	2025-10-11 23:17:52.782
854	Z1212	Display Xiaomi REDMI NOTE12 4G/5G	Display compatible con: REDMI	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:04:19.275	2025-08-27 12:27:58.666
855	Z1120	Display Xiaomi REDMI 9T/NOTE9 4G/POCO	Display compatible con: REDMI	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:04:19.287	2025-08-27 12:27:58.669
856	Z0179+F	Display Xiaomi REDMI NOTE11 4G/NOTE11S/POCO	Display compatible con: REDMI	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:04:19.296	2025-08-27 12:27:58.673
857	Z0330	Display Xiaomi REDMI NOTE10PRO 5G/POCO	Display compatible con: REDMI	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:04:19.303	2025-08-27 12:27:58.676
858	Z0345	Display Xiaomi POCO X3/X3 PRO/NOTE9PRO	Display compatible con: POCO	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:04:19.311	2025-08-27 12:27:58.677
859	Z1110	Display Xiaomi REDMI NOTE12 4G&5G/POCO	Display compatible con: REDMI	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:04:19.321	2025-08-27 12:27:58.68
860	Z0690+F	Display Xiaomi REDMI NOTE8 INCELL	Display compatible con: REDMI	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:04:19.334	2025-08-27 12:27:58.683
861	Z0690	Display Xiaomi REDMI NOTE8 INCELL	Display compatible con: REDMI	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:04:19.34	2025-08-27 12:27:58.689
862	Z0092	Display Xiaomi REDMI NOTE7/NOTE7 PRO	Display compatible con: REDMI	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:04:19.352	2025-08-27 12:27:58.693
863	Z1122	Display Xiaomi REDMI NOTE11 4G/11S/12S/POCO	Display compatible con: REDMI	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:04:19.368	2025-08-27 12:27:58.695
864	Z8877	Display Xiaomi REDMI NOTE11 4G/NOTE11S/NOTE12S/POCO	Display compatible con: REDMI	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:04:19.377	2025-08-27 12:27:58.697
865	Z0091	Display Xiaomi REDMI NOTE10 4G/10S/POCO	Display compatible con: REDMI	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:04:19.39	2025-08-27 12:27:58.699
866	Z0535	Display Xiaomi REDMI NOTE10 4G/10S/POCO	Display compatible con: REDMI	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:04:19.4	2025-08-27 12:27:58.702
867	Z0022	Display Xiaomi REDMI NOTE9/NOTE10X ORIG	Display compatible con: REDMI	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:04:19.41	2025-08-27 12:27:58.706
868	Z7000	Display Xiaomi REDMI NOTE11T PRO/NOTE12T	Display compatible con: REDMI	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:04:19.419	2025-08-27 12:27:58.709
869	Z0155	Display Xiaomi REDMI NOTE11 5G/POCO	Display compatible con: REDMI	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:04:19.427	2025-08-27 12:27:58.711
870	Z0123-Z0887	Display Xiaomi "REDMI NOTE10 PRO/NOTE10	Display compatible con: "REDMI	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:04:19.44	2025-08-27 12:27:58.713
871	Z0120	Display Xiaomi REDMI NOTE9S/NOTE9 PRO	Display compatible con: REDMI	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:04:19.451	2025-08-27 12:27:58.715
872	Z0010	Display Xiaomi REDMI 10/NOTE11 4G	Display compatible con: REDMI	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:04:19.457	2025-08-27 12:27:58.717
873	ZT202+F	Display ZTE A3 2020 ORIG	Display compatible con: A3	\N	\N	\N	\N	56	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:06:59.244	2025-08-27 12:27:58.719
874	ZT502+F	Display ZTE A5 2020 ORIG	Display compatible con: A5	\N	\N	\N	\N	56	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:06:59.263	2025-08-27 12:27:58.722
875	ZT072+F	Display ZTE A72 4G ORIG	Display compatible con: A72	\N	\N	\N	\N	56	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:06:59.279	2025-08-27 12:27:58.724
876	ZT540+F	Display ZTE A54 ORIG C/M(BOUTIQUE)	Display compatible con: A54	\N	\N	\N	\N	56	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:06:59.291	2025-08-27 12:27:58.73
877	ZT533+F	Display ZTE A53PLUS ORIG C/M(BOUTIQUE)	Display compatible con: A53PLUS	\N	\N	\N	\N	56	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:06:59.308	2025-08-27 12:27:58.734
878	ZT700+F	Display ZTE A71 ORIG C/M(BOUTIQUE)	Display compatible con: A71	\N	\N	\N	\N	56	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:06:59.323	2025-08-27 12:27:58.736
879	ZT522+F	Display ZTE A52 ORIG C/M(BOUTIQUE)	Display compatible con: A52	\N	\N	\N	\N	56	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:06:59.335	2025-08-27 12:27:58.738
880	ZT720+F	Display ZTE A72S 5G ORIG	Display compatible con: A72S	\N	\N	\N	\N	56	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:06:59.348	2025-08-27 12:27:58.74
881	ZT053+F	Display ZTE A53 ORIG C/M(BOUTIQUE)	Display compatible con: A53	\N	\N	\N	\N	56	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:06:59.36	2025-08-27 12:27:58.742
883	ZT207	Display ZTE A7S 2020 ORIG	Display compatible con: A7S	\N	\N	\N	\N	56	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:06:59.379	2025-08-27 12:27:58.745
884	ZT031	Display ZTE A31 ORIG S/M	Display compatible con: A31	\N	\N	\N	\N	56	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:06:59.394	2025-08-27 12:27:58.749
836	Z1133+F/A	Display Xiaomi NOTE 13 4G	Display compatible con: NOTE	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:04:19.075	2025-08-27 12:27:58.755
837	Z1133+F	Display Xiaomi NOTE 13 4G	Display compatible con: NOTE	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:04:19.093	2025-08-27 12:27:58.613
885	ZT720	Display ZTE A72S 5G ORIG	Display compatible con: A72S	\N	\N	\N	\N	56	\N	\N	250	1	\N	10	1	PRODUCTO	2025-08-26 23:06:59.414	2025-10-28 22:03:44.879
889	ZT520	Display ZTE A52 LITE ORIG	Display compatible con: A52	\N	\N	\N	\N	56	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:06:59.462	2025-08-27 12:27:58.762
890	ZT522	Display ZTE A52/A72 ORIG S/M	Display compatible con: A52/A72	\N	\N	\N	\N	56	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:06:59.475	2025-08-27 12:27:58.765
891	ZT505	Display ZTE A51/A71/NOBIA N41 ORIG	Display compatible con: A51/A71/NOBIA	\N	\N	\N	\N	56	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:06:59.483	2025-08-27 12:27:58.771
892	ZT702	Display ZTE A7 2020 ORIG	Display compatible con: A7	\N	\N	\N	\N	56	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:06:59.492	2025-08-27 12:27:58.774
893	ZT502	Display ZTE A5 2020 ORIG	Display compatible con: A5	\N	\N	\N	\N	56	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:06:59.506	2025-08-27 12:27:58.777
894	ZT202	Display ZTE A3 2020 ORIG	Display compatible con: A3	\N	\N	\N	\N	56	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:06:59.517	2025-08-27 12:27:58.779
895	AX60	Display ZTE AXON 60 ORIG	Display compatible con: AXON	\N	\N	\N	\N	56	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:06:59.53	2025-08-27 12:27:58.781
896	AX60lite	Display ZTE AXON 60 LITE	Display compatible con: AXON	\N	\N	\N	\N	56	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:06:59.549	2025-08-27 12:27:58.784
897	AX040	Display ZTE AXON 40SE ORIG	Display compatible con: AXON	\N	\N	\N	\N	56	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:06:59.557	2025-08-27 12:27:58.787
898	AX20	Display ZTE AXON 20 ORIG	Display compatible con: AXON	\N	\N	\N	\N	56	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:06:59.566	2025-08-27 12:27:58.79
899	AX40pro	Display ZTE AXON 40 PRO	Display compatible con: AXON	\N	\N	\N	\N	56	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:06:59.579	2025-08-27 12:27:58.793
900	AX11	Display ZTE AXON 11 ORIG	Display compatible con: AXON	\N	\N	\N	\N	56	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:06:59.595	2025-08-27 12:27:58.797
901	AX30	Display ZTE AXON 30 ORIG	Display compatible con: AXON	\N	\N	\N	\N	56	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:06:59.604	2025-08-27 12:27:58.801
902	AX30pro	Display ZTE AXON 30 PRO	Display compatible con: AXON	\N	\N	\N	\N	56	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:06:59.612	2025-08-27 12:27:58.803
903	AX50lite	Display ZTE AXON 50 LITE	Display compatible con: AXON	\N	\N	\N	\N	56	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:06:59.627	2025-08-27 12:27:58.808
904	AX40lite	Display ZTE AXON 40 LITE	Display compatible con: AXON	\N	\N	\N	\N	56	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:06:59.637	2025-08-27 12:27:58.813
905	ZT222	Display ZTE L220 ORIG S/M	Display compatible con: L220	\N	\N	\N	\N	56	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:06:59.646	2025-08-27 12:27:58.816
906	ZT200	Display ZTE L210 ORIG S/M	Display compatible con: L210	\N	\N	\N	\N	56	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:06:59.657	2025-08-27 12:27:58.818
907	ZT046+F	Display ZTE V30 VITA ORIG	Display compatible con: V30	\N	\N	\N	\N	56	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:06:59.672	2025-08-27 12:27:58.822
908	ZT044+F	Display ZTE V40 SMART ORIG	Display compatible con: V40	\N	\N	\N	\N	56	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:06:59.682	2025-08-27 12:27:58.825
909	ZT400+F	Display ZTE V40 VITA ORIG	Display compatible con: V40	\N	\N	\N	\N	56	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:06:59.689	2025-08-27 12:27:58.827
910	ZT030+F	Display ZTE V30 ORIG C/M(BOUTIQUE)	Display compatible con: V30	\N	\N	\N	\N	56	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:06:59.7	2025-08-27 12:27:58.83
911	ZT004	Display ZTE V40 PRO ORIG	Display compatible con: V40	\N	\N	\N	\N	56	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:06:59.713	2025-08-27 12:27:58.832
912	ZT500	Display ZTE V50 SMART ORIG	Display compatible con: V50	\N	\N	\N	\N	56	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:06:59.72	2025-08-27 12:27:58.835
913	ZT020	Display ZTE V2020 5G ORIG	Display compatible con: V2020	\N	\N	\N	\N	56	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:06:59.729	2025-08-27 12:27:58.839
914	ZT022	Display ZTE V2020 VITA ORIG	Display compatible con: V2020	\N	\N	\N	\N	56	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:06:59.741	2025-08-27 12:27:58.845
915	ZT002	Display ZTE V20 ORIG S/M	Display compatible con: V20	\N	\N	\N	\N	56	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:06:59.75	2025-08-27 12:27:58.852
916	ZT441	Display ZTE V41 SMART ORIG	Display compatible con: V41	\N	\N	\N	\N	56	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:06:59.763	2025-08-27 12:27:58.856
917	ZT001	Display ZTE V10 ORIG S/M	Display compatible con: V10	\N	\N	\N	\N	56	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:06:59.775	2025-08-27 12:27:58.862
919	ZT010	Display ZTE V10 VITA ORIG	Display compatible con: V10	\N	\N	\N	\N	56	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:06:59.797	2025-08-27 12:27:58.866
920	ZT099	Display ZTE V9 LITE ORIG	Display compatible con: V9	\N	\N	\N	\N	56	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:06:59.804	2025-08-27 12:27:58.872
921	ZT030	Display ZTE V30/V40 ORIG S/M	Display compatible con: V30/V40	\N	\N	\N	\N	56	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:06:59.811	2025-08-27 12:27:58.876
922	ZT400	Display ZTE V40 VITA/V40S SMART/V41S	Display compatible con: V40	\N	\N	\N	\N	56	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:06:59.824	2025-08-27 12:27:58.881
923	ZT801	Display ZTE V20 SMART 8010	Display compatible con: V20	\N	\N	\N	\N	56	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:06:59.834	2025-08-27 12:27:58.887
924	ZT205	Display ZTE V20 SMART 2050	Display compatible con: V20	\N	\N	\N	\N	56	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:06:59.844	2025-08-27 12:27:58.892
925	ZT046	Display ZTE V30 VITA ORIG	Display compatible con: V30	\N	\N	\N	\N	56	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:06:59.85	2025-08-27 12:27:58.895
926	ZT044	Display ZTE V40 SMART ORIG	Display compatible con: V40	\N	\N	\N	\N	56	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:06:59.857	2025-08-27 12:27:58.897
927	ZT056	Display ZTE V SMART/2050 ORIG	Display compatible con: V	\N	\N	\N	\N	56	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:06:59.873	2025-08-27 12:27:58.899
27	LPN385300	Batería Hisense F23	Batería compatible con: F23	\N	\N	\N	\N	49	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:33:40.945	2025-08-27 12:27:58.902
888	ZT053	Display ZTE A53 ORIG S/M	Display compatible con: A53	\N	\N	\N	\N	56	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:06:59.45	2025-08-27 12:27:58.759
31	HB299418ECW	Batería Honor MediaPad M5 Pro	Batería compatible con: MediaPad M5 Pro, HUAWEI MediaPad M5, HUAWEI MediaPad M5 lite, HUAWEI MediaPad M6	\N	\N	\N	\N	57	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:38:06.33	2025-08-27 12:27:58.905
58	24022735	Batería Huawei HONOR 8X / HONOR 9X Lite	Batería compatible con: HONOR 8X, HONOR 9X Lite	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:43:16.323	2025-08-27 12:27:58.907
93	24022919	Batería Huawei HUAWEI Y9 2019 / HUAWEI P smart 2019 / HONOR 20 Lite / HONOR 20i / HUAWEI P smart 2020	Batería compatible con: HUAWEI Y9 2019, HUAWEI P smart 2019, HONOR 20 Lite, HONOR 20i, HUAWEI P smart 2020	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:43:16.858	2025-08-27 12:27:58.91
125	KR40	Batería Motorola G8 / ONE VISION / ONE ATION	Batería compatible con: G8, ONE VISION, ONE ATION	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:46:42.071	2025-08-27 12:27:58.912
135	JK50	Batería Motorola E7 / E7i / E7 POWER / E7i POWER / E7PLUS / G9PLAY / E40 / G7 POWER / G8 POWER LITE / G9 PLAY / G10 / G20 / G30 / G50	Batería compatible con: E7, E7i, E7 POWER, E7i POWER, E7PLUS, G9PLAY, E40, G7 POWER, G8 POWER LITE, G9 PLAY, G10, G20, G30, G50	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:46:42.175	2025-08-27 12:27:58.915
887	ZT533	Display ZTE A53PLUS ORIG S/M	Display compatible con: A53PLUS	\N	\N	\N	\N	56	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:06:59.436	2025-08-27 12:27:58.919
143	BLP915	Batería Oppo A17 / A17K / A57 / A57S / A57E / A58 4G A78 5G / K10 5G / N20SE	Batería compatible con: A17, A17K, A57, A57S, A57E, A58 4G A78 5G, K10 5G, N20SE	\N	\N	\N	\N	46	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:51:42.098	2025-08-27 12:27:58.939
188	EB-BM526ABY	Batería Samsung A23 4G / M23 / M23 5G / M33 / M33 5G / a23 lite / A73 5G	Batería compatible con: A23 4G, M23, M23 5G, M33, M33 5G, a23 lite, A73 5G	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:56:45.422	2025-08-27 12:27:58.94
223	BN56	Batería Xiaomi REDMI 9A / 9AT / 9I / 9C / 10A / POCO C3 / POCO C31	Batería compatible con: REDMI 9A, 9AT, 9I, 9C, 10A, POCO C3, POCO C31	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:59:54.188	2025-08-27 12:27:58.942
236	BM4F	Batería Xiaomi MI A3	Batería compatible con: MI A3	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:59:54.316	2025-08-27 12:27:58.944
271	W1199+F	Display Honor X9B ORIG C/M(BOUTIQUE)	Display compatible con: X9B	\N	\N	\N	\N	57	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:23:47.273	2025-08-27 12:27:58.947
285	W1199	Display Honor X9B/Magic 6 ORIG	Display compatible con: X9B/Magic	\N	\N	\N	\N	57	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:23:47.416	2025-08-27 12:27:58.95
289	W9090+F/g	Display Honor X9A ORIG C/M(BOUTIQUE)	Display compatible con: X9A	\N	\N	\N	\N	57	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:23:47.443	2025-08-27 12:27:58.952
329	W1212-COG	Display Huawei NOVA9 SE/N0VA 11i	Display compatible con: NOVA9	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:27:29.698	2025-08-27 12:27:58.956
337	W0020	Display Huawei NOVA Y70 ORIG	Display compatible con: NOVA	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:27:29.773	2025-08-27 12:27:58.959
338	W0004	Display Huawei NOVA Y60 ORIG	Display compatible con: NOVA	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:27:29.78	2025-08-27 12:27:58.962
371	W6000+F	Display Huawei Y6P/HONOR9A/HONOR9S PRIME ORIG	Display compatible con: Y6P/HONOR9A/HONOR9S	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:27:30.155	2025-08-27 12:27:58.968
389	W0777	Display Huawei Y7 2019 ORIG	Display compatible con: Y7	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:27:30.347	2025-08-27 12:27:58.972
392	X0678+F	Display Infinix X678B/NOTE30 PRO ORIG	Display compatible con: X678B/NOTE30	\N	\N	\N	\N	51	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:30:04.422	2025-08-27 12:27:58.975
439	F2002	Display Motorola EDGE20 LITE AMOLED	Display compatible con: EDGE20	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.176	2025-08-27 12:27:58.978
442	F0279	Display Motorola G52/G71S/G82/EDGE30 AMOLED (BOUTIQUE)	Display compatible con: G52/G71S/G82/EDGE30	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.203	2025-08-27 12:27:58.981
489	F5040	Display Motorola G50 4G ORIG	Display compatible con: G50	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.58	2025-08-27 12:27:58.983
517	F1022	Display Motorola G60/G60S/G51 5G/G40FUSION ORIG	Display compatible con: G60/G60S/G51	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.824	2025-08-27 12:27:58.987
539	F0333	Display Motorola Z3 PLAY OLED	Display compatible con: Z3	\N	\N	\N	\N	41	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:36:08.036	2025-08-27 12:27:58.99
548	KL-HD062-A12	Display Oppo A12/A7/AX7/A5S/A12S/A7n/Ax5s/realme3/realme3i INCELL300+ S/M	Display compatible con: A12/A7/AX7/A5S/A12S/A7n/Ax5s/realme3/realme3i	\N	\N	\N	\N	46	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:43:52.617	2025-08-27 12:27:58.995
586	P0016	Display Oppo A16/A16S/A54S/A56/4G/C25/C25S/NARZO50A ORIG S/M	Display compatible con: A16/A16S/A54S/A56/4G/C25/C25S/NARZO50A	\N	\N	\N	\N	46	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:43:52.947	2025-08-27 12:27:58.998
629	T0185+F	Display Samsung A30/A50/A50S INCELL C/M	Display compatible con: A30/A50/A50S	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:15.84	2025-08-27 12:27:59.001
634	T0147+F	Display Samsung A70/A70S INCELL C/M	Display compatible con: A70/A70S	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:15.882	2025-08-27 12:27:59.008
674	T0987	Display Samsung A70/A70S INCELL C/M（BOUTIQUE)	Display compatible con: A70/A70S	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:16.248	2025-08-27 12:27:59.013
684	T2222	Display Samsung A02S/A03/A03S/A04E ORIG S/M	Display compatible con: A02S/A03/A03S/A04E	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:16.335	2025-08-27 12:27:59.018
705	T0819	Display Samsung J4CORE/J4PLUS/J6PLUS/J610 ORIG C/PEGAMENTO	Display compatible con: J4CORE/J4PLUS/J6PLUS/J610	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:16.534	2025-08-27 12:27:59.022
734	TG035	Display Samsung G530 LCD INCELL	Display compatible con: G530	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:16.908	2025-08-27 12:27:59.028
742	T2244+F	Display Samsung S24 ULTRA AMOLED	Display compatible con: S24	\N	\N	\N	\N	38	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:49:17.007	2025-08-27 12:27:59.031
764	KL-HD062-Y93	Display Vivo Y1S/Y90/Y91/Y91I/Y91C/Y93/Y93S/Y95/U1 INCELL300+ S/M	Display compatible con: Y1S/Y90/Y91/Y91I/Y91C/Y93/Y93S/Y95/U1	\N	\N	\N	\N	54	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:56:32.224	2025-08-27 12:27:59.034
784	K0071	Display Vivo Y71/Y73 ORIG S/M	Display compatible con: Y71/Y73	\N	\N	\N	\N	54	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:56:32.49	2025-08-27 12:27:59.037
785	K0113	Display Vivo Y3/Y3S/Y11/Y12/Y15/Y17/U3X/U10 ORIG S/M	Display compatible con: Y3/Y3S/Y11/Y12/Y15/Y17/U3X/U10	\N	\N	\N	\N	54	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:56:32.501	2025-08-27 12:27:59.04
835	Z1133+F/V	Display Xiaomi NOTE 13 4G	Display compatible con: NOTE	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:04:19.062	2025-08-27 12:27:59.044
841	Z0675	Display Xiaomi POCO M4/M5/REDMI10 5G/NOTE11	Display compatible con: POCO	\N	\N	\N	\N	44	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:04:19.143	2025-08-27 12:27:59.047
882	ZT505+F	Display ZTE A51 ORIG C/M(BOUTIQUE)	Display compatible con: A51	\N	\N	\N	\N	56	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:06:59.368	2025-08-27 12:27:59.052
886	ZT540	Display ZTE A34/A54 ORIG S/M	Display compatible con: A34/A54	\N	\N	\N	\N	56	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:06:59.421	2025-08-27 12:27:59.057
918	ZT009	Display ZTE V9 ORIG S/M	Display compatible con: V9	\N	\N	\N	\N	56	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 23:06:59.785	2025-08-27 12:27:59.059
929	BT-IP-13	Batería Apple iPhone 13	Batería original Apple para iPhone 13	\N	\N	\N	\N	37	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-27 12:16:34.728	2025-08-27 12:27:59.062
930	BT-IP-13MINI	Batería Apple iPhone 13MINI	Batería original Apple para iPhone 13MINI	\N	\N	\N	\N	37	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-27 12:16:34.737	2025-08-27 12:27:59.067
390	W0069	Display Huawei Y6 2019/Y6S/HONOR 8A	Display compatible con: Y6	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:27:30.363	2025-08-27 12:27:58.93
786	K2020	Display Vivo "Y20/Y20 2021/Y20i/Y20S/Y20sg/Y15A/Y15s/Y11s/Y12s/V12A/V12s 2021/Y3s	Display compatible con: "Y20/Y20	\N	\N	\N	\N	54	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 22:56:32.514	2025-08-27 12:27:58.933
59	24022915(HB446486ECW)	Batería Huawei HUAWEI-Y9 PRIME 2019 / Y9s / P SMART Z / P20 LITE / NOVA 5i / HONOR 9X / HONOR 9X PRO / P SMART PRO	Batería compatible con: HUAWEI-Y9 PRIME 2019, Y9s, P SMART Z, P20 LITE, NOVA 5i, HONOR 9X, HONOR 9X PRO, P SMART PRO	\N	\N	\N	\N	40	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:43:16.34	2025-08-27 12:27:58.935
142	BLP779	Batería Oppo A93 4G	Batería compatible con: A93 4G	\N	\N	\N	\N	46	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:51:42.089	2025-08-27 12:27:58.937
1035	Au234	Audífonos unicornio lila	\N	\N	\N	\N	1	59	1096	\N	0	0	31	0	0	PRODUCTO	2025-09-05 17:20:50.612	2025-09-05 17:20:50.611
1036	Au345	Audifonos Ximi	\N	\N	\N	\N	1	59	1096	\N	12	20	31	0	0	PRODUCTO	2025-09-05 17:21:27.731	2025-09-15 17:43:18.149
935	BT-IP-11	Batería Apple iPhone 11	Batería original Apple para iPhone 11	\N	\N	\N	\N	37	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-27 12:16:34.829	2025-08-27 12:27:59.09
936	BT-IP-XS	Batería Apple iPhone MAX XS MAX	Batería original Apple para iPhone MAX XS MAX	\N	\N	\N	\N	37	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-27 12:16:34.851	2025-08-27 12:27:59.098
938	BT-IP-X	Batería Apple iPhone X	Batería original Apple para iPhone X	\N	\N	\N	\N	37	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-27 12:16:34.898	2025-08-27 12:27:59.103
939	BT-IP-8PLUS	Batería Apple iPhone 8PLUS	Batería original Apple para iPhone 8PLUS	\N	\N	\N	\N	37	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-27 12:16:34.917	2025-08-27 12:27:59.107
941	BT-IP-8G	Batería Apple iPhone 8G	Batería original Apple para iPhone 8G	\N	\N	\N	\N	37	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-27 12:16:34.942	2025-08-27 12:27:59.111
942	BT-IP-7PLUS	Batería Apple iPhone 7PLUS	Batería original Apple para iPhone 7PLUS	\N	\N	\N	\N	37	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-27 12:16:34.954	2025-08-27 12:27:59.113
943	BT-IP-7G	Batería Apple iPhone 7G	Batería original Apple para iPhone 7G	\N	\N	\N	\N	37	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-27 12:16:34.97	2025-08-27 12:27:59.115
945	BT-IP-6G	Batería Apple iPhone 6G	Batería original Apple para iPhone 6G	\N	\N	\N	\N	37	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-27 12:16:35.01	2025-08-27 12:27:59.12
946	V003	Display Apple 6S PLUS AAA	Display compatible con: 6S	\N	\N	\N	\N	37	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-27 12:19:29.661	2025-08-27 12:27:59.122
947	V004-B	Display Apple 7G AAA BLANCO	Display compatible con: 7G	\N	\N	\N	\N	37	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-27 12:19:29.682	2025-08-27 12:27:59.127
948	V004-N	Display Apple 7G AAA NEGRO	Display compatible con: 7G	\N	\N	\N	\N	37	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-27 12:19:29.695	2025-08-27 12:27:59.135
949	V0092-B	Display Apple 8G/SE 2020 AAA	Display compatible con: 8G/SE	\N	\N	\N	\N	37	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-27 12:19:29.73	2025-08-27 12:27:59.139
950	V0092-N	Display Apple 8G/SE 2020 AAA	Display compatible con: 8G/SE	\N	\N	\N	\N	37	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-27 12:19:29.761	2025-08-27 12:27:59.142
951	V0015-B	Display Apple 6G AAA S/M	Display compatible con: 6G	\N	\N	\N	\N	37	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-27 12:19:29.786	2025-08-27 12:27:59.146
952	V0015-N	Display Apple 6G AAA S/M	Display compatible con: 6G	\N	\N	\N	\N	37	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-27 12:19:29.81	2025-08-27 12:27:59.151
953	V0091-B	Display Apple 8PLUS AAA BLANCO	Display compatible con: 8PLUS	\N	\N	\N	\N	37	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-27 12:19:29.83	2025-08-27 12:27:59.153
954	V0091-N	Display Apple 8PLUS AAA NEGRO	Display compatible con: 8PLUS	\N	\N	\N	\N	37	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-27 12:19:29.856	2025-08-27 12:27:59.156
955	V005-B	Display Apple 7PLUS AAA BLANCO	Display compatible con: 7PLUS	\N	\N	\N	\N	37	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-27 12:19:29.869	2025-08-27 12:27:59.159
956	V005-N	Display Apple 7PLUS AAA NEGRO	Display compatible con: 7PLUS	\N	\N	\N	\N	37	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-27 12:19:29.882	2025-08-27 12:27:59.162
957	I014	Display Apple HG X FHD	Display compatible con: HG	\N	\N	\N	\N	37	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-27 12:19:29.895	2025-08-27 12:27:59.165
958	I023	Display Apple HG X11(MOVIL IC)	Display compatible con: HG	\N	\N	\N	\N	37	\N	\N	395	0	\N	10	1	PRODUCTO	2025-08-27 12:19:29.902	2025-10-28 22:22:01.288
960	I027	Display Apple HG X13PRO(MOVIL IC)	Display compatible con: HG	\N	\N	\N	\N	37	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-27 12:19:29.928	2025-08-27 12:27:59.171
937	BT-IP-XR	Batería Apple iPhone XR	Batería original Apple para iPhone XR	\N	\N	\N	\N	37	\N	\N	165	0	\N	10	1	PRODUCTO	2025-08-27 12:16:34.873	2025-11-13 18:21:28.617
962	I029	Display Apple HG X14(MOVIL IC)	Display compatible con: HG	\N	\N	\N	\N	37	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-27 12:19:29.957	2025-08-27 12:27:59.176
963	I028	Display Apple HG X13PRO MAX(MOVIL	Display compatible con: HG	\N	\N	\N	\N	37	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-27 12:19:29.967	2025-08-27 12:27:59.18
964	I015	Display Apple HG XS FHD	Display compatible con: HG	\N	\N	\N	\N	37	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-27 12:19:29.977	2025-08-27 12:27:59.183
965	I017	Display Apple HG XS MAX	Display compatible con: HG	\N	\N	\N	\N	37	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-27 12:19:29.988	2025-08-27 12:27:59.185
966	I019	Display Apple HG X11PRO MAX(MOVIL	Display compatible con: HG	\N	\N	\N	\N	37	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-27 12:19:29.996	2025-08-27 12:27:59.19
967	I021	Display Apple HG X12/12PRO(MOVIL IC)	Display compatible con: HG	\N	\N	\N	\N	37	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-27 12:19:30.007	2025-08-27 12:27:59.193
968	I022	Display Apple HG X12PRO MAX(MOVIL	Display compatible con: HG	\N	\N	\N	\N	37	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-27 12:19:30.021	2025-08-27 12:27:59.197
969	I034	Display Apple HG X15PRO FHD	Display compatible con: HG	\N	\N	\N	\N	37	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-27 12:19:30.034	2025-08-27 12:27:59.199
970	I030	Display Apple HG X14PRO(MOVIL IC)	Display compatible con: HG	\N	\N	\N	\N	37	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-27 12:19:30.046	2025-08-27 12:27:59.203
971	I024	Display Apple HG X13(MOVIL IC)	Display compatible con: HG	\N	\N	\N	\N	37	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-27 12:19:30.06	2025-08-27 12:27:59.206
972	I018	Display Apple HG X11PRO(MOVIL IC)	Display compatible con: HG	\N	\N	\N	\N	37	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-27 12:19:30.073	2025-08-27 12:27:59.21
973	JKI-FHD0670-C8	Display Apple JK 13 PRO	Display compatible con: JK	\N	\N	\N	\N	37	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-27 12:19:30.088	2025-08-27 12:27:59.216
974	JKI-FHD0550-M2	Display Apple JK 13MINI(MOVIL IC)	Display compatible con: JK	\N	\N	\N	\N	37	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-27 12:19:30.102	2025-08-27 12:27:59.218
975	JKI-FHD0550-M1	Display Apple JK 12MINI(MOVIL IC)	Display compatible con: JK	\N	\N	\N	\N	37	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-27 12:19:30.11	2025-08-27 12:27:59.221
976	JKI-FHD0600-H4	Display Apple JK X15(MOVIL IC)	Display compatible con: JK	\N	\N	\N	\N	37	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-27 12:19:30.119	2025-08-27 12:27:59.223
977	JKI-FHD0670-C6	Display Apple JK X12PRO MAX	Display compatible con: JK	\N	\N	\N	\N	37	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-27 12:19:30.13	2025-08-27 12:27:59.225
978	JKI-FHD0650-L2	Display Apple JK X11PRO MAX	Display compatible con: JK	\N	\N	\N	\N	37	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-27 12:19:30.143	2025-08-27 12:27:59.23
979	JKI-FHD0650-L1	Display Apple JK XS MAX	Display compatible con: JK	\N	\N	\N	\N	37	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-27 12:19:30.154	2025-08-27 12:27:59.233
980	JKI-FHD0600-H3	Display Apple JK X14 FHD	Display compatible con: JK	\N	\N	\N	\N	37	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-27 12:19:30.163	2025-08-27 12:27:59.237
981	JKI-FHD0600-H2	Display Apple JK X13 FHD	Display compatible con: JK	\N	\N	\N	\N	37	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-27 12:19:30.171	2025-08-27 12:27:59.241
961	I016	Display Apple HG XR FHD	Display compatible con: HG	\N	\N	\N	\N	37	\N	\N	310	0	\N	10	1	PRODUCTO	2025-08-27 12:19:29.946	2025-11-13 18:22:18.368
931	BT-IP-12	Batería Apple iPhone MINI 12 MINI	Batería original Apple para iPhone MINI 12 MINI	\N	\N	\N	\N	37	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-27 12:16:34.747	2025-08-27 12:27:59.073
932	BT-IP-12PRO	Batería Apple iPhone MAX 12PRO MAX	Batería original Apple para iPhone MAX 12PRO MAX	\N	\N	\N	\N	37	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-27 12:16:34.763	2025-08-27 12:27:59.078
940	BT-IP-SE	Batería Apple iPhone 2020 SE 2020	Batería original Apple para iPhone 2020 SE 2020	\N	\N	\N	\N	37	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-27 12:16:34.927	2025-08-27 12:27:59.08
944	BT-IP-6S	Batería Apple iPhone PLUS 6S PLUS	Batería original Apple para iPhone PLUS 6S PLUS	\N	\N	\N	\N	37	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-27 12:16:34.988	2025-08-27 12:27:59.083
934	BT-IP-11PRO	Batería Apple iPhone MAX 11PRO MAX	Batería original Apple para iPhone MAX 11PRO MAX	\N	\N	\N	\N	37	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-27 12:16:34.8	2025-08-27 12:27:59.087
984	JKI-FHD0610-S1	Display Apple JK XR FHD	Display compatible con: JK	\N	\N	\N	\N	37	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-27 12:19:30.195	2025-08-27 12:27:59.309
985	JKI-FHD0580-Z3	Display Apple JK X11PRO FHD	Display compatible con: JK	\N	\N	\N	\N	37	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-27 12:19:30.206	2025-08-27 12:27:59.312
986	JKI-FHD0580-Z2	Display Apple JK XS FHD	Display compatible con: JK	\N	\N	\N	\N	37	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-27 12:19:30.217	2025-08-27 12:27:59.314
987	JKI-FHD0580-Z1	Display Apple JK X FHD	Display compatible con: JK	\N	\N	\N	\N	37	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-27 12:19:30.225	2025-08-27 12:27:59.316
988	JKI-HD0580-Z3	Display Apple MS X11PRO INCELL	Display compatible con: MS	\N	\N	\N	\N	37	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-27 12:19:30.238	2025-08-27 12:27:59.319
989	JKI-HD0650-L2	Display Apple MS X11PRO MAX(MOVIL	Display compatible con: MS	\N	\N	\N	\N	37	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-27 12:19:30.256	2025-08-27 12:27:59.323
990	JKI-HD0650-L1	Display Apple MS XS MAX	Display compatible con: MS	\N	\N	\N	\N	37	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-27 12:19:30.266	2025-08-27 12:27:59.326
991	JKI-HD0610-S2	Display Apple MS X11(MOVIL IC)	Display compatible con: MS	\N	\N	\N	\N	37	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-27 12:19:30.278	2025-08-27 12:27:59.328
992	JKI-HD0610-S1	Display Apple MS XR INCELL	Display compatible con: MS	\N	\N	\N	\N	37	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-27 12:19:30.291	2025-08-27 12:27:59.331
993	JKI-HD0580-Z2	Display Apple MS XS INCELL	Display compatible con: MS	\N	\N	\N	\N	37	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-27 12:19:30.301	2025-08-27 12:27:59.333
994	JKI-HD0580-Z1	Display Apple MS X INCELL	Display compatible con: MS	\N	\N	\N	\N	37	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-27 12:19:30.314	2025-08-27 12:27:59.335
997	V0037	Display Apple X HD INCELL	Display compatible con: X	\N	\N	\N	\N	37	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-27 12:19:30.352	2025-08-27 12:27:59.339
998	V0035	Display Apple XR HD INCELL	Display compatible con: XR	\N	\N	\N	\N	37	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-27 12:19:30.368	2025-08-27 12:27:59.344
999	V0038	Display Apple XS HD INCELL	Display compatible con: XS	\N	\N	\N	\N	37	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-27 12:19:30.379	2025-08-27 12:27:59.347
1007	RF-6715PM-F	Display Apple HG X15PRO MAX	Display compatible con: HG	\N	\N	\N	\N	37	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-27 12:19:30.48	2025-08-27 12:27:59.351
1008	RF-6714PM-F	Display Apple HG X14PRO MAX	Display compatible con: HG	\N	\N	\N	\N	37	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-27 12:19:30.494	2025-08-27 12:27:59.355
1009	RF-6713PM-F	Display Apple HG X13PRO MAX	Display compatible con: HG	\N	\N	\N	\N	37	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-27 12:19:30.503	2025-08-27 12:27:59.358
1010	LF-6712PM-F	Display Apple HG X12PRO MAX	Display compatible con: HG	\N	\N	\N	\N	37	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-27 12:19:30.513	2025-08-27 12:27:59.36
1013	JKO-FHD0600-C1	Display Apple JK X12/12PRO(MOVIL IC)	Display compatible con: JK	\N	\N	\N	\N	37	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-27 12:19:30.543	2025-08-27 12:27:59.367
1014	JKO-FHD0600-C3	Display Apple JK X14(MOVIL IC)	Display compatible con: JK	\N	\N	\N	\N	37	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-27 12:19:30.551	2025-08-27 12:27:59.371
1015	JKO-FHD0600-C2	Display Apple JK X13(MOVIL IC)	Display compatible con: JK	\N	\N	\N	\N	37	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-27 12:19:30.568	2025-08-27 12:27:59.374
1016	JKO-FHD0650-L3	Display Apple JK X11PRO MAX(MOVIL	Display compatible con: JK	\N	\N	\N	\N	37	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-27 12:19:30.576	2025-08-27 12:27:59.378
1017	JKO-FHD0650-L4	Display Apple JK XS MAX	Display compatible con: JK	\N	\N	\N	\N	37	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-27 12:19:30.584	2025-08-27 12:27:59.381
1021	displayx	Display Apple  X  OLed	\N	\N	\N	\N	1	37	1086	\N	0	0	1	0	0	PRODUCTO	2025-08-28 23:50:31.569	2025-08-28 23:50:31.567
1022	var	varios	\N	\N	\N	\N	1	\N	\N	\N	0	0	1	0	0	SERVICIO	2025-08-29 18:44:11.734	2025-08-29 18:44:11.731
149	BLP805	Batería Oppo A16K / A16E / A16 / A16S / A54S / A56 / A53 2020 / A32 / A33 / A53S / A11S / A54 4G / A55 4G / A9	Batería compatible con: A16K, A16E, A16, A16S, A54S, A56, A53 2020, A32, A33, A53S, A11S, A54 4G, A55 4G, A9	\N	\N	\N	\N	46	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-26 21:51:42.171	2025-08-27 12:27:58.923
995	X15PRO	Display Apple MAX INCELL-IC X15PRO	Display compatible con: MAX	\N	\N	\N	\N	37	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-27 12:19:30.326	2025-08-27 12:27:59.243
996	X12MINI	Display Apple INCELL 12 MINI	Display compatible con: INCELL	\N	\N	\N	\N	37	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-27 12:19:30.339	2025-08-27 12:27:59.246
1000	XS	Display Apple INCELL XS INCELL	Display compatible con: INCELL	\N	\N	\N	\N	37	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-27 12:19:30.387	2025-08-27 12:27:59.254
1001	X11PRO	Display Apple INCELL-IC 11PRO(MOVIL IC)	Display compatible con: INCELL-IC	\N	\N	\N	\N	37	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-27 12:19:30.403	2025-08-27 12:27:59.257
1002	X12PRO	Display Apple INCELL-IC 12/12PRO(MOVIL IC)	Display compatible con: INCELL-IC	\N	\N	\N	\N	37	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-27 12:19:30.417	2025-08-27 12:27:59.261
1003	X11	Display Apple INCELL-IC X11(MOVIL IC)	Display compatible con: INCELL-IC	\N	\N	\N	\N	37	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-27 12:19:30.437	2025-08-27 12:27:59.263
1004	X13MINI	Display Apple INCELL 13 MINI	Display compatible con: INCELL	\N	\N	\N	\N	37	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-27 12:19:30.447	2025-08-27 12:27:59.265
1005	XR	Display Apple INCELL XR INCELL	Display compatible con: INCELL	\N	\N	\N	\N	37	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-27 12:19:30.456	2025-08-27 12:27:59.267
1006	X	Display Apple INCELL X(CARTAN) INCELL	Display compatible con: INCELL	\N	\N	\N	\N	37	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-27 12:19:30.466	2025-08-27 12:27:59.269
1011	X15	Display Apple OLED-IC X15(MOVIL IC)	Display compatible con: OLED-IC	\N	\N	\N	\N	37	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-27 12:19:30.521	2025-08-27 12:27:59.273
1012	X13PRO	Display Apple MAX OLED-IC X13PRO	Display compatible con: MAX	\N	\N	\N	\N	37	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-27 12:19:30.534	2025-08-27 12:27:59.276
1018	X14	Display Apple OLED-IC 14(MOVIL IC)	Display compatible con: OLED-IC	\N	\N	\N	\N	37	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-27 12:19:30.595	2025-08-27 12:27:59.279
1019	X14PRO	Display Apple OLED-IC 14PRO(MOVIL IC)	Display compatible con: OLED-IC	\N	\N	\N	\N	37	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-27 12:19:30.61	2025-08-27 12:27:59.284
1020	X13	Display Apple OLED 13 OLED	Display compatible con: OLED	\N	\N	\N	\N	37	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-27 12:19:30.621	2025-08-27 12:27:59.289
928	BT-IP-12MINI	Batería Apple iPhone 12MINI	Batería original Apple para iPhone 12MINI	\N	\N	\N	\N	37	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-27 12:16:34.712	2025-08-27 12:27:59.295
933	BT-IP-12/12PRO	Batería Apple iPhone 12/12PRO	Batería original Apple para iPhone 12/12PRO	\N	\N	\N	\N	37	\N	\N	265	0	\N	10	1	PRODUCTO	2025-08-27 12:16:34.785	2025-10-28 21:58:54.155
959	I031	Display Apple HG X14PLUS(MOVIL IC)	Display compatible con: HG	\N	\N	\N	\N	37	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-27 12:19:29.913	2025-08-27 12:27:59.301
982	JKI-FHD0600-H1	Display Apple JK X12/X12PRO FHD	Display compatible con: JK	\N	\N	\N	\N	37	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-27 12:19:30.176	2025-08-27 12:27:59.304
983	JKI-FHD0610-S2	Display Apple JK X11(MOVIL IC)	Display compatible con: JK	\N	\N	\N	\N	37	\N	\N	0	0	\N	10	1	PRODUCTO	2025-08-27 12:19:30.184	2025-08-27 12:27:59.306
1027	marcoandroid	Marco Android 	\N	\N	\N	\N	1	47	141	\N	0	0	1	0	0	PRODUCTO	2025-08-30 18:05:43.951	2025-08-30 18:05:43.95
1026	tapaandroid	Tapa Android	\N	\N	\N	\N	1	47	141	\N	180	0	1	0	0	PRODUCTO	2025-08-30 18:05:06.162	2025-10-28 22:20:43.969
1037	So234	Soportes para motocicleta  	\N	\N	\N	\N	1	59	1097	\N	0	0	31	0	0	PRODUCTO	2025-09-05 17:23:10.523	2025-09-05 17:23:10.522
1038	Mot123	Audifonos Motorola 	\N	\N	\N	\N	1	59	1095	\N	0	0	31	0	0	PRODUCTO	2025-09-05 17:23:52.588	2025-09-05 17:23:52.586
1039	So123	Audífonos Sony 	\N	\N	\N	\N	1	59	1095	\N	0	0	31	0	0	PRODUCTO	2025-09-05 17:24:23.106	2025-09-05 17:24:23.104
1040	Bos123	Audífonos Bose	\N	\N	\N	\N	1	59	1095	\N	0	0	31	0	0	PRODUCTO	2025-09-05 17:24:51.466	2025-09-05 17:24:51.465
1042	Bo234	Bocina cuadrada YA!	\N	\N	\N	\N	1	59	1091	\N	300	6	31	0	0	PRODUCTO	2025-09-05 17:28:50.381	2025-09-05 17:35:06.513
1043	Car123	Cargador Motorola 	\N	\N	\N	\N	1	59	1094	\N	55	7	31	0	0	PRODUCTO	2025-09-05 17:53:42.401	2025-11-13 18:12:33.478
1046	YA741	Cargador tipo IPhone YA! 	\N	\N	\N	\N	1	59	1093	\N	26	10	31	0	0	PRODUCTO	2025-09-05 17:57:38.427	2025-09-05 18:03:29.415
1045	YA456	Cargador tipo V8 YA!	\N	\N	\N	\N	1	59	1093	\N	26	2	31	0	0	PRODUCTO	2025-09-05 17:57:03.491	2025-09-05 18:04:03.733
1047	Cub852	Cubo para cable	\N	\N	\N	\N	1	59	1093	\N	21	10	31	0	0	PRODUCTO	2025-09-05 17:59:52.885	2025-09-05 18:04:31.373
1078	Dc123	Desarmador de cruz	\N	\N	\N	\N	1	63	1101	\N	0.01	10	32	0	0	PRODUCTO	2025-09-17 18:45:10.258	2025-11-19 18:55:09.342
1051	servcen123	Servicio a centro de carga tipo C	\N	\N	\N	\N	1	\N	\N	\N	0	0	1	0	0	SERVICIO	2025-09-05 18:17:21.494	2025-09-05 18:17:21.492
1052	servcen789	Servicio a centro de carga tipo V8	\N	\N	\N	\N	1	\N	\N	\N	0	0	1	0	0	SERVICIO	2025-09-05 18:17:54.46	2025-09-05 18:17:54.459
1053	serv789	Centro de carga tipo C	\N	\N	\N	\N	1	\N	\N	\N	0	0	1	0	0	SERVICIO	2025-09-05 18:18:17.569	2025-09-05 18:18:17.567
1054	serv145	Centro de carga tipo V8	\N	\N	\N	\N	1	\N	\N	\N	0	0	1	0	0	SERVICIO	2025-09-05 18:19:00.156	2025-09-05 18:19:00.155
1056	mot4589	Bateria moto E13	\N	\N	\N	\N	1	41	376	\N	0	0	1	0	0	PRODUCTO	2025-09-08 19:46:32.874	2025-09-08 19:46:32.873
1057	DES4578	Desbloqueo básico	\N	\N	\N	\N	1	\N	\N	\N	0	0	1	0	0	SERVICIO	2025-09-08 19:52:18.837	2025-09-08 19:52:18.836
1060	Pp123	Pegamento negro para pantalla	\N	\N	\N	\N	1	62	1104	\N	0	0	32	0	0	PRODUCTO	2025-09-09 22:52:03.528	2025-09-09 22:52:03.526
1061	Om123	Paquete oppener de metal	\N	\N	\N	\N	1	65	1103	\N	0	0	32	0	0	PRODUCTO	2025-09-09 22:52:53.743	2025-09-09 22:52:53.742
1062	Tr123	Tester 	\N	\N	\N	\N	1	64	1102	\N	0	0	32	0	0	PRODUCTO	2025-09-09 22:53:25.518	2025-09-09 22:53:25.517
1065	Pt123	Pegamento transparente para pantalla	\N	\N	\N	\N	1	62	1104	\N	0	0	32	0	0	PRODUCTO	2025-09-09 22:58:45.384	2025-09-09 22:58:45.383
1068	Md123	Mini drill	\N	\N	\N	\N	1	67	1107	\N	0	0	32	0	0	PRODUCTO	2025-09-09 23:12:18.078	2025-09-09 23:12:18.076
1069	Eb123	Espatula para baterias	\N	\N	\N	\N	1	64	1102	\N	0	0	32	0	0	PRODUCTO	2025-09-09 23:12:47.754	2025-09-09 23:12:47.752
1070	PK123	PUNTA K	\N	\N	\N	\N	1	63	1101	\N	0	0	32	0	0	PRODUCTO	2025-09-13 19:46:14.288	2025-09-13 19:46:14.286
1071	PR123	PUNTA RECTA	\N	\N	\N	\N	1	63	1101	\N	0	0	32	0	0	PRODUCTO	2025-09-13 19:47:13.404	2025-09-13 19:47:13.402
1099	ES1245	e-Sim	\N	\N	\N	\N	1	68	1109	\N	0	0	31	0	0	PRODUCTO	2025-09-27 20:15:29.247	2025-09-27 20:15:29.245
1074	Op456	Oppener de metal	\N	\N	\N	\N	1	63	1101	\N	0	0	32	0	0	PRODUCTO	2025-09-17 18:33:22.933	2025-09-17 18:33:22.932
1080	Cl123	Cepillo de limpieza	\N	\N	\N	\N	1	63	1101	\N	0	0	32	0	0	PRODUCTO	2025-09-17 19:54:32.489	2025-09-17 19:54:32.487
1081	Su123	Stencil universal	\N	\N	\N	\N	1	63	1101	\N	0	0	32	0	0	PRODUCTO	2025-09-17 21:39:50.128	2025-09-17 21:39:50.126
1088	Ecp123	Espátula CPU y RAM 	\N	\N	\N	\N	1	63	1101	\N	0	0	32	0	0	PRODUCTO	2025-09-17 21:44:43.001	2025-09-17 21:44:42.999
1089	Pcv123	PUNTA CURVA 	\N	\N	\N	\N	1	63	1101	\N	0	0	32	0	0	PRODUCTO	2025-09-17 21:45:33.304	2025-09-17 21:45:33.303
1090	Pk123	Puntas de limpieza tipo K	\N	\N	\N	\N	1	63	1101	\N	0	0	32	0	0	PRODUCTO	2025-09-17 21:58:26.442	2025-09-17 21:58:26.44
1055	cac456	Cable C a	\N	\N	\N	\N	1	59	1098	\N	60	9	31	0	0	PRODUCTO	2025-09-05 18:24:13.623	2025-09-05 18:25:02.848
1092	Tc123	Chip TELCEL	\N	\N	\N	\N	1	70	1111	\N	1	2	31	0	0	PRODUCTO	2025-09-20 18:04:22.998	2025-09-20 18:09:09.48
1093	cM123	Chip MOVISTAR	\N	\N	\N	\N	1	69	1108	\N	1	2	31	0	0	PRODUCTO	2025-09-20 18:04:53.866	2025-09-20 18:09:22.313
1094	Ba123	Chip BAIT	\N	\N	\N	\N	1	71	1110	\N	1	1	31	0	0	PRODUCTO	2025-09-20 18:05:49.237	2025-09-20 18:10:01.543
1097	Ct123	Cámaras iPhone 11 pro max	\N	\N	\N	\N	1	\N	\N	\N	0	0	1	0	0	SERVICIO	2025-09-23 16:32:56.907	2025-09-23 16:32:56.906
1098	Ai478	Auricular iPhone	\N	\N	\N	\N	1	37	1072	\N	0	0	1	0	0	PRODUCTO	2025-09-23 16:33:35.854	2025-09-23 16:33:35.853
1086	Hj123	Hilo de jumper 	\N	\N	\N	\N	1	63	1101	\N	0.01	6	32	0	0	PRODUCTO	2025-09-17 21:43:18.514	2025-11-17 18:35:56.353
1100	vidrio	vidrio da camara	\N	\N	\N	\N	1	47	141	\N	0	0	1	0	0	PRODUCTO	2025-10-04 14:23:07.637	2025-10-04 14:23:07.636
1091	Ms123	Malla para soldar 	\N	\N	\N	\N	1	63	1101	\N	0.01	27	32	0	0	PRODUCTO	2025-09-17 21:59:01.719	2025-11-17 18:36:29.509
1095	Catt123	Chip AT&T	\N	\N	\N	\N	1	68	1109	\N	1	1	31	0	0	PRODUCTO	2025-09-20 18:07:38.584	2025-09-21 00:04:47.507
1096	PRe123	Pinzas rectas	\N	\N	\N	\N	1	63	1101	\N	75	5	32	0	0	PRODUCTO	2025-09-20 23:49:07.009	2025-09-21 00:04:47.486
1101	50 lite	display axon 50 lite	\N	\N	\N	\N	1	56	1028	\N	0	0	1	0	0	PRODUCTO	2025-10-04 14:24:49.143	2025-10-04 14:24:49.142
1058	AV123	Alcoholera de vidrio	\N	\N	\N	\N	1	61	1105	\N	0.01	16	32	0	0	PRODUCTO	2025-09-09 22:50:40.659	2025-11-17 18:48:22.589
1085	Muv123	Máscara UV 	\N	\N	\N	\N	1	63	1101	\N	0.01	15	32	0	0	PRODUCTO	2025-09-17 21:42:31.895	2025-11-17 18:46:40.488
1076	Got789	Gotero	\N	\N	\N	\N	1	63	1101	\N	0.01	15	32	0	0	PRODUCTO	2025-09-17 18:34:17.311	2025-11-17 18:45:40.356
1063	Tl123	Toallitas limpiadoras	\N	\N	\N	\N	1	63	1101	\N	0.01	12	32	0	0	PRODUCTO	2025-09-09 22:53:56.045	2025-11-17 18:46:07.447
1087	Pco123	Pinzas de corte 	\N	\N	\N	\N	1	63	1101	\N	0.01	0	32	0	0	PRODUCTO	2025-09-17 21:43:47.216	2025-11-16 17:41:37.826
1067	Cg123	Caja organizadora grande	\N	\N	\N	\N	1	66	1106	\N	0.01	7	32	0	0	PRODUCTO	2025-09-09 23:01:50.635	2025-11-19 18:56:31.731
1077	Ck123	Cinta Kapton 	\N	\N	\N	\N	1	63	1101	\N	0.01	3	32	0	0	PRODUCTO	2025-09-17 18:36:53.331	2025-11-17 18:50:37.376
1064	Op123	Oppener de plastico	\N	\N	\N	\N	1	63	1101	\N	0.01	298	32	0	0	PRODUCTO	2025-09-09 22:56:16.625	2025-11-17 18:49:38.113
1072	RS123	ROSIN	\N	\N	\N	\N	1	63	1101	\N	0.01	1	32	0	0	PRODUCTO	2025-09-13 19:47:37.556	2025-11-17 19:08:17.77
1048	Pul753	Cables Pulpo	\N	\N	\N	\N	1	59	1098	\N	25	8	31	0	0	PRODUCTO	2025-09-05 18:00:27.82	2025-09-05 18:04:57.52
1079	Dp123	Desarmador plano	\N	\N	\N	\N	1	63	1101	\N	0.01	8	32	0	0	PRODUCTO	2025-09-17 18:45:51.089	2025-11-19 18:55:28.434
1082	Di123	Desarmador T 0.8 IPhone	\N	\N	\N	\N	1	63	1101	\N	0.01	10	32	0	0	PRODUCTO	2025-09-17 21:40:57.051	2025-11-19 18:55:57.151
1084	Dpa123	Desarmador pata de gallo 	\N	\N	\N	\N	1	63	1101	\N	0.01	10	32	0	0	PRODUCTO	2025-09-17 21:41:36.675	2025-11-19 18:56:08.04
1066	Cp123	Caja organizadora pequeña	\N	\N	\N	\N	1	66	1106	\N	0.01	2	32	0	0	PRODUCTO	2025-09-09 23:01:24.427	2025-11-19 18:56:42.86
1031	Bo123	Bocina pequeña YA 	\N	\N	\N	\N	1	59	1091	\N	65	2	31	0	0	PRODUCTO	2025-09-05 17:16:21.471	2025-09-05 17:36:04.174
1059	Fx123	Flux	\N	\N	\N	\N	1	63	1101	\N	0.01	14	32	0	0	PRODUCTO	2025-09-09 22:51:24.829	2025-11-17 18:47:04.166
1105	Comp	Compra de display 	\N	\N	\N	\N	1	47	141	\N	380	0	1	0	0	PRODUCTO	2025-10-08 20:36:46.327	2025-10-08 20:38:15.439
1114	gfgh	Bateria Iphone 15	\N	\N	\N	\N	1	37	111	\N	490	0	1	0	0	PRODUCTO	2025-10-30 23:26:00.845	2025-11-08 22:43:42.452
1136	H12	Lampara UV	\N	\N	\N	\N	1	47	141	\N	0	0	32	0	0	PRODUCTO	2025-11-17 18:59:23.849	2025-11-17 18:59:23.848
1119	RA00	Tarjeta Lógica	\N	\N	\N	\N	1	47	141	\N	400	0	31	0	0	PRODUCTO	2025-11-12 17:12:41.392	2025-11-12 17:16:06.496
1106	wrgtyb	prueba 3	\N	\N	\N	\N	1	72	1114	\N	0.1	3	1	0	0	PRODUCTO	2025-10-09 15:19:28.952	2025-10-09 19:20:05.124
270	W0070	Display Honor 70 ORIG OLED	Display compatible con: 70	\N	\N	\N	\N	57	\N	\N	700	0	\N	10	1	PRODUCTO	2025-08-26 22:23:47.268	2025-10-11 23:08:17.264
1109	Ulba14789	Bateria S23 Ultra	\N	\N	\N	\N	1	38	834	\N	150	0	1	0	0	PRODUCTO	2025-10-11 23:09:58.411	2025-10-11 23:10:26.407
1120	R00	Logica	\N	\N	\N	\N	1	47	141	\N	200	0	1	0	0	PRODUCTO	2025-11-13 17:11:54.076	2025-11-15 16:20:33.233
1111	ipa5678	Ipad 6ta	\N	\N	\N	\N	1	37	1066	\N	0	0	2	0	0	PRODUCTO	2025-10-16 21:15:17.057	2025-10-16 21:15:17.055
1103	Z06755	Display Xiaomi POCO M4/M5/REDMI10 5G/NOTE 11	\N	\N	\N	\N	1	44	953	\N	600	0	1	0	0	PRODUCTO	2025-10-06 20:46:17.892	2025-10-18 20:55:13.95
1112	hjy76	Lector de SIM	\N	\N	\N	\N	1	60	1099	\N	0	0	1	0	0	PRODUCTO	2025-10-20 19:57:52.008	2025-10-20 19:57:52.007
1113	ps6754	Porta sim 	\N	\N	\N	\N	1	60	1099	\N	90	0	1	0	0	PRODUCTO	2025-10-28 21:49:39.355	2025-10-28 21:49:57.988
496	F1010+F	Display Motorola G10/G20/G30 ORIG C/M(BOUTIQUE)	Display compatible con: G10/G20/G30	\N	\N	\N	\N	41	\N	\N	260	0	\N	10	1	PRODUCTO	2025-08-26 22:36:07.641	2025-10-28 21:51:34.356
1044	Ya789	Cargador tipo C YA! 	\N	\N	\N	\N	1	59	1093	\N	26	9	31	0	0	PRODUCTO	2025-09-05 17:56:06.137	2025-11-01 20:55:34.479
1121	R01	Display iPhone	\N	\N	\N	\N	1	47	141	\N	190	0	1	0	0	PRODUCTO	2025-11-15 16:59:37.249	2025-11-15 17:00:33.694
1104	Dev	Devolución	\N	\N	\N	\N	1	47	141	\N	200	0	1	0	0	PRODUCTO	2025-10-08 20:29:01.238	2025-11-02 21:22:56.637
1150	H23	Tapete termico	\N	\N	\N	\N	1	47	141	\N	0	0	32	0	0	PRODUCTO	2025-11-17 19:10:35.424	2025-11-17 19:10:35.423
1124	H01	Navaja Qianli 007	\N	\N	\N	\N	1	47	141	\N	0.01	11	32	0	0	PRODUCTO	2025-11-17 18:52:44.916	2025-11-17 19:12:50.246
1125	H02	Navaja Qianli 008	\N	\N	\N	\N	1	47	141	\N	0.01	11	32	0	0	PRODUCTO	2025-11-17 18:53:11.137	2025-11-17 19:13:04.929
1075	Ai456	Alcohol isopropilico	\N	\N	\N	\N	1	63	1101	\N	65	3	32	0	0	PRODUCTO	2025-09-17 18:33:54.271	2025-09-21 00:04:47.495
1126	H03	Navaja Qianli 009	\N	\N	\N	\N	1	47	141	\N	0.01	8	32	0	0	PRODUCTO	2025-11-17 18:53:52.336	2025-11-17 19:13:17.427
1127	H04	Esténcil Universal	\N	\N	\N	\N	1	47	141	\N	0.01	10	32	0	0	PRODUCTO	2025-11-17 18:54:50.299	2025-11-17 19:13:40.899
1129	H06	Soldadura en pasta 138°C	\N	\N	\N	\N	1	47	141	\N	0.01	8	32	0	0	PRODUCTO	2025-11-17 18:56:12.44	2025-11-17 19:14:33.924
1131	H07	Soldadura en pasta 183°C	\N	\N	\N	\N	1	47	141	\N	0.01	8	32	0	0	PRODUCTO	2025-11-17 18:56:53.995	2025-11-17 19:14:41.376
1132	H08	Soldadura en Rollo	\N	\N	\N	\N	1	47	141	\N	0.01	9	32	0	0	PRODUCTO	2025-11-17 18:57:15.694	2025-11-17 19:14:52.02
1133	H09	Pinzas de corte	\N	\N	\N	\N	1	47	141	\N	0.01	1	32	0	0	PRODUCTO	2025-11-17 18:57:50.667	2025-11-17 19:15:24.917
1134	H10	Pinzas de precisión rectas	\N	\N	\N	\N	1	47	141	\N	0.01	5	32	0	0	PRODUCTO	2025-11-17 18:58:35.887	2025-11-17 19:15:39.888
1135	H11	Pinzas de precisión curvas	\N	\N	\N	\N	1	47	141	\N	0.01	6	32	0	0	PRODUCTO	2025-11-17 18:59:02.805	2025-11-17 19:15:55.031
1139	H13	Punta recta para cautín	\N	\N	\N	\N	1	47	141	\N	0.01	4	32	0	0	PRODUCTO	2025-11-17 19:02:08.697	2025-11-17 19:17:52.848
1140	H14	Punta curva para cautín	\N	\N	\N	\N	1	47	141	\N	0.01	8	32	0	0	PRODUCTO	2025-11-17 19:02:34.489	2025-11-17 19:18:11.698
1142	H15	Punta de limpieza para cautín	\N	\N	\N	\N	1	47	141	\N	0.01	3	32	0	0	PRODUCTO	2025-11-17 19:03:10.525	2025-11-17 19:18:35.812
1143	H16	Base PCB Universal	\N	\N	\N	\N	1	47	141	\N	0.01	5	32	0	0	PRODUCTO	2025-11-17 19:03:42.844	2025-11-17 19:19:08.784
1144	H17	Base de limpieza para IC	\N	\N	\N	\N	1	47	141	\N	0.01	3	32	0	0	PRODUCTO	2025-11-17 19:04:12.23	2025-11-17 19:19:21.013
1145	H18	Limpiador para cautín	\N	\N	\N	\N	1	47	141	\N	0.01	15	32	0	0	PRODUCTO	2025-11-17 19:05:13.179	2025-11-17 19:19:45.433
1146	H19	Cinta de aluminio	\N	\N	\N	\N	1	47	141	\N	0.01	28	32	0	0	PRODUCTO	2025-11-17 19:05:37.326	2025-11-17 19:20:10.224
1148	H21	Pegamento para pantalla B	\N	\N	\N	\N	1	47	141	\N	0.01	4	32	0	0	PRODUCTO	2025-11-17 19:06:30.016	2025-11-17 19:20:35.102
1149	H22	USB fast charger	\N	\N	\N	\N	1	47	141	\N	0.01	1	32	0	0	PRODUCTO	2025-11-17 19:07:27.313	2025-11-17 19:21:04.129
1151	H24	Embolo Flux	\N	\N	\N	\N	1	47	141	\N	0.01	19	32	0	0	PRODUCTO	2025-11-17 19:11:01.124	2025-11-17 19:21:37.32
1122	H00	Tapete Louwei	\N	\N	\N	\N	1	60	1099	\N	0.01	9	31	0	0	PRODUCTO	2025-11-16 17:38:06.453	2025-11-17 19:22:03.415
1117	serve01	Servicio de entrega	\N	\N	\N	\N	1	47	141	\N	30	1	31	0	0	PRODUCTO	2025-11-06 18:42:38.312	2025-11-18 21:54:58.615
1116	prod789	Centro de carga tipo C	\N	\N	\N	\N	1	47	141	\N	15	6	1	0	0	PRODUCTO	2025-11-06 18:38:15.12	2025-11-20 19:21:54.937
1108	DES4552	Desbloqueo básico	\N	\N	\N	\N	1	60	1099	\N	250	0	1	0	0	PRODUCTO	2025-10-11 23:06:04.8	2025-11-20 21:48:03.052
1118	IOSTapa01	Tapa IOS	\N	\N	\N	\N	1	37	1065	\N	160	1	1	0	0	PRODUCTO	2025-11-08 22:47:15.274	2025-11-22 20:10:08.506
1147	H20	Pegamento para pantalla N	\N	\N	\N	\N	1	47	141	\N	0.01	3	32	0	0	PRODUCTO	2025-11-17 19:06:06.782	2025-11-17 19:20:47.921
1128	H05	Espatula para soldar	\N	\N	\N	\N	1	47	141	\N	0.01	11	32	0	0	PRODUCTO	2025-11-17 18:55:29.322	2025-11-17 19:13:59.649
\.
COPY public.productos_presupuesto_independiente (id, presupuesto_independiente_id, producto_id, cantidad, precio_venta, concepto_extra, precio_concepto_extra, created_at, updated_at) FROM stdin;
14	11	1067	1	50	\N	\N	2025-11-23 19:01:29.514	2025-11-23 19:01:29.514
15	11	1147	1	89	\N	\N	2025-11-23 19:01:29.514	2025-11-23 19:01:29.514
\.
COPY public.productos_reparacion_frecuente (id, reparacion_frecuente_id, producto_id, cantidad, precio_venta, concepto_extra, precio_concepto_extra, created_at, updated_at) FROM stdin;
5	1	5	1	4000	\N	\N	2025-06-18 00:08:07.746	2025-06-18 00:08:07.746
6	1	8	1	500	\N	\N	2025-06-18 00:08:07.746	2025-06-18 00:08:07.746
7	2	6	1	3000	\N	\N	2025-06-18 00:08:23.812	2025-06-18 00:08:23.812
8	2	8	1	500	\N	\N	2025-06-18 00:08:23.812	2025-06-18 00:08:23.812
9	3	12	1	200	\N	\N	2025-08-18 20:12:41.658	2025-08-18 20:12:41.658
10	4	13	1	200	\N	\N	2025-08-19 15:35:10.977	2025-08-19 15:35:10.977
\.
COPY public.proveedores (id, nombre, contacto, telefono, email, direccion, notas, banco, clabe_interbancaria, cuenta_bancaria, rfc, tipo, created_at, updated_at) FROM stdin;
3	Aureliano Buendía García	Aureliano Buendía García	5544332211	aureliano@100anios.com	Camino a Macondo #1	\N	Bienestar	123456789012345678	12345678	BUGA670501	FISICA	2025-06-17 21:34:27.924	2025-06-17 21:34:27.924
5	Rolidan cell	Daniela flores	5530451209	rolidancell@gmail.com	José Maria  Morelos y Pavón Lt1 Mz1, 55520, Hank Gonzáles, Ecatepec de Morelos		mercado pago	722969010445082652	722969010445082652	qwerty	FISICA	2025-08-19 15:30:21.811	2025-08-19 17:15:56.781
7	Yaavshop	Sandra Mayab	5536085622	sandramayab@yaavs.com.mx	Paseo de Plateros 10, Ojo de agua	\N	BBVA	123456789101254789	1457896541236	YAA125	FISICA	2025-09-05 17:33:39.895	2025-09-05 17:33:39.893
8	Mensajería	5555555555	5555555555	5555555555@gmail.com	N/A	\N	N/A	000000000000000000	N/A	N/A	FISICA	2025-11-06 18:47:04.728	2025-11-06 18:47:04.727
9	VicTech	5647850673	5647850673	victech@gmail.com	victech@gmail.com	\N	N/A	123456789123456789	N/A	123456789123456789	FISICA	2025-11-12 17:15:15.94	2025-11-12 17:15:15.939
11	AcademiaYaayvs	5638143944	5638143944	acadmiayaav@gmail.com	Plaza Ecatepec	\N	N/A	000000000000000000	N/A	AcademiaYaayvs01234	MORAL	2025-11-16 17:34:58.671	2025-11-16 17:34:58.67
\.
COPY public.puntos_recoleccion (id, nombre, activo, created_at, updated_at, email, is_headquarters, location, parent_id, phone, schedule, url, is_repair_point) FROM stdin;
1	Matriz Punto Uno	t	2025-06-17 18:06:41.221	2025-06-18 02:38:25.216	matriz@puntouno.com	t	{"lat": 20.0930958, "lng": -98.7523802, "address": "Boulevard Valle de San Javier, Valle de San Javier 3°, 4° y 7°. Sección, Pachuca, Pachuca de Soto, Hidalgo, 42086, Mexico"}	\N	5544332211	{"friday": {"end": "18:00", "open": true, "start": "09:00"}, "monday": {"end": "18:00", "open": true, "start": "09:00"}, "sunday": {"end": "18:00", "open": false, "start": "09:00"}, "tuesday": {"end": "18:00", "open": true, "start": "09:00"}, "saturday": {"end": "18:00", "open": true, "start": "09:00"}, "thursday": {"end": "18:00", "open": true, "start": "09:00"}, "wednesday": {"end": "18:00", "open": true, "start": "09:00"}}	http://puntouno.com	f
\.
COPY public.reparaciones (id, ticket_id, diagnostico, solucion, observaciones, fecha_inicio, fecha_fin, created_at, updated_at, capacidad, codigo_desbloqueo, red_celular, salud_bateria, version_so, fecha_pausa, fecha_reanudacion) FROM stdin;
102	55		\N	Listo	2025-09-29 21:48:59.765	2025-09-29 21:48:59.765	2025-09-29 21:48:59.765	2025-09-29 21:48:59.765	\N	\N	\N	\N		\N	\N
103	57		\N	Limpieza lista	2025-09-30 22:17:17.074	2025-09-30 22:49:17.42	2025-09-30 22:17:17.074	2025-09-30 22:49:17.42	\N	\N	\N	\N		\N	\N
105	43		\N	Desbloqueado	2025-09-30 23:03:39.077	2025-09-30 23:03:39.077	2025-09-30 23:03:39.077	2025-09-30 23:03:39.077	\N	\N	\N	\N		\N	\N
106	60		\N		2025-10-01 21:25:29.211	2025-10-01 21:25:29.211	2025-10-01 21:25:29.211	2025-10-01 21:25:29.211	\N	\N	\N	\N		\N	\N
107	58		\N	Display reemplazado	2025-10-01 21:26:23.518	2025-10-01 23:20:49.615	2025-10-01 21:26:23.518	2025-10-01 23:20:49.615	\N	\N	\N	\N		\N	\N
109	59		\N	Equipo reparado 	2025-10-01 23:57:46.063	2025-10-01 23:57:46.063	2025-10-01 23:57:46.063	2025-10-01 23:57:46.063	\N	\N	\N	\N		\N	\N
51	19		\N	Se repara satisfactoriamente, listo para cargar. 	2025-09-01 17:27:26.496	2025-09-01 17:36:29.576	2025-09-01 17:27:26.497	2025-09-01 17:36:29.576	\N	\N	\N	\N		\N	\N
53	20		\N	Reparación de cargados de laptop	2025-09-01 19:00:22.409	2025-09-01 19:00:42.383	2025-09-01 19:00:22.409	2025-09-01 19:00:42.383	\N	\N	\N	\N		\N	\N
55	21		\N	Restablecimiento de fabrica 	2025-09-01 20:09:02.043	2025-09-01 21:17:46.358	2025-09-01 20:09:02.044	2025-09-01 21:17:46.358	\N	\N	\N	\N		\N	\N
57	22		\N		2025-09-05 20:45:21.551	2025-09-06 22:37:30.069	2025-09-05 20:45:21.551	2025-09-06 22:37:30.069	\N	\N	\N	\N		\N	\N
110	62		\N	Equipo entregado 	2025-10-02 22:05:51.963	2025-10-04 16:49:31.298	2025-10-02 22:05:51.963	2025-10-04 16:49:31.298	\N	\N	\N	\N		\N	\N
60	24		\N		2025-09-08 19:53:32.432	2025-09-08 19:54:27.212	2025-09-08 19:53:32.432	2025-09-08 19:54:27.212	\N	\N	\N	\N		\N	\N
63	25		\N		2025-09-10 00:00:51.239	2025-09-10 00:00:51.239	2025-09-10 00:00:51.239	2025-09-10 00:00:51.239	\N	\N	\N	\N		\N	\N
64	26		\N		2025-09-10 16:36:30.854	2025-09-10 16:36:30.854	2025-09-10 16:36:30.854	2025-09-10 16:36:30.854	\N	\N	\N	\N		\N	\N
59	23		\N		2025-09-08 19:47:42.938	2025-09-10 18:43:21.361	2025-09-08 19:47:42.938	2025-09-10 18:43:21.361	\N	\N	\N	\N		\N	\N
66	27		\N		2025-09-11 18:24:42.491	2025-09-11 18:24:42.491	2025-09-11 18:24:42.491	2025-09-11 18:24:42.491	\N	\N	\N	\N		\N	\N
67	29		\N		2025-09-13 20:19:13.399	2025-09-13 20:20:44.631	2025-09-13 20:19:13.399	2025-09-13 20:20:44.631	\N	\N	\N	\N		\N	\N
112	65	\N	\N	\N	2025-10-05 19:03:59.728	\N	2025-10-05 19:03:59.729	2025-10-05 19:03:59.728	\N	\N	\N	\N	\N	\N	\N
71	30		\N	Herramienta entregada	2025-09-13 23:49:28.113	2025-09-13 23:49:46.723	2025-09-13 23:49:28.113	2025-09-13 23:49:46.723	\N	\N	\N	\N		\N	\N
69	28		\N	Equipos listo para entregar	2025-09-13 20:21:21.217	2025-09-13 23:50:25.163	2025-09-13 20:21:21.217	2025-09-13 23:50:25.163	\N	\N	\N	\N		\N	\N
74	31		\N		2025-09-17 20:02:26.504	2025-09-17 20:02:44.728	2025-09-17 20:02:26.504	2025-09-17 20:02:44.728	\N	\N	\N	\N		\N	\N
76	32		\N		2025-09-21 00:04:36.573	2025-09-21 00:04:47.44	2025-09-21 00:04:36.573	2025-09-21 00:04:47.44	\N	\N	\N	\N		\N	\N
78	33		\N	Ya carga, listo para entrega	2025-09-21 00:07:12.043	2025-09-21 00:07:12.043	2025-09-21 00:07:12.043	2025-09-21 00:07:12.043	\N	\N	\N	\N		\N	\N
79	35		\N		2025-09-21 20:58:13.9	2025-09-21 20:58:13.9	2025-09-21 20:58:13.9	2025-09-21 20:58:13.9	\N	\N	\N	\N		\N	\N
80	37		\N	listo	2025-09-22 23:41:30.03	2025-09-22 23:41:30.03	2025-09-22 23:41:30.03	2025-09-22 23:41:30.03	\N	\N	\N	\N		\N	\N
81	38		\N		2025-09-23 16:35:11.355	2025-09-23 16:35:11.355	2025-09-23 16:35:11.355	2025-09-23 16:35:11.355	\N	\N	\N	\N		\N	\N
82	39		\N		2025-09-23 16:41:07.116	2025-09-23 16:41:08.938	2025-09-23 16:41:07.116	2025-09-23 16:41:08.938	\N	\N	\N	\N		\N	\N
84	36		\N		2025-09-23 22:05:35.757	2025-09-23 22:05:35.757	2025-09-23 22:05:35.757	2025-09-23 22:05:35.757	\N	\N	\N	\N		\N	\N
85	34		\N		2025-09-23 22:12:55.01	2025-09-23 22:12:55.907	2025-09-23 22:12:55.01	2025-09-23 22:12:55.907	\N	\N	\N	\N		\N	\N
87	42		\N	Listo para entregar	2025-09-23 22:16:50.48	2025-09-23 22:16:51.899	2025-09-23 22:16:50.48	2025-09-23 22:16:51.899	\N	\N	\N	\N		\N	\N
90	45		\N	Se reemplazo el centro de carga	2025-09-26 22:45:40.555	2025-09-26 22:45:40.555	2025-09-26 22:45:40.555	2025-09-26 22:45:40.555	\N	\N	\N	\N		\N	\N
91	47		\N	Desbloqueado	2025-09-26 23:07:43.788	2025-09-26 23:07:45.229	2025-09-26 23:07:43.788	2025-09-26 23:07:45.229	\N	\N	\N	\N		\N	\N
89	44		\N	Reparado	2025-09-26 15:56:55.796	2025-09-26 23:51:09.252	2025-09-26 15:56:55.797	2025-09-26 23:51:09.252	\N	\N	\N	\N		\N	\N
94	49		\N	Listo	2025-09-27 20:11:05.217	2025-09-27 20:11:05.217	2025-09-27 20:11:05.217	2025-09-27 20:11:05.217	\N	\N	\N	\N		\N	\N
95	50		\N	Venta de cargador	2025-09-27 20:12:55.799	2025-09-27 20:13:12.91	2025-09-27 20:12:55.799	2025-09-27 20:13:12.91	\N	\N	\N	\N		\N	\N
97	51		\N	Se envio QR	2025-09-27 20:16:57.463	2025-09-27 20:16:57.463	2025-09-27 20:16:57.463	2025-09-27 20:16:57.463	\N	\N	\N	\N		\N	\N
98	48		\N	Centro reemplazado	2025-09-27 23:40:17.17	2025-09-27 23:40:17.17	2025-09-27 23:40:17.17	2025-09-27 23:40:17.17	\N	\N	\N	\N		\N	\N
99	53		\N		2025-09-28 19:35:28.134	2025-09-28 19:35:28.134	2025-09-28 19:35:28.134	2025-09-28 19:35:28.134	\N	\N	\N	\N		\N	\N
101	54		\N		2025-09-28 21:06:57.522	2025-09-28 21:06:57.522	2025-09-28 21:06:57.522	2025-09-28 21:06:57.522	\N	\N	\N	\N		\N	\N
114	67		\N		2025-10-06 21:42:02.283	2025-10-06 21:42:02.283	2025-10-06 21:42:02.283	2025-10-06 21:42:02.283	\N	\N	\N	\N		\N	\N
115	68		\N		2025-10-07 16:05:13.8	2025-10-07 16:05:13.8	2025-10-07 16:05:13.8	2025-10-07 16:05:13.8	\N	\N	\N	\N		\N	\N
116	69		\N		2025-10-07 17:34:47.757	2025-10-07 23:21:43.194	2025-10-07 17:34:47.758	2025-10-07 23:21:43.194	\N	\N	\N	\N		\N	\N
113	66		\N		2025-10-05 22:58:57.646	2025-10-08 20:09:07.239	2025-10-05 22:58:57.647	2025-10-08 20:09:07.239	\N	\N	\N	\N		\N	\N
120	63		\N		2025-10-08 20:22:07.246	2025-10-08 20:22:07.246	2025-10-08 20:22:07.246	2025-10-08 20:22:07.246	\N	\N	\N	\N		\N	\N
118	70		\N	listo	2025-10-08 20:07:35.766	2025-10-08 22:25:00.6	2025-10-08 20:07:35.766	2025-10-08 22:25:00.6	\N	\N	\N	\N		\N	\N
140	82		\N	Listo	2025-10-10 22:41:55.518	2025-10-13 20:32:54.07	2025-10-10 22:41:55.518	2025-10-13 20:32:54.07	\N	\N	\N	\N		\N	\N
147	86		\N	Equipo entregado	2025-10-13 23:30:11.108	2025-10-13 23:30:11.108	2025-10-13 23:30:11.108	2025-10-13 23:30:11.108	\N	\N	\N	\N		\N	\N
149	88		\N		2025-10-14 19:07:00.945	2025-10-14 19:07:01.801	2025-10-14 19:07:00.945	2025-10-14 19:07:01.801	\N	\N	\N	\N		\N	\N
134	80		\N		2025-10-09 23:05:22.005	2025-10-09 23:05:22.609	2025-10-09 23:05:22.005	2025-10-09 23:05:22.609	\N	\N	\N	\N		\N	\N
137	79		\N		2025-10-10 22:20:55.526	2025-10-10 22:20:55.526	2025-10-10 22:20:55.526	2025-10-10 22:20:55.526	\N	\N	\N	\N		\N	\N
138	64		\N		2025-10-10 22:30:11.362	2025-10-10 22:30:11.362	2025-10-10 22:30:11.362	2025-10-10 22:30:11.362	\N	\N	\N	\N		\N	\N
139	81		\N		2025-10-10 22:31:30.884	2025-10-10 22:31:30.884	2025-10-10 22:31:30.884	2025-10-10 22:31:30.884	\N	\N	\N	\N		\N	\N
166	95		\N		2025-10-23 16:22:28.848	2025-10-23 16:22:28.848	2025-10-23 16:22:28.848	2025-10-23 16:22:28.848	\N	\N	\N	\N		\N	\N
136	78		\N		2025-10-09 23:08:01.624	2025-10-11 19:21:07.004	2025-10-09 23:08:01.624	2025-10-11 19:21:07.004	\N	\N	\N	\N		\N	\N
143	84		\N		2025-10-11 22:39:41.757	2025-10-11 22:40:53.744	2025-10-11 22:39:41.757	2025-10-11 22:40:53.744	\N	\N	\N	\N		\N	\N
145	83		\N		2025-10-11 23:24:27.9	2025-10-11 23:24:27.9	2025-10-11 23:24:27.9	2025-10-11 23:24:27.9	\N	\N	\N	\N		\N	\N
151	85		\N	listo	2025-10-14 21:32:38.873	2025-10-14 21:32:42.493	2025-10-14 21:32:38.873	2025-10-14 21:32:42.493	\N	\N	\N	\N		\N	\N
153	89		\N		2025-10-16 21:11:23.153	2025-10-16 21:12:42.132	2025-10-16 21:11:23.153	2025-10-16 21:12:42.132	\N	\N	\N	\N		\N	\N
155	90		\N	Listo 	2025-10-16 21:22:56.575	2025-10-16 21:22:56.575	2025-10-16 21:22:56.575	2025-10-16 21:22:56.575	\N	\N	\N	\N		\N	\N
100	52		\N	Diagnostico entregado 	2025-09-28 19:44:00.751	2025-10-16 23:19:54.306	2025-09-28 19:44:00.752	2025-10-16 23:19:54.306	\N	\N	\N	\N		\N	\N
148	87		\N	listo	2025-10-14 15:00:46.575	2025-10-17 20:59:59.71	2025-10-14 15:00:46.575	2025-10-17 20:59:59.71	\N	\N	\N	\N		\N	\N
158	91		\N		2025-10-17 21:52:59.264	2025-10-17 21:53:01.255	2025-10-17 21:52:59.264	2025-10-17 21:53:01.255	\N	\N	\N	\N		\N	\N
160	92		\N		2025-10-18 19:50:53.608	2025-10-18 19:50:53.608	2025-10-18 19:50:53.608	2025-10-18 19:50:53.608	\N	\N	\N	\N		\N	\N
161	93		\N		2025-10-18 19:52:43.299	2025-10-18 20:37:04.657	2025-10-18 19:52:43.299	2025-10-18 20:37:04.657	\N	\N	\N	\N		\N	\N
163	94		\N		2025-10-19 19:49:34.539	2025-10-19 19:49:34.539	2025-10-19 19:49:34.539	2025-10-19 19:49:34.539	\N	\N	\N	\N		\N	\N
164	97		\N		2025-10-22 19:26:09.883	2025-10-22 19:26:09.883	2025-10-22 19:26:09.883	2025-10-22 19:26:09.883	\N	\N	\N	\N		\N	\N
165	99		\N		2025-10-23 15:35:42.473	2025-10-23 15:35:42.473	2025-10-23 15:35:42.473	2025-10-23 15:35:42.473	\N	\N	\N	\N		\N	\N
169	102		\N		2025-10-25 18:04:57.324	2025-10-25 18:04:57.324	2025-10-25 18:04:57.324	2025-10-25 18:04:57.324	\N	\N	\N	\N		\N	\N
170	103		\N	Se entrega equipo cargando 	2025-10-27 19:59:06.262	2025-10-27 19:59:06.262	2025-10-27 19:59:06.262	2025-10-27 19:59:06.262	\N	\N	\N	\N		\N	\N
171	104		\N	listo, se reemplazo. 	2025-10-27 22:35:50.531	2025-10-27 22:36:32.46	2025-10-27 22:35:50.532	2025-10-27 22:36:32.46	\N	\N	\N	\N		\N	\N
173	105		\N	Equipo listo para entregar.	2025-10-27 22:47:27.142	2025-10-27 22:47:27.142	2025-10-27 22:47:27.142	2025-10-27 22:47:27.142	\N	\N	\N	\N		\N	\N
177	107		\N	Concluida	2025-10-28 00:33:11.906	2025-10-28 00:33:11.906	2025-10-28 00:33:11.906	2025-10-28 00:33:11.906	\N	\N	\N	\N		\N	\N
174	106		\N		2025-10-28 00:30:32.918	2025-10-28 00:31:24.72	2025-10-28 00:30:32.918	2025-10-28 00:31:24.72	\N	\N	\N	\N		\N	\N
178	108		\N	centro 	2025-10-28 20:12:22.497	2025-10-28 20:12:22.497	2025-10-28 20:12:22.497	2025-10-28 20:12:22.497	\N	\N	\N	\N		\N	\N
180	110		\N		2025-10-29 23:11:05.403	2025-10-29 23:11:18.609	2025-10-29 23:11:05.403	2025-10-29 23:11:18.609	\N	\N	\N	\N		\N	\N
182	113		\N		2025-10-30 18:52:04.934	2025-10-30 18:52:04.934	2025-10-30 18:52:04.934	2025-10-30 18:52:04.934	\N	\N	\N	\N		\N	\N
179	111		\N		2025-10-28 23:45:55.176	2025-10-31 19:52:02.432	2025-10-28 23:45:55.176	2025-10-31 19:52:02.432	\N	\N	\N	\N		\N	\N
183	116		\N		2025-10-31 18:08:40.191	2025-10-31 20:55:03.266	2025-10-31 18:08:40.191	2025-10-31 20:55:03.266	\N	\N	\N	\N		\N	\N
184	115		\N		2025-10-31 18:08:51.877	2025-10-31 21:41:36.677	2025-10-31 18:08:51.877	2025-10-31 21:41:36.677	\N	\N	\N	\N		\N	\N
188	119		\N		2025-11-01 18:13:32.104	2025-11-01 18:13:32.104	2025-11-01 18:13:32.104	2025-11-01 18:13:32.104	\N	\N	\N	\N		\N	\N
189	109		\N		2025-11-01 18:16:14.435	2025-11-01 18:16:14.435	2025-11-01 18:16:14.435	2025-11-01 18:16:14.435	\N	\N	\N	\N		\N	\N
190	122		\N		2025-11-01 20:55:18.126	2025-11-01 20:55:34.446	2025-11-01 20:55:18.126	2025-11-01 20:55:34.446	\N	\N	\N	\N		\N	\N
192	121		\N		2025-11-01 23:18:32.636	2025-11-01 23:18:32.636	2025-11-01 23:18:32.636	2025-11-01 23:18:32.636	\N	\N	\N	\N		\N	\N
193	120		\N		2025-11-01 23:19:11.468	2025-11-01 23:19:11.468	2025-11-01 23:19:11.468	2025-11-01 23:19:11.468	\N	\N	\N	\N		\N	\N
167	98		\N		2025-10-24 21:31:03.959	2025-11-02 21:20:55.576	2025-10-24 21:31:03.959	2025-11-02 21:20:55.576	\N	\N	\N	\N		\N	\N
195	123		\N		2025-11-02 22:00:38.685	2025-11-02 22:00:38.685	2025-11-02 22:00:38.685	2025-11-02 22:00:38.685	\N	\N	\N	\N		\N	\N
196	124		\N		2025-11-03 22:41:08.599	2025-11-03 22:41:08.599	2025-11-03 22:41:08.599	2025-11-03 22:41:08.599	\N	\N	\N	\N		\N	\N
197	126		\N	Se entregó material.	2025-11-04 23:20:36.995	2025-11-04 23:20:36.995	2025-11-04 23:20:36.995	2025-11-04 23:20:36.995	\N	\N	\N	\N		\N	\N
198	127		\N		2025-11-05 16:28:10.157	2025-11-05 16:28:10.157	2025-11-05 16:28:10.157	2025-11-05 16:28:10.157	\N	\N	\N	\N		\N	\N
199	128		\N		2025-11-05 23:28:19.406	2025-11-05 23:28:21.485	2025-11-05 23:28:19.406	2025-11-05 23:28:21.485	\N	\N	\N	\N		\N	\N
202	132		\N		2025-11-06 22:22:35.47	2025-11-06 22:22:35.47	2025-11-06 22:22:35.47	2025-11-06 22:22:35.47	\N	\N	\N	\N		\N	\N
205	134		\N		2025-11-07 16:01:04.915	2025-11-07 16:01:04.915	2025-11-07 16:01:04.915	2025-11-07 16:01:04.915	\N	\N	\N	\N		\N	\N
203	129		\N		2025-11-06 22:43:51.469	2025-11-07 22:29:58.42	2025-11-06 22:43:51.469	2025-11-07 22:29:58.42	\N	\N	\N	\N		\N	\N
207	135		\N		2025-11-08 20:56:56.892	2025-11-08 20:56:56.892	2025-11-08 20:56:56.892	2025-11-08 20:56:56.892	\N	\N	\N	\N		\N	\N
201	131		\N		2025-11-06 21:50:36.744	2025-11-08 21:05:07.647	2025-11-06 21:50:36.744	2025-11-08 21:05:07.647	\N	\N	\N	\N		\N	\N
209	133		\N		2025-11-08 21:07:31.724	2025-11-08 21:53:18.594	2025-11-08 21:07:31.724	2025-11-08 21:53:18.594	\N	\N	\N	\N		\N	\N
204	118		\N		2025-11-06 22:44:15.724	2025-11-09 19:16:34.093	2025-11-06 22:44:15.724	2025-11-09 19:16:34.093	\N	\N	\N	\N		\N	\N
212	137		\N		2025-11-09 21:52:35.543	2025-11-09 22:19:10.402	2025-11-09 21:52:35.543	2025-11-09 22:19:10.402	\N	\N	\N	\N		\N	\N
213	138		\N		2025-11-09 22:13:38.452	2025-11-10 20:42:12.866	2025-11-09 22:13:38.452	2025-11-10 20:42:12.866	\N	\N	\N	\N		\N	\N
216	139		\N		2025-11-10 21:14:39.4	2025-11-10 21:14:39.4	2025-11-10 21:14:39.4	2025-11-10 21:14:39.4	\N	\N	\N	\N		\N	\N
258	162		\N		2025-11-19 21:02:24.797	2025-11-21 20:34:12.789	2025-11-19 21:02:24.797	2025-11-21 20:34:12.789	\N	\N	\N	\N		\N	\N
217	130		\N	EQUIPO NO PUDO SER REPARADO.\nSE COTIZA REPARACIÓN SUPERA COSTO DEL EQUIPO CELULAR, NO REPARABLE.	2025-11-10 21:55:05.112	2025-11-10 21:55:54.187	2025-11-10 21:55:05.112	2025-11-10 21:55:54.187	\N	\N	\N	\N		\N	\N
221	146		\N		2025-11-12 18:37:26.886	2025-11-12 18:37:26.886	2025-11-12 18:37:26.886	2025-11-12 18:37:26.886	\N	\N	\N	\N		\N	\N
223	148		\N		2025-11-12 23:24:26.265	2025-11-12 23:28:50.952	2025-11-12 23:24:26.265	2025-11-12 23:28:50.952	\N	\N	\N	\N		\N	\N
266	166		\N		2025-11-21 21:19:06.997	2025-11-21 21:19:06.997	2025-11-21 21:19:06.997	2025-11-21 21:19:06.997	\N	\N	\N	\N		\N	\N
267	169		\N		2025-11-22 19:52:40.586	2025-11-22 19:52:40.586	2025-11-22 19:52:40.586	2025-11-22 19:52:40.586	\N	\N	\N	\N		\N	\N
268	168		\N		2025-11-22 22:07:53.169	2025-11-22 22:07:53.169	2025-11-22 22:07:53.169	2025-11-22 22:07:53.169	\N	\N	\N	\N		\N	\N
269	167		\N		2025-11-22 22:08:00.861	2025-11-22 22:08:00.861	2025-11-22 22:08:00.861	2025-11-22 22:08:00.861	\N	\N	\N	\N		\N	\N
226	150		\N		2025-11-12 23:57:53.234	2025-11-12 23:58:22.581	2025-11-12 23:57:53.234	2025-11-12 23:58:22.581	\N	\N	\N	\N		\N	\N
232	149		\N		2025-11-13 15:35:29.085	2025-11-13 15:35:29.085	2025-11-13 15:35:29.085	2025-11-13 15:35:29.085	\N	\N	\N	\N		\N	\N
233	140		\N		2025-11-13 15:54:23.408	2025-11-13 15:54:23.408	2025-11-13 15:54:23.408	2025-11-13 15:54:23.408	\N	\N	\N	\N		\N	\N
234	125		\N		2025-11-13 17:15:16.395	2025-11-13 17:15:17.186	2025-11-13 17:15:16.395	2025-11-13 17:15:17.186	\N	\N	\N	\N		\N	\N
270	170		\N		2025-11-23 19:21:18.276	2025-11-23 19:21:18.276	2025-11-23 19:21:18.276	2025-11-23 19:21:18.276	\N	\N	\N	\N		\N	\N
271	176		\N		2025-11-24 18:25:29.769	2025-11-24 18:25:29.769	2025-11-24 18:25:29.769	2025-11-24 18:25:29.769	\N	\N	\N	\N		\N	\N
272	174		\N		2025-11-24 23:00:57.898	2025-11-24 23:00:57.898	2025-11-24 23:00:57.898	2025-11-24 23:00:57.898	\N	\N	\N	\N		\N	\N
273	157		\N		2025-11-24 23:56:43.757	2025-11-24 23:56:43.757	2025-11-24 23:56:43.757	2025-11-24 23:56:43.757	\N	\N	\N	\N		\N	\N
220	142		\N		2025-11-11 22:16:50.122	2025-11-13 18:11:26.48	2025-11-11 22:16:50.122	2025-11-13 18:11:26.48	\N	\N	\N	\N		\N	\N
224	145		\N		2025-11-12 23:24:49.855	2025-11-13 18:12:11.201	2025-11-12 23:24:49.855	2025-11-13 18:12:11.201	\N	\N	\N	\N		\N	\N
222	147		\N		2025-11-12 22:47:19.597	2025-11-13 18:12:33.446	2025-11-12 22:47:19.597	2025-11-13 18:12:33.446	\N	\N	\N	\N		\N	\N
244	143		\N		2025-11-14 18:56:49.612	2025-11-14 18:56:49.612	2025-11-14 18:56:49.612	2025-11-14 18:56:49.612	\N	\N	\N	\N		\N	\N
246	153		\N		2025-11-14 20:00:50.642	2025-11-14 20:00:50.642	2025-11-14 20:00:50.642	2025-11-14 20:00:50.642	\N	\N	\N	\N		\N	\N
245	151		\N		2025-11-14 19:07:18.474	2025-11-14 22:05:12.051	2025-11-14 19:07:18.474	2025-11-14 22:05:12.051	\N	\N	\N	\N		\N	\N
249	154		\N		2025-11-15 18:48:59.859	2025-11-15 18:49:00.419	2025-11-15 18:48:59.859	2025-11-15 18:49:00.419	\N	\N	\N	\N		\N	\N
251	136		\N		2025-11-15 23:44:30.783	2025-11-15 23:44:30.783	2025-11-15 23:44:30.783	2025-11-15 23:44:30.783	\N	\N	\N	\N		\N	\N
252	114		\N		2025-11-18 21:31:33.372	2025-11-18 21:31:33.372	2025-11-18 21:31:33.372	2025-11-18 21:31:33.372	\N	\N	\N	\N		\N	\N
248	152		\N		2025-11-14 22:51:28.607	2025-11-18 21:36:35.953	2025-11-14 22:51:28.607	2025-11-18 21:36:35.953	\N	\N	\N	\N		\N	\N
254	158		\N	telefono reparado con marco roto se le informo al cliente de los riesgos que conlleva	2025-11-19 15:02:34.485	2025-11-19 15:03:10.709	2025-11-19 15:02:34.485	2025-11-19 15:03:10.709	\N	\N	\N	\N		\N	\N
256	160		\N	tenia un trozo de plastico debido a la caida solo se quito y listo	2025-11-19 18:11:25.284	2025-11-19 18:11:25.284	2025-11-19 18:11:25.284	2025-11-19 18:11:25.284	\N	\N	\N	\N		\N	\N
257	161		\N		2025-11-19 21:02:12.359	2025-11-20 19:21:54.89	2025-11-19 21:02:12.359	2025-11-20 19:21:54.89	\N	\N	\N	\N		\N	\N
260	165		\N		2025-11-21 18:26:38.349	2025-11-21 18:29:10.083	2025-11-21 18:26:38.349	2025-11-21 18:29:10.083	\N	\N	\N	\N		\N	\N
261	164		\N		2025-11-21 18:26:47.375	2025-11-21 18:29:38.159	2025-11-21 18:26:47.375	2025-11-21 18:29:38.159	\N	\N	\N	\N		\N	\N
264	163		\N		2025-11-21 18:30:43.306	2025-11-21 18:30:43.306	2025-11-21 18:30:43.306	2025-11-21 18:30:43.306	\N	\N	\N	\N		\N	\N
\.
COPY public.reparaciones_frecuentes (id, nombre, descripcion, activo, created_at, updated_at) FROM stdin;
1	Cambio pantalla iPhone 16 Pro	Cambio de pantalla, servicio y colocación de pantalla nueva original de iPhone 16 Pro	t	2025-06-17 20:04:59.051	2025-06-18 00:08:07.746
2	Cambio de Batería iPhone 16 Pro	Cambio de batería, y servicio para iPhone 16 Pro con producto original	t	2025-06-17 20:05:45.513	2025-06-18 00:08:23.812
3	servicio a centros de carga	se realiza la limpieza al centro de carga 	t	2025-08-18 20:12:41.658	2025-08-18 20:12:41.658
4	Diagnostico	Diagnostico a fallas , carga, imagen, audio, señal, touch, luz, encendido ,etc....	t	2025-08-19 15:35:10.977	2025-08-19 15:35:10.977
\.
COPY public.roles (id, nombre, descripcion, created_at, updated_at) FROM stdin;
16	ADMINISTRADOR_PUNTO	Administrador del punto de reparación	2025-06-17 21:30:43.504	2025-06-17 21:30:43.504
17	OPERADOR_PUNTO	Operador del punto de reparación	2025-06-17 21:30:43.514	2025-06-17 21:30:43.514
18	TECNICO	Técnico responsable de las reparaciones en central.	2025-06-17 21:33:19.092	2025-06-17 21:33:19.092
15	ADMINISTRADOR	Acceso total al sistema con todos los permisos	2025-06-17 21:30:43.134	2025-08-07 23:15:22.652
\.
COPY public.roles_permisos (id, rol_id, permiso_id, created_at, updated_at) FROM stdin;
260	16	223	2025-06-17 21:30:43.506	2025-06-17 21:30:43.506
261	16	224	2025-06-17 21:30:43.508	2025-06-17 21:30:43.508
262	16	225	2025-06-17 21:30:43.509	2025-06-17 21:30:43.509
263	16	226	2025-06-17 21:30:43.51	2025-06-17 21:30:43.51
264	16	227	2025-06-17 21:30:43.511	2025-06-17 21:30:43.511
265	16	228	2025-06-17 21:30:43.512	2025-06-17 21:30:43.512
266	16	229	2025-06-17 21:30:43.513	2025-06-17 21:30:43.513
267	16	230	2025-06-17 21:30:43.513	2025-06-17 21:30:43.513
268	17	227	2025-06-17 21:30:43.514	2025-06-17 21:30:43.514
269	17	228	2025-06-17 21:30:43.515	2025-06-17 21:30:43.515
270	17	229	2025-06-17 21:30:43.515	2025-06-17 21:30:43.515
271	18	206	2025-06-17 21:33:19.092	2025-06-17 21:33:19.092
272	18	208	2025-06-17 21:33:19.092	2025-06-17 21:33:19.092
273	18	209	2025-06-17 21:33:19.092	2025-06-17 21:33:19.092
274	18	207	2025-06-17 21:33:19.092	2025-06-17 21:33:19.092
275	18	196	2025-06-17 21:33:19.092	2025-06-17 21:33:19.092
276	18	198	2025-06-17 21:33:19.092	2025-06-17 21:33:19.092
277	18	199	2025-06-17 21:33:19.092	2025-06-17 21:33:19.092
278	18	197	2025-06-17 21:33:19.092	2025-06-17 21:33:19.092
279	18	200	2025-06-17 21:33:19.092	2025-06-17 21:33:19.092
280	18	204	2025-06-17 21:33:19.092	2025-06-17 21:33:19.092
281	18	202	2025-06-17 21:33:19.092	2025-06-17 21:33:19.092
282	18	201	2025-06-17 21:33:19.092	2025-06-17 21:33:19.092
283	18	203	2025-06-17 21:33:19.092	2025-06-17 21:33:19.092
284	18	205	2025-06-17 21:33:19.092	2025-06-17 21:33:19.092
285	18	185	2025-06-18 21:59:03.152	2025-06-18 21:59:03.152
325	15	185	2025-08-07 23:15:22.66	2025-08-07 23:15:22.66
326	15	186	2025-08-07 23:15:22.666	2025-08-07 23:15:22.666
327	15	187	2025-08-07 23:15:22.668	2025-08-07 23:15:22.668
328	15	188	2025-08-07 23:15:22.673	2025-08-07 23:15:22.673
329	15	189	2025-08-07 23:15:22.677	2025-08-07 23:15:22.677
330	15	190	2025-08-07 23:15:22.682	2025-08-07 23:15:22.682
331	15	191	2025-08-07 23:15:22.684	2025-08-07 23:15:22.684
332	15	192	2025-08-07 23:15:22.687	2025-08-07 23:15:22.687
333	15	193	2025-08-07 23:15:22.691	2025-08-07 23:15:22.691
334	15	194	2025-08-07 23:15:22.694	2025-08-07 23:15:22.694
335	15	195	2025-08-07 23:15:22.696	2025-08-07 23:15:22.696
336	15	196	2025-08-07 23:15:22.699	2025-08-07 23:15:22.699
337	15	197	2025-08-07 23:15:22.702	2025-08-07 23:15:22.702
338	15	198	2025-08-07 23:15:22.705	2025-08-07 23:15:22.705
339	15	199	2025-08-07 23:15:22.708	2025-08-07 23:15:22.708
340	15	200	2025-08-07 23:15:22.713	2025-08-07 23:15:22.713
341	15	201	2025-08-07 23:15:22.715	2025-08-07 23:15:22.715
342	15	202	2025-08-07 23:15:22.718	2025-08-07 23:15:22.718
343	15	203	2025-08-07 23:15:22.722	2025-08-07 23:15:22.722
344	15	204	2025-08-07 23:15:22.725	2025-08-07 23:15:22.725
345	15	205	2025-08-07 23:15:22.729	2025-08-07 23:15:22.729
346	15	206	2025-08-07 23:15:22.732	2025-08-07 23:15:22.732
347	15	207	2025-08-07 23:15:22.735	2025-08-07 23:15:22.735
348	15	208	2025-08-07 23:15:22.738	2025-08-07 23:15:22.738
349	15	209	2025-08-07 23:15:22.74	2025-08-07 23:15:22.74
350	15	210	2025-08-07 23:15:22.743	2025-08-07 23:15:22.743
351	15	211	2025-08-07 23:15:22.745	2025-08-07 23:15:22.745
352	15	212	2025-08-07 23:15:22.748	2025-08-07 23:15:22.748
353	15	213	2025-08-07 23:15:22.75	2025-08-07 23:15:22.75
354	15	214	2025-08-07 23:15:22.752	2025-08-07 23:15:22.752
355	15	215	2025-08-07 23:15:22.756	2025-08-07 23:15:22.756
356	15	216	2025-08-07 23:15:22.758	2025-08-07 23:15:22.758
357	15	217	2025-08-07 23:15:22.761	2025-08-07 23:15:22.761
358	15	218	2025-08-07 23:15:22.764	2025-08-07 23:15:22.764
359	15	219	2025-08-07 23:15:22.767	2025-08-07 23:15:22.767
360	15	220	2025-08-07 23:15:22.77	2025-08-07 23:15:22.77
361	15	221	2025-08-07 23:15:22.773	2025-08-07 23:15:22.773
362	15	222	2025-08-07 23:15:22.776	2025-08-07 23:15:22.776
363	15	231	2025-08-07 23:15:22.779	2025-08-07 23:15:22.779
364	15	232	2025-08-07 23:15:22.782	2025-08-07 23:15:22.782
\.
COPY public.salidas_almacen (id, producto_id, cantidad, razon, tipo, referencia, fecha, usuario_id, created_at, updated_at) FROM stdin;
1	5	1	Reparación completada - Ticket #10	REPARACION	Ticket-10	2025-08-07 15:02:20.986	2	2025-08-07 15:02:20.986	2025-08-07 15:02:20.986
2	5	2	VENTA	VENTA	Venta #1	2025-08-07 21:35:21.792	2	2025-08-07 21:35:21.792	2025-08-07 21:35:21.792
3	6	1	VENTA	VENTA	Venta #1	2025-08-07 21:35:21.805	2	2025-08-07 21:35:21.805	2025-08-07 21:35:21.805
4	5	1	Reparación completada - Ticket #11	REPARACION	Ticket-11	2025-08-08 15:43:57.292	2	2025-08-08 15:43:57.292	2025-08-08 15:43:57.292
5	6	1	VENTA	VENTA	Venta #2	2025-08-12 22:08:43.246	17	2025-08-12 22:08:43.246	2025-08-12 22:08:43.246
6	5	1	VENTA	VENTA	Venta #3	2025-08-18 16:20:41.238	18	2025-08-18 16:20:41.238	2025-08-18 16:20:41.238
7	5	1	Reparación completada - Ticket #13	REPARACION	Ticket-13	2025-08-19 15:33:03.251	15	2025-08-19 15:33:03.251	2025-08-19 15:33:03.251
9	11	1	VENTA	VENTA	Venta #4	2025-08-19 15:53:46.807	15	2025-08-19 15:53:46.807	2025-08-19 15:53:46.807
10	11	1	VENTA	VENTA	Venta #5	2025-08-19 15:54:23.135	15	2025-08-19 15:54:23.135	2025-08-19 15:54:23.135
11	6	1	VENTA	VENTA	Venta #5	2025-08-19 15:54:23.139	15	2025-08-19 15:54:23.139	2025-08-19 15:54:23.139
12	14	10	VENTA	VENTA	Venta #6	2025-08-19 15:55:13.68	15	2025-08-19 15:55:13.68	2025-08-19 15:55:13.68
13	5	1	Reparación completada - Ticket #3	REPARACION	Ticket-3	2025-08-19 23:19:20.84	15	2025-08-19 23:19:20.84	2025-08-19 23:19:20.84
14	14	1	Reparación completada - Ticket #15	REPARACION	Ticket-15	2025-08-20 01:16:11.005	2	2025-08-20 01:16:11.005	2025-08-20 01:16:11.005
15	6	1	VENTA	VENTA	Venta #7	2025-08-20 08:27:08.009	2	2025-08-20 08:27:08.009	2025-08-20 08:27:08.009
16	14	1	Reparación completada - Ticket #16	REPARACION	Ticket-16	2025-08-20 16:56:51.567	15	2025-08-20 16:56:51.567	2025-08-20 16:56:51.567
17	5	1	VENTA	VENTA	Venta #8	2025-08-20 20:37:17.3	17	2025-08-20 20:37:17.3	2025-08-20 20:37:17.3
18	19	1	VENTA	VENTA	Venta #9	2025-08-20 20:52:58.321	17	2025-08-20 20:52:58.321	2025-08-20 20:52:58.321
20	1048	1	Venta al publico	VENTA		2025-09-05 18:05:17.191	17	2025-09-05 18:05:17.191	2025-09-05 18:05:17.19
21	1043	1	Reparación completada - Ticket #29	REPARACION	Ticket-29	2025-09-13 20:20:44.667	17	2025-09-13 20:20:44.667	2025-09-13 20:20:44.667
22	1055	1	VENTA	VENTA	Venta #10	2025-09-19 20:01:52.228	17	2025-09-19 20:01:52.228	2025-09-19 20:01:52.228
23	1095	1	VENTA	VENTA	Venta #11	2025-09-20 18:12:00.714	17	2025-09-20 18:12:00.714	2025-09-20 18:12:00.714
24	1096	2	Reparación completada - Ticket #32	REPARACION	Ticket-32	2025-09-21 00:04:47.482	17	2025-09-21 00:04:47.482	2025-09-21 00:04:47.482
25	1075	1	Reparación completada - Ticket #32	REPARACION	Ticket-32	2025-09-21 00:04:47.492	17	2025-09-21 00:04:47.492	2025-09-21 00:04:47.492
26	1095	1	Reparación completada - Ticket #32	REPARACION	Ticket-32	2025-09-21 00:04:47.504	17	2025-09-21 00:04:47.504	2025-09-21 00:04:47.504
27	1043	1	Reparación completada - Ticket #50	REPARACION	Ticket-50	2025-09-27 20:13:12.942	17	2025-09-27 20:13:12.942	2025-09-27 20:13:12.942
28	1096	1	VENTA	VENTA	Venta #12	2025-10-02 17:35:08.448	17	2025-10-02 17:35:08.448	2025-10-02 17:35:08.448
29	933	1	se instalo	REPARACION		2025-10-02 22:06:43.724	17	2025-10-02 22:06:43.724	2025-10-02 22:06:43.723
30	1104	1	Hicimos devolución de $500 a Brenda García TICK-1759533269126	AJUSTE	TICK-1759533269126	2025-10-08 20:32:05.595	17	2025-10-08 20:32:05.595	2025-10-08 20:32:05.594
31	1104	1	Se realiza devolución ,no se consiguió la refacción  TICK-1758648971834	AJUSTE	TICK-1758648971834	2025-10-08 20:35:01.082	17	2025-10-08 20:35:01.082	2025-10-08 20:35:01.081
32	1105	1	Se realizo la instalación correctamente	VENTA		2025-10-08 20:39:29.15	17	2025-10-08 20:39:29.15	2025-10-08 20:39:29.149
42	1108	1	Se entrega equipo desbloqueado	VENTA		2025-10-11 23:07:15.956	17	2025-10-11 23:07:15.956	2025-10-11 23:07:15.955
43	270	1	Se coloca display 	VENTA		2025-10-11 23:08:52.392	17	2025-10-11 23:08:52.392	2025-10-11 23:08:52.391
44	1109	1	Se coloca bateria nueva	VENTA		2025-10-11 23:10:44.749	17	2025-10-11 23:10:44.749	2025-10-11 23:10:44.748
45	286	1	Se cambia display	VENTA		2025-10-11 23:14:22.692	17	2025-10-11 23:14:22.692	2025-10-11 23:14:22.691
46	853	1	Se coloca display nuevo	VENTA		2025-10-11 23:18:27.877	17	2025-10-11 23:18:27.877	2025-10-11 23:18:27.875
47	14	1	Colocación de auricular	VENTA		2025-10-11 23:19:51.085	17	2025-10-11 23:19:51.085	2025-10-11 23:19:51.084
48	432	1	Colocación de display	VENTA		2025-10-14 21:43:15.706	17	2025-10-14 21:43:15.706	2025-10-14 21:43:15.705
49	365	1	Colocación de display y tapa	VENTA		2025-10-14 21:46:09.764	17	2025-10-14 21:46:09.764	2025-10-14 21:46:09.763
50	275	1	Colocación display	VENTA		2025-10-14 21:51:04.646	17	2025-10-14 21:51:04.646	2025-10-14 21:51:04.645
51	1104	1	El equipo venia muy mal trabajado de otro taller, se corría mas riesgo reparándolo	VENTA		2025-10-14 21:54:52.055	17	2025-10-14 21:54:52.055	2025-10-14 21:54:52.052
52	372	1	Colocacion de display 	VENTA		2025-10-16 20:26:22.792	17	2025-10-16 20:26:22.792	2025-10-16 20:26:22.791
53	432	1	Colocación de display 	VENTA		2025-10-17 20:50:48.377	17	2025-10-17 20:50:48.377	2025-10-17 20:50:48.376
54	1103	1	se colocó la refacción	VENTA		2025-10-18 20:55:55.624	17	2025-10-18 20:55:55.624	2025-10-18 20:55:55.623
56	564	1	Colocación de display 	VENTA		2025-10-27 23:04:14.272	17	2025-10-27 23:04:14.272	2025-10-27 23:04:14.271
57	212	1	Colocación de bateria	VENTA		2025-10-28 21:48:45.773	17	2025-10-28 21:48:45.773	2025-10-28 21:48:45.772
58	1113	1	Colocación portasim	VENTA		2025-10-28 21:50:30.999	17	2025-10-28 21:50:30.999	2025-10-28 21:50:30.998
59	496	1	Colocacion de display	VENTA		2025-10-28 21:52:15.607	17	2025-10-28 21:52:15.607	2025-10-28 21:52:15.606
60	933	1	Colocación de bateria	VENTA		2025-10-28 21:59:15.461	17	2025-10-28 21:59:15.461	2025-10-28 21:59:15.46
61	303	1	Colocación de display	VENTA		2025-10-28 22:00:49.548	17	2025-10-28 22:00:49.548	2025-10-28 22:00:49.547
62	241	1	Colocacion de display	VENTA		2025-10-28 22:02:53.988	17	2025-10-28 22:02:53.988	2025-10-28 22:02:53.987
63	245	1	Colocación de pieza	VENTA		2025-10-28 22:06:58.36	17	2025-10-28 22:06:58.36	2025-10-28 22:06:58.359
64	141	1	Colocacion de pieza	VENTA		2025-10-28 22:10:26.551	17	2025-10-28 22:10:26.551	2025-10-28 22:10:26.55
65	434	1	Colocación pieza	VENTA		2025-10-28 22:18:17.041	17	2025-10-28 22:18:17.041	2025-10-28 22:18:17.038
66	1026	1	Colocación pieza	VENTA		2025-10-28 22:19:20.711	17	2025-10-28 22:19:20.711	2025-10-28 22:19:20.71
67	431	1	Colocación de pieza	VENTA		2025-10-28 22:20:07.803	17	2025-10-28 22:20:07.803	2025-10-28 22:20:07.802
68	1026	1	Colocacion de pieza	VENTA		2025-10-28 22:20:55.53	17	2025-10-28 22:20:55.53	2025-10-28 22:20:55.529
69	958	1	Colocacion de display	VENTA		2025-10-28 22:22:18.701	17	2025-10-28 22:22:18.701	2025-10-28 22:22:18.7
70	467	1	Colocacion de display	VENTA		2025-10-28 22:23:43.529	17	2025-10-28 22:23:43.529	2025-10-28 22:23:43.528
71	379	1	Colocacion de pieza	VENTA		2025-10-28 22:24:23.889	17	2025-10-28 22:24:23.889	2025-10-28 22:24:23.888
72	826	1	Colocacion de pieza	VENTA		2025-10-28 22:27:37.796	17	2025-10-28 22:27:37.796	2025-10-28 22:27:37.795
73	810	1	se coloco el display	VENTA		2025-10-31 22:20:45.542	17	2025-10-31 22:20:45.542	2025-10-31 22:20:45.541
74	152	1	se coloco pila a samsung a 35	VENTA		2025-10-31 22:22:01.189	17	2025-10-31 22:22:01.189	2025-10-31 22:22:01.188
75	1044	1	Reparación completada - Ticket #122	REPARACION	Ticket-122	2025-11-01 20:55:34.476	17	2025-11-01 20:55:34.476	2025-11-01 20:55:34.476
76	412	1	Colocación de display	VENTA		2025-11-01 21:56:51.168	17	2025-11-01 21:56:51.168	2025-11-01 21:56:51.167
77	417	1	Colocacion  de display	VENTA		2025-11-01 21:57:47.215	17	2025-11-01 21:57:47.215	2025-11-01 21:57:47.214
78	1114	1	Colocacion de pieza	VENTA		2025-11-01 21:58:57.897	17	2025-11-01 21:58:57.897	2025-11-01 21:58:57.896
79	423	1	Colocacion de pieza	VENTA		2025-11-01 22:00:19.353	17	2025-11-01 22:00:19.353	2025-11-01 22:00:19.352
80	1104	1	se hizo devolución de $200 bocina jbl z5 flip regreso por garantia  	VENTA		2025-11-02 21:24:10.292	17	2025-11-02 21:24:10.292	2025-11-02 21:24:10.291
81	467	1	Se instaló la pantalla	VENTA		2025-11-05 22:24:07.824	16	2025-11-05 22:24:07.824	2025-11-05 22:24:07.823
82	1116	1	Se realiza instalación de pin de carga por reparación.\n#TICK-1762451567142\n06/11/2025	REPARACION	#TICK-1762451567142	2025-11-06 19:11:18.573	24	2025-11-06 19:11:18.573	2025-11-06 19:11:18.572
83	1108	1	Se realizo desbloque de equipo, para reparación.	REPARACION		2025-11-06 23:22:51.382	24	2025-11-06 23:22:51.382	2025-11-06 23:22:51.381
84	1116	1	Reparación completada - Ticket #131	REPARACION	Ticket-131	2025-11-08 21:05:07.683	24	2025-11-08 21:05:07.683	2025-11-08 21:05:07.683
85	626	1	Se realiza reparación celular del equipo SM-a15	REPARACION	TICK-1762633045155	2025-11-08 21:47:51.425	24	2025-11-08 21:47:51.425	2025-11-08 21:47:51.424
86	6	1	Reparación completada - Ticket #133	REPARACION	Ticket-133	2025-11-08 21:53:18.625	24	2025-11-08 21:53:18.625	2025-11-08 21:53:18.625
87	1114	1	Se realiza reparación	REPARACION	#TICK-1762473272836	2025-11-08 22:43:58.323	24	2025-11-08 22:43:58.323	2025-11-08 22:43:58.321
88	1118	1	Se realiza reparación	REPARACION	#TICK-1762473272836	2025-11-08 22:48:53.349	24	2025-11-08 22:48:53.349	2025-11-08 22:48:53.348
89	1117	2	Se realiza reparación de IOS, tapa ty bateria	REPARACION	#TICK-1762473272836	2025-11-08 22:50:13.193	24	2025-11-08 22:50:13.193	2025-11-08 22:50:13.192
90	1059	1	VENTA	VENTA	Venta #16	2025-11-10 16:10:44.509	24	2025-11-10 16:10:44.509	2025-11-10 16:10:44.509
91	1063	1	VENTA	VENTA	Venta #17	2025-11-10 16:29:18.845	16	2025-11-10 16:29:18.845	2025-11-10 16:29:18.845
92	1119	1	Se realiza reparación de Redmi Note 11 	REPARACION	#TICK-1762288770175	2025-11-12 17:17:02.832	24	2025-11-12 17:17:02.832	2025-11-12 17:17:02.831
93	1117	1	Reparación celular	REPARACION		2025-11-12 19:58:52.581	24	2025-11-12 19:58:52.581	2025-11-12 19:58:52.579
94	1117	1	Reparación	REPARACION	TICK-1762970205831	2025-11-12 20:35:35.883	24	2025-11-12 20:35:35.883	2025-11-12 20:35:35.882
95	1117	1	Se realiza reparación a motorola E22i\n	REPARACION	Ticket #TICK-1762993061755	2025-11-13 17:07:01.527	24	2025-11-13 17:07:01.527	2025-11-13 17:07:01.526
96	1120	1	Se realiza reparación de un Redmi Note 11	REPARACION	Ticket #TICK-1762288770175	2025-11-13 17:14:33.468	24	2025-11-13 17:14:33.468	2025-11-13 17:14:33.467
97	1043	1	Reparación completada - Ticket #147	REPARACION	Ticket-147	2025-11-13 18:12:33.475	24	2025-11-13 18:12:33.475	2025-11-13 18:12:33.475
98	937	1	Se realiza reparación de equipo celular.	REPARACION	#TICK-1762970205831	2025-11-13 18:23:54.785	24	2025-11-13 18:23:54.785	2025-11-13 18:23:54.784
99	961	1	Se realiza reparación a iPhone XR	REPARACION	#TICK-1762970205831	2025-11-13 18:26:24.362	24	2025-11-13 18:26:24.362	2025-11-13 18:26:24.362
100	423	1	Se realiza reparación a motorola E22i	REPARACION	#TICK-1762993061755	2025-11-13 19:19:13.767	24	2025-11-13 19:19:13.767	2025-11-13 19:19:13.766
101	1116	1	VENTA	VENTA	Venta #18	2025-11-14 22:49:45.087	24	2025-11-14 22:49:45.087	2025-11-14 22:49:45.087
102	1120	1	Se realiza reparación a Motorola G	REPARACION	#TICK-1763066143652	2025-11-15 16:21:28.556	24	2025-11-15 16:21:28.556	2025-11-15 16:21:28.555
103	1121	1	Se ingresa a reparación de iPhone 7 Plus	REPARACION	#TICK-1763134004250	2025-11-15 17:01:33.316	24	2025-11-15 17:01:33.316	2025-11-15 17:01:33.315
104	1108	1	Se pide desbloqueo Motog53	REPARACION	#TICK-1763134004250	2025-11-15 17:21:01.251	24	2025-11-15 17:21:01.251	2025-11-15 17:21:01.25
105	1117	1	Se solicito refacción de pantalla iPhone 7plus	REPARACION	Ticket #TICK-1763134004250	2025-11-15 19:33:07.467	24	2025-11-15 19:33:07.467	2025-11-15 19:33:07.466
106	1087	1	VENTA	VENTA	Venta #19	2025-11-16 17:46:58.932	24	2025-11-16 17:46:58.932	2025-11-16 17:46:58.932
107	1076	2	VENTA	VENTA	Venta #19	2025-11-16 17:46:58.938	24	2025-11-16 17:46:58.938	2025-11-16 17:46:58.938
108	1064	2	VENTA	VENTA	Venta #19	2025-11-16 17:46:58.943	24	2025-11-16 17:46:58.943	2025-11-16 17:46:58.943
109	1122	1	VENTA	VENTA	Venta #19	2025-11-16 17:46:58.948	24	2025-11-16 17:46:58.948	2025-11-16 17:46:58.948
110	1075	1	VENTA	VENTA	Venta #19	2025-11-16 17:46:58.954	24	2025-11-16 17:46:58.954	2025-11-16 17:46:58.954
111	1048	1	VENTA	VENTA	Venta #20	2025-11-17 23:35:27.285	24	2025-11-17 23:35:27.285	2025-11-17 23:35:27.285
112	427	1	Se realiza reparación de equipo motorola E7	REPARACION	#TICK-1763497875867	2025-11-18 21:54:05.266	24	2025-11-18 21:54:05.266	2025-11-18 21:54:05.264
113	1116	1	Reparación completada - Ticket #161	REPARACION	Ticket-161	2025-11-20 19:21:54.934	24	2025-11-20 19:21:54.934	2025-11-20 19:21:54.934
114	1031	1	VENTA	VENTA	Venta #21	2025-11-20 21:37:05.309	24	2025-11-20 21:37:05.309	2025-11-20 21:37:05.309
115	1108	1	Se realiza reparación motorola G85	REPARACION	#TICK-1763497875867	2025-11-20 21:48:50.255	24	2025-11-20 21:48:50.255	2025-11-20 21:48:50.254
116	447	1	Se realiza reparación de motorola g9 play	REPARACION	 #TICK-1763837982813	2025-11-22 20:08:29.782	24	2025-11-22 20:08:29.782	2025-11-22 20:08:29.781
117	447	1	Se realiza reparación de motorola g9 play	REPARACION	#TICK-1763838343466	2025-11-22 20:09:01.231	24	2025-11-22 20:09:01.231	2025-11-22 20:09:01.231
118	1059	1	VENTA	VENTA	Venta #22	2025-11-22 23:38:17.66	24	2025-11-22 23:38:17.66	2025-11-22 23:38:17.66
119	1067	1	Venta de herramienta	VENTA	#TICK-1763925587776	2025-11-23 19:22:24.604	24	2025-11-23 19:22:24.604	2025-11-23 19:22:24.603
120	1147	1	Se vende herramienta	VENTA	#TICK-1763925587776	2025-11-23 19:23:13.044	24	2025-11-23 19:23:13.044	2025-11-23 19:23:13.043
121	1128	1	Venta de herramienta	VENTA	#TICK-1763925587776	2025-11-23 19:23:30.512	24	2025-11-23 19:23:30.512	2025-11-23 19:23:30.511
\.
COPY public.ticket_problemas (id, ticket_id, problema_id, created_at, updated_at) FROM stdin;
\.
COPY public.tickets (id, numero_ticket, fecha_recepcion, cliente_id, tipo_servicio_id, modelo_id, descripcion_problema, estatus_reparacion_id, creador_id, tecnico_asignado_id, punto_recoleccion_id, recogida, fecha_entrega, entregado, cancelado, motivo_cancelacion, fecha_inicio_diagnostico, fecha_fin_diagnostico, fecha_inicio_reparacion, fecha_fin_reparacion, fecha_cancelacion, direccion_id, imei, capacidad, color, fecha_compra, codigo_desbloqueo, red_celular, patron_desbloqueo, created_at, updated_at, tipo_desbloqueo) FROM stdin;
23	TICK-1757186508300	2025-09-06 19:21:48.302	19	1	376	Cambio de batería y reemplazo del vidrio de la cámara trasera. 	32	17	16	\N	f	2025-09-10 18:43:40.936	t	f	\N	\N	\N	\N	2025-09-10 18:43:21.366	\N	\N		265	gris	2025-04-30 00:00:00	1234	5g	{}	2025-09-06 19:21:48.302	2025-09-10 18:43:40.936	pin
33	TICK-1758413178742	2025-09-21 00:06:18.749	17	32	373	Sin carga	32	17	16	\N	f	2025-09-21 00:07:33.367	t	f	\N	\N	\N	\N	2025-09-21 00:07:12.048	\N	\N	012545212012545	265	negro	2025-08-06 00:00:00			{}	2025-09-21 00:06:18.749	2025-09-21 00:07:33.367	pin
42	TICK-1758665702329	2025-09-23 22:15:02.331	31	1	710	Display roto.	32	17	16	\N	f	2025-09-23 22:17:02.535	t	f	\N	\N	\N	\N	2025-09-23 22:16:51.904	\N	\N	012545212012545	265	negro	2025-05-06 00:00:00	100283	5G	{}	2025-09-23 22:15:02.331	2025-09-23 22:17:02.535	pin
26	TICK-1757522119102	2025-09-10 16:35:19.103	23	1	1080	Ya no carga el equipo	32	17	16	\N	f	2025-09-11 18:25:29.41	t	f	\N	\N	\N	\N	2025-09-10 16:36:30.859	\N	\N		256		2025-06-03 00:00:00	\N		{2,4,6,8,1,3}	2025-09-10 16:35:19.103	2025-09-11 18:25:29.41	patron
22	TICK-1757089253383	2025-09-05 16:20:53.385	18	1	1072	display dañado	29	17	16	\N	f	2025-09-06 22:37:38.414	t	f	\N	2025-09-06 23:18:14.211	\N	\N	2025-09-06 22:37:30.076	\N	\N			gris	2020-12-12 00:00:00	121083	att	{}	2025-09-05 16:20:53.385	2025-09-06 23:18:14.211	pin
30	TICK-1757807287925	2025-09-13 23:48:07.927	22	32	1101	Compra de herramienta	30	17	16	\N	f	2025-09-13 23:50:02.416	t	f	\N	\N	\N	\N	2025-09-13 23:49:46.727	\N	\N				2025-09-13 00:00:00			{}	2025-09-13 23:48:07.927	2025-09-13 23:50:02.416	pin
27	TICK-1757615046984	2025-09-11 18:24:06.986	17	32	1106	caja	32	17	16	\N	f	2025-09-11 18:24:56.337	t	f	\N	\N	\N	\N	2025-09-11 18:24:42.495	\N	\N	012545212012545			2025-09-11 00:00:00			{}	2025-09-11 18:24:06.986	2025-09-11 18:24:56.337	pin
20	TICK-1756752940482	2025-09-01 18:55:40.484	14	6	141	Cargador no emite carga 	32	17	16	\N	f	2025-09-01 19:01:16.88	t	f	\N	\N	\N	\N	2025-09-01 19:00:42.39	\N	\N				2025-07-01 00:00:00			{}	2025-09-01 18:55:40.484	2025-09-01 19:02:41.933	pin
37	TICK-1758584461460	2025-09-22 23:41:01.462	17	31	1098	accesorios	32	17	16	\N	f	\N	f	f	\N	\N	\N	\N	2025-09-22 23:41:30.034	\N	\N	012545212012545	265	negro	2025-08-06 00:00:00			{}	2025-09-22 23:41:01.462	2025-09-22 23:41:30.034	pin
19	TICK-1756747440673	2025-09-01 17:24:00.675	13	1	515	No carga el equipo.\n\nSe brinda servicio a centro de carga 	32	17	16	\N	f	2025-09-01 17:50:55.875	t	f	\N	2025-09-01 17:28:08.954	\N	\N	2025-09-01 17:36:29.58	\N	\N	868112063200640	256	negro	2025-06-03 00:00:00		5G	{1,2,3,4}	2025-09-01 17:24:00.675	2025-09-01 17:50:55.875	patron
24	TICK-1757360997928	2025-09-08 19:49:57.93	17	1	236	Bloqueado por compañia	32	17	16	\N	f	2025-09-08 19:55:18.556	t	f	\N	\N	\N	\N	2025-09-08 19:54:27.217	\N	\N				2025-03-05 00:00:00			{}	2025-09-08 19:49:57.93	2025-09-08 19:55:18.556	pin
21	TICK-1756757211166	2025-09-01 20:06:51.168	15	1	117	Bloqueo por olvido de contraseña	32	17	16	\N	f	2025-09-01 21:18:10.308	t	f	\N	2025-09-01 20:09:02.084	\N	\N	2025-09-01 21:17:46.362	\N	\N		256	negro	2025-03-31 00:00:00	\N	5G	{1,2,3,4,5,6}	2025-09-01 20:06:51.168	2025-09-01 21:18:10.308	patron
41	TICK-1758655917665	2025-09-23 19:31:57.667	30	1	236	Desbloqueo 	30	17	16	\N	f	\N	f	f	\N	\N	\N	\N	\N	\N	\N				2025-09-23 00:00:00			{}	2025-09-23 19:31:57.667	2025-09-23 19:39:08.585	pin
25	TICK-1757459875684	2025-09-09 23:17:55.685	22	32	1107	Compra de herramienta	32	17	16	\N	f	2025-09-10 00:02:15.004	t	f	\N	\N	\N	\N	2025-09-10 00:00:51.243	\N	\N	123456789123456	12		2025-09-08 00:00:00		5g	{}	2025-09-09 23:17:55.685	2025-09-10 00:02:15.004	pin
40	TICK-1758648971834	2025-09-23 17:36:11.837	29	1	834	Altavoz no funciona, se solicita reemplazo.	34	17	16	\N	f	\N	f	t	Eliminado por el usuario	\N	\N	\N	\N	\N	\N		256		2025-06-04 00:00:00			{}	2025-09-23 17:36:11.837	2025-09-25 17:06:28.737	pin
29	TICK-1757794653020	2025-09-13 20:17:33.022	25	33	392	no carga el equipo, se reemplaza centro de carga	32	17	16	\N	f	2025-09-13 20:20:05.461	t	f	\N	\N	\N	\N	2025-09-13 20:20:44.637	\N	\N				2025-06-11 00:00:00			{}	2025-09-13 20:17:33.022	2025-09-13 20:20:44.637	pin
38	TICK-1758645030104	2025-09-23 16:30:30.105	28	1	1073	Cámaras rotas, auricular no se escucha 	32	17	16	\N	f	2025-09-23 16:35:22.499	t	f	\N	\N	\N	\N	2025-09-23 16:35:11.36	\N	\N	012545212012545	265	negro	2025-05-06 00:00:00	100283	5G	{}	2025-09-23 16:30:30.105	2025-09-23 16:35:22.499	pin
35	TICK-1758488259795	2025-09-21 20:57:39.797	27	1	916	servicio a centro de carga	32	16	16	\N	f	2025-09-21 20:58:34.006	t	f	\N	\N	\N	\N	2025-09-21 20:58:13.905	\N	\N				2025-12-20 00:00:00			{}	2025-09-21 20:57:39.797	2025-09-21 20:58:34.006	pin
32	TICK-1758413015124	2025-09-21 00:03:35.126	17	32	1101	Compra herramienta	32	17	16	\N	f	2025-09-21 00:05:13.512	t	f	\N	\N	\N	\N	2025-09-21 00:04:47.444	\N	\N	012545212012545	265		2025-09-20 00:00:00			{}	2025-09-21 00:03:35.126	2025-09-21 00:05:13.512	pin
28	TICK-1757634136054	2025-09-11 23:42:16.055	24	1	390	Carga de sistema operativo 	32	17	16	\N	f	2025-09-13 23:51:20.315	t	f	\N	\N	\N	\N	2025-09-13 23:50:25.169	\N	\N				2025-05-07 00:00:00			{}	2025-09-11 23:42:16.055	2025-09-13 23:51:20.315	pin
34	TICK-1758488096009	2025-09-21 20:54:56.01	23	1	1073	display dañado	32	16	16	\N	f	2025-09-23 22:13:09.436	t	f	\N	\N	\N	\N	2025-09-23 22:12:55.912	\N	\N			gris	0025-09-20 00:00:00	171062		{}	2025-09-21 20:54:56.01	2025-09-23 22:13:09.436	pin
46	TICK-1758925072013	2025-09-26 22:17:52.014	35	1	709	Virus  se le informo que perdía la información y se lo llevo para resguardarla y regresa   	34	17	16	\N	f	\N	f	t	Eliminado por el usuario	\N	\N	\N	\N	\N	\N	012545212012545	265	negro	2025-09-26 00:00:00		5G	{}	2025-09-26 22:17:52.014	2025-10-11 15:09:50.885	pin
39	TICK-1758645499436	2025-09-23 16:38:19.438	28	1	1086	Display roto, auricular inservible 	32	17	16	\N	f	2025-09-23 16:41:21.224	t	f	\N	\N	\N	\N	2025-09-23 16:41:08.943	\N	\N	012545212012545	265	negro	2025-05-06 00:00:00	100283	5G	{}	2025-09-23 16:38:19.438	2025-09-23 16:41:21.224	pin
31	TICK-1758134335824	2025-09-17 18:38:55.826	26	32	1101	Venta de herramienta	30	17	16	\N	f	\N	f	t	Eliminado por el usuario	\N	\N	\N	2025-09-17 20:02:44.733	\N	\N				2025-09-17 00:00:00			{}	2025-09-17 18:38:55.826	2025-09-21 20:59:01.562	pin
47	TICK-1758927462045	2025-09-26 22:57:42.046	36	1	618	Bloqueado	32	17	16	\N	f	2025-09-26 23:07:58.34	t	f	\N	\N	\N	\N	2025-09-26 23:07:45.234	\N	\N	123456789123456	256	azul	2025-08-05 00:00:00		5G	{}	2025-09-26 22:57:42.046	2025-09-26 23:07:58.34	pin
36	TICK-1758581046360	2025-09-22 22:44:06.361	17	1	1039	Display roto y despegado	32	17	16	\N	f	2025-09-23 22:06:08.159	t	f	\N	\N	\N	\N	2025-09-23 22:05:35.763	\N	\N	012545212012545	265	negro	2025-08-06 00:00:00	\N		{3,9,7,1}	2025-09-22 22:44:06.361	2025-09-23 22:06:08.159	patron
45	TICK-1758919209598	2025-09-26 20:40:09.599	34	1	323	No reconoce el centro de carga 	32	17	16	\N	f	2025-09-26 22:46:00.138	t	f	\N	\N	\N	\N	2025-09-26 22:45:40.56	\N	\N	012545212012545	265	azul	2025-09-05 00:00:00		5G	{}	2025-09-26 20:40:09.599	2025-09-26 22:46:00.138	pin
49	TICK-1759003818178	2025-09-27 20:10:18.18	38	31	1093	Compra de cargador	32	17	16	\N	f	2025-09-27 20:11:14.433	t	f	\N	\N	\N	\N	2025-09-27 20:11:05.222	\N	\N	012545212012545	265	negro	2025-09-27 00:00:00		5G	{}	2025-09-27 20:10:18.18	2025-09-27 20:11:14.433	pin
43	TICK-1758841288286	2025-09-25 23:01:28.289	32	1	719	Desbloqueo y eliminación de cuenta Gmail	32	17	16	\N	f	2025-09-30 23:03:56.043	t	f	\N	\N	\N	\N	2025-09-30 23:03:39.082	\N	\N	012545212012545	265	negro	2025-09-03 00:00:00	100283	5G	{}	2025-09-25 23:01:28.289	2025-09-30 23:03:56.043	pin
48	TICK-1759002532609	2025-09-27 19:48:52.61	37	1	925	Cambio de centro de carga tipo C	32	17	16	\N	f	2025-09-27 23:40:29.553	t	f	\N	\N	\N	\N	2025-09-27 23:40:17.176	\N	\N	012545212012545	265	negro	2025-09-27 00:00:00		5G	{}	2025-09-27 19:48:52.61	2025-09-27 23:40:29.553	pin
44	TICK-1758902137712	2025-09-26 15:55:37.714	33	1	421	display dañado	32	17	16	\N	f	2025-09-26 23:51:21.502	t	f	\N	2025-09-26 15:56:55.826	\N	\N	2025-09-26 23:51:09.257	\N	\N				2025-09-26 00:00:00			{}	2025-09-26 15:55:37.714	2025-09-26 23:51:21.502	pin
50	TICK-1759003938110	2025-09-27 20:12:18.112	38	31	1094	Venta de cargador	32	17	16	\N	f	2025-09-27 20:13:28.908	t	f	\N	\N	\N	\N	2025-09-27 20:13:12.914	\N	\N	012545212012545			2025-09-27 00:00:00			{}	2025-09-27 20:12:18.112	2025-09-27 20:13:28.908	pin
51	TICK-1759004059049	2025-09-27 20:14:19.051	38	31	1109	Venta E-sim	32	17	16	\N	f	2025-09-27 20:17:13.023	t	f	\N	\N	\N	\N	2025-09-27 20:16:57.467	\N	\N	012545212012545	265	negro	2025-09-27 00:00:00		5G	{}	2025-09-27 20:14:19.051	2025-09-27 20:17:13.023	pin
53	TICK-1759088074341	2025-09-28 19:34:34.342	40	1	445	limpieza d carga	32	17	16	\N	f	2025-09-28 19:35:40.731	t	f	\N	\N	\N	\N	2025-09-28 19:35:28.14	\N	\N				2025-09-28 00:00:00			{}	2025-09-28 19:34:34.342	2025-09-28 19:35:40.731	pin
61	TICK-1759431579135	2025-10-02 18:59:39.136	45	1	1004	Lo creo el conta para prueba.	34	22	16	\N	f	\N	f	t	Eliminado por el usuario	\N	\N	\N	\N	\N	\N	123456789101112	1	morado	2025-10-02 00:00:00		att	{}	2025-10-02 18:59:39.136	2025-10-02 22:11:39.718	pin
66	TICK-1759705105926	2025-10-05 22:58:25.928	51	1	342	Desbloqueo de cuenta google 	32	17	16	\N	f	2025-10-08 20:09:18.538	t	f	\N	2025-10-05 22:58:57.685	\N	\N	2025-10-08 20:09:07.243	\N	\N	012545212012545	265	negro	2025-10-05 00:00:00		5G	{}	2025-10-05 22:58:25.928	2025-10-08 20:09:18.538	pin
64	TICK-1759587725582	2025-10-04 14:22:05.584	49	1	1028	display y vidrio de camara	33	17	16	\N	f	2025-11-20 20:00:08.45	t	f	\N	\N	\N	\N	2025-10-10 22:30:11.367	\N	\N	012545212012545	256	blanco	2025-10-01 00:00:00		5G	{}	2025-10-04 14:22:05.584	2025-11-20 20:00:08.45	pin
58	TICK-1759275203620	2025-09-30 23:33:23.622	44	1	433	Display roto 	32	17	16	\N	f	2025-10-01 23:20:54.915	t	f	\N	\N	\N	\N	2025-10-01 23:20:49.622	\N	\N	012545212012545	126	lila	2025-09-30 00:00:00		5G	{}	2025-09-30 23:33:23.622	2025-10-01 23:20:54.915	pin
55	TICK-1759182498122	2025-09-29 21:48:18.123	41	1	408	Limpieza a centro de carga	32	17	16	\N	f	2025-09-29 21:49:09.339	t	f	\N	\N	\N	\N	2025-09-29 21:48:59.77	\N	\N				2025-09-29 00:00:00			{}	2025-09-29 21:48:18.123	2025-09-29 21:49:09.339	pin
67	TICK-1759785399994	2025-10-06 21:16:39.996	52	1	285	Desbloqueo Google	32	17	16	\N	f	2025-10-06 21:42:54.954	t	f	\N	\N	\N	\N	2025-10-06 21:42:02.292	\N	\N	012545212012545	265	negro	2025-10-05 00:00:00		5G	{}	2025-10-06 21:16:39.996	2025-10-06 21:42:54.954	pin
59	TICK-1759340869919	2025-10-01 17:47:49.921	45	1	373	pantalla rota	32	17	16	\N	f	2025-10-01 23:58:10.268	t	f	\N	\N	\N	\N	2025-10-01 23:57:46.07	\N	\N	012545212012545	126	negro	2025-09-30 00:00:00		5G	{}	2025-10-01 17:47:49.921	2025-10-01 23:58:10.268	pin
63	TICK-1759533269126	2025-10-03 23:14:29.128	48	1	1113	payjoy no se pudo realizar el desbloqueo por la seguridad del equipo hicimos devolución de 500 en efectivo	34	17	16	\N	f	\N	f	t	Eliminado por el usuario	\N	\N	\N	2025-10-08 20:22:07.252	\N	\N	012545212012545	256	blanco	2025-10-01 00:00:00		5G	{}	2025-10-03 23:14:29.128	2025-10-11 15:07:36.195	pin
62	TICK-1759433106146	2025-10-02 19:25:06.151	47	1	1076	No carga su batería 	32	17	16	\N	f	2025-10-04 16:49:36.104	t	f	\N	\N	\N	\N	2025-10-04 16:49:31.304	\N	\N	012545212012545	256	blanco	2025-10-01 00:00:00		5G	{}	2025-10-02 19:25:06.151	2025-10-04 16:49:36.104	pin
57	TICK-1759266074578	2025-09-30 21:01:14.58	43	1	748	Equipo mojado y tapa despegada 	32	17	16	\N	f	2025-09-30 22:49:22.879	t	f	\N	\N	\N	\N	2025-09-30 22:49:17.425	\N	\N	012545212012545	256		2025-09-30 00:00:00		5G	{}	2025-09-30 21:01:14.58	2025-09-30 22:49:22.879	pin
78	TICK-1760033813233	2025-10-09 18:16:53.235	57	1	342	Display Dañado	33	17	16	\N	f	2025-10-11 19:33:40.149	t	t	Eliminado por el usuario	\N	\N	\N	2025-10-11 19:21:07.012	\N	\N	012545212012545			0055-05-05 00:00:00	110265		{}	2025-10-09 18:16:53.235	2025-10-11 19:33:40.149	pin
56	TICK-1759253357854	2025-09-30 17:29:17.855	42	1	1074	No da imagen el equipo, no trae porta SIM \nse cancela debido a que se desarma y faltan muchas piezas \nvenía de otro taller	34	17	\N	\N	f	\N	f	t	Eliminado por el usuario	\N	\N	\N	\N	\N	\N	012545212012545	256		2025-09-03 00:00:00		5G	{}	2025-09-30 17:29:17.855	2025-10-01 17:39:07.941	pin
68	TICK-1759853053303	2025-10-07 16:04:13.305	53	1	1065	servicio a centro de carga 	32	17	16	\N	f	2025-10-07 16:05:22.509	t	f	\N	\N	\N	\N	2025-10-07 16:05:13.805	\N	\N	012545212012545	265	rojo	2025-10-05 00:00:00		5G	{}	2025-10-07 16:04:13.305	2025-10-07 16:05:22.509	pin
82	TICK-1760136065815	2025-10-10 22:41:05.816	60	1	323	Display dañado 	33	17	16	\N	f	2025-10-13 20:34:37.281	t	f	\N	\N	\N	\N	2025-10-13 20:32:54.076	\N	\N	012545212012545	256	plata	2025-10-10 00:00:00	110265	5G	{}	2025-10-10 22:41:05.816	2025-10-13 20:34:37.281	pin
70	TICK-1759880467402	2025-10-07 23:41:07.404	55	1	934	Camaras totalmente estrelladas y no enciende 	32	17	16	\N	f	2025-10-09 23:09:16.71	t	f	\N	\N	\N	\N	2025-10-08 22:25:00.605	\N	\N	012545212012545	126	negro	2025-10-07 00:00:00	3005	5G	{}	2025-10-07 23:41:07.404	2025-10-09 23:09:16.71	pin
84	TICK-1760209901542	2025-10-11 19:11:41.544	62	1	886	Cambio de micrófono y altavoz 	33	17	16	\N	f	2025-10-11 22:41:54.795	t	f	\N	\N	\N	\N	2025-10-11 22:40:53.748	\N	\N	012545212012545	256	negro	2025-10-11 00:00:00	19451991	5G	{}	2025-10-11 19:11:41.544	2025-10-11 22:41:54.795	pin
69	TICK-1759858370736	2025-10-07 17:32:50.737	54	1	696	Display y marco roto 	32	17	16	\N	f	2025-10-07 23:22:03.379	t	f	\N	2025-10-07 17:34:47.797	\N	\N	2025-10-07 23:21:43.199	\N	\N	012545212012545	256	azul	2025-10-07 00:00:00		5G	{}	2025-10-07 17:32:50.737	2025-10-07 23:22:03.379	pin
80	TICK-1760051091261	2025-10-09 23:04:51.263	58	1	341	No carga adecuadamente	32	17	16	\N	f	2025-10-09 23:10:01.283	t	f	\N	\N	\N	\N	2025-10-09 23:05:22.613	\N	\N	123456789123456	256	plata	2025-10-09 00:00:00		5G	{}	2025-10-09 23:04:51.263	2025-10-09 23:10:01.283	pin
65	TICK-1759690744913	2025-10-05 18:59:04.915	50	1	408	Sin tableta de centro de carga 	34	17	16	\N	f	\N	f	t	Eliminado por el usuario	2025-10-05 19:03:59.772	\N	\N	\N	\N	\N	012545212012545	256	negro	2025-10-05 00:00:00		5G	{}	2025-10-05 18:59:04.915	2025-10-13 20:34:47.66	pin
87	TICK-1760387920206	2025-10-13 20:38:40.208	65	1	321	Cambio de display y tapa	33	17	16	\N	f	2025-10-17 21:00:06.187	t	f	\N	\N	\N	\N	2025-10-17 20:59:59.715	\N	\N	012545212012545	128	negro	2025-10-13 00:00:00		5G	{}	2025-10-13 20:38:40.208	2025-10-17 21:00:06.187	pin
79	TICK-1760045495712	2025-10-09 21:31:35.714	46	1	834	Servicio a pantalla	32	17	16	\N	f	2025-10-10 22:21:06.388	t	f	\N	\N	\N	\N	2025-10-10 22:20:55.529	\N	\N	123456789123456	256	negro	2025-10-09 00:00:00		5G	{}	2025-10-09 21:31:35.714	2025-10-10 22:21:06.388	pin
54	TICK-1759093545851	2025-09-28 21:05:45.852	33	1	1112	bloqueo telcel	30	16	16	\N	f	2025-09-29 21:50:18.526	t	f	\N	\N	\N	\N	2025-09-28 21:06:57.526	\N	\N				2025-09-28 00:00:00			{}	2025-09-28 21:05:45.852	2025-09-29 21:50:18.526	pin
81	TICK-1760118153081	2025-10-10 17:42:33.083	59	1	960	Display dañado\n	33	17	16	\N	f	2025-10-11 12:14:07.247	t	f	\N	\N	\N	\N	2025-10-10 22:31:30.889	\N	\N	123456789123456	256	plata	2025-10-09 00:00:00	\N	5G	{2,5,4,6,8,1,3,7,9}	2025-10-10 17:42:33.083	2025-10-11 12:14:07.247	patron
83	TICK-1760198785048	2025-10-11 16:06:25.049	61	1	740	Desbloqueo de cuenta google y desbloqueo	33	17	16	\N	f	2025-10-11 23:24:45.379	t	f	\N	\N	\N	\N	2025-10-11 23:24:27.906	\N	\N	012545212012545	256	negr	2025-10-11 00:00:00	110265	5G	{}	2025-10-11 16:06:25.049	2025-10-11 23:24:45.379	pin
88	TICK-1760468679566	2025-10-14 19:04:39.568	66	1	519	Traía problema en el conector de la huella y la batería desconectada 	33	17	16	\N	f	2025-10-14 19:07:18.692	t	f	\N	\N	\N	\N	2025-10-14 19:07:01.805	\N	\N	012545212012545	126	azul	2025-10-14 00:00:00		5G	{}	2025-10-14 19:04:39.568	2025-10-14 19:07:18.692	pin
86	TICK-1760378606217	2025-10-13 18:03:26.218	64	1	339	Cambio de display 	33	17	16	\N	f	2025-10-13 23:30:34.021	t	f	\N	\N	\N	\N	2025-10-13 23:30:11.111	\N	\N	012545212012545	126	negro	2025-10-13 00:00:00	2525	5G	{}	2025-10-13 18:03:26.218	2025-10-13 23:30:34.021	pin
90	TICK-1760639336396	2025-10-16 18:28:56.399	68	1	1048	no detecta el cargador, se da mantenimiento 	33	17	16	\N	f	2025-10-16 21:23:12.798	t	f	\N	\N	\N	\N	2025-10-16 21:22:56.584	\N	\N	012545212012545	126	azul	2025-10-16 00:00:00		5G	{}	2025-10-16 18:28:56.399	2025-10-16 21:23:12.798	pin
89	TICK-1760565490101	2025-10-15 21:58:10.103	67	1	321	Cambio de display 	33	17	16	\N	f	2025-10-16 21:13:54.656	t	f	\N	\N	\N	\N	2025-10-16 21:12:42.136	\N	\N	012545212012545	126	azul	2025-10-15 00:00:00		5G	{}	2025-10-15 21:58:10.103	2025-10-16 21:13:54.656	pin
52	TICK-1759083462541	2025-09-28 18:17:42.543	39	1	752	equipo no enciende después de golpe	32	17	16	\N	f	\N	f	f	\N	2025-09-28 19:44:00.811	\N	\N	2025-10-16 23:19:54.311	\N	\N				2025-09-28 00:00:00	\N		{4,7,8,5,6,9}	2025-09-28 18:17:42.543	2025-10-16 23:19:54.311	patron
85	TICK-1760296196504	2025-10-12 19:09:56.506	63	35	395	display roto ,	33	17	16	\N	f	2025-10-18 20:53:25.655	t	f	\N	\N	\N	\N	2025-10-14 21:32:42.5	\N	\N	255887444646848	256	azul	2025-10-12 00:00:00	2297	5G	{}	2025-10-12 19:09:56.506	2025-10-18 20:53:25.655	pin
91	TICK-1760649431810	2025-10-16 21:17:11.812	69	2	1066	Se cambia centro de carga 	33	17	16	\N	f	2025-10-18 20:53:06.096	t	f	\N	\N	\N	\N	2025-10-17 21:53:01.259	\N	\N	012545212012545	126	gris	2025-10-16 00:00:00			{}	2025-10-16 21:17:11.812	2025-10-18 20:53:06.096	pin
92	TICK-1760723858072	2025-10-17 17:57:38.074	70	1	409	Display roto. 	33	17	16	\N	f	2025-10-18 19:52:22.157	t	f	\N	\N	\N	\N	2025-10-18 19:50:53.614	\N	\N	012545212012545	126	azul	2025-10-17 00:00:00		5G	{}	2025-10-17 17:57:38.074	2025-10-18 19:52:22.157	pin
106	TICK-1761610210363	2025-10-28 00:10:10.366	82	1	451	El equipo no carga.	32	17	16	\N	f	2025-10-28 00:31:15.544	t	f	\N	\N	\N	\N	2025-10-28 00:31:24.724	\N	\N	012545212012545	256	Azul	2025-10-27 00:00:00		5G	{}	2025-10-28 00:10:10.366	2025-10-28 00:31:24.724	pin
93	TICK-1760799416808	2025-10-18 14:56:56.81	71	1	917	display dañado	33	17	16	\N	f	2025-10-18 20:37:29.001	t	f	\N	\N	\N	\N	2025-10-18 20:37:04.662	\N	\N	012545212012545	126	azul	2025-10-17 00:00:00		5G	{}	2025-10-18 14:56:56.81	2025-10-18 20:37:29.001	pin
107	TICK-1761610858350	2025-10-28 00:20:58.351	83	1	226	Servicio a centro de carga 	33	17	16	\N	f	2025-10-28 00:33:44.428	t	f	\N	\N	\N	\N	2025-10-28 00:33:11.911	\N	\N	012545212012545	256	plata	2025-10-27 00:00:00		5G	{}	2025-10-28 00:20:58.351	2025-10-28 00:33:44.428	pin
94	TICK-1760903347947	2025-10-19 19:49:07.948	72	1	1115	centro de carga	33	17	16	\N	f	2025-10-19 19:49:53.844	t	f	\N	\N	\N	\N	2025-10-19 19:49:34.544	\N	\N				5555-05-05 00:00:00			{}	2025-10-19 19:49:07.948	2025-10-19 19:49:53.844	pin
114	TICK-1761866651308	2025-10-30 23:24:11.31	90	1	111	Cambio de batería 	33	17	16	\N	f	2025-11-18 21:31:40.43	t	f	\N	\N	\N	\N	2025-11-18 21:31:33.378	\N	\N	012545212012545	256	blanco 	2025-10-30 00:00:00		5G	{}	2025-10-30 23:24:11.31	2025-11-18 21:31:40.43	pin
111	TICK-1761694779825	2025-10-28 23:39:39.827	87	1	733	Cambio de display	33	17	24	\N	f	2025-10-31 19:52:27.014	t	f	\N	\N	\N	\N	2025-10-31 19:52:02.437	\N	\N	012545212012545	256	blanco	2025-10-28 00:00:00		5G	{}	2025-10-28 23:39:39.827	2025-10-31 19:52:27.014	pin
101	TICK-1761233428467	2025-10-23 15:30:28.469	46	1	1009	no enciende  \nse dio presupuesto de $400 no acepto	34	17	16	\N	f	\N	f	t	Eliminado por el usuario	\N	\N	\N	\N	\N	\N				2025-10-23 00:00:00			{}	2025-10-23 15:30:28.469	2025-10-24 21:32:54.004	pin
100	TICK-1761233395613	2025-10-23 15:29:55.615	46	1	659	no enciende\nse dio presupuesto de $700 no acepto	34	17	16	\N	f	\N	f	t	Eliminado por el usuario	\N	\N	\N	\N	\N	\N				2025-10-23 00:00:00			{}	2025-10-23 15:29:55.615	2025-10-24 21:32:56.58	pin
96	TICK-1760990305392	2025-10-20 19:58:25.393	74	1	687	No lee los SIM  \nse regresa equipo sin reparar por que la reparación sale más cara que el equipo  	34	17	16	\N	f	\N	f	t	Eliminado por el usuario	\N	\N	\N	\N	\N	\N	012545212012545	126	negro	2025-10-20 00:00:00		5G	{}	2025-10-20 19:58:25.393	2025-10-22 15:13:49.812	pin
105	TICK-1761605066958	2025-10-27 22:44:26.96	81	1	522	Cambió de display.	33	17	16	\N	f	2025-10-27 22:48:14.874	t	f	\N	\N	\N	\N	2025-10-27 22:47:27.147	\N	\N	012545212012545	256	Negro	2025-10-26 00:00:00		5G	{}	2025-10-27 22:44:26.96	2025-10-27 22:48:14.874	pin
98	TICK-1761156174684	2025-10-22 18:02:54.686	76	6	1117	NO SE ESCUCHA\nse hace la devolución de su efectivo debido a que regreso por garantía y no se consigue la pieza (amplificador de audio)	34	17	16	\N	f	2025-10-24 21:33:28.064	t	t	Eliminado por el usuario	\N	\N	\N	2025-11-02 21:20:55.581	\N	\N				2025-10-22 00:00:00			{}	2025-10-22 18:02:54.686	2025-11-02 21:24:35.877	pin
108	TICK-1761682240317	2025-10-28 20:10:40.319	84	1	834	Servicio a centro de carga 	33	17	16	\N	f	2025-10-28 20:13:01.644	t	f	\N	\N	\N	\N	2025-10-28 20:12:22.502	\N	\N	012545212012545	256	gris	2025-10-28 00:00:00		5G	{}	2025-10-28 20:10:40.319	2025-10-28 20:13:01.644	pin
104	TICK-1761604313954	2025-10-27 22:31:53.956	80	1	1072	Ticket de prueba para capacitación 	34	17	16	\N	f	\N	f	t	Eliminado por el usuario	2025-10-27 22:35:50.593	\N	\N	2025-10-27 22:36:32.465	\N	\N	012545212012545	256	blanco	2025-10-27 00:00:00		5G	{}	2025-10-27 22:31:53.956	2025-10-27 23:02:04.954	pin
97	TICK-1761152763110	2025-10-22 17:06:03.113	75	1	114	Error en cámaras 	33	17	16	\N	f	2025-10-22 19:30:33.744	t	f	\N	\N	\N	\N	2025-10-22 19:26:09.889	\N	\N	350496870428410	265		2025-10-22 00:00:00	\N		{1,5,3,2}	2025-10-22 17:06:03.113	2025-10-22 19:30:33.744	patron
102	TICK-1761243194409	2025-10-23 18:13:14.41	78	2	1118	No carga. 	33	17	16	\N	f	2025-10-25 18:05:23.585	t	f	\N	\N	\N	\N	2025-10-25 18:04:57.332	\N	\N	255887444646848	126	café	2025-10-23 00:00:00		5G	{}	2025-10-23 18:13:14.41	2025-10-25 18:05:23.585	pin
103	TICK-1761593843831	2025-10-27 19:37:23.833	79	1	1076	Servicio a centro de carga 	33	17	16	\N	f	2025-10-27 23:02:21.237	t	f	\N	\N	\N	\N	2025-10-27 19:59:06.266	\N	\N	012545212012545	256	blanco	2025-10-27 00:00:00			{}	2025-10-27 19:37:23.833	2025-10-27 23:02:21.237	pin
99	TICK-1761166489964	2025-10-22 20:54:49.966	77	1	433	display dañado	33	17	16	\N	f	2025-10-23 15:36:24.762	t	f	\N	\N	\N	\N	2025-10-23 15:35:42.478	\N	\N	351889693471113			2025-10-22 00:00:00			{}	2025-10-22 20:54:49.966	2025-10-23 15:36:24.762	pin
95	TICK-1760976445388	2025-10-20 16:07:25.39	73	1	1116	Cambio de tapa \nNO DEJA EL EQUIPO	33	17	16	\N	f	2025-10-23 16:23:18.117	t	f	\N	\N	\N	\N	2025-10-23 16:22:28.856	\N	\N				2025-10-20 00:00:00			{}	2025-10-20 16:07:25.39	2025-10-23 16:23:18.117	pin
125	TICK-1762288770175	2025-11-04 20:39:30.177	99	1	953	equipo no enciende tapa rota 	33	24	16	\N	f	2025-11-23 18:07:17.13	t	f	\N	\N	\N	\N	2025-11-13 17:15:17.19	\N	\N				2025-11-04 00:00:00			{}	2025-11-04 20:39:30.177	2025-11-23 18:07:17.13	pin
120	TICK-1762021733287	2025-11-01 18:28:53.289	96	1	376	display	33	17	16	\N	f	2025-11-01 23:19:30.053	t	f	\N	\N	\N	\N	2025-11-01 23:19:11.474	\N	\N				2025-11-01 00:00:00			{}	2025-11-01 18:28:53.289	2025-11-01 23:19:30.053	pin
116	TICK-1761928650245	2025-10-31 16:37:30.246	92	1	743	bateria inflada	33	17	16	\N	f	2025-10-31 20:55:24.458	t	f	\N	\N	\N	\N	2025-10-31 20:55:03.272	\N	\N	012545212012545	256	azul marino	2025-10-31 00:00:00	589754	5G	{}	2025-10-31 16:37:30.246	2025-10-31 20:55:24.458	pin
110	TICK-1761693257873	2025-10-28 23:14:17.875	86	1	453	Cuenta google 	33	17	16	\N	f	2025-10-29 23:19:45.875	t	f	\N	\N	\N	\N	2025-10-29 23:11:18.613	\N	\N	012545212012545	126	azul	2025-10-28 00:00:00		5G	{}	2025-10-28 23:14:17.875	2025-10-29 23:19:45.875	pin
113	TICK-1761778708789	2025-10-29 22:58:28.79	89	6	1099	Soldar y reconstruir pistas de un circuito 	33	17	16	\N	f	2025-10-30 18:52:30.216	t	f	\N	\N	\N	\N	2025-10-30 18:52:04.942	\N	\N	012545212012545	256	negro	2025-10-29 00:00:00			{}	2025-10-29 22:58:28.79	2025-10-30 18:52:30.216	pin
117	TICK-1761929682917	2025-10-31 16:54:42.918	93	1	326	servicio a micrófono no quedo no quiso cambio de pieza	34	17	16	\N	f	\N	f	t	Eliminado por el usuario	\N	\N	\N	\N	\N	\N				2025-10-31 00:00:00			{}	2025-10-31 16:54:42.918	2025-10-31 17:09:43.543	pin
115	TICK-1761922508375	2025-10-31 14:55:08.376	91	1	938	display roto	33	17	16	\N	f	2025-10-31 21:42:04.049	t	f	\N	\N	\N	\N	2025-10-31 21:41:36.682	\N	\N	868063053091004			2025-10-31 00:00:00			{}	2025-10-31 14:55:08.376	2025-10-31 21:42:04.049	pin
119	TICK-1762019360548	2025-11-01 17:49:20.55	95	1	1083	limpieza	33	17	16	\N	f	2025-11-01 18:15:17.757	t	f	\N	\N	\N	\N	2025-11-01 18:13:32.108	\N	\N	255887444646848	256	azul	2025-11-01 00:00:00		5G	{}	2025-11-01 17:49:20.55	2025-11-01 18:15:17.757	pin
109	TICK-1761687354461	2025-10-28 21:35:54.463	85	1	427	Cambio de display 	33	17	24	\N	f	2025-11-01 18:16:28.014	t	f	\N	\N	\N	\N	2025-11-01 18:16:14.443	\N	\N	012545212012545	126	azul	2025-10-27 00:00:00		5G	{}	2025-10-28 21:35:54.463	2025-11-01 18:16:28.014	pin
122	TICK-1762030453427	2025-11-01 20:54:13.429	41	1	1065	limpieza de carga	32	17	16	\N	f	2025-11-01 20:55:28.533	t	f	\N	\N	\N	\N	2025-11-01 20:55:34.45	\N	\N				2025-11-01 00:00:00			{}	2025-11-01 20:54:13.429	2025-11-01 20:55:34.45	pin
121	TICK-1762021761337	2025-11-01 18:29:21.339	96	1	378	display	33	17	16	\N	f	2025-11-01 23:18:49.059	t	f	\N	\N	\N	\N	2025-11-01 23:18:32.642	\N	\N				2025-11-01 00:00:00			{}	2025-11-01 18:29:21.339	2025-11-01 23:18:49.059	pin
123	TICK-1762120724559	2025-11-02 21:58:44.561	97	1	661	cambio de display de uno a otro	33	17	16	\N	f	2025-11-02 22:00:51.872	t	f	\N	\N	\N	\N	2025-11-02 22:00:38.69	\N	\N				2025-11-02 00:00:00			{}	2025-11-02 21:58:44.561	2025-11-02 22:00:51.872	pin
112	TICK-1761759340298	2025-10-29 17:35:40.299	88	1	342	Desbloqueo basico y cuenta de pago	30	17	16	\N	f	\N	f	f	\N	\N	\N	\N	\N	\N	\N	012545212012545	126	azul	2025-10-29 00:00:00		5G	{}	2025-10-29 17:35:40.299	2025-10-29 17:35:40.298	pin
124	TICK-1762196500944	2025-11-03 19:01:40.945	98	1	542	Cambio de display	33	17	25	\N	f	2025-11-03 22:41:58.884	t	f	\N	\N	\N	\N	2025-11-03 22:41:08.605	\N	\N	255887444646848	126	gris	2025-11-03 00:00:00		5G	{}	2025-11-03 19:01:40.945	2025-11-03 22:41:58.884	pin
118	TICK-1761945105659	2025-10-31 21:11:45.661	94	1	379	Cambio de display y cuenta google.	33	17	16	\N	f	2025-11-13 17:38:51.46	t	f	\N	\N	\N	\N	2025-11-09 19:16:34.1	\N	\N	255887444646848	256	azul	2025-10-31 00:00:00		5G	{}	2025-10-31 21:11:45.661	2025-11-13 17:38:51.46	pin
133	TICK-1762473272836	2025-11-06 23:54:32.838	104	1	1078	Batería dañada no prende, adicional se le remplazará la tapa.	33	24	25	\N	f	2025-11-08 21:54:00.027	t	f	\N	\N	\N	\N	2025-11-08 21:53:18.598	\N	\N			rosa	2025-11-06 00:00:00			{}	2025-11-06 23:54:32.838	2025-11-08 21:54:00.027	pin
126	TICK-1762298114414	2025-11-04 23:15:14.416	38	31	141	Venta de accesorios de reparación.\n1 pza Centro de carga tipo c\n1 pza Maneral para bisturí\n1 pza Caja organizadora	33	24	16	\N	f	2025-11-04 23:20:45.814	t	f	\N	\N	\N	\N	2025-11-04 23:20:37.001	\N	\N				2025-11-04 00:00:00			{}	2025-11-04 23:15:14.416	2025-11-04 23:20:45.814	pin
127	TICK-1762360042164	2025-11-05 16:27:22.166	100	1	1072	limpieza de bocinas	33	24	16	\N	f	2025-11-05 16:28:35.219	t	f	\N	\N	\N	\N	2025-11-05 16:28:10.164	\N	\N				2025-11-05 00:00:00			{}	2025-11-05 16:27:22.166	2025-11-05 16:28:35.219	pin
137	TICK-1762724097533	2025-11-09 21:34:57.534	38	1	139	No carga, se detecta pin sucio.	33	24	24	\N	f	2025-11-09 22:19:14.854	t	f	\N	\N	\N	\N	2025-11-09 22:19:10.407	\N	\N				2025-11-09 00:00:00			{}	2025-11-09 21:34:57.534	2025-11-09 22:19:14.854	pin
146	TICK-1762972093467	2025-11-12 18:28:13.468	113	1	110	Servicio de Limpieza.	33	24	16	\N	f	2025-11-12 18:37:37.625	t	f	\N	\N	\N	\N	2025-11-12 18:37:26.891	\N	\N			Negro	2025-11-12 00:00:00			{}	2025-11-12 18:28:13.468	2025-11-12 18:37:37.625	pin
138	TICK-1762726388411	2025-11-09 22:13:08.413	38	1	139	Equipo no carga	32	24	24	\N	f	2025-11-09 22:13:52.824	t	f	\N	\N	\N	\N	2025-11-10 20:42:12.871	\N	\N				2025-11-09 00:00:00			{}	2025-11-09 22:13:08.413	2025-11-10 20:42:12.871	pin
129	TICK-1762384520088	2025-11-05 23:15:20.091	46	1	716	Desbloqueo de cuenta\nEl equipo viene abierto, no trae bandeja de SIM y el seguro del botón de desbloqueo tampoco lo tiene.	33	24	25	\N	f	2025-11-07 22:31:11.827	t	f	\N	\N	\N	\N	2025-11-07 22:29:58.424	\N	\N			Tornasol plateado	2025-11-05 00:00:00			{}	2025-11-05 23:15:20.091	2025-11-07 22:31:11.827	pin
134	TICK-1762531207769	2025-11-07 16:00:07.771	85	1	307	cambio, de centro de carga	33	16	16	\N	f	2025-11-10 20:42:47.958	t	f	\N	\N	\N	\N	2025-11-07 16:01:04.919	\N	\N			azul	2025-11-07 00:00:00			{}	2025-11-07 16:00:07.771	2025-11-10 20:42:47.958	pin
142	TICK-1762896427552	2025-11-11 21:27:07.554	89	6	1118	Ayuda a reconexión por soldadura.	33	24	16	\N	f	2025-11-13 18:11:50.62	t	f	\N	\N	\N	\N	2025-11-13 18:11:26.484	\N	\N				2025-11-11 00:00:00			{}	2025-11-11 21:27:07.554	2025-11-13 18:11:50.62	pin
141	TICK-1762819281196	2025-11-11 00:01:21.197	110	1	110	Equipo, no instala app de Uber (lleva un día descargando)\nApaga de manera normal, al prender el equipo celular ya no prende ni con inicio forzado.	30	24	\N	\N	f	\N	f	f	\N	\N	\N	\N	\N	\N	\N			Gris	2025-11-10 00:00:00	260499		{}	2025-11-11 00:01:21.197	2025-11-11 00:01:21.196	pin
132	TICK-1762467715410	2025-11-06 22:21:55.411	17	31	141	Venta de cepillo de limpieza.	33	24	\N	\N	f	2025-11-06 22:22:47.285	t	f	\N	\N	\N	\N	2025-11-06 22:22:35.475	\N	\N				2025-11-06 00:00:00			{}	2025-11-06 22:21:55.411	2025-11-06 22:22:47.285	pin
151	TICK-1762993061755	2025-11-13 00:17:41.757	117	1	380	Esquipo tiene daño en el display, se solicita refacción, se ingresa a reparación.	33	24	25	\N	f	2025-11-14 22:50:56.264	t	f	\N	\N	\N	\N	2025-11-14 22:05:12.054	\N	\N				2025-11-12 00:00:00		Azul plata	{}	2025-11-13 00:17:41.757	2025-11-14 22:50:56.264	pin
131	TICK-1762451567142	2025-11-06 17:52:47.143	103	1	862	No realiza carga, se hará cambió de pin de carga	32	24	25	\N	f	2025-11-06 22:43:24.935	t	f	\N	\N	\N	\N	2025-11-08 21:05:07.652	\N	\N				2025-11-06 00:00:00			{}	2025-11-06 17:52:47.143	2025-11-08 21:05:07.652	pin
153	TICK-1763134004250	2025-11-14 15:26:44.252	118	1	1069	display dañado	33	24	25	\N	f	2025-11-14 22:51:08.789	t	f	\N	\N	\N	\N	2025-11-14 20:00:50.648	\N	\N				2025-11-14 00:00:00	1379		{}	2025-11-14 15:26:44.252	2025-11-14 22:51:08.789	pin
128	TICK-1762364184687	2025-11-05 17:36:24.688	49	1	421	display dañado	33	24	25	\N	f	2025-11-08 21:07:01.546	t	f	\N	\N	\N	\N	2025-11-05 23:28:21.49	\N	\N				0025-11-05 00:00:00			{}	2025-11-05 17:36:24.688	2025-11-08 21:07:01.546	pin
139	TICK-1762809243683	2025-11-10 21:14:03.684	109	1	110	Equipo no carga, al poner cargador no se queda y esta flojo.	33	24	25	\N	f	2025-11-10 21:22:23.558	t	f	\N	\N	\N	\N	2025-11-10 21:14:39.407	\N	\N				2025-11-10 00:00:00			{}	2025-11-10 21:14:03.684	2025-11-10 21:22:23.558	pin
147	TICK-1762987088667	2025-11-12 22:38:08.669	114	1	1084	Entrada de carga no entra bien al pin.	33	24	16	\N	f	2025-11-13 18:12:37.642	t	f	\N	\N	\N	\N	2025-11-13 18:12:33.45	\N	\N				2025-11-12 00:00:00			{}	2025-11-12 22:38:08.669	2025-11-13 18:12:37.642	pin
60	TICK-1759353512901	2025-10-01 21:18:32.903	46	1	1074	No se escucha el altavoz	34	17	16	\N	f	\N	f	t	Eliminado por el usuario	\N	\N	\N	2025-10-01 21:25:29.216	\N	\N	012545212012545	256	negro	2025-10-01 00:00:00		5G	{}	2025-10-01 21:18:32.903	2025-11-10 22:01:01.754	pin
148	TICK-1762988673505	2025-11-12 23:04:33.507	115	1	139	Indica que su bocina no se escucha, se recomienda ingresar a limpieza.	33	24	25	\N	f	2025-11-13 18:12:48.396	t	f	\N	\N	\N	\N	2025-11-12 23:28:50.955	\N	\N			Azul	2025-11-12 00:00:00			{}	2025-11-12 23:04:33.507	2025-11-13 18:12:48.396	pin
150	TICK-1762991844687	2025-11-12 23:57:24.689	38	1	141	Pantalla fantasma. No se actualiza la pantalla	33	24	25	\N	f	2025-11-13 18:13:22.624	t	f	\N	\N	\N	\N	2025-11-12 23:58:22.587	\N	\N				2025-11-12 00:00:00			{}	2025-11-12 23:57:24.689	2025-11-13 18:13:22.624	pin
145	TICK-1762970205831	2025-11-12 17:56:45.833	112	1	1087	Cambió de display.	33	24	16	\N	f	2025-11-13 18:12:24.152	t	f	\N	\N	\N	\N	2025-11-13 18:12:11.206	\N	\N				2025-11-12 00:00:00	260795		{}	2025-11-12 17:56:45.833	2025-11-13 18:12:24.152	pin
144	TICK-1762970121022	2025-11-12 17:55:21.024	112	1	139	No da señal móvil.	30	24	\N	\N	f	\N	f	f	\N	\N	\N	\N	\N	\N	\N				2025-11-12 00:00:00	140520		{}	2025-11-12 17:55:21.024	2025-11-12 17:55:21.022	pin
140	TICK-1762812128571	2025-11-10 22:02:08.573	46	1	716	Equipo no puede desbloquearse.	33	24	25	\N	f	2025-11-13 15:55:15.918	t	f	\N	\N	\N	\N	2025-11-13 15:54:23.415	\N	\N				2025-11-10 00:00:00			{}	2025-11-10 22:02:08.573	2025-11-13 15:55:15.918	pin
130	TICK-1762448320035	2025-11-06 16:58:40.037	102	1	972	Equipo, se cayó al agua y no prende.	33	24	25	\N	f	2025-11-13 17:16:16.509	t	f	\N	\N	\N	\N	2025-11-10 21:55:54.191	\N	\N	861201060101880			2025-11-06 00:00:00			{}	2025-11-06 16:58:40.037	2025-11-13 17:16:16.509	pin
155	TICK-1763233037359	2025-11-15 18:57:17.361	120	1	115	Se ingresa a diagnóstico, y se solicita liberación de AT&T Samsun S24+\n353471660196342\n5522959810\nNo se liberó y se hace la devolución de su dinero.	34	24	25	\N	f	\N	f	t	Eliminado por el usuario	\N	\N	\N	\N	\N	\N	353471660196342			2025-11-15 00:00:00	\N		{1,2,3,5,4,7,8,6}	2025-11-15 18:57:17.361	2025-11-17 22:15:21.103	patron
149	TICK-1762990637372	2025-11-12 23:37:17.373	116	1	406	Equipo presenta pila inflada, se ingresa para cambio de pila.	32	24	16	\N	f	\N	f	f	\N	\N	\N	\N	2025-11-13 15:35:29.091	\N	\N				2025-11-12 00:00:00			{}	2025-11-12 23:37:17.373	2025-11-13 15:35:29.091	pin
152	TICK-1763066143652	2025-11-13 20:35:43.654	89	1	475	Equipo celular se apagó, no carga y no prende.	33	24	25	\N	f	2025-11-18 21:39:13.093	t	f	\N	\N	\N	\N	2025-11-18 21:36:35.96	\N	\N				2025-11-13 00:00:00			{}	2025-11-13 20:35:43.654	2025-11-18 21:39:13.093	pin
154	TICK-1763232507243	2025-11-15 18:48:27.245	119	1	139	No carga, se ingresa a limpieza	33	24	25	\N	f	2025-11-15 18:49:22.507	t	f	\N	\N	\N	\N	2025-11-15 18:49:00.422	\N	\N				2025-11-15 00:00:00			{}	2025-11-15 18:48:27.245	2025-11-15 18:49:22.507	pin
136	TICK-1762633505948	2025-11-08 20:25:05.95	108	1	696	Equipo manda mensaje de temperatura alta y no deja hacer nada en el dispositivo.\nSe ingresa para reparación.	33	24	25	\N	f	2025-11-20 19:57:35.148	t	f	\N	\N	\N	\N	2025-11-15 23:44:30.789	\N	\N			Negro	2025-11-08 00:00:00	No pide nada		{}	2025-11-08 20:25:05.95	2025-11-20 19:57:35.148	pin
156	TICK-1763233773052	2025-11-15 19:09:33.054	121	1	834	Solicita refacciones, no ingresa su equipo celular a resguardo, se le notificara para que venga a la instalación de la pantalla.\nModelo sm-s918b	31	24	\N	\N	f	\N	f	f	\N	\N	\N	\N	\N	\N	\N			Negro	2025-11-15 00:00:00			{}	2025-11-15 19:09:33.054	2025-11-15 19:13:52.844	pin
143	TICK-1762968253661	2025-11-12 17:24:13.664	111	1	445	Equipo no pueden desbloquearlo. Se ingresa a desbloqueo.	33	24	25	\N	f	2025-11-14 19:00:13.066	t	f	\N	\N	\N	\N	2025-11-14 18:56:49.618	\N	\N	352295695333005		Azul gris	2025-11-12 00:00:00			{}	2025-11-12 17:24:13.664	2025-11-14 19:00:13.066	pin
135	TICK-1762633045155	2025-11-08 20:17:25.157	107	1	719	Equipo ingresa por error en touch, da toques fantasma y deja de detectar touch.\nNo hay daño en cristal, pero se diagnostica daño en touch y se hará cambió de display.	30	24	25	\N	f	2025-11-08 21:04:12.116	t	f	\N	\N	\N	\N	2025-11-08 20:56:56.898	\N	\N			azul plata	2025-11-08 00:00:00			{}	2025-11-08 20:17:25.157	2025-11-08 21:04:12.116	pin
167	TICK-1763837982813	2025-11-22 18:59:42.815	133	1	484	Cambio de display por impacto presentado	33	24	25	\N	f	2025-11-22 23:41:28.458	t	f	\N	\N	\N	\N	2025-11-22 22:08:00.865	\N	\N			Azul metalico	2025-11-22 00:00:00	shadow		{}	2025-11-22 18:59:42.815	2025-11-22 23:41:28.458	pin
161	TICK-1763573547664	2025-11-19 17:32:27.666	125	1	1119	no carga, centro de carga se mueve parece estar roto	33	25	16	\N	f	2025-11-20 19:22:46.052	t	f	\N	\N	\N	\N	2025-11-20 19:21:54.895	\N	\N	345454545656789		plateado	2025-11-19 00:00:00			{}	2025-11-19 17:32:27.666	2025-11-20 19:22:46.052	pin
159	TICK-1763497875867	2025-11-18 20:31:15.868	124	1	478	Pantalla rota y desbloqueo google.	31	24	\N	\N	f	\N	f	f	\N	\N	\N	\N	\N	\N	\N				2025-11-18 00:00:00			{}	2025-11-18 20:31:15.868	2025-11-18 21:49:50.989	pin
168	TICK-1763838343466	2025-11-22 19:05:43.468	132	1	484	Se ingresa para cambio de display por impacto.\nSolicita Restablecimiento de fábrica.	33	24	25	\N	f	2025-11-22 23:42:06.46	t	f	\N	\N	\N	\N	2025-11-22 22:07:53.174	\N	\N			azul	2025-11-22 00:00:00			{}	2025-11-22 19:05:43.468	2025-11-22 23:42:06.46	pin
158	TICK-1763497343313	2025-11-18 20:22:23.315	123	1	393	Equipo presenta daño físico, solicita cambió de display y de tapa (ya tare su tapa para instalación).	32	24	25	\N	f	\N	f	f	\N	\N	\N	\N	2025-11-19 15:03:10.713	\N	\N			Azul menta	2025-11-18 00:00:00			{}	2025-11-18 20:22:23.315	2025-11-19 15:03:10.713	pin
166	TICK-1763759921304	2025-11-21 21:18:41.305	85	1	477	Remplazo de lógica x falla de señal 	32	24	16	\N	f	\N	f	f	\N	\N	\N	\N	2025-11-21 21:19:07.002	\N	\N	359386601856214	256	azul	2025-11-21 00:00:00		libre	{}	2025-11-21 21:18:41.305	2025-11-21 21:19:07.002	pin
160	TICK-1763573418964	2025-11-19 17:30:18.966	126	1	497	Esquipo esta apagado y el boton no da contacto y no prende, se ingresa solo para iniciar equipo.	33	24	25	\N	f	2025-11-19 18:51:35.898	t	f	\N	\N	\N	\N	2025-11-19 18:11:25.292	\N	\N			Rojo	2025-11-19 00:00:00			{}	2025-11-19 17:30:18.966	2025-11-19 18:51:35.898	pin
172	TICK-1763932381778	2025-11-23 21:13:01.78	137	1	1023	Se ingresa a diagnóstico.\nEquipo mojado, dejo de recibir carga y murió de apoco.	30	24	\N	\N	f	\N	f	f	\N	\N	\N	\N	\N	\N	\N			Negro	2025-11-23 00:00:00		5 g	{}	2025-11-23 21:13:01.78	2025-11-23 21:13:01.778	pin
177	TICK-1764027450680	2025-11-24 23:37:30.681	141	1	1079	Tiene su cámara trasera  el cristal roto.	31	24	\N	\N	f	\N	f	f	\N	\N	\N	\N	\N	\N	\N	357590499636503		Azul	2025-11-24 00:00:00			{}	2025-11-24 23:37:30.681	2025-11-24 23:38:06.659	pin
157	TICK-1763411912726	2025-11-17 20:38:32.727	122	1	112	Equipo tiene tapa dañada solicita el cambió,	32	24	\N	\N	f	\N	f	f	\N	\N	\N	\N	2025-11-24 23:56:43.762	\N	\N	351850724223592		Dorado	2025-11-17 00:00:00			{}	2025-11-17 20:38:32.727	2025-11-24 23:56:43.762	pin
170	TICK-1763925587776	2025-11-23 19:19:47.778	135	32	141	Se registra venta por tiket por detalle en precios.	33	24	24	\N	f	2025-11-23 19:21:29.001	t	f	\N	\N	\N	\N	2025-11-23 19:21:18.282	\N	\N				2025-11-23 00:00:00			{}	2025-11-23 19:19:47.778	2025-11-23 19:21:29.001	pin
165	TICK-1763746735828	2025-11-21 17:38:55.83	129	1	472	Reinicio de fabrica	33	24	16	\N	f	2025-11-21 18:29:55.8	t	f	\N	\N	\N	\N	2025-11-21 18:29:10.089	\N	\N				2025-11-21 00:00:00	5986		{}	2025-11-21 17:38:55.83	2025-11-21 18:29:55.8	pin
164	TICK-1763746669544	2025-11-21 17:37:49.545	129	1	460	Desbloqueo de pin 	33	24	25	\N	f	2025-11-21 18:30:10.944	t	f	\N	\N	\N	\N	2025-11-21 18:29:38.164	\N	\N				2025-11-21 00:00:00			{}	2025-11-21 17:37:49.545	2025-11-21 18:30:10.944	pin
171	TICK-1763931596408	2025-11-23 20:59:56.41	136	6	141	Se ingresa audífonos senneisher Momentum True Wireless 3 \nProblema de batería en audífonos.	28	24	\N	\N	f	\N	f	f	\N	\N	\N	\N	\N	\N	\N				2025-11-23 00:00:00			{}	2025-11-23 20:59:56.41	2025-11-23 20:59:56.408	pin
169	TICK-1763841129560	2025-11-22 19:52:09.562	130	1	141	Mantenimiento a equipo celular	33	24	25	\N	f	2025-11-22 19:53:06.448	t	f	\N	\N	\N	\N	2025-11-22 19:52:40.591	\N	\N				2025-11-22 00:00:00			{}	2025-11-22 19:52:09.562	2025-11-22 19:53:06.448	pin
163	TICK-1763675085593	2025-11-20 21:44:45.595	128	1	445	Cambio de auricular y micrófono	33	24	16	\N	f	2025-11-21 18:34:24.494	t	f	\N	\N	\N	\N	2025-11-21 18:30:43.31	\N	\N	352295693875346		Azul 	2025-11-20 00:00:00		5G	{}	2025-11-20 21:44:45.595	2025-11-21 18:34:24.494	pin
162	TICK-1763583446436	2025-11-19 20:17:26.438	127	1	917	Equipo celular se calienta del botón de desbloqueo que tiene la huella, este bloqueado o apagado el display, ya apagando el celular ya deja de calentarse del botón de desbloqueo que tiene la huella.\nSe ingresa a reparar.	33	24	25	\N	f	2025-11-21 20:34:27.378	t	f	\N	\N	\N	\N	2025-11-21 20:34:12.796	\N	\N			Azul	2025-11-19 00:00:00	\N		{1,4,7,8}	2025-11-19 20:17:26.438	2025-11-21 20:34:27.378	patron
176	TICK-1764008645579	2025-11-24 18:24:05.582	38	32	141	Venta de herramienta	33	24	25	\N	f	2025-11-24 18:25:38.486	t	f	\N	\N	\N	\N	2025-11-24 18:25:29.774	\N	\N				2025-11-24 00:00:00			{}	2025-11-24 18:24:05.582	2025-11-24 18:25:38.486	pin
173	TICK-1763933474268	2025-11-23 21:31:14.27	138	1	743	Se solicita cambio de tapa solamente	31	24	\N	\N	f	\N	f	f	\N	\N	\N	\N	\N	\N	\N	350182152029171		Negro	2025-11-23 00:00:00			{}	2025-11-23 21:31:14.27	2025-11-23 21:32:41.047	pin
175	TICK-1764000028798	2025-11-24 16:00:28.8	140	1	141	Se ingresa a diagnostico por problemas de carga en la bocina.\nModelo:\nKaiser 2	28	24	\N	\N	f	\N	f	f	\N	\N	\N	\N	\N	\N	\N				2025-11-24 00:00:00			{}	2025-11-24 16:00:28.8	2025-11-24 16:00:28.798	pin
174	TICK-1763999578543	2025-11-24 15:52:58.544	139	1	1030	Solicita el cambió de display	33	24	25	\N	f	2025-11-24 23:01:41.452	t	f	\N	\N	\N	\N	2025-11-24 23:00:57.904	\N	\N				2025-11-24 00:00:00			{}	2025-11-24 15:52:58.544	2025-11-24 23:01:41.452	pin
\.
COPY public.tipos_servicio (id, nombre, descripcion, created_at, updated_at) FROM stdin;
1	Reparación de Celulares	\N	2025-06-17 17:42:32.568	2025-06-17 17:42:32.568
2	Reparación de Tablets	\N	2025-06-17 17:42:32.568	2025-06-17 17:42:32.568
3	Reparación de Laptops	\N	2025-06-17 17:42:32.568	2025-06-17 17:42:32.568
4	Reparación de Consolas	\N	2025-06-17 17:42:32.568	2025-06-17 17:42:32.568
5	Reparación de Smartwatches	\N	2025-06-17 17:42:32.568	2025-06-17 17:42:32.568
6	Reparación de Otros Dispositivos	\N	2025-06-17 17:42:32.568	2025-06-17 17:42:32.568
31	Accesorios	Varios 	2025-09-05 17:15:50.07	2025-09-05 17:15:50.069
32	Herramienta	\N	2025-09-09 22:42:48.847	2025-09-09 22:42:48.845
33	Cambio centro de carga V8	\N	2025-09-13 20:13:29	2025-09-13 20:13:28.999
34	prueba 1	\N	2025-10-09 15:18:44.531	2025-10-09 15:18:44.53
35	Servicio a pantallas 	Limpieza y colocación 	2025-10-09 22:23:58.221	2025-10-09 22:23:58.22
37	Cambio auricular android	\N	2025-10-11 20:34:15.061	2025-10-11 20:34:15.06
38	Cambio auricular Iphone	\N	2025-10-11 20:34:29.433	2025-10-11 20:34:29.432
39	Cambio altavoz android 	\N	2025-10-11 20:34:44.135	2025-10-11 20:34:44.134
40	Cambio altavoz Iphone	\N	2025-10-11 20:34:56.085	2025-10-11 20:34:56.084
41	Altavoz Iphone	Varios	2025-10-11 20:36:14.695	2025-10-11 20:36:14.694
\.
COPY public.usos_cupon (id, cupon_id, ticket_id, venta_id, usuario_id, monto_descuento, created_at, updated_at) FROM stdin;
\.
COPY public.usuarios (id, nombre, apellido_paterno, apellido_materno, email, password_hash, telefono, activo, created_at, updated_at) FROM stdin;
2	Sergio	Velazco		sergio@hoom.mx	$2a$10$6Eo3IFvqInqnGp82ur46Z.HvMIt.Qc7NGmjmPtUs1lKL7Iurzww.G	\N	t	2025-06-17 17:42:32.343	2025-06-17 21:30:43.308
15	David	Martínez		david.martinez@yaavs.com.mx	$2a$10$V2MqbiNnlf8cJiPXSa6NAuB4sLYQGfuPTOIg1PK8jyWP4K92zUS22	\N	t	2025-08-07 19:24:45.749	2025-08-07 19:24:45.749
18	Alexis	Silva		alex.silva@yaavs.com.mx	$2a$10$nr7X2P3GBCGQluQfYhDoy.7CEnUKZe9CcJEolXDT0XGkV7FsaAet.	\N	t	2025-08-07 19:26:12.9	2025-08-07 19:26:12.9
19	Efrén	Tello		efren.tello@yaavs.com.mx	$2a$10$gDOPFADZOwu9G/JIyVPK/e4U31OunYq2Hfz3vB1Or59AiMEm42.lW	\N	t	2025-08-07 19:26:34.872	2025-08-07 19:26:34.872
22	Jose Angel 	Castañon	Solano	jose.castanon@yaavs.com.mx	$2a$10$ZMGFdh9Or7EnJFZW.I3e..r5dEF/UGhTvOKKjv8EfBZXwepierjxW	\N	t	2025-08-20 20:34:05.417	2025-10-01 19:27:01.822
25	Alexei	Centeno 	Centeno	luis.mercado@arregla.mx	$2a$10$uPvIzXb0l3/.TpATwdCHwOJ0L/gj1g4tQ4boVS9irv2P69QvqkAee	\N	t	2025-11-03 15:51:57.178	2025-11-03 15:51:57.178
17	Montserrat	Hernández		montserrat.hernandez@yaavs.com.mx	$2a$10$CbIg8xEUVYrM4MTXuYXHYOVBf33bNHkYm1DP9/ww0zC13XwyCZU8.	\N	f	2025-08-07 19:25:47.112	2025-11-06 15:55:59.834
24	Joshua			joshua.paz@yaavs.com.mx	$2a$10$gXpiUm/fxzJdZbqFi.GAR.I2Y/2eEpHXHx0fh/D95i6TloXfEYn7W	\N	t	2025-10-28 21:30:30.286	2025-11-06 16:48:11.796
16	Victor	Delgado	Chamorro	victor.delgado@yaavs.com.mx	$2a$10$JHb94rczia6wml4vEC585egsIZ9hr1HznSqcvlvvQh5wcxWFXsfUq	\N	t	2025-08-07 19:25:14.78	2025-11-06 21:51:21.616
26	Yessica	Alfaro		vivian@yaavs.com.mx	$2a$10$AIFt26EWbnewYZJTPwNKpO1VFvaG0EqCWowE1qDQd8PeLaPollA9C	\N	t	2025-11-18 23:08:40.336	2025-11-18 23:08:40.336
\.
COPY public.usuarios_puntos_recoleccion (id, usuario_id, punto_recoleccion_id, nivel, created_at, updated_at) FROM stdin;
\.
COPY public.usuarios_roles (id, usuario_id, rol_id, created_at, updated_at) FROM stdin;
12	2	15	2025-06-17 21:30:43.31	2025-06-17 21:30:43.31
22	15	15	2025-08-07 19:24:45.753	2025-08-07 19:24:45.753
25	18	15	2025-08-07 19:26:12.905	2025-08-07 19:26:12.905
26	19	15	2025-08-07 19:26:34.875	2025-08-07 19:26:34.875
35	22	15	2025-10-01 19:27:01.84	2025-10-01 19:27:01.822
37	25	18	2025-11-03 15:51:57.183	2025-11-03 15:51:57.183
52	17	15	2025-11-06 15:55:59.836	2025-11-06 15:55:59.834
54	24	15	2025-11-06 16:48:11.798	2025-11-06 16:48:11.797
55	24	17	2025-11-06 16:48:11.798	2025-11-06 16:48:11.797
56	24	16	2025-11-06 16:48:11.798	2025-11-06 16:48:11.797
57	24	18	2025-11-06 16:48:11.798	2025-11-06 16:48:11.797
58	16	15	2025-11-06 21:51:21.618	2025-11-06 21:51:21.617
59	16	18	2025-11-06 21:51:21.618	2025-11-06 21:51:21.617
60	26	15	2025-11-18 23:08:40.343	2025-11-18 23:08:40.343
61	26	16	2025-11-18 23:08:40.343	2025-11-18 23:08:40.343
\.
COPY public.ventas (id, cliente_id, usuario_id, total, estado, created_at, updated_at) FROM stdin;
10	17	17	60	COMPLETADA	2025-09-19 20:01:52.214	2025-09-19 20:01:52.214
11	17	17	1	COMPLETADA	2025-09-20 18:12:00.706	2025-09-20 18:12:00.706
12	26	17	99	COMPLETADA	2025-10-02 17:35:08.43	2025-10-02 17:35:08.43
16	38	24	290	COMPLETADA	2025-11-10 16:10:44.5	2025-11-10 16:10:44.5
17	38	16	200	COMPLETADA	2025-11-10 16:29:18.834	2025-11-10 16:29:18.834
18	38	24	50	COMPLETADA	2025-11-14 22:49:45.08	2025-11-14 22:49:45.08
19	38	24	484	COMPLETADA	2025-11-16 17:46:58.924	2025-11-16 17:46:58.924
20	38	24	60	COMPLETADA	2025-11-17 23:35:27.274	2025-11-17 23:35:27.274
21	38	24	150	COMPLETADA	2025-11-20 21:37:05.299	2025-11-20 21:37:05.299
22	134	24	290	COMPLETADA	2025-11-22 23:38:17.649	2025-11-22 23:38:17.649
\.
SELECT pg_catalog.setval('public.categorias_id_seq', 1, false);
SELECT pg_catalog.setval('public.checklist_diagnostico_id_seq', 17, true);
SELECT pg_catalog.setval('public.checklist_items_id_seq', 15, true);
SELECT pg_catalog.setval('public.checklist_reparacion_id_seq', 232, true);
SELECT pg_catalog.setval('public.checklist_respuesta_diagnostico_id_seq', 304, true);
SELECT pg_catalog.setval('public.checklist_respuesta_reparacion_id_seq', 3433, true);
SELECT pg_catalog.setval('public.clientes_id_seq', 141, true);
SELECT pg_catalog.setval('public.conceptos_presupuesto_id_seq', 363, true);
SELECT pg_catalog.setval('public.cupones_id_seq', 8, true);
SELECT pg_catalog.setval('public.detalle_ventas_id_seq', 28, true);
SELECT pg_catalog.setval('public.direcciones_id_seq', 1, false);
SELECT pg_catalog.setval('public.dispositivos_id_seq', 5, true);
SELECT pg_catalog.setval('public.entradas_almacen_id_seq', 148, true);
SELECT pg_catalog.setval('public.entregas_id_seq', 1, false);
SELECT pg_catalog.setval('public.estatus_reparacion_id_seq', 35, true);
SELECT pg_catalog.setval('public.fotos_producto_id_seq', 1, false);
SELECT pg_catalog.setval('public.marcas_id_seq', 74, true);
SELECT pg_catalog.setval('public.modelos_id_seq', 1119, true);
SELECT pg_catalog.setval('public.pagos_id_seq', 235, true);
SELECT pg_catalog.setval('public.pasos_reparacion_frecuente_id_seq', 6, true);
SELECT pg_catalog.setval('public.permisos_id_seq', 232, true);
SELECT pg_catalog.setval('public.piezas_id_seq', 1, false);
SELECT pg_catalog.setval('public.piezas_reparacion_id_seq', 1, false);
SELECT pg_catalog.setval('public.piezas_reparacion_productos_id_seq', 170, true);
SELECT pg_catalog.setval('public.precios_venta_id_seq', 1085, true);
SELECT pg_catalog.setval('public.presupuestos_id_seq', 167, true);
SELECT pg_catalog.setval('public.presupuestos_independientes_id_seq', 11, true);
SELECT pg_catalog.setval('public.problemas_frecuentes_id_seq', 1, false);
SELECT pg_catalog.setval('public.productos_id_seq', 1151, true);
SELECT pg_catalog.setval('public.productos_presupuesto_independiente_id_seq', 15, true);
SELECT pg_catalog.setval('public.productos_reparacion_frecuente_id_seq', 10, true);
SELECT pg_catalog.setval('public.proveedores_id_seq', 12, true);
SELECT pg_catalog.setval('public.puntos_recoleccion_id_seq', 1, true);
SELECT pg_catalog.setval('public.reparaciones_frecuentes_id_seq', 4, true);
SELECT pg_catalog.setval('public.reparaciones_id_seq', 273, true);
SELECT pg_catalog.setval('public.roles_id_seq', 18, true);
SELECT pg_catalog.setval('public.roles_permisos_id_seq', 364, true);
SELECT pg_catalog.setval('public.salidas_almacen_id_seq', 121, true);
SELECT pg_catalog.setval('public.ticket_problemas_id_seq', 1, false);
SELECT pg_catalog.setval('public.tickets_id_seq', 177, true);
SELECT pg_catalog.setval('public.tipos_servicio_id_seq', 41, true);
SELECT pg_catalog.setval('public.usos_cupon_id_seq', 1, false);
SELECT pg_catalog.setval('public.usuarios_id_seq', 26, true);
SELECT pg_catalog.setval('public.usuarios_puntos_recoleccion_id_seq', 1, true);
SELECT pg_catalog.setval('public.usuarios_roles_id_seq', 61, true);
SELECT pg_catalog.setval('public.ventas_id_seq', 22, true);
ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);
ALTER TABLE ONLY public.categorias
    ADD CONSTRAINT categorias_pkey PRIMARY KEY (id);
ALTER TABLE ONLY public.checklist_diagnostico
    ADD CONSTRAINT checklist_diagnostico_pkey PRIMARY KEY (id);
ALTER TABLE ONLY public.checklist_items
    ADD CONSTRAINT checklist_items_pkey PRIMARY KEY (id);
ALTER TABLE ONLY public.checklist_reparacion
    ADD CONSTRAINT checklist_reparacion_pkey PRIMARY KEY (id);
ALTER TABLE ONLY public.checklist_respuesta_diagnostico
    ADD CONSTRAINT checklist_respuesta_diagnostico_pkey PRIMARY KEY (id);
ALTER TABLE ONLY public.checklist_respuesta_reparacion
    ADD CONSTRAINT checklist_respuesta_reparacion_pkey PRIMARY KEY (id);
ALTER TABLE ONLY public.clientes
    ADD CONSTRAINT clientes_pkey PRIMARY KEY (id);
ALTER TABLE ONLY public.conceptos_presupuesto
    ADD CONSTRAINT conceptos_presupuesto_pkey PRIMARY KEY (id);
ALTER TABLE ONLY public.cupones
    ADD CONSTRAINT cupones_pkey PRIMARY KEY (id);
ALTER TABLE ONLY public.detalle_ventas
    ADD CONSTRAINT detalle_ventas_pkey PRIMARY KEY (id);
ALTER TABLE ONLY public.direcciones
    ADD CONSTRAINT direcciones_pkey PRIMARY KEY (id);
ALTER TABLE ONLY public.dispositivos
    ADD CONSTRAINT dispositivos_pkey PRIMARY KEY (id);
ALTER TABLE ONLY public.entradas_almacen
    ADD CONSTRAINT entradas_almacen_pkey PRIMARY KEY (id);
ALTER TABLE ONLY public.entregas
    ADD CONSTRAINT entregas_pkey PRIMARY KEY (id);
ALTER TABLE ONLY public.estatus_reparacion
    ADD CONSTRAINT estatus_reparacion_pkey PRIMARY KEY (id);
ALTER TABLE ONLY public.fotos_producto
    ADD CONSTRAINT fotos_producto_pkey PRIMARY KEY (id);
ALTER TABLE ONLY public.marcas
    ADD CONSTRAINT marcas_pkey PRIMARY KEY (id);
ALTER TABLE ONLY public.modelos
    ADD CONSTRAINT modelos_pkey PRIMARY KEY (id);
ALTER TABLE ONLY public.pagos
    ADD CONSTRAINT pagos_pkey PRIMARY KEY (id);
ALTER TABLE ONLY public.pasos_reparacion_frecuente
    ADD CONSTRAINT pasos_reparacion_frecuente_pkey PRIMARY KEY (id);
ALTER TABLE ONLY public.permisos
    ADD CONSTRAINT permisos_pkey PRIMARY KEY (id);
ALTER TABLE ONLY public.piezas
    ADD CONSTRAINT piezas_pkey PRIMARY KEY (id);
ALTER TABLE ONLY public.piezas_reparacion
    ADD CONSTRAINT piezas_reparacion_pkey PRIMARY KEY (id);
ALTER TABLE ONLY public.piezas_reparacion_productos
    ADD CONSTRAINT piezas_reparacion_productos_pkey PRIMARY KEY (id);
ALTER TABLE ONLY public.precios_venta
    ADD CONSTRAINT precios_venta_pkey PRIMARY KEY (id);
ALTER TABLE ONLY public.presupuestos_independientes
    ADD CONSTRAINT presupuestos_independientes_pkey PRIMARY KEY (id);
ALTER TABLE ONLY public.presupuestos
    ADD CONSTRAINT presupuestos_pkey PRIMARY KEY (id);
ALTER TABLE ONLY public.problemas_frecuentes
    ADD CONSTRAINT problemas_frecuentes_pkey PRIMARY KEY (id);
ALTER TABLE ONLY public.productos
    ADD CONSTRAINT productos_pkey PRIMARY KEY (id);
ALTER TABLE ONLY public.productos_presupuesto_independiente
    ADD CONSTRAINT productos_presupuesto_independiente_pkey PRIMARY KEY (id);
ALTER TABLE ONLY public.productos_reparacion_frecuente
    ADD CONSTRAINT productos_reparacion_frecuente_pkey PRIMARY KEY (id);
ALTER TABLE ONLY public.proveedores
    ADD CONSTRAINT proveedores_pkey PRIMARY KEY (id);
ALTER TABLE ONLY public.puntos_recoleccion
    ADD CONSTRAINT puntos_recoleccion_pkey PRIMARY KEY (id);
ALTER TABLE ONLY public.reparaciones_frecuentes
    ADD CONSTRAINT reparaciones_frecuentes_pkey PRIMARY KEY (id);
ALTER TABLE ONLY public.reparaciones
    ADD CONSTRAINT reparaciones_pkey PRIMARY KEY (id);
ALTER TABLE ONLY public.roles_permisos
    ADD CONSTRAINT roles_permisos_pkey PRIMARY KEY (id);
ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);
ALTER TABLE ONLY public.salidas_almacen
    ADD CONSTRAINT salidas_almacen_pkey PRIMARY KEY (id);
ALTER TABLE ONLY public.ticket_problemas
    ADD CONSTRAINT ticket_problemas_pkey PRIMARY KEY (id);
ALTER TABLE ONLY public.tickets
    ADD CONSTRAINT tickets_pkey PRIMARY KEY (id);
ALTER TABLE ONLY public.tipos_servicio
    ADD CONSTRAINT tipos_servicio_pkey PRIMARY KEY (id);
ALTER TABLE ONLY public.usos_cupon
    ADD CONSTRAINT usos_cupon_pkey PRIMARY KEY (id);
ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT usuarios_pkey PRIMARY KEY (id);
ALTER TABLE ONLY public.usuarios_puntos_recoleccion
    ADD CONSTRAINT usuarios_puntos_recoleccion_pkey PRIMARY KEY (id);
ALTER TABLE ONLY public.usuarios_roles
    ADD CONSTRAINT usuarios_roles_pkey PRIMARY KEY (id);
ALTER TABLE ONLY public.ventas
    ADD CONSTRAINT ventas_pkey PRIMARY KEY (id);
CREATE UNIQUE INDEX categorias_nombre_key ON public.categorias USING btree (nombre);
CREATE UNIQUE INDEX checklist_diagnostico_reparacion_id_key ON public.checklist_diagnostico USING btree (reparacion_id);
CREATE UNIQUE INDEX checklist_reparacion_reparacion_id_key ON public.checklist_reparacion USING btree (reparacion_id);
CREATE UNIQUE INDEX clientes_email_key ON public.clientes USING btree (email);
CREATE UNIQUE INDEX cupones_codigo_key ON public.cupones USING btree (codigo);
CREATE UNIQUE INDEX dispositivos_ticket_id_key ON public.dispositivos USING btree (ticket_id);
CREATE UNIQUE INDEX entregas_ticket_id_key ON public.entregas USING btree (ticket_id);
CREATE UNIQUE INDEX estatus_reparacion_nombre_key ON public.estatus_reparacion USING btree (nombre);
CREATE UNIQUE INDEX marcas_nombre_key ON public.marcas USING btree (nombre);
CREATE UNIQUE INDEX permisos_codigo_key ON public.permisos USING btree (codigo);
CREATE UNIQUE INDEX presupuestos_ticket_id_key ON public.presupuestos USING btree (ticket_id);
CREATE UNIQUE INDEX productos_sku_key ON public.productos USING btree (sku);
CREATE UNIQUE INDEX puntos_recoleccion_email_key ON public.puntos_recoleccion USING btree (email);
CREATE UNIQUE INDEX puntos_recoleccion_url_key ON public.puntos_recoleccion USING btree (url);
CREATE UNIQUE INDEX reparaciones_ticket_id_key ON public.reparaciones USING btree (ticket_id);
CREATE UNIQUE INDEX roles_nombre_key ON public.roles USING btree (nombre);
CREATE UNIQUE INDEX roles_permisos_rol_id_permiso_id_key ON public.roles_permisos USING btree (rol_id, permiso_id);
CREATE UNIQUE INDEX tickets_direccion_id_key ON public.tickets USING btree (direccion_id);
CREATE UNIQUE INDEX tickets_numero_ticket_key ON public.tickets USING btree (numero_ticket);
CREATE UNIQUE INDEX tipos_servicio_nombre_key ON public.tipos_servicio USING btree (nombre);
CREATE UNIQUE INDEX usuarios_email_key ON public.usuarios USING btree (email);
CREATE UNIQUE INDEX usuarios_roles_usuario_id_rol_id_key ON public.usuarios_roles USING btree (usuario_id, rol_id);
ALTER TABLE ONLY public.checklist_diagnostico
    ADD CONSTRAINT checklist_diagnostico_reparacion_id_fkey FOREIGN KEY (reparacion_id) REFERENCES public.reparaciones(id) ON UPDATE CASCADE ON DELETE RESTRICT;
ALTER TABLE ONLY public.checklist_reparacion
    ADD CONSTRAINT checklist_reparacion_reparacion_id_fkey FOREIGN KEY (reparacion_id) REFERENCES public.reparaciones(id) ON UPDATE CASCADE ON DELETE RESTRICT;
ALTER TABLE ONLY public.checklist_respuesta_diagnostico
    ADD CONSTRAINT checklist_respuesta_diagnostico_checklist_diagnostico_id_fkey FOREIGN KEY (checklist_diagnostico_id) REFERENCES public.checklist_diagnostico(id) ON UPDATE CASCADE ON DELETE RESTRICT;
ALTER TABLE ONLY public.checklist_respuesta_diagnostico
    ADD CONSTRAINT checklist_respuesta_diagnostico_checklist_item_id_fkey FOREIGN KEY (checklist_item_id) REFERENCES public.checklist_items(id) ON UPDATE CASCADE ON DELETE RESTRICT;
ALTER TABLE ONLY public.checklist_respuesta_reparacion
    ADD CONSTRAINT checklist_respuesta_reparacion_checklist_item_id_fkey FOREIGN KEY (checklist_item_id) REFERENCES public.checklist_items(id) ON UPDATE CASCADE ON DELETE RESTRICT;
ALTER TABLE ONLY public.checklist_respuesta_reparacion
    ADD CONSTRAINT checklist_respuesta_reparacion_checklist_reparacion_id_fkey FOREIGN KEY (checklist_reparacion_id) REFERENCES public.checklist_reparacion(id) ON UPDATE CASCADE ON DELETE RESTRICT;
ALTER TABLE ONLY public.clientes
    ADD CONSTRAINT clientes_creado_por_id_fkey FOREIGN KEY (creado_por_id) REFERENCES public.usuarios(id) ON UPDATE CASCADE ON DELETE SET NULL;
ALTER TABLE ONLY public.clientes
    ADD CONSTRAINT clientes_punto_recoleccion_id_fkey FOREIGN KEY (punto_recoleccion_id) REFERENCES public.puntos_recoleccion(id) ON UPDATE CASCADE ON DELETE SET NULL;
ALTER TABLE ONLY public.conceptos_presupuesto
    ADD CONSTRAINT conceptos_presupuesto_presupuesto_id_fkey FOREIGN KEY (presupuesto_id) REFERENCES public.presupuestos(id) ON UPDATE CASCADE ON DELETE RESTRICT;
ALTER TABLE ONLY public.detalle_ventas
    ADD CONSTRAINT detalle_ventas_producto_id_fkey FOREIGN KEY (producto_id) REFERENCES public.productos(id) ON UPDATE CASCADE ON DELETE RESTRICT;
ALTER TABLE ONLY public.detalle_ventas
    ADD CONSTRAINT detalle_ventas_venta_id_fkey FOREIGN KEY (venta_id) REFERENCES public.ventas(id) ON UPDATE CASCADE ON DELETE RESTRICT;
ALTER TABLE ONLY public.direcciones
    ADD CONSTRAINT direcciones_cliente_id_fkey FOREIGN KEY (cliente_id) REFERENCES public.clientes(id) ON UPDATE CASCADE ON DELETE RESTRICT;
ALTER TABLE ONLY public.dispositivos
    ADD CONSTRAINT dispositivos_ticket_id_fkey FOREIGN KEY (ticket_id) REFERENCES public.tickets(id) ON UPDATE CASCADE ON DELETE RESTRICT;
ALTER TABLE ONLY public.entradas_almacen
    ADD CONSTRAINT entradas_almacen_producto_id_fkey FOREIGN KEY (producto_id) REFERENCES public.productos(id) ON UPDATE CASCADE ON DELETE RESTRICT;
ALTER TABLE ONLY public.entradas_almacen
    ADD CONSTRAINT entradas_almacen_proveedor_id_fkey FOREIGN KEY (proveedor_id) REFERENCES public.proveedores(id) ON UPDATE CASCADE ON DELETE SET NULL;
ALTER TABLE ONLY public.entradas_almacen
    ADD CONSTRAINT entradas_almacen_usuario_id_fkey FOREIGN KEY (usuario_id) REFERENCES public.usuarios(id) ON UPDATE CASCADE ON DELETE RESTRICT;
ALTER TABLE ONLY public.entregas
    ADD CONSTRAINT entregas_ticket_id_fkey FOREIGN KEY (ticket_id) REFERENCES public.tickets(id) ON UPDATE CASCADE ON DELETE RESTRICT;
ALTER TABLE ONLY public.fotos_producto
    ADD CONSTRAINT fotos_producto_producto_id_fkey FOREIGN KEY (producto_id) REFERENCES public.productos(id) ON UPDATE CASCADE ON DELETE RESTRICT;
ALTER TABLE ONLY public.modelos
    ADD CONSTRAINT modelos_marca_id_fkey FOREIGN KEY (marca_id) REFERENCES public.marcas(id) ON UPDATE CASCADE ON DELETE RESTRICT;
ALTER TABLE ONLY public.pagos
    ADD CONSTRAINT pagos_ticket_id_fkey FOREIGN KEY (ticket_id) REFERENCES public.tickets(id) ON UPDATE CASCADE ON DELETE RESTRICT;
ALTER TABLE ONLY public.pasos_reparacion_frecuente
    ADD CONSTRAINT pasos_reparacion_frecuente_reparacion_frecuente_id_fkey FOREIGN KEY (reparacion_frecuente_id) REFERENCES public.reparaciones_frecuentes(id) ON UPDATE CASCADE ON DELETE RESTRICT;
ALTER TABLE ONLY public.piezas
    ADD CONSTRAINT piezas_marca_id_fkey FOREIGN KEY (marca_id) REFERENCES public.marcas(id) ON UPDATE CASCADE ON DELETE RESTRICT;
ALTER TABLE ONLY public.piezas
    ADD CONSTRAINT piezas_modelo_id_fkey FOREIGN KEY (modelo_id) REFERENCES public.modelos(id) ON UPDATE CASCADE ON DELETE RESTRICT;
ALTER TABLE ONLY public.piezas_reparacion
    ADD CONSTRAINT piezas_reparacion_pieza_id_fkey FOREIGN KEY (pieza_id) REFERENCES public.piezas(id) ON UPDATE CASCADE ON DELETE RESTRICT;
ALTER TABLE ONLY public.piezas_reparacion_productos
    ADD CONSTRAINT piezas_reparacion_productos_producto_id_fkey FOREIGN KEY (producto_id) REFERENCES public.productos(id) ON UPDATE CASCADE ON DELETE RESTRICT;
ALTER TABLE ONLY public.piezas_reparacion_productos
    ADD CONSTRAINT piezas_reparacion_productos_reparacion_id_fkey FOREIGN KEY (reparacion_id) REFERENCES public.reparaciones(id) ON UPDATE CASCADE ON DELETE RESTRICT;
ALTER TABLE ONLY public.piezas_reparacion
    ADD CONSTRAINT piezas_reparacion_reparacion_id_fkey FOREIGN KEY (reparacion_id) REFERENCES public.reparaciones(id) ON UPDATE CASCADE ON DELETE RESTRICT;
ALTER TABLE ONLY public.precios_venta
    ADD CONSTRAINT precios_venta_producto_id_fkey FOREIGN KEY (producto_id) REFERENCES public.productos(id) ON UPDATE CASCADE ON DELETE SET NULL;
ALTER TABLE ONLY public.precios_venta
    ADD CONSTRAINT precios_venta_servicio_id_fkey FOREIGN KEY (servicio_id) REFERENCES public.tipos_servicio(id) ON UPDATE CASCADE ON DELETE SET NULL;
ALTER TABLE ONLY public.presupuestos_independientes
    ADD CONSTRAINT presupuestos_independientes_usuario_id_fkey FOREIGN KEY (usuario_id) REFERENCES public.usuarios(id) ON UPDATE CASCADE ON DELETE RESTRICT;
ALTER TABLE ONLY public.presupuestos
    ADD CONSTRAINT presupuestos_ticket_id_fkey FOREIGN KEY (ticket_id) REFERENCES public.tickets(id) ON UPDATE CASCADE ON DELETE RESTRICT;
ALTER TABLE ONLY public.productos
    ADD CONSTRAINT productos_categoria_id_fkey FOREIGN KEY (categoria_id) REFERENCES public.categorias(id) ON UPDATE CASCADE ON DELETE SET NULL;
ALTER TABLE ONLY public.productos
    ADD CONSTRAINT productos_marca_id_fkey FOREIGN KEY (marca_id) REFERENCES public.marcas(id) ON UPDATE CASCADE ON DELETE SET NULL;
ALTER TABLE ONLY public.productos
    ADD CONSTRAINT productos_modelo_id_fkey FOREIGN KEY (modelo_id) REFERENCES public.modelos(id) ON UPDATE CASCADE ON DELETE SET NULL;
ALTER TABLE ONLY public.productos_presupuesto_independiente
    ADD CONSTRAINT productos_presupuesto_independiente_presupuesto_independie_fkey FOREIGN KEY (presupuesto_independiente_id) REFERENCES public.presupuestos_independientes(id) ON UPDATE CASCADE ON DELETE CASCADE;
ALTER TABLE ONLY public.productos_presupuesto_independiente
    ADD CONSTRAINT productos_presupuesto_independiente_producto_id_fkey FOREIGN KEY (producto_id) REFERENCES public.productos(id) ON UPDATE CASCADE ON DELETE SET NULL;
ALTER TABLE ONLY public.productos
    ADD CONSTRAINT productos_proveedor_id_fkey FOREIGN KEY (proveedor_id) REFERENCES public.proveedores(id) ON UPDATE CASCADE ON DELETE SET NULL;
ALTER TABLE ONLY public.productos_reparacion_frecuente
    ADD CONSTRAINT productos_reparacion_frecuente_producto_id_fkey FOREIGN KEY (producto_id) REFERENCES public.productos(id) ON UPDATE CASCADE ON DELETE RESTRICT;
ALTER TABLE ONLY public.productos_reparacion_frecuente
    ADD CONSTRAINT productos_reparacion_frecuente_reparacion_frecuente_id_fkey FOREIGN KEY (reparacion_frecuente_id) REFERENCES public.reparaciones_frecuentes(id) ON UPDATE CASCADE ON DELETE RESTRICT;
ALTER TABLE ONLY public.productos
    ADD CONSTRAINT productos_tipo_servicio_id_fkey FOREIGN KEY (tipo_servicio_id) REFERENCES public.tipos_servicio(id) ON UPDATE CASCADE ON DELETE SET NULL;
ALTER TABLE ONLY public.puntos_recoleccion
    ADD CONSTRAINT puntos_recoleccion_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.puntos_recoleccion(id) ON UPDATE CASCADE ON DELETE SET NULL;
ALTER TABLE ONLY public.reparaciones
    ADD CONSTRAINT reparaciones_ticket_id_fkey FOREIGN KEY (ticket_id) REFERENCES public.tickets(id) ON UPDATE CASCADE ON DELETE RESTRICT;
ALTER TABLE ONLY public.roles_permisos
    ADD CONSTRAINT roles_permisos_permiso_id_fkey FOREIGN KEY (permiso_id) REFERENCES public.permisos(id) ON UPDATE CASCADE ON DELETE RESTRICT;
ALTER TABLE ONLY public.roles_permisos
    ADD CONSTRAINT roles_permisos_rol_id_fkey FOREIGN KEY (rol_id) REFERENCES public.roles(id) ON UPDATE CASCADE ON DELETE RESTRICT;
ALTER TABLE ONLY public.salidas_almacen
    ADD CONSTRAINT salidas_almacen_producto_id_fkey FOREIGN KEY (producto_id) REFERENCES public.productos(id) ON UPDATE CASCADE ON DELETE RESTRICT;
ALTER TABLE ONLY public.salidas_almacen
    ADD CONSTRAINT salidas_almacen_usuario_id_fkey FOREIGN KEY (usuario_id) REFERENCES public.usuarios(id) ON UPDATE CASCADE ON DELETE RESTRICT;
ALTER TABLE ONLY public.ticket_problemas
    ADD CONSTRAINT ticket_problemas_problema_id_fkey FOREIGN KEY (problema_id) REFERENCES public.problemas_frecuentes(id) ON UPDATE CASCADE ON DELETE RESTRICT;
ALTER TABLE ONLY public.ticket_problemas
    ADD CONSTRAINT ticket_problemas_ticket_id_fkey FOREIGN KEY (ticket_id) REFERENCES public.tickets(id) ON UPDATE CASCADE ON DELETE RESTRICT;
ALTER TABLE ONLY public.tickets
    ADD CONSTRAINT tickets_cliente_id_fkey FOREIGN KEY (cliente_id) REFERENCES public.clientes(id) ON UPDATE CASCADE ON DELETE RESTRICT;
ALTER TABLE ONLY public.tickets
    ADD CONSTRAINT tickets_creador_id_fkey FOREIGN KEY (creador_id) REFERENCES public.usuarios(id) ON UPDATE CASCADE ON DELETE RESTRICT;
ALTER TABLE ONLY public.tickets
    ADD CONSTRAINT tickets_direccion_id_fkey FOREIGN KEY (direccion_id) REFERENCES public.direcciones(id) ON UPDATE CASCADE ON DELETE SET NULL;
ALTER TABLE ONLY public.tickets
    ADD CONSTRAINT tickets_estatus_reparacion_id_fkey FOREIGN KEY (estatus_reparacion_id) REFERENCES public.estatus_reparacion(id) ON UPDATE CASCADE ON DELETE RESTRICT;
ALTER TABLE ONLY public.tickets
    ADD CONSTRAINT tickets_modelo_id_fkey FOREIGN KEY (modelo_id) REFERENCES public.modelos(id) ON UPDATE CASCADE ON DELETE RESTRICT;
ALTER TABLE ONLY public.tickets
    ADD CONSTRAINT tickets_punto_recoleccion_id_fkey FOREIGN KEY (punto_recoleccion_id) REFERENCES public.puntos_recoleccion(id) ON UPDATE CASCADE ON DELETE SET NULL;
ALTER TABLE ONLY public.tickets
    ADD CONSTRAINT tickets_tecnico_asignado_id_fkey FOREIGN KEY (tecnico_asignado_id) REFERENCES public.usuarios(id) ON UPDATE CASCADE ON DELETE SET NULL;
ALTER TABLE ONLY public.tickets
    ADD CONSTRAINT tickets_tipo_servicio_id_fkey FOREIGN KEY (tipo_servicio_id) REFERENCES public.tipos_servicio(id) ON UPDATE CASCADE ON DELETE RESTRICT;
ALTER TABLE ONLY public.usos_cupon
    ADD CONSTRAINT usos_cupon_cupon_id_fkey FOREIGN KEY (cupon_id) REFERENCES public.cupones(id) ON UPDATE CASCADE ON DELETE RESTRICT;
ALTER TABLE ONLY public.usos_cupon
    ADD CONSTRAINT usos_cupon_ticket_id_fkey FOREIGN KEY (ticket_id) REFERENCES public.tickets(id) ON UPDATE CASCADE ON DELETE SET NULL;
ALTER TABLE ONLY public.usos_cupon
    ADD CONSTRAINT usos_cupon_usuario_id_fkey FOREIGN KEY (usuario_id) REFERENCES public.usuarios(id) ON UPDATE CASCADE ON DELETE RESTRICT;
ALTER TABLE ONLY public.usos_cupon
    ADD CONSTRAINT usos_cupon_venta_id_fkey FOREIGN KEY (venta_id) REFERENCES public.ventas(id) ON UPDATE CASCADE ON DELETE SET NULL;
ALTER TABLE ONLY public.usuarios_puntos_recoleccion
    ADD CONSTRAINT usuarios_puntos_recoleccion_punto_recoleccion_id_fkey FOREIGN KEY (punto_recoleccion_id) REFERENCES public.puntos_recoleccion(id) ON UPDATE CASCADE ON DELETE RESTRICT;
ALTER TABLE ONLY public.usuarios_puntos_recoleccion
    ADD CONSTRAINT usuarios_puntos_recoleccion_usuario_id_fkey FOREIGN KEY (usuario_id) REFERENCES public.usuarios(id) ON UPDATE CASCADE ON DELETE RESTRICT;
ALTER TABLE ONLY public.usuarios_roles
    ADD CONSTRAINT usuarios_roles_rol_id_fkey FOREIGN KEY (rol_id) REFERENCES public.roles(id) ON UPDATE CASCADE ON DELETE RESTRICT;
ALTER TABLE ONLY public.usuarios_roles
    ADD CONSTRAINT usuarios_roles_usuario_id_fkey FOREIGN KEY (usuario_id) REFERENCES public.usuarios(id) ON UPDATE CASCADE ON DELETE RESTRICT;
ALTER TABLE ONLY public.ventas
    ADD CONSTRAINT ventas_cliente_id_fkey FOREIGN KEY (cliente_id) REFERENCES public.clientes(id) ON UPDATE CASCADE ON DELETE RESTRICT;
ALTER TABLE ONLY public.ventas
    ADD CONSTRAINT ventas_usuario_id_fkey FOREIGN KEY (usuario_id) REFERENCES public.usuarios(id) ON UPDATE CASCADE ON DELETE RESTRICT;
