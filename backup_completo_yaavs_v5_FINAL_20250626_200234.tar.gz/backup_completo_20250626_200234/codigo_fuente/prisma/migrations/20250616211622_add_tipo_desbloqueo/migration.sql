-- AlterTable
ALTER TABLE "tickets" ADD COLUMN     "tipo_desbloqueo" TEXT;
