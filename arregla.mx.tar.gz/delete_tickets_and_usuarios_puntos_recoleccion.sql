DELETE FROM "tickets";
DELETE FROM "usuarios_puntos_recoleccion"; 