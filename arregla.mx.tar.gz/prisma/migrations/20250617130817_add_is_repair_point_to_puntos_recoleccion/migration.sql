-- AlterTable
ALTER TABLE "puntos_recoleccion" ADD COLUMN "is_repair_point" BOOLEAN NOT NULL DEFAULT false;
