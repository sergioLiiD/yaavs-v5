-- AlterTable
ALTER TABLE "puntos_recoleccion" ALTER COLUMN "updated_at" SET DEFAULT NOW(); 