UPDATE usuarios 
SET "passwordHash" = '$2b$10$LEQIkAkZSzVTeAdZb.sjAuLlcCWatonqvJKTGCS/q7XY.KVma7x46'
WHERE email = 'sergio@hoom.mx'; 